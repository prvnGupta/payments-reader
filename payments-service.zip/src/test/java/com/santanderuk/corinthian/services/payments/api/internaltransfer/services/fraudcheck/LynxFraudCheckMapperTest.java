package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataRequest;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils.PaymentReferenceGenerator;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class LynxFraudCheckMapperTest {

    private LynxFraudCheckMapper lynxFraudCheckMapper;
    private InternalTransferRequest request;
    private InternalTransferAccountsDetails accountsDetails;

    @SpyBean
    private InternalAccountFormatConverter internalAccountFormatConverter;

    @SpyBean
    private PaymentReferenceGenerator paymentReferenceGenerator;

    @Mock
    private OverpaymentsConfig overpaymentsConfig;

    @BeforeEach
    void setUp() {
        Clock fixedClock = Clock.fixed(Instant.parse("2020-04-12T17:45:34Z"), ZoneOffset.UTC);
        when(overpaymentsConfig.getLynxFraudDebitType()).thenReturn("Debit");
        when(overpaymentsConfig.getLynxFraudCreditType()).thenReturn("Credit");
        when(overpaymentsConfig.getLynxFraudCurrency()).thenReturn("lynx-currency");
        when(overpaymentsConfig.getLynxFraudChannelType()).thenReturn("COR");
        when(overpaymentsConfig.getLynxFraudProcessFlag()).thenReturn("Process");
        when(overpaymentsConfig.getLynxFraudFlagCreditDebit()).thenReturn("FCD");
        when(overpaymentsConfig.getLynxFraudMessageType()).thenReturn("LFM");
        lynxFraudCheckMapper = new LynxFraudCheckMapper(internalAccountFormatConverter, overpaymentsConfig, paymentReferenceGenerator, fixedClock);
        request = TestDataCreator.generateDefaultInternalTransferControllerRequest();
        accountsDetails = TestDataCreator.generateDefaultInternalTransferAccountsDetails();
    }

    @Test
    void testMappingForOverpayment() throws FraudException, IOException {

        when(overpaymentsConfig.getLynxFraudApplicationCodeOverpayment()).thenReturn("103");
        LynxDataRequest requestData = lynxFraudCheckMapper.decorateRequestData(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), createSetupResponse());

        assertEquals("0015", requestData.getDebitEmpresa());
        assertEquals("4247", requestData.getDebitCentre());
        assertEquals("300", requestData.getDebitProduct());
        assertEquals("1234567", requestData.getDebitContractNo());
        assertEquals("Debit", requestData.getDebitType());
        assertEquals("09012712345678", requestData.getDebitDetalle());

        assertEquals("Forename1 Surname", requestData.getBeneficiaryName());
        assertEquals("company", requestData.getCreditEmpresa());
        assertEquals("centre", requestData.getCreditCentre());
        assertEquals("product", requestData.getCreditProduct());
        assertEquals("contract", requestData.getCreditContractNo());
        assertEquals("Credit", requestData.getCreditType());
        assertEquals("ldapUid", requestData.getStaffUserID());
        assertEquals("lynx-currency", requestData.getCurrency());
        assertEquals(5000.0, requestData.getOverpaymentAmount());
        assertEquals("12-04-2020 17:45:34.000000", requestData.getTransTimestamp());
        assertEquals("554", requestData.getCustomerNumber());
        assertEquals("F", requestData.getCustomerType());
        assertEquals("reference", requestData.getMandateNumber());

        assertEquals("COR", requestData.getChannelType());
        assertEquals("Process", requestData.getProcessFlag());
        assertEquals("FCD", requestData.getFlagCreditDebit());
        assertEquals("103", requestData.getTransCode());
        assertEquals("LFM", requestData.getTransType());
        assertEquals("SAVINGX1412345WAR", requestData.getCreditDetail());
        assertEquals("123456789SURNAME  ", requestData.getReference());
    }

    @Test
    void testMappingForOverpaymentLongSurname() throws FraudException, IOException {

        when(overpaymentsConfig.getLynxFraudApplicationCodeOverpayment()).thenReturn("103");
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        context.getLoggedCustomer().setOSurname("LongSurname");
        LynxDataRequest requestData = lynxFraudCheckMapper.decorateRequestData(context, createSetupResponse());
        assertEquals("Forename1 LongSurname", requestData.getBeneficiaryName());
        assertEquals("123456789LONGSURNA", requestData.getReference());
        assertEquals("103", requestData.getTransCode());
    }

    @Test
    void testMappingForInternalTransferFeePayment() throws FraudException {

        when(overpaymentsConfig.getLynxFraudApplicationCodeFee()).thenReturn("129");
        LynxDataRequest requestData = lynxFraudCheckMapper.decorateRequestData(request, accountsDetails, createSetupResponse(), "ldap-uid");

        assertEquals("0015", requestData.getDebitEmpresa());
        assertEquals("4247", requestData.getDebitCentre());
        assertEquals("300", requestData.getDebitProduct());
        assertEquals("1234567", requestData.getDebitContractNo());
        assertEquals("Debit", requestData.getDebitType());
        assertEquals("09012712345678", requestData.getDebitDetalle());

        assertEquals("Sponge Bob", requestData.getBeneficiaryName());
        assertEquals("company", requestData.getCreditEmpresa());
        assertEquals("centre", requestData.getCreditCentre());
        assertEquals("product", requestData.getCreditProduct());
        assertEquals("contract", requestData.getCreditContractNo());
        assertEquals("Credit", requestData.getCreditType());
        assertEquals("ldap-uid", requestData.getStaffUserID());
        assertEquals("lynx-currency", requestData.getCurrency());
        assertEquals(123.45, requestData.getOverpaymentAmount());
        assertEquals("12-04-2020 17:45:34.000000", requestData.getTransTimestamp());
        assertEquals("1", requestData.getCustomerNumber());
        assertEquals("F", requestData.getCustomerType());
        assertEquals("reference", requestData.getMandateNumber());

        assertEquals("COR", requestData.getChannelType());
        assertEquals("Process", requestData.getProcessFlag());
        assertEquals("FCD", requestData.getFlagCreditDebit());
        assertEquals("129", requestData.getTransCode());
        assertEquals("LFM", requestData.getTransType());
        assertEquals("SAVINGX1412345WAR", requestData.getCreditDetail());
        assertEquals("paymentReference", requestData.getReference());
    }

    private SetupResponse createSetupResponse() {
        SetupResponse setupResponse = new SetupResponse();
        setupResponse.setNumsOr("reference");
        return setupResponse;
    }
}
