package com.santanderuk.corinthian.services.payments.api.regularoverpayment.service;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.ANMFPaymentArrangementResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.OPayArrOvpInst;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.PaymentServiceConfig;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class PaymentArrangementEnquiryHelperTest {

    private PaymentArrangementEnquiryHelper paymentArrangementEnquiryHelper;

    @Mock
    private AnmfCoreClient anmfCoreClient;
    @Mock
    private EndpointConfiguration endpointConfiguration;
    @Mock
    private PaymentServiceConfig paymentServiceConfig;

    @BeforeEach
    void setUp() {
        paymentArrangementEnquiryHelper = new PaymentArrangementEnquiryHelper(anmfCoreClient, endpointConfiguration, paymentServiceConfig);
    }

    @Test
    void testExtractInstructionToBeAmendedOrDeletedHappyPath() throws GeneralException, IOException {
        ANMFPaymentArrangementResponse anmfPaymentArrangementResponse = TestDataCreator.generatePaymentArrangementEnquiryResponse("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json");

        Mockito.when(endpointConfiguration.getAnmfFetchRegularOverpaymentUrl()).thenReturn("serviceUrl");
        Mockito.when(paymentServiceConfig.getPaymentArrangementsType()).thenReturn("OP");
        Mockito.when(anmfCoreClient.fetchMortgageArrangements(123456789, "serviceUrl", "OP", AnmfRegion.A)).thenReturn(anmfPaymentArrangementResponse);
        OPayArrOvpInst instruction = paymentArrangementEnquiryHelper.extractInstructionToBeAmendedOrCancelled(123456789, AnmfRegion.A);

        Assertions.assertEquals(485.65, instruction.getOPayArrMonPay());
        Assertions.assertEquals("M", instruction.getOPayArrImpact());
        Assertions.assertEquals("23/10/2018", instruction.getOPayArrEndDate());
        Assertions.assertEquals("N", instruction.getOPayArrNoEndDate());
        Assertions.assertEquals("24/08/2018", instruction.getOPayArrStartDate());
    }

    @Test
    void testExtractInstructionToBeAmendedOrDeletedHappyPathOneNoDDInstruction() throws GeneralException, IOException {
        ANMFPaymentArrangementResponse anmfPaymentArrangementResponse = TestDataCreator.generatePaymentArrangementEnquiryResponse("payment-arrangement-enquiry/payment-arrangement-enquiry-two-instruction-one-DD-one-no-DD.json");

        Mockito.when(endpointConfiguration.getAnmfFetchRegularOverpaymentUrl()).thenReturn("serviceUrl");
        Mockito.when(paymentServiceConfig.getPaymentArrangementsType()).thenReturn("OP");
        Mockito.when(anmfCoreClient.fetchMortgageArrangements(123456789, "serviceUrl", "OP", AnmfRegion.A)).thenReturn(anmfPaymentArrangementResponse);
        OPayArrOvpInst instruction = paymentArrangementEnquiryHelper.extractInstructionToBeAmendedOrCancelled(123456789, AnmfRegion.A);

        Assertions.assertEquals(485.65, instruction.getOPayArrMonPay());
        Assertions.assertEquals("M", instruction.getOPayArrImpact());
        Assertions.assertEquals("23/10/2018", instruction.getOPayArrEndDate());
        Assertions.assertEquals("N", instruction.getOPayArrNoEndDate());
        Assertions.assertEquals("24/08/2018", instruction.getOPayArrStartDate());
    }

    @Test
    void testExtractInstructionToBeAmendedOrDeletedTwoInstructions() throws GeneralException, IOException {
        ANMFPaymentArrangementResponse anmfPaymentArrangementResponse = TestDataCreator.generatePaymentArrangementEnquiryResponse("payment-arrangement-enquiry/payment-arrangement-enquiry-two-existing-instruction.json");

        Mockito.when(endpointConfiguration.getAnmfFetchRegularOverpaymentUrl()).thenReturn("serviceUrl");
        Mockito.when(paymentServiceConfig.getPaymentArrangementsType()).thenReturn("OP");
        Mockito.when(anmfCoreClient.fetchMortgageArrangements(123456789, "serviceUrl", "OP", AnmfRegion.A)).thenReturn(anmfPaymentArrangementResponse);

        GeneralException exception = assertThrows(GeneralException.class, () -> paymentArrangementEnquiryHelper.extractInstructionToBeAmendedOrCancelled(123456789, AnmfRegion.A));
        assertEquals("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup", exception.getMessage());
        assertEquals("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT", exception.getCode());

    }

    @Test
    void testExtractInstructionToBeAmendedOrDeletedNoDD() throws GeneralException, IOException {
        ANMFPaymentArrangementResponse anmfPaymentArrangementResponse = TestDataCreator.generatePaymentArrangementEnquiryResponse("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction-no-DD.json");

        Mockito.when(endpointConfiguration.getAnmfFetchRegularOverpaymentUrl()).thenReturn("serviceUrl");
        Mockito.when(paymentServiceConfig.getPaymentArrangementsType()).thenReturn("OP");
        Mockito.when(anmfCoreClient.fetchMortgageArrangements(123456789, "serviceUrl", "OP", AnmfRegion.A)).thenReturn(anmfPaymentArrangementResponse);

        GeneralException exception = assertThrows(GeneralException.class, () -> paymentArrangementEnquiryHelper.extractInstructionToBeAmendedOrCancelled(123456789, AnmfRegion.A));
        assertEquals("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup", exception.getMessage());
        assertEquals("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT", exception.getCode());

    }

    @Test
    void testExtractInstructionToBeAmendedOrDeletedNoInstruction() throws GeneralException, IOException {
        ANMFPaymentArrangementResponse anmfPaymentArrangementResponse = TestDataCreator.generatePaymentArrangementEnquiryResponse("payment-arrangement-enquiry/payment-arrangement-enquiry-no-existing-instruction.json");

        Mockito.when(endpointConfiguration.getAnmfFetchRegularOverpaymentUrl()).thenReturn("serviceUrl");
        Mockito.when(paymentServiceConfig.getPaymentArrangementsType()).thenReturn("OP");
        Mockito.when(anmfCoreClient.fetchMortgageArrangements(123456789, "serviceUrl", "OP", AnmfRegion.A)).thenReturn(anmfPaymentArrangementResponse);

        GeneralException exception = assertThrows(GeneralException.class, () -> paymentArrangementEnquiryHelper.extractInstructionToBeAmendedOrCancelled(123456789, AnmfRegion.A));
        assertEquals("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup", exception.getMessage());
        assertEquals("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT", exception.getCode());

    }
}
