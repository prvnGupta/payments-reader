package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt;

import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.io.lynxNRT.LynxNRTDataRequest;
import com.santanderuk.corinthian.hub.lynxnrtconnection.io.lynxNRT.LynxNRTDataResponse;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class LynxNrtClientTest {

    private LynxNrtClient lynxNrtClient;

    @Mock
    private OverpaymentsConfig mockConfig;

    @Mock
    private RestTemplate mockRestTemplate;

    @BeforeEach
    void setUp() {
        lynxNrtClient = new LynxNrtClient(mockRestTemplate, mockConfig);
        when(mockConfig.getClientId()).thenReturn("client-id");
        when(mockConfig.getLynxNRTEndpoint()).thenReturn("url");
    }

    @Test
    void shouldThrowLynxNRTException() {

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(LynxNRTDataResponse.class)))
                .thenThrow(RestClientException.class);

        assertThrows(LynxNRTException.class, () -> {
            lynxNrtClient.callLynxNRTClient(new LynxNRTDataRequest());
        });
    }
}
