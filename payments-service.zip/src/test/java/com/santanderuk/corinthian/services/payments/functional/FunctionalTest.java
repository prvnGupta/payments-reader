package com.santanderuk.corinthian.services.payments.functional;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.path.json.config.JsonPathConfig;
import com.santanderuk.corinthian.services.payments.PaymentsServiceApplication;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.context.ApplicationContextInitializer;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.support.TestPropertySourceUtils;
import org.springframework.util.SocketUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.jayway.restassured.config.JsonConfig.jsonConfig;
import static com.jayway.restassured.config.RestAssuredConfig.newConfig;

@ContextConfiguration(initializers = FunctionalTest.RandomPortInitializer.class)
@ExtendWith(MockitoExtension.class)
@SpringBootTest(classes = PaymentsServiceApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Slf4j
public abstract class FunctionalTest {

    protected String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    @LocalServerPort
    protected String serverPort;


    @Value("${wiremock.port}")
    protected int anmfWiremockPort;

    private WireMockServer wiremock;


    @BeforeEach
    public void setUp() {

        RestAssured.config =
                newConfig().jsonConfig(jsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.BIG_DECIMAL));

        wiremock = new WireMockServer(anmfWiremockPort);
        wiremock.start();

    }

    @AfterEach
    void tearDown() {

        wiremock.stop();
    }

    protected void stubHeartbeatRegionA() {

        wiremock.stubFor(get(urlPathEqualTo("/heartbeat/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("heartbeat/heartbeat-response-a.json"))));
    }

    protected void stubHeartbeatRegionW() {

        wiremock.stubFor(get(urlPathEqualTo("/heartbeat/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("heartbeat/heartbeat-response-w.json"))));
    }

    protected void stubHeartbeatRegionX() {

        wiremock.stubFor(get(urlPathEqualTo("/heartbeat/get-region"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("heartbeat/heartbeat-response-x.json"))));
    }

    protected void stubGetCustomerInfoARegion() {

        wiremock.stubFor(get(urlPathEqualTo("/sanuk/internal/mortgage-customer-details/accounts/12345678/customers"))
                .withHeader("Region", matching("A"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-borrower/mortgage-customer-details-default-response.json"))));
    }

    protected void stubGetCustomerInfoExc() {

        wiremock.stubFor(get(urlPathEqualTo("/sanuk/internal/mortgage-customer-details/accounts/12345678/customers"))
                .withHeader("Region", matching("A"))
                .willReturn(aResponse().withStatus(500)));
    }

    protected void stubGetCustomerInfoARegion(int account) {

        wiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/mortgage-customer-details/accounts/%d/customers", account)))
                .withHeader("Region", matching("A"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-borrower/mortgage-customer-details-2-borrowers-response.json"))));
    }

    protected void stubGetCustomerInfoWRegion(int account) {

        wiremock.stubFor(get(urlPathEqualTo(String.format("/sanuk/internal/mortgage-customer-details/accounts/%d/customers", account)))
                .withHeader("Region", matching("W"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-borrower/mortgage-customer-details-2-borrowers-response.json"))));
    }

    protected void stubGetCustomerInfoWRegion() {

        wiremock.stubFor(get(urlPathEqualTo("/sanuk/internal/mortgage-customer-details/accounts/12345678/customers"))
                .withHeader("Region", matching("W"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-borrower/mortgage-customer-details-default-response.json"))));
    }

    protected void stubGetCustomerListWithEmptyName() {

        wiremock.stubFor(get(urlPathEqualTo("/sanuk/internal/mortgage-customer-details/accounts/12345678/customers"))
                .withHeader("Region", matching("A|W"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-borrower/mortgage-customer-details-response-name-is-empty.json"))));
    }

    protected void stubSetUpRegularARegion() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payment-arrangements/overpayment"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-core-setup-regular-response.json"))));
    }

    protected void stubPaymentsArrangementEnquiry(String testFixture, int accountNumber) {
        wiremock.stubFor(get(String.format("/sanuk/internal/mortgage-payment-arrangements/accounts/%d/arrangements?arrangement-transaction=OP", accountNumber))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubPaymentsArrangementEnquiryDown(int accountNumber) {
        wiremock.stubFor(get(String.format("/sanuk/internal/mortgage-payment-arrangements/accounts/%d/arrangements?arrangement-transaction=OP", accountNumber))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(503)));
    }

    protected void stubAnmfSetupRegular(String testFixture) {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payment-arrangements/overpayment"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubAnmfEditRegularOverpayment() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payment-arrangements/overpayment"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-cud-regular/anmf-cud-response.json"))));
    }

    protected void stubAnmfCancelRegularOverpayment() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payment-arrangements/overpayment"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-cud-regular/anmf-cud-response.json"))));
    }

    protected void stubAnmfCancelRegularOverpaymentAnmfDown() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payment-arrangements/overpayment"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(503)));
    }

    protected void stubAnmfEditRegularOverpaymentAnmfDown() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payment-arrangements/overpayment"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(503)));
    }

    protected void stubSetUpRegularBadResponse() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/mortgage-payment-arrangements/overpayment"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(400)));
    }

    protected void stubAnmfAccountDetails(String fixture) {

        wiremock.stubFor(get(urlMatching("/sanuk/internal/mortgage-account-details/accounts/.*"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(fixture))));
    }

    protected void stubCardTransactionChallengeResponse() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/card-transactions/"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.ACCEPTED.value())
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("opayo/card-transaction/response/challenge.json"))));
    }

    protected void stubConfirmTransactionOkResponse() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.CREATED.value())
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("opayo/confirm/response/authorised.json"))));
    }

    protected void stubConfirmTransactionDeclinedResponse() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.CREATED.value())
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("opayo/confirm/response/declined.json"))));
    }

    protected void stubConfirmErrorResponse() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())));
    }

    protected void stubCardTransactionException() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/card-transactions/"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())));
    }

    protected void stubCardTransactionRejectedResponse() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/card-transactions/"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.ACCEPTED.value())
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("opayo/card-transaction/response/rejected.json"))));
    }

    protected void stubCardTransactionFrictionlessOkResponse() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/card-transactions/"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.ACCEPTED.value())
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("opayo/card-transaction/response/frictionless-ok.json"))));
    }


    protected void stubUpdateCPSOkResponse() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1/cps/"))
                .willReturn(aResponse()
                        .withStatus(HttpStatus.OK.value())));
    }

    protected void stubAnmfAccountDetailsExc() {

        wiremock.stubFor(get(urlMatching("/sanuk/internal/mortgage-account-details/accounts/.*"))
                .willReturn(aResponse().withStatus(500)));
    }

    protected void stubSimulationReduceMonthlyPayment() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"\"}"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-simulation/reduceMonthlyPayment.json"))));
    }

    protected void stubSimulationError() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"\"}"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-simulation/default-ko-response.json"))));
    }


    protected void stubSimulationExc() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"\"}"))
                .willReturn(aResponse().withStatus(500)));
    }

    protected void stubSimulationReduceTerm() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"\"}"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-simulation/reduceTerm.json"))));
    }

    protected void stubSimulationReduceBalance() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"\"}"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-simulation/reduceBalance.json"))));
    }

    protected void stubSimulationUpdatePaymentMethodOK() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"TT\"}"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-simulation/update-payment-method.json"))));
    }

    protected void stubSimulationUpdatePaymentMethodOKCard() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"DC\"}"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-simulation/update-payment-method.json"))));
    }

    protected void stubSimulationUpdatePaymentMethodKO() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"TT\"}"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-simulation/update-payment-method-ko.json"))));
    }

    protected void stubSimulationUpdatePaymentMethodExc() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/overpayment/simulation"))
                .withRequestBody(containing("{\"i_sim_pay_meth\":\"TT\"}"))
                .willReturn(aResponse().withStatus(500)));
    }

    protected void stubSimulationApply() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/payments"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-payment/default-ok-response.json"))));
    }

    protected void stubSimulationApplyKo() {

        wiremock.stubFor(post(urlMatching("/sanuk/internal/mortgage-payments/payments"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("anmf-payment/default-ko-response.json"))));
    }


    protected void stubLacOk() {
        wiremock.stubFor(any(urlPathMatching("/sanuk/internal/contracts/.*/identifiers"))
                .withQueryParam("contract_input_type", equalTo("LOUK"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("lac/success-response.json"))));

    }

    protected void stubLacExc() {
        wiremock.stubFor(any(urlPathMatching("/sanuk/internal/contracts/.*/identifiers"))
                .withQueryParam("contract_input_type", equalTo("LOUK"))
                .willReturn(aResponse().withStatus(500)));

    }


    protected void stubLacOkForAccount(String account) {
        String path = "/sanuk/internal/contracts/REPLACE/identifiers".replaceAll("REPLACE", account);
        wiremock.stubFor(any(urlPathEqualTo(path))
                .withQueryParam("contract_input_type", equalTo("LOUK"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("lac/success-response.json"))));

    }

    protected void stubLacOkForAccount09012686890994() {
        String path = "/sanuk/internal/contracts/REPLACE/identifiers".replaceAll("REPLACE", "09012686890994");
        wiremock.stubFor(any(urlPathEqualTo(path))
                .withQueryParam("contract_input_type", equalTo("LOUK"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("lac/success-response-09012686890994.json"))));

    }

    protected void stubLacOkForAccount09008520007437034218165Surname() {
        String path = "/sanuk/internal/contracts/REPLACE/identifiers".replaceAll("REPLACE", "09008520007437034218165Surname");
        wiremock.stubFor(any(urlPathEqualTo(path))
                .withQueryParam("contract_input_type", equalTo("LOUK"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("lac/success-response-09008520007437034218165Surname.json"))));

    }

    protected void stubAnmfLoanPaymentPlan(String testFixture) {
        wiremock.stubFor(get(urlMatching("/sanuk/internal/loan-payment-plan/v1/a/account/.*/paymentenquiry"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubAnmfLoanPaymentPlanRegionW(String testFixture) {
        wiremock.stubFor(get(urlMatching("/sanuk/internal/loan-payment-plan/v1/w/account/.*/paymentenquiry"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubBksConnectClientRetrieveMcc(String testFixture) {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubBksConnectClientRetrieveMccExc() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user"))
                .willReturn(aResponse().withStatus(500)));
    }

    protected void stubContractsInMcc(String testFixture) {
        wiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/core-bks-connect/ioc-core/contract-mcc"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubContractsInMccExc() {
        wiremock.stubFor(any(urlPathEqualTo("/sanuk/internal/core-bks-connect/ioc-core/contract-mcc"))
                .willReturn(aResponse().withStatus(500)));
    }

    protected void stubAccountBalancesOK(String testFixture) {
        wiremock.stubFor(get(urlMatching("/sanuk/internal/accounts-balances/v1/balances.*"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubAccountBalancesExc() {
        wiremock.stubFor(get(urlMatching("/sanuk/internal/accounts-balances/v1/balances.*"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)));
    }

    protected void stubSetupPartenonPaymentOk(String testFixture) {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/setup"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubLynxFraudCheckOk(String testFixture) {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/lynx-fraud"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubLynxFraudCheckOkDeclinedResponse() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/lynx-fraud"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("internal-transfer/lynx-fraud/lynx-fraud-ok-declined-response.json"))));
    }

    protected void stubLynxFraudCheckConnectionException() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/lynx-fraud"))
                .willReturn(aResponse()
                        .withStatus(500)));
    }

    protected void stubMakePaymentOk(String testFixture) {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/debit"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubMakePaymentKoUnclearedFunds() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/debit"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("internal-transfer/make-payment/make-payment-ko-uncleared-funds.json"))));
    }

    protected void stubMakePaymentKoBlockedAccount() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/debit"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("internal-transfer/make-payment/make-payment-account-blocked.json"))));
    }

    protected void stubMakePaymentKoUnknownError() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/debit"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents("internal-transfer/make-payment/make-payment-ko-unknown-error.json"))));
    }

    protected void stubSetupPartenonPaymentKo(String testFixture) {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/setup"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(readFileContents(testFixture))));
    }

    protected void stubSetupPartenonPaymentExc() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/setup"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(500)));
    }

    protected void stubCardOperationalNonSantanderCard() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1.0/card/operationality-details"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(404)
                        .withBody(readFileContents("card-operational/nonSantanderCard.json"))));
    }

    protected void stubCardOperationalInvalidCheckSumCard() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1.0/card/operationality-details"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(400)
                        .withBody(readFileContents("card-operational/invalidCheckSum.json"))));
    }

    protected void stubCardOperationalSantanderCard() {
        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/v1.0/card/operationality-details"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withStatus(200)
                        .withBody(readFileContents("card-operational/santanderCard.json"))));
    }

    protected void stubLynxNRTOK() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/lynx-nrt"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withHeader("Accept", "application/json")));
    }

    protected void stubLynxNRTKO() {

        wiremock.stubFor(post(urlPathEqualTo("/sanuk/internal/core/payments/partenon-internal-transfer/lynx-nrt"))
                .willReturn(aResponse()
                        .withStatus(500)));
    }

    public static class RandomPortInitializer
            implements ApplicationContextInitializer<ConfigurableApplicationContext> {

        @Override
        public void initialize(ConfigurableApplicationContext applicationContext) {

            int randomPort = SocketUtils.findAvailableTcpPort();

            String anmfHeartBeatUrl = String.format("http://localhost:%d/heartbeat/get-region", randomPort);
            String anmfGetCustomerInfoUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-customer-details/accounts/{account}/customers", randomPort);
            String anmfCRUDRegularUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-payment-arrangements/overpayment", randomPort);
            String anmfAccountService = String.format("http://localhost:%d/sanuk/internal/mortgage-account-details/accounts/{account}", randomPort);
            String anmfLoanPaymentPlanUrl = String.format("http://localhost:%d/sanuk/internal/loan-payment-plan/v1/{region}/account/{account}/paymentenquiry", randomPort);
            String anmfSimulationUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-payments/overpayment/simulation", randomPort);
            String anmfApplyPaymentUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-payments/payments", randomPort);
            String bksConnectClientUrl = String.format("http://localhost:%d/sanuk/internal/core-bks-connect/ioc-core/retrieve-mcc-from-ldap-user", randomPort);
            String bksConnectContractsInMccUrl = String.format("http://localhost:%d/sanuk/internal/core-bks-connect/ioc-core/contract-mcc", randomPort);
            String balancesUrl = String.format("http://localhost:%d/sanuk/internal/accounts-balances/v1/balances", randomPort);
            String paymentArrangementsEnquiryUrl = String.format("http://localhost:%d/sanuk/internal/mortgage-payment-arrangements/accounts/{account}/arrangements?arrangement-transaction=OP", randomPort);
            String setupPaymentUrl = String.format("http://localhost:%d/sanuk/internal/core/payments/partenon-internal-transfer/setup", randomPort);
            String lynxFraudUrl = String.format("http://localhost:%d/sanuk/internal/core/payments/partenon-internal-transfer/lynx-fraud", randomPort);
            String lynxNRTUrl = String.format("http://localhost:%d/sanuk/internal/core/payments/partenon-internal-transfer/lynx-nrt", randomPort);
            String makePaymentUrl = String.format("http://localhost:%d/sanuk/internal/core/payments/partenon-internal-transfer/debit", randomPort);
            String lacUrl = String.format("http://localhost:%d/sanuk/internal/contracts/{localAccount}/identifiers?contract_input_type=LOUK", randomPort);
            String cardTransactionUrl = String.format("http://localhost:%d/sanuk/internal/v1/card-transactions/", randomPort);
            String updateCpsUrl = String.format("http://localhost:%d/sanuk/internal/v1/cps/", randomPort);
            String confirmCardTransactionUrl = String.format("http://localhost:%d/sanuk/internal/v1/card-transactions/{transactionId}/confirm", randomPort);
            String cardOperationalUrl = String.format("http://localhost:%d/sanuk/internal/v1.0/card/operationality-details", randomPort);


            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "wiremock.port=" + randomPort);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "heartbeat.get-region=" + anmfHeartBeatUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "anmf.services.customerservice=" + anmfGetCustomerInfoUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    "anmf.services.regular-overpayment=" + anmfCRUDRegularUrl);

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.account-details=%s", anmfAccountService));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.loan-payment-plan=%s", anmfLoanPaymentPlanUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.simulation=%s", anmfSimulationUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.apply-overpayment=%s", anmfApplyPaymentUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("anmf.services.payment-arrangements-enquiry=%s", paymentArrangementsEnquiryUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("bksconnect.endpoints.retrievemcc=%s", bksConnectClientUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("bksconnect.endpoints.contractsInMcc=%s", bksConnectContractsInMccUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("accountBalances=%s", balancesUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("internal-transfer.setup-payment.endpoint=%s", setupPaymentUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("internal-transfer.lynx-fraud.endpoint=%s", lynxFraudUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("internal-transfer.lynx-nrt.endpoint=%s", lynxNRTUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("internal-transfer.make-payment.endpoint=%s", makePaymentUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("lac.url=%s", lacUrl));

            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("opayo.endpoints.card-transaction=%s", cardTransactionUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("opayo.endpoints.cps=%s", updateCpsUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("opayo.endpoints.confirm=%s", confirmCardTransactionUrl));
            TestPropertySourceUtils.addInlinedPropertiesToEnvironment(applicationContext,
                    String.format("internal-transfer.card-operational.endpoint=%s", cardOperationalUrl));

        }
    }

    protected static String readFileContents(String filename) {
        InputStream resource;
        String fixtureContents = "";
        try {
            resource = new ClassPathResource(String.format("/fixtures/%s", filename)).getInputStream();
            fixtureContents = IOUtils.toString(resource, Charset.defaultCharset());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fixtureContents;
    }
}
