package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
@Slf4j
class OpayoUtilsTest {

    OpayoUtils opayoUtils;

    @BeforeEach
    void setUp() {
        opayoUtils = new OpayoUtils();
        ReflectionTestUtils.setField(opayoUtils, "keyPassword", "E/KV7D4LJTK5FMhI6lUo53H1/rgkrFbc5TxZB6BkypM=");
    }

    @Test
    void testGenerateCpsTransactionIdStartsWithO() {
        String transactionId = opayoUtils.generateVendorCode("1111222233334444");
        assertEquals("O", transactionId.substring(0, 1));
        transactionId = opayoUtils.generateVendorCode("111122*4444");
        assertEquals("O", transactionId.substring(0, 1));
    }

    @Test
    void testGenerateCpsTransactionIdLength() {
        for (int i = 0; i < 100000; i++) {
            String transactionId = opayoUtils.generateVendorCode("1111222233334444");
            assertEquals(30, transactionId.length());
            transactionId = opayoUtils.generateVendorCode("111122*4444");
            assertEquals(30, transactionId.length());
        }
    }

    @Test
    void testGenerateCpsTransactionIdLast10Digits() {
        String transactionId = opayoUtils.generateVendorCode("1111222233334444");
        assertEquals("1111224444", transactionId.substring(20, 30));
        transactionId = opayoUtils.generateVendorCode("111122*4444");
        assertEquals("1111224444", transactionId.substring(20, 30));
    }

    @Test
    void testMaksCardNumber() {
        assertEquals("111122*4444", opayoUtils.maskCardNumber("1111222233334444"));
        assertEquals("111122*4444", opayoUtils.maskCardNumber("111122*4444"));
    }

    @Test
    void testGCMEncryptionAndDecryption1() throws GeneralException {
        String cipheredText = opayoUtils.encryptGivenText("1234 5678 9123 8456");
        String plainText = opayoUtils.decryptGivenText(cipheredText);
        assertEquals("1234 5678 9123 8456", plainText);
    }

    @Test
    void testGCMEncryptionAndDecryption2() throws GeneralException {
        String cipheredText = opayoUtils.encryptGivenText("1234 5678 9123 4567");
        String plainText = opayoUtils.decryptGivenText(cipheredText);
        assertEquals("1234 5678 9123 4567", plainText);
    }
}
