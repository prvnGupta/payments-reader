package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt;

import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(SpringExtension.class)
class LynxNRTServiceTest {

    private LynxNRTService lynxNRTService;

    @Mock
    private LynxNRTDataMapper mockLynxNRTDataMapper;

    @Mock
    private LynxNrtClient mockLynxNRTClient;

    @BeforeEach
    void setUp() {
        lynxNRTService = new LynxNRTService(mockLynxNRTDataMapper, mockLynxNRTClient);
    }

    @Test
    void shouldCallLynxNRTDataMapper() throws LynxNRTException {

        InternalTransferRequest inputRequest = TestDataCreator.generateDefaultInternalTransferControllerRequest();
        InternalTransferAccountsDetails accountsDetails = TestDataCreator.generateDefaultInternalTransferAccountsDetails();
        lynxNRTService.mapAndCallLynxNRT(inputRequest, accountsDetails, "OK", "ldapUid", "127.0.0.1");
        verify(mockLynxNRTDataMapper, times(1)).decorateLynxNRTRequestData(inputRequest, accountsDetails, "OK", "ldapUid", "127.0.0.1");
        verify(mockLynxNRTClient, times(1)).callLynxNRTClient(any());
    }

    @Test
    void shouldCallLynxNRTDataMapperExc() throws LynxNRTException {

        InternalTransferRequest inputRequest = TestDataCreator.generateDefaultInternalTransferControllerRequest();
        InternalTransferAccountsDetails accountsDetails = TestDataCreator.generateDefaultInternalTransferAccountsDetails();
        Mockito.when(mockLynxNRTDataMapper.decorateLynxNRTRequestData(inputRequest, accountsDetails, "OK", "ldapUid", "127.0.0.1")).thenThrow(LynxNRTException.class);
        assertThrows(LynxNRTException.class, () -> lynxNRTService.mapAndCallLynxNRT(inputRequest, accountsDetails, "OK", "ldapUid", "127.0.0.1"));
    }

    @Test
    void shouldCallLynxNRTDataMapperInternalTransferSingleOverpayment() throws LynxNRTException, IOException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        lynxNRTService.mapAndCallLynxNRT(context, "OK");
        verify(mockLynxNRTDataMapper, times(1)).decorateLynxNRTRequestData(context, "OK");
        verify(mockLynxNRTClient, times(1)).callLynxNRTClient(any());
    }

    @Test
    void shouldCallLynxNRTDataMapperInternalTransferSingleOverpaymentMapperExc() throws LynxNRTException, IOException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        Mockito.when(mockLynxNRTDataMapper.decorateLynxNRTRequestData(context, "OK")).thenThrow(LynxNRTException.class);
        assertThrows(LynxNRTException.class, () -> lynxNRTService.mapAndCallLynxNRT(context, "OK"));
    }
}
