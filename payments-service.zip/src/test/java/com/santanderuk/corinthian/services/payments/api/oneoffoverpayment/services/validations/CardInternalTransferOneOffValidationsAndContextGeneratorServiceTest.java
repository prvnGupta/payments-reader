package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.CardOperationalService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalServiceResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoUtils;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
class CardInternalTransferOneOffValidationsAndContextGeneratorServiceTest {

    private final String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    @Mock
    AnmfCoreClient anmfCoreClient;
    @Mock
    EndpointConfiguration endpointConfiguration;
    @Mock
    HeartBeatClient heartBeatClient;
    @Mock
    OpayoUtils opayoUtils;
    @Mock
    OneOffCommonValidations oneOffCommonValidations;
    @Mock
    CardOperationalService cardOperationalService;

    private CardOneOffValidationsAndContextGeneratorService cardOneOffValidationsAndContextGeneratorService;

    @BeforeEach
    void setUp() {
        cardOneOffValidationsAndContextGeneratorService = new CardOneOffValidationsAndContextGeneratorService(anmfCoreClient, oneOffCommonValidations, endpointConfiguration, heartBeatClient, opayoUtils, cardOperationalService);

    }

    @Test
    void testMinimumAmountValidation() throws ValidationsException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateCardMortgageSingleOverpaymentControllerRequest();
        cardOneOffPaymentRequest.getLoanDetails().get(0).setLoanOverpaymentAmount(new BigDecimal("9.99"));
        doThrow(ValidationsException.class).when(oneOffCommonValidations).validateMinimumOverpaymentAmount(cardOneOffPaymentRequest.getLoanDetails());
        assertThrows(ValidationsException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, jwtToken, "127.0.0.1", "origin"));


    }

    @Test
    void testValidateCardHolderIsNotABorrower() throws IOException, MaintenanceException, ConnectionException, ValidationsException, OperativeSecurityException {

        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationListOnlyOneBorrower().getCustomerDetailsResponse());

        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateCardMortgageSingleOverpaymentControllerRequestSecondBorrowerIsCardHolder(), jwtToken, "127.0.0.1", "origin"));

        assertEquals("CardHolder is not a mortgage borrower", validationsException.getMessage());
        assertEquals("CARDHOLDER_KO", validationsException.getCode());
    }

    @Test
    void testAnmfDoesntBelongToCustomer() throws MaintenanceException, ConnectionException, ValidationsException, OperativeSecurityException {
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        doThrow(OperativeSecurityException.class).when(oneOffCommonValidations).validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A);

        assertThrows(OperativeSecurityException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateCardMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1", "origin"));
    }

    @Test
    void testHappyPath() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(cardOperationalService.checkIfSantanderCard(cardOneOffPaymentRequest)).thenReturn(new CardOperationalServiceResponse(true, true));

        CardMortgageSingleOverpaymentsContext context = cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, jwtToken, "127.0.0.1", "origin");

        Mockito.verify(opayoUtils, times(0)).encryptGivenText(anyString());
        assertEquals(AnmfRegion.A, context.getAnmfRegion());
        assertEquals(new BigDecimal("111.11"), context.getCardOneOffPaymentRequest().getLoanDetails().get(0).getLoanOverpaymentAmount());
        assertEquals("F554", context.getCardOneOffPaymentRequest().getCardDetails().getCustomerId());
        assertEquals("Milton Keynes", context.getCardOneOffPaymentRequest().getCardDetails().getAddress().getCity());
        assertEquals("127.0.0.1", context.getIpAddress());
        assertEquals(12345678, context.getMortgageAccount());
        assertEquals("A", context.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOAccStatus());
        assertEquals("Surname", context.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOSurname());
        assertEquals("Forename1", context.getLoggedCustomer().getOForename1());
        assertEquals("O", context.getSimulationChosenValues().getErcCollectionOption());
        assertEquals("M", context.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType());
        assertEquals(new BigDecimal("111.11"), context.getSimulationChosenValues().getPaymentAmount());
        assertEquals("pgwe51ZD", context.getLdapUid());
        assertEquals("origin", context.getOrigin());
        assertTrue(context.isSantanderCard());
        assertTrue(context.isUsingOwnSantanderCard());

        assertEquals("4462000000000003", context.getCardTransactionDetails().getCardNumber());
        assertEquals(12345678, context.getCardTransactionDetails().getMortgageAccount());
        assertEquals("01/26", context.getCardTransactionDetails().getExpiryDate());
        assertEquals("line 1 Westbury Farm Studios Group Westbury Farm Studios Studios", context.getCardTransactionDetails().getAddress().getLine1());
        assertEquals("line 2 Witan Gate Foxcovert Road", context.getCardTransactionDetails().getAddress().getLine2());
        assertEquals("Milton Keynes", context.getCardTransactionDetails().getAddress().getCity());
        assertEquals("MK92BQ", context.getCardTransactionDetails().getAddress().getPostcode());
        assertEquals("F554", context.getCardTransactionDetails().getCardHolderCustomerId());
        assertEquals("Forename1", context.getCardTransactionDetails().getCardHolderFirstName());
        assertEquals("Surname", context.getCardTransactionDetails().getCardHolderLastName());
        assertEquals("15/05/1979", context.getCardTransactionDetails().getCardHolderBirthDate());
        assertEquals(new BigDecimal("111.11"), context.getCardTransactionDetails().getOverpaymentAmount());
        assertEquals("O", context.getCardTransactionDetails().getErcCollectionOption());
        assertEquals("M", context.getCardTransactionDetails().getLoanDetails().get(0).getLoanChangeType());
        assertNull(context.getCardTransactionDetails().getVendorCode());
    }

    @Test
    void testHappyPathCustomerZeroLeftPaddedIn() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(cardOperationalService.checkIfSantanderCard(cardOneOffPaymentRequest)).thenReturn(new CardOperationalServiceResponse(false, false));

        cardOneOffPaymentRequest.getCardDetails().setCustomerId("F000000554");
        CardMortgageSingleOverpaymentsContext context = cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, jwtToken, "127.0.0.1", "origin");

        assertEquals("F554", context.getCardOneOffPaymentRequest().getCardDetails().getCustomerId());
        assertEquals("F554", context.getCardTransactionDetails().getCardHolderCustomerId());
        assertFalse(context.isSantanderCard());
        assertFalse(context.isUsingOwnSantanderCard());


    }

    @Test
    void testHappyPathConfirm() throws GeneralException, IOException {


        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());

        when(opayoUtils.decryptGivenText("encryptedCardNumber")).thenReturn("1111222233334444");
        CardTransactionDetails cardTransactionDetails = TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext().getCardTransactionDetails();
        cardTransactionDetails.setCardNumber("encryptedCardNumber");
        CardMortgageSingleOverpaymentsContext context = cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345678, TestDataCreator.generateConfirmCardPaymentRequest(), cardTransactionDetails, jwtToken, "127.0.0.1");
        verify(opayoUtils, times(1)).decryptGivenText("encryptedCardNumber");
        assertEquals(AnmfRegion.A, context.getAnmfRegion());
        assertNull(context.getCardOneOffPaymentRequest());
        assertEquals("127.0.0.1", context.getIpAddress());
        assertEquals(12345678, context.getMortgageAccount());
        assertEquals("A", context.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOAccStatus());
        assertEquals("Surname", context.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOSurname());
        assertEquals("Forename1", context.getLoggedCustomer().getOForename1());
        assertEquals("O", context.getSimulationChosenValues().getErcCollectionOption());
        assertEquals("T", context.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType());
        assertEquals(new BigDecimal("11"), context.getSimulationChosenValues().getPaymentAmount());
        assertEquals("pgwe51ZD", context.getLdapUid());


        assertEquals("1111222233334444", context.getCardTransactionDetails().getCardNumber());
        assertEquals(12345678, context.getCardTransactionDetails().getMortgageAccount());
        assertEquals("01/26", context.getCardTransactionDetails().getExpiryDate());
        assertEquals("line 1", context.getCardTransactionDetails().getAddress().getLine1());
        assertEquals("Witan Gate", context.getCardTransactionDetails().getAddress().getLine2());
        assertEquals("Milton Keynes", context.getCardTransactionDetails().getAddress().getCity());
        assertEquals("MK92BQ", context.getCardTransactionDetails().getAddress().getPostcode());
        assertEquals("F554", context.getCardTransactionDetails().getCardHolderCustomerId());
        assertEquals("Forename1", context.getCardTransactionDetails().getCardHolderFirstName());
        assertEquals("Surname", context.getCardTransactionDetails().getCardHolderLastName());
        assertEquals("15/05/1979", context.getCardTransactionDetails().getCardHolderBirthDate());
        assertEquals(new BigDecimal("11"), context.getCardTransactionDetails().getOverpaymentAmount());
        assertEquals("O", context.getCardTransactionDetails().getErcCollectionOption());
        assertEquals("T", context.getCardTransactionDetails().getLoanDetails().get(0).getLoanChangeType());
        assertNull(context.getCardTransactionDetails().getVendorCode());

    }

    @Test
    void testHappyPathSecondBorrower() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequestSecondBorrower();

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());

        when(cardOperationalService.checkIfSantanderCard(cardOneOffPaymentRequest)).thenReturn(new CardOperationalServiceResponse(true, false));

        CardMortgageSingleOverpaymentsContext context = cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, jwtToken, "127.0.0.1", "origin");
        Mockito.verify(opayoUtils, times(0)).encryptGivenText(anyString());

        assertEquals(AnmfRegion.A, context.getAnmfRegion());
        assertEquals(new BigDecimal("111.11"), context.getCardOneOffPaymentRequest().getLoanDetails().get(0).getLoanOverpaymentAmount());
        assertEquals("F555", context.getCardOneOffPaymentRequest().getCardDetails().getCustomerId());
        assertEquals("Milton Keynes", context.getCardOneOffPaymentRequest().getCardDetails().getAddress().getCity());
        assertEquals("127.0.0.1", context.getIpAddress());
        assertEquals(12345678, context.getMortgageAccount());
        assertEquals("A", context.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOAccStatus());
        assertEquals("Surname", context.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOSurname());
        assertEquals("Forename1", context.getLoggedCustomer().getOForename1());
        assertEquals("O", context.getSimulationChosenValues().getErcCollectionOption());
        assertEquals("M", context.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType());
        assertEquals(new BigDecimal("111.11"), context.getSimulationChosenValues().getPaymentAmount());
        assertEquals("pgwe51ZD", context.getLdapUid());
        assertTrue(context.isSantanderCard());
        assertFalse(context.isUsingOwnSantanderCard());

        assertEquals("4462000000000003", context.getCardTransactionDetails().getCardNumber());
        assertEquals(12345678, context.getCardTransactionDetails().getMortgageAccount());
        assertEquals("01/26", context.getCardTransactionDetails().getExpiryDate());
        assertEquals("line 1 Westbury Farm Studios Group Westbury Farm Studios Studios", context.getCardTransactionDetails().getAddress().getLine1());
        assertEquals("line 2 Witan Gate Foxcovert Road", context.getCardTransactionDetails().getAddress().getLine2());
        assertEquals("Milton Keynes", context.getCardTransactionDetails().getAddress().getCity());
        assertEquals("MK92BQ", context.getCardTransactionDetails().getAddress().getPostcode());
        assertEquals("F555", context.getCardTransactionDetails().getCardHolderCustomerId());
        assertEquals("SARAH", context.getCardTransactionDetails().getCardHolderFirstName());
        assertEquals("ANXXXXXXXX", context.getCardTransactionDetails().getCardHolderLastName());
        assertEquals("29/03/1982", context.getCardTransactionDetails().getCardHolderBirthDate());
        assertEquals(new BigDecimal("111.11"), context.getCardTransactionDetails().getOverpaymentAmount());
        assertEquals("O", context.getCardTransactionDetails().getErcCollectionOption());
        assertEquals("M", context.getCardTransactionDetails().getLoanDetails().get(0).getLoanChangeType());
        assertNull(context.getCardTransactionDetails().getVendorCode());

    }

    @Test
    void testAnmfBelongToCustomerWithBorrowerListServiceExc() throws GeneralException {
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        doThrow(ConnectionException.class).when(oneOffCommonValidations).validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A);
        assertThrows(ConnectionException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateDefaultCardPaymentInputRequest(), jwtToken, "127.0.0.1", "origin"));
    }

    @Test
    void testAnmfBelongToCustomerWithBorrowerListServiceExcConfirm() throws GeneralException {
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        doThrow(ConnectionException.class).when(oneOffCommonValidations).validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A);
        assertThrows(ConnectionException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345678, TestDataCreator.generateConfirmCardPaymentRequest(), TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext().getCardTransactionDetails(), jwtToken, "127.0.0.1"));

    }

    @Test
    void testDifferentAnmfAccountConfirm() {
        assertThrows(ValidationsException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345679, TestDataCreator.generateConfirmCardPaymentRequest(), TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext().getCardTransactionDetails(), jwtToken, "127.0.0.1"));
    }

    @Test
    void testMaximumNumberOfOverpaymentsReached() throws GeneralException, IOException {

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();
        anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().setOOverpayNum(3);
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(anmfAccountServiceResponse);
        doThrow(ValidationsException.class).when(oneOffCommonValidations).validateNumberOfSingleOverpaymentsDoneToday(anmfAccountServiceResponse);

        assertThrows(ValidationsException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateDefaultCardPaymentInputRequest(), jwtToken, "127.0.0.1", "origin"));

    }

    @Test
    void testPaymentAmountMoreThanMaximumAmountAllowedToOverpay() throws MaintenanceException, ConnectionException, ValidationsException, IOException, OperativeSecurityException {

        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        cardOneOffPaymentRequest.getLoanDetails().get(0).setLoanOverpaymentAmount(BigDecimal.valueOf(4950));

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();

        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(anmfAccountServiceResponse);

        doThrow(ValidationsException.class).when(oneOffCommonValidations).validateMaximumAmountAllowed(any(), any());

        assertThrows(ValidationsException.class, () -> cardOneOffValidationsAndContextGeneratorService.
                validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, jwtToken, "127.0.0.1", "origin"));

    }

    @Test
    void testAnmfCoreClientExceptionAccountDetails() throws GeneralException, IOException {

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenThrow(ConnectionException.class);

        assertThrows(ConnectionException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateDefaultCardPaymentInputRequest(), jwtToken, "127.0.0.1", "origin"));
    }

    @Test
    void testHeartbeatClientException() throws GeneralException {
        when(heartBeatClient.fetchCurrentRegion()).thenThrow(MaintenanceException.class);
        assertThrows(MaintenanceException.class, () -> cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateDefaultCardPaymentInputRequest(), jwtToken, "127.0.0.1", "origin"));
    }
}
