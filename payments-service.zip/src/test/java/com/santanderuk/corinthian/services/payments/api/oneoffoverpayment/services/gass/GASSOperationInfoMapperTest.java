package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass;

import com.santander.common.instrumentation.logger.functional.dto.OperationInfo;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model.GASSMessageData;
import com.santanderuk.corinthian.services.payments.config.GASSConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;


@ExtendWith(MockitoExtension.class)
public class GASSOperationInfoMapperTest {
    @Mock
    GASSConfig gassConfig;
    private GASSOperationInfoMapper gassOperationInfoMapper;

    @BeforeEach
    public void setup() {
        gassOperationInfoMapper = new GASSOperationInfoMapper(gassConfig);
    }

    @Test
    public void Test_GASSCall_Assemble() {

        Mockito.when(gassConfig.getAuditTrnGrpId()).thenReturn(647);
        Mockito.when(gassConfig.getAuthCdUserCompSysId()).thenReturn("168");
        Mockito.when(gassConfig.getInstGrUserCompSysId()).thenReturn("168");
        Mockito.when(gassConfig.getOrgId()).thenReturn("2");
        Mockito.when(gassConfig.getOrgUtId()).thenReturn("NA");
        Mockito.when(gassConfig.getOrgUttp()).thenReturn("98");
        Mockito.when(gassConfig.getAuthCdUser()).thenReturn("rmq_el_corinthian_producer");

        OperationInfo info = gassOperationInfoMapper.assemble(createGaasMessageData(), true);

        assertEquals(123, info.getAppsysid());
        assertEquals(647, info.getAudittrngrpid());
        assertEquals(168, info.getAuthcdusercompsysid());
        assertEquals(168, info.getInstgrusercompsysid());
        assertEquals(2, info.getOrgid());
        assertEquals("1.1.1.1", info.getDvcid());
        assertEquals(1, info.getDvctyp());
        assertEquals("Tran Type", info.getAudittrntpname());
        assertEquals(98, info.getOrguttp());
        assertEquals("091586 123456789", info.getKeyhldgref());
        assertEquals("091586 123456789", info.getTrncltref());
        assertEquals("F12345678", info.getKeyuserid());
        assertEquals("ldapUid", info.getKeyaltuid());
        assertEquals("12300", info.getKeyamt());
        assertEquals("F12345678", info.getInstgruserusrid());
        assertEquals("rmq_el_corinthian_producer", info.getAuthcduserusrid());
        assertEquals("NA", info.getOrgutid());
        assertEquals(1, info.getOprtnsuctyp());
        assertEquals("<FRMTDDATA></FRMTDDATA>", info.getFrmtddataString());
    }

    private GASSMessageData createGaasMessageData() {
        GASSMessageData gassMessageData = new GASSMessageData();

        gassMessageData.setAppSysId(123);
        gassMessageData.setAuditTrnTpName("Tran Type");
        gassMessageData.setCustomerId("F12345678");
        gassMessageData.setUserId("F12345678");
        gassMessageData.setMccId("0015 7740 520 9656256");
        gassMessageData.setDeviceId("1.1.1.1");
        gassMessageData.setLdapUid("ldapUid");
        gassMessageData.setDeviceTyp(1);
        gassMessageData.setFormattedData("<FRMTDDATA></FRMTDDATA>");
        gassMessageData.setAnmfAccount("091586 123456789");
        gassMessageData.setAmount("12300");
        return gassMessageData;
    }

}
