package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.internalaccounts.InternalAccountsValidator;
import com.santanderuk.corinthian.services.commons.internalaccounts.RetrieveInternalAccounts;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.LacService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
class InternalTransferOneOffValidationsAndContextGeneratorServiceTest {

    private final String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    @Mock
    AnmfCoreClient anmfCoreClient;
    @Mock
    EndpointConfiguration endpointConfiguration;
    @Mock
    OneOffCommonValidations oneOffCommonValidations;
    @Mock
    HeartBeatClient heartBeatClient;
    @Mock
    LacService lacService;
    @Mock
    OverpaymentsConfig overpaymentsConfig;
    @Mock
    RetrieveInternalAccounts retrieveInternalAccounts;
    @Mock
    InternalAccountsValidator internalAccountsValidator;

    @Mock
    GassDataFetcher gassDataFetcher;

    private InternalTransferOneOffValidationsAndContextGeneratorService internalTransferOneOffValidationsAndContextGeneratorService;

    @BeforeEach
    void setUp() {
        internalTransferOneOffValidationsAndContextGeneratorService = new InternalTransferOneOffValidationsAndContextGeneratorService(anmfCoreClient, oneOffCommonValidations, endpointConfiguration, heartBeatClient, lacService, overpaymentsConfig, retrieveInternalAccounts, internalAccountsValidator, gassDataFetcher);
    }

    @Test
    void testMinimumAmountValidation() throws ValidationsException {
        MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(0).setLoanOverpaymentAmount(new BigDecimal("9.99"));

        doThrow(ValidationsException.class).when(oneOffCommonValidations).validateMinimumOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails());
        assertThrows(ValidationsException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, mortgageSingleOverpaymentInternalTransferRequest, jwtToken, "127.0.0.1"));
    }

    @Test
    void testAnmfDoesntBelongToCustomer() throws MaintenanceException, ConnectionException, OperativeSecurityException, ValidationsException {
        doThrow(OperativeSecurityException.class).when(oneOffCommonValidations).validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A);
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        assertThrows(OperativeSecurityException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));
    }

    @Test
    void testHappyPath() throws GeneralException, IOException {

        doNothing().when(oneOffCommonValidations).validateMinimumOverpaymentAmount(any());
        doNothing().when(oneOffCommonValidations).validateMaximumAmountAllowed(any(), any());
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(lacService.getAccountsDetails(any(), any())).thenReturn(TestDataCreator.generateDefaultInternalTransferAccountsDetails());
        when(overpaymentsConfig.getBeneficiaryLocalAccountSortcode()).thenReturn("090085");
        when(overpaymentsConfig.getBeneficiaryLocalAccountNumber()).thenReturn("20007437");
        when(retrieveInternalAccounts.getAccounts(anyString(), any(), any())).thenReturn(TestDataCreator.generateContractsInMccResponse());
        when(endpointConfiguration.getAccountBalancesUrl()).thenReturn("https://dummy/sanuk/internal/accounts-balances/v1/balances");
        when(gassDataFetcher.fetchMccId(anyString())).thenReturn("1234567");
        doNothing().when(internalAccountsValidator).validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(any(), any(), anyString(), any());

        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1");

        assertEquals("127.0.0.1", mortgageSingleOverpaymentsContext.getIpAddress());
        assertEquals(12345678, mortgageSingleOverpaymentsContext.getMortgageAccount());
        assertEquals(AnmfRegion.A, mortgageSingleOverpaymentsContext.getAnmfRegion());
        assertEquals("A", mortgageSingleOverpaymentsContext.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOAccStatus());
        assertEquals("Surname", mortgageSingleOverpaymentsContext.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOSurname());
        assertEquals("Forename1", mortgageSingleOverpaymentsContext.getLoggedCustomer().getOForename1());
        assertEquals("1234567", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getContract());
        assertEquals("O", mortgageSingleOverpaymentsContext.getSimulationChosenValues().getErcCollectionOption());
        assertEquals("M", mortgageSingleOverpaymentsContext.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType());
        assertEquals(new BigDecimal("111.11"), mortgageSingleOverpaymentsContext.getSimulationChosenValues().getPaymentAmount());
        assertEquals("pgwe51ZD", mortgageSingleOverpaymentsContext.getLdapUid());
        assertEquals("123 CURRENT ACCOUNT", mortgageSingleOverpaymentsContext.getAccountFromAlias());

    }

    @Test
    void testHappyPathSaving() throws GeneralException, IOException {
        doNothing().when(oneOffCommonValidations).validateMinimumOverpaymentAmount(any());
        doNothing().when(oneOffCommonValidations).validateMaximumAmountAllowed(any(), any());
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(lacService.getAccountsDetails(any(), any())).thenReturn(TestDataCreator.generateDefaultInternalTransferAccountsDetails());
        when(overpaymentsConfig.getBeneficiaryLocalAccountSortcode()).thenReturn("090085");
        when(overpaymentsConfig.getBeneficiaryLocalAccountNumber()).thenReturn("20007437");
        when(retrieveInternalAccounts.getAccounts(anyString(), any(), any())).thenReturn(TestDataCreator.generateContractsInMccResponse());
        when(endpointConfiguration.getAccountBalancesUrl()).thenReturn("https://dummy/sanuk/internal/accounts-balances/v1/balances");
        when(gassDataFetcher.fetchMccId(anyString())).thenReturn("1234567");
        doNothing().when(internalAccountsValidator).validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(any(), any(), anyString(), any());

        MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        mortgageSingleOverpaymentInternalTransferRequest.setOriginAccount(new LocalAccountNumber("SAVING", "272403091STE"));
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, mortgageSingleOverpaymentInternalTransferRequest, jwtToken, "127.0.0.1");

        assertEquals("127.0.0.1", mortgageSingleOverpaymentsContext.getIpAddress());
        assertEquals(12345678, mortgageSingleOverpaymentsContext.getMortgageAccount());
        assertEquals(AnmfRegion.A, mortgageSingleOverpaymentsContext.getAnmfRegion());
        assertEquals("A", mortgageSingleOverpaymentsContext.getAnmfAccountServiceResponse().getAccountServiceResponse().getResponse().getOStruc().getOAccStatus());
        assertEquals("Surname", mortgageSingleOverpaymentsContext.getCustomerDetailsResponse().getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).getOSurname());
        assertEquals("Forename1", mortgageSingleOverpaymentsContext.getLoggedCustomer().getOForename1());
        assertEquals("1234567", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getContract());
        assertEquals("O", mortgageSingleOverpaymentsContext.getSimulationChosenValues().getErcCollectionOption());
        assertEquals("M", mortgageSingleOverpaymentsContext.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType());
        assertEquals(new BigDecimal("111.11"), mortgageSingleOverpaymentsContext.getSimulationChosenValues().getPaymentAmount());
        assertEquals("pgwe51ZD", mortgageSingleOverpaymentsContext.getLdapUid());
        assertEquals("INSTANT SAVER", mortgageSingleOverpaymentsContext.getAccountFromAlias());

    }

    @Test
    void testLACCallLongSurname() throws GeneralException, IOException {

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(1234, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationListLongName().getCustomerDetailsResponse());

        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(overpaymentsConfig.getBeneficiaryLocalAccountSortcode()).thenReturn("090085");
        when(overpaymentsConfig.getBeneficiaryLocalAccountNumber()).thenReturn("20007437");
        when(retrieveInternalAccounts.getAccounts(anyString(), any(), any())).thenReturn(TestDataCreator.generateContractsInMccResponse());
        when(endpointConfiguration.getAccountBalancesUrl()).thenReturn("https://dummy/sanuk/internal/accounts-balances/v1/balances");
        when(gassDataFetcher.fetchMccId(anyString())).thenReturn("1234567");
        doNothing().when(internalAccountsValidator).validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(any(), any(), anyString(), any());
        when(lacService.getAccountsDetails(any(), any())).thenReturn(TestDataCreator.generateDefaultInternalTransferAccountsDetails());

        var localAccountNumberFromArgumentCaptor = ArgumentCaptor.forClass(LocalAccountNumber.class);
        var localAccountNumberToArgumentCaptor = ArgumentCaptor.forClass(LocalAccountNumber.class);

        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(1234, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1");
        verify(lacService).getAccountsDetails(localAccountNumberFromArgumentCaptor.capture(), localAccountNumberToArgumentCaptor.capture());

        assertEquals("090127", localAccountNumberFromArgumentCaptor.getValue().getSortcode());
        assertEquals("88889999", localAccountNumberFromArgumentCaptor.getValue().getAccountNumber());
        assertEquals("090085", localAccountNumberToArgumentCaptor.getValue().getSortcode());
        assertEquals("20007437000001234ThisIsALongSurnam", localAccountNumberToArgumentCaptor.getValue().getAccountNumber());

        assertEquals("0015", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCompany());
        assertEquals("4247", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCentre());
        assertEquals("300", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getProduct());
        assertEquals("1234567", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getContract());
        assertEquals("company", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCompany());
        assertEquals("centre", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCentre());
        assertEquals("product", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getProduct());
        assertEquals("contract", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getContract());
    }

    @Test
    void testLACCall() throws GeneralException, IOException {
        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        doNothing().when(oneOffCommonValidations).validateMinimumOverpaymentAmount(any());
        doNothing().when(oneOffCommonValidations).validateMaximumAmountAllowed(any(), any());
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());

        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(lacService.getAccountsDetails(any(), any())).thenReturn(TestDataCreator.generateDefaultInternalTransferAccountsDetails());
        when(overpaymentsConfig.getBeneficiaryLocalAccountSortcode()).thenReturn("090085");
        when(overpaymentsConfig.getBeneficiaryLocalAccountNumber()).thenReturn("20007437");
        when(retrieveInternalAccounts.getAccounts(anyString(), any(), any())).thenReturn(TestDataCreator.generateContractsInMccResponse());
        when(endpointConfiguration.getAccountBalancesUrl()).thenReturn("https://dummy/sanuk/internal/accounts-balances/v1/balances");
        when(gassDataFetcher.fetchMccId(anyString())).thenReturn("1234567");
        doNothing().when(internalAccountsValidator).validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(any(), any(), anyString(), any());


        var localAccountNumberFromArgumentCaptor = ArgumentCaptor.forClass(LocalAccountNumber.class);
        var localAccountNumberToArgumentCaptor = ArgumentCaptor.forClass(LocalAccountNumber.class);

        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1");
        verify(lacService).getAccountsDetails(localAccountNumberFromArgumentCaptor.capture(), localAccountNumberToArgumentCaptor.capture());

        assertEquals("090127", localAccountNumberFromArgumentCaptor.getValue().getSortcode());
        assertEquals("88889999", localAccountNumberFromArgumentCaptor.getValue().getAccountNumber());
        assertEquals("090085", localAccountNumberToArgumentCaptor.getValue().getSortcode());
        assertEquals("20007437012345678Surname", localAccountNumberToArgumentCaptor.getValue().getAccountNumber());

        assertEquals("0015", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCompany());
        assertEquals("4247", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCentre());
        assertEquals("300", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getProduct());
        assertEquals("1234567", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getContract());
        assertEquals("company", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCompany());
        assertEquals("centre", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCentre());
        assertEquals("product", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getProduct());
        assertEquals("contract", mortgageSingleOverpaymentsContext.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getContract());
    }

    @Test
    void testAnmfBelongToCustomerWithBorrowerListServiceExc() throws GeneralException {

        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        doThrow(ConnectionException.class).when(oneOffCommonValidations).validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A);

        assertThrows(ConnectionException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));

    }

    @Test
    void testLacServiceException() throws GeneralException, IOException {
        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(lacService.getAccountsDetails(any(), any())).thenThrow(GeneralException.class);
        when(retrieveInternalAccounts.getAccounts(anyString(), any(), any())).thenReturn(TestDataCreator.generateContractsInMccResponse());
        when(endpointConfiguration.getAccountBalancesUrl()).thenReturn("https://dummy/sanuk/internal/accounts-balances/v1/balances");
        doNothing().when(internalAccountsValidator).validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(any(), any(), anyString(), any());

        assertThrows(GeneralException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));

    }

    @Test
    void testInternalAccountsValidatorException() throws GeneralException, IOException {
        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());

        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(retrieveInternalAccounts.getAccounts(anyString(), any(), any())).thenReturn(TestDataCreator.generateContractsInMccResponse());
        when(endpointConfiguration.getAccountBalancesUrl()).thenReturn("https://dummy/sanuk/internal/accounts-balances/v1/balances");
        doThrow(GeneralException.class).when(internalAccountsValidator).validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(any(), any(), anyString(), any());
        assertThrows(GeneralException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));
    }

    @Test
    void testRetrieveContractsInMccException() throws GeneralException, IOException {

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateDefaultAccountInfoResponse());
        when(retrieveInternalAccounts.getAccounts(anyString(), any(), any())).thenThrow(ConnectionException.class);

        assertThrows(ConnectionException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));
    }

    @Test
    void testMaximumNumberOfOverpaymentsReached() throws GeneralException, IOException {

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();
        anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().setOOverpayNum(3);
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(anmfAccountServiceResponse);
        doThrow(ValidationsException.class).when(oneOffCommonValidations).validateNumberOfSingleOverpaymentsDoneToday(anmfAccountServiceResponse);

        assertThrows(ValidationsException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));

    }

    @Test
    void testPaymentAmountMoreThanMaximumAmountAllowedToOverpay() throws MaintenanceException, ConnectionException, ValidationsException, IOException, OperativeSecurityException {

        MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOvrInternalTransferRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        mortgageSingleOvrInternalTransferRequest.getLoanDetails().get(0).setLoanOverpaymentAmount(BigDecimal.valueOf(4950));

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);

        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());

        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();

        doThrow(ValidationsException.class).when(oneOffCommonValidations).validateMaximumAmountAllowed(any(), any());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenReturn(anmfAccountServiceResponse);

        assertThrows(ValidationsException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.
                validateRequestAndGenerateContext(12345678, mortgageSingleOvrInternalTransferRequest, jwtToken, "127.0.0.1"));

    }

    @Test
    void testAnmfCoreClientExceptionAccountDetails() throws GeneralException, IOException {

        when(endpointConfiguration.getAnmfAccountInfoUrl()).thenReturn("anmf/account/{account}");
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList().getCustomerDetailsResponse());
        when(anmfCoreClient.fetchMortgageAccountDetailsV5(anyInt(), anyString(), any())).thenThrow(ConnectionException.class);

        assertThrows(ConnectionException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));
    }

    @Test
    void testHeartbeatClientException() throws GeneralException {
        when(heartBeatClient.fetchCurrentRegion()).thenThrow(MaintenanceException.class);
        assertThrows(MaintenanceException.class, () -> internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), jwtToken, "127.0.0.1"));
    }
}
