package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck.LynxFraudCheckService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt.LynxNRTService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.MakePaymentService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.*;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.gass.OneOffInternalTransferGassService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OneOffInternalTransferServiceTest {

    @Mock
    SetupPaymentMapper setupPaymentMapper;
    @Mock
    SetupPaymentClient setupPaymentClient;
    @Mock
    LynxFraudCheckService lynxFraudCheckService;
    @Mock
    LynxNRTService lynxNRTService;
    @Mock
    MakePaymentService makePaymentService;
    @Mock
    OneOffInternalTransferGassService oneOffInternalTransferGassService;

    OneOffInternalTransferService oneOffInternalTransferService;

    @BeforeEach
    void setUp() {
        oneOffInternalTransferService = new OneOffInternalTransferService(setupPaymentMapper, setupPaymentClient, lynxFraudCheckService, lynxNRTService, makePaymentService, oneOffInternalTransferGassService);
    }

    @Test
    void testHappyPath() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        ArgumentCaptor<PartenonAccountNumber> partenonAccountNumberArgumentCaptor = ArgumentCaptor.forClass(PartenonAccountNumber.class);
        ArgumentCaptor<BigDecimal> paymentAmountCaptor = ArgumentCaptor.forClass(BigDecimal.class);
        when(setupPaymentMapper.generateSetupRequest(partenonAccountNumberArgumentCaptor.capture(), paymentAmountCaptor.capture())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doNothing().when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);
        when(makePaymentService.callMakePayment(setupRequest, setupResponse, context)).thenReturn(TestDataCreator.generateDefaultDebitPaymentResponse());
        doNothing().when(lynxNRTService).mapAndCallLynxNRT(context, "ok");

        String response = oneOffInternalTransferService.makeInternalTransfer(context);

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(1)).callGassMakePayment(context, "1");

        assertEquals("0015", partenonAccountNumberArgumentCaptor.getValue().getCompany());
        assertEquals("4247", partenonAccountNumberArgumentCaptor.getValue().getCentre());
        assertEquals("300", partenonAccountNumberArgumentCaptor.getValue().getProduct());
        assertEquals("1234567", partenonAccountNumberArgumentCaptor.getValue().getContract());
        assertEquals("5000", paymentAmountCaptor.getValue().toString());

        assertEquals("MORTGAGE2102111212", response);
    }

    @Test
    void testSetupPaymentExc() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenThrow(PaymentsFuncException.class);

        assertThrows(PaymentsFuncException.class, () -> oneOffInternalTransferService.makeInternalTransfer(context));

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "2");
        verify(oneOffInternalTransferGassService, times(0)).callGassMakePayment(any(), anyString());
        verify(lynxFraudCheckService, times(0)).callLynxFraudCheck(any(), any());
        verify(makePaymentService, times(0)).callMakePayment(any(), any(), any());
        verify(lynxNRTService, times(0)).mapAndCallLynxNRT(any(), anyString());
    }

    @Test
    void testFraudCheckExc() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doThrow(new FraudException("TRANSACTION DECLINED BY FRAUD")).when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);

        assertThrows(FraudException.class, () -> oneOffInternalTransferService.makeInternalTransfer(context));

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(0)).callGassMakePayment(any(), anyString());
        verify(makePaymentService, times(0)).callMakePayment(any(), any(), any());
        verify(lynxNRTService, times(1)).mapAndCallLynxNRT(context, "KO");
    }

    @Test
    void testFraudCheckExc2() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doThrow(new FraudException("Other")).when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);

        assertThrows(FraudException.class, () -> oneOffInternalTransferService.makeInternalTransfer(context));

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(0)).callGassMakePayment(any(), anyString());
        verify(makePaymentService, times(0)).callMakePayment(any(), any(), any());
        verify(lynxNRTService, times(0)).mapAndCallLynxNRT(any(), anyString());
    }

    @Test
    void testMakePaymentExc() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doNothing().when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);
        when(makePaymentService.callMakePayment(setupRequest, setupResponse, context)).thenThrow(new PaymentsFuncException("Exception while calling Debit payment"));

        assertThrows(PaymentsFuncException.class, () -> oneOffInternalTransferService.makeInternalTransfer(context));

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(1)).callGassMakePayment(context, "2");

        verify(lynxNRTService, times(1)).mapAndCallLynxNRT(context, "KO");
    }

    @Test
    void testMakePaymentExcBlockedAccount() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doNothing().when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);
        when(makePaymentService.callMakePayment(setupRequest, setupResponse, context)).thenThrow(new PaymentsFuncException("blocked account"));

        assertThrows(PaymentsFuncException.class, () -> oneOffInternalTransferService.makeInternalTransfer(context));

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(1)).callGassMakePayment(context, "2");

        verify(lynxNRTService, times(1)).mapAndCallLynxNRT(context, "KO");
    }

    @Test
    void testMakePaymentExcUnclearedFunds() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doNothing().when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);
        when(makePaymentService.callMakePayment(setupRequest, setupResponse, context)).thenThrow(new PaymentsFuncException("uncleared funds"));

        assertThrows(PaymentsFuncException.class, () -> oneOffInternalTransferService.makeInternalTransfer(context));

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(1)).callGassMakePayment(context, "2");

        verify(lynxNRTService, times(1)).mapAndCallLynxNRT(context, "KO");
    }

    @Test
    void testMakePaymentExcOtherException() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doNothing().when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);
        when(makePaymentService.callMakePayment(setupRequest, setupResponse, context)).thenThrow(new PaymentsFuncException("unknown exception"));

        assertThrows(PaymentsFuncException.class, () -> oneOffInternalTransferService.makeInternalTransfer(context));

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(1)).callGassMakePayment(context, "2");

        verify(lynxNRTService, times(1)).mapAndCallLynxNRT(context, "KO");
    }

    @Test
    void testLynxNRTCallExcIgnored() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doNothing().when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);
        when(makePaymentService.callMakePayment(setupRequest, setupResponse, context)).thenReturn(TestDataCreator.generateDefaultDebitPaymentResponse());
        doThrow(new LynxNRTException("Exception while calling LynxNRT Core Api")).when(lynxNRTService).mapAndCallLynxNRT(context, "ok");

        String response = oneOffInternalTransferService.makeInternalTransfer(context);
        assertEquals("MORTGAGE2102111212", response);

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(1)).callGassMakePayment(context, "1");


    }

    @Test
    void testLynxNRTMapperExcIgnored() throws IOException, PaymentsFuncException, FraudException, LynxNRTException {

        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        SetupRequest setupRequest = TestDataCreator.generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = TestDataCreator.generateSetupPaymentResponseOK();
        when(setupPaymentMapper.generateSetupRequest(any(), any())).thenReturn(setupRequest);
        when(setupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        doNothing().when(lynxFraudCheckService).callLynxFraudCheck(context, setupResponse);
        when(makePaymentService.callMakePayment(setupRequest, setupResponse, context)).thenReturn(TestDataCreator.generateDefaultDebitPaymentResponse());
        doThrow(new LynxNRTException("Exception while creating LynxNrt Request")).when(lynxNRTService).mapAndCallLynxNRT(context, "ok");

        String response = oneOffInternalTransferService.makeInternalTransfer(context);
        assertEquals("MORTGAGE2102111212", response);

        verify(oneOffInternalTransferGassService, times(1)).callGassSetup(context, "1");
        verify(oneOffInternalTransferGassService, times(1)).callGassMakePayment(context, "1");


    }
}
