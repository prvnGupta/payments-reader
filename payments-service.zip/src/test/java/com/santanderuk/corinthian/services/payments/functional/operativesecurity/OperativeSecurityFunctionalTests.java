package com.santanderuk.corinthian.services.payments.functional.operativesecurity;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class OperativeSecurityFunctionalTests extends FunctionalTest {

    String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
    String jwtWithNoCustomer = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImx5bngiLCJpb2MiLCJpc2MiLCJsYWMiXSwibmJmIjoxNTE5MjA3MjgzLCJleHAiOjE1MTkyMTA4ODMsImlhdCI6MTUxOTIwNzI4MywianRpIjoiMjIwNDEyOGYtY2ZlMi00ZWMxLTkyMjItZmQzMmVmNDQxMjE0In0.p2WEO3nyKZaeMs4VjVOI5FDvlqzjsFe_iO7RygccU4xLSk8teIW0FuNL50_JZAFL0S5jZEIBCAUlYyb3Xz-NNUoRC0SWJC0sSfeSuapSBTdBgw8JFcXyn6wTUm-fpo1gyUtFq4CcjqmQt5RMzR6sp0WoVileuHDyntWYYN9u4hBA2iln5seLj1PDcMH4YHNzgTedoBOwMrWknjTrVgVfz63wiOlPDlgzQHtlxYI3vvkXrL99J_8C7sfip2SYM8tn_YTyCte176MQPuh0GOwS8ZfMg_nIJyF3gXrJQZhNrQjCzr1zXEESY0Ly19EznHyp7rHpZDWhkUGs6J18PkYNTA";
    private String setupRegularPaymentUrl;
    private Header header;

    @BeforeEach
    public void setupThisTest() {
        int accountNumber = 12345678;
        setupRegularPaymentUrl = String.format("http://localhost:%s/payments-service/regular-overpayment/%s", serverPort, accountNumber);

        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
    }

    @Test
    public void operativeSecurityOKDespiteAnmfCustomerServiceReturningEmptyNames() {
        stubSetUpRegularARegion();
        stubGetCustomerListWithEmptyName();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        header = new Header("authorization", jwtWithCustomer554);

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201);
    }

    @Test
    public void operativeSecurityExc() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        header = new Header("authorization", jwtWithNoCustomer);

        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(401)
                .and()
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("SECURITY_KO"),
                        "info.message", equalTo("Mortgage does not belong to customer")
                );
    }


    @Test
    public void corsAcceptedDomainTest() {
        stubGetCustomerListWithEmptyName();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");


        header = new Header("authorization", jwtWithCustomer554);

        given().
                header(header).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                header("Origin", "http://localhost:4200").
                body(readFileContents("happy-path-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201);
    }

    @Test
    public void corsNotAcceptedDomainTest() {
        header = new Header("authorization", jwtWithCustomer554);

        given().
                header(header).
                header("Accept", MediaType.APPLICATION_JSON_VALUE).
                header("Content-Type", MediaType.APPLICATION_JSON_VALUE).
                header("Origin", "taherah.hacker.com").
                body(readFileContents("happy-path-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(403);
    }
}
