package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataRequest;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class LynxFraudCheckServiceTest {

    private LynxFraudCheckService lynxFraudCheckService;

    @MockBean
    private LynxFraudCheckMapper mockLynxFraudCheckMapper;

    @MockBean
    private LynxFraudCheckClient mockLynxFraudCheckClient;

    @BeforeEach
    void setUp() {
        lynxFraudCheckService = new LynxFraudCheckService(mockLynxFraudCheckMapper, mockLynxFraudCheckClient);
    }

    @Test
    void callLynxFraudCheck() throws FraudException {

        lynxFraudCheckService.callLynxFraudCheck(new InternalTransferRequest(), TestDataCreator.generateDefaultInternalTransferAccountsDetails(), new SetupResponse(), "ldap-uid");

        verify(mockLynxFraudCheckMapper, times(1)).decorateRequestData(any(InternalTransferRequest.class), any(InternalTransferAccountsDetails.class), any(SetupResponse.class), any(String.class));
        verify(mockLynxFraudCheckClient, times(1)).callFraudCheck(any());
    }

    @Test
    void shouldCatchFraudException() throws FraudException {
        when(mockLynxFraudCheckClient.callFraudCheck(any()))
                .thenThrow(FraudException.class);

        assertThrows(FraudException.class, () -> mockLynxFraudCheckClient.callFraudCheck(new LynxDataRequest()));
    }

    @Test
    void callLynxFraudCheckForSingleOverpayment() throws IOException, FraudException {

        lynxFraudCheckService.callLynxFraudCheck(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), new SetupResponse());

        verify(mockLynxFraudCheckMapper, times(1)).decorateRequestData(any(MortgageSingleOverpaymentsContext.class), any(SetupResponse.class));
        verify(mockLynxFraudCheckClient, times(1)).callFraudCheck(any());
    }

    @Test
    void shouldCatchFraudExceptionForSingleOverpayment() throws FraudException {
        when(mockLynxFraudCheckClient.callFraudCheck(any()))
                .thenThrow(FraudException.class);

        assertThrows(FraudException.class, () -> lynxFraudCheckService.callLynxFraudCheck(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), new SetupResponse()));
    }

}
