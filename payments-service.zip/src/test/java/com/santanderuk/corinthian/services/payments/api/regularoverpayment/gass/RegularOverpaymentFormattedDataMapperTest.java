package com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentFormattedData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.Response;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.AnmfLoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.LoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.ODirectDebitDetails;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.OutputStruc;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.Centre;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.MccContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.ArrayList;

@ExtendWith(SpringExtension.class)
class RegularOverpaymentFormattedDataMapperTest {

    RegularOverpaymentFormattedDataMapper mapper;

    @Mock
    GassConfig mockConfig;

    @BeforeEach
    void setUp() {
        mapper = new RegularOverpaymentFormattedDataMapper(mockConfig);
        Mockito.when(mockConfig.getAnmfSortcode()).thenReturn("12345678");
    }

    @Test
    void toFormattedData() {
        ///arrange //act
        SetUpRegularOverpaymentFormattedData formattedData = mapper.toFormattedData(context());

        //assert
        Assertions.assertEquals("3", formattedData.getFormattedLoans().get(0).getLoanSchema());
        Assertions.assertEquals(1, formattedData.getFormattedLoans().get(0).getOrderId());

        Assertions.assertEquals("2", formattedData.getFormattedLoans().get(1).getLoanSchema());
        Assertions.assertEquals(2, formattedData.getFormattedLoans().get(1).getOrderId());

        Assertions.assertEquals("1", formattedData.getFormattedLoans().get(2).getLoanSchema());
        Assertions.assertEquals(3, formattedData.getFormattedLoans().get(2).getOrderId());
    }

    private RegularOverpaymentContext context() {
        Loan loan1 = new Loan();
        loan1.setLoanSchema("1");
        loan1.setOrderId(3);
        loan1.setLoanType("R");
        loan1.setAppSequenceNumber("1");

        Loan loan2 = new Loan();
        loan2.setLoanSchema("3");
        loan2.setOrderId(1);
        loan2.setLoanType("R");
        loan2.setAppSequenceNumber("2");

        Loan loan3 = new Loan();
        loan3.setLoanSchema("2");
        loan3.setOrderId(2);
        loan3.setLoanType("R");
        loan3.setAppSequenceNumber("3");

        ArrayList<Loan> loans = new ArrayList<>();
        loans.add(loan1);
        loans.add(loan2);
        loans.add(loan3);

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setLoans(loans);
        input.setOverpaymentAmount(new BigDecimal("123.45"));
        input.setStartDate("01/04/2021");
        input.setEndDate("01/04/2022");

        com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc customerOutputStruc = new com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc();
        customerOutputStruc.setOCustomerList(new ArrayList<>());

        CustomerServiceResponse customerServiceResponse = new CustomerServiceResponse();

        customerServiceResponse.setOStruc(customerOutputStruc);

        CustomerDetailsResponse customerDetailsResponse = new CustomerDetailsResponse();
        customerDetailsResponse.setCustomerServiceResponse(customerServiceResponse);

        ODirectDebitDetails oDirectDebitDetails = new ODirectDebitDetails();
        oDirectDebitDetails.setOBankSortCode("12-12-12");
        oDirectDebitDetails.setOBankAccount(12345678);

        OutputStruc outputStruc1 = new OutputStruc();
        outputStruc1.setODirectDebitDetails(oDirectDebitDetails);

        LoanPaymentPlanResponse loanPaymentPlanResponse = new LoanPaymentPlanResponse();
        loanPaymentPlanResponse.setOutputStruc(outputStruc1);

        AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse = new AnmfLoanPaymentPlanResponse();
        anmfLoanPaymentPlanResponse.setLoanPaymentPlanResponse(loanPaymentPlanResponse);

        Centre centre = new Centre();
        centre.setCentreCode("T");
        centre.setCompany("IO");

        PartenonContract partenonContract = new PartenonContract();
        partenonContract.setCentre(centre);
        partenonContract.setContractNumber("1234");
        partenonContract.setProductTypeCode("R");

        MccContract mccContract = new MccContract();
        mccContract.setPartenonContract(partenonContract);

        AnmfAccountServiceResponse anmfAccountServiceResponse = new AnmfAccountServiceResponse();
        AccountServiceResponse accountServiceResponse = new AccountServiceResponse();
        Response response = new Response();
        OStruc oStruct = new OStruc();
        oStruct.setOContMonPay(new BigDecimal("123.23"));
        response.setOStruc(oStruct);
        accountServiceResponse.setResponse(response);
        anmfAccountServiceResponse.setAccountServiceResponse(accountServiceResponse);

        RegularOverpaymentContext context = new RegularOverpaymentContext();
        context.setControllerRequest(input);
        context.setAnmfAccountResponse(anmfAccountServiceResponse);
        context.setMccContract(mccContract);
        context.setAnmfLoanPaymentPlanResponse(anmfLoanPaymentPlanResponse);
        context.setCustomerDetailsResponse(customerDetailsResponse);
        context.setAccount(123456);
        return context;
    }
}
