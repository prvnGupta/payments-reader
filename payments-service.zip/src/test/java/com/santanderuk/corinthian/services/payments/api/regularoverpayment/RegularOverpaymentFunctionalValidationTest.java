package com.santanderuk.corinthian.services.payments.api.regularoverpayment;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.validation.ValidationRule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
public class RegularOverpaymentFunctionalValidationTest {

    RegularOverpaymentFunctionalValidation functionalValidation;
    List<ValidationRule> validationRules;

    @BeforeEach
    void setUp() {
        validationRules = new ArrayList<>();
        functionalValidation = new RegularOverpaymentFunctionalValidation(validationRules);
    }

    @Test
    public void testHappyPathDateEqualsFirstDate() throws GeneralException {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        functionalValidation.validate(context);
    }

    @Test
    public void testHappyPathDateEqualsSecondDate() throws GeneralException {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/01/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        functionalValidation.validate(context);
    }

    @Test
    public void testHappyPathDateEqualsThirdDate() throws GeneralException {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        functionalValidation.validate(context);
    }

    @Test
    public void functionalValidationCustomerInputAmountMoreThanTheHighestOfNextThreePayments() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("5.73"));

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            functionalValidation.validate(context);

        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_LESS_THAN_HIGHEST_OF_NEXT_3_PAYMENTS", e.getCode());
            assertEquals("The amount requested is less than the highest of next 3 payments", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void functionalValidationCustomerStartingDateIsNotInAvailableDates() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("22/08/2019");

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            functionalValidation.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_STARTING_DATE_NOT_VALID", e.getCode());
            assertEquals("The starting date is not one of the available dates", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void functionalValidationCustomerFinalDateIsUntilFurtherNotice() throws GeneralException {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("untilfurthernotice");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        functionalValidation.validate(context);
    }

    @Test
    public void functionalValidationCustomerSelectedEndDateIsBeforeAvailableFinalDate() throws GeneralException {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2053");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        functionalValidation.validate(context);
    }

    @Test
    public void functionalValidationCustomerSelectedEndDateInWrongFormat() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31-12-2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            functionalValidation.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("BAD REQUEST", e.getCode());
            assertEquals("Invalid Request", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void functionalValidationCustomerSelectedEndDateIsAfterAvailableFinalDate() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("02/01/2057");

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            functionalValidation.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_ENDING_DATE_NOT_VALID", e.getCode());
            assertEquals("The selected ending date is after the final available date", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void functionalValidationCustomerSelectedWrongLoanPartSchemaIsIncorrect() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2022");

        Loan loan = new Loan();
        loan.setLoanSchema("3A"); // Correct one is 3T
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            functionalValidation.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", e.getCode());
            assertEquals("The loan selected is not valid", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void functionalValidationCustomerSelectedWrongSequenceNumberIsIncorrect() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2022");

        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("2");// Correct one is 3
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            functionalValidation.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", e.getCode());
            assertEquals("The loan selected is not valid", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void functionalValidationCustomerSelectedWrongSequenceNumberAndSchemeAreIncorrect() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2022");

        Loan loan = new Loan();
        loan.setLoanSchema("3A");// Correct one is 3T
        loan.setAppSequenceNumber("2");// Correct one is 3
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            functionalValidation.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN", e.getCode());
            assertEquals("The loan selected is not valid", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void testSetUpHasERCApplicableAndTheRemainingAllowanceIsEnoughForMakingAPayment() throws ValidationsException {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        // Removing the erc allowance amount
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp()
                .getOProdErc().setOTotProdErcAllow(new BigDecimal("1000.00"));

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2022");

        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        functionalValidation.validate(context);
    }

    @Test
    public void testSetUpNoERCApplicable() throws ValidationsException {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        // Removing the erc allowance amount
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp()
                .setOErcApplFlag("N");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp()
                .getOProdErc().setOTotProdErcAllow(new BigDecimal("0"));

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2022");

        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        functionalValidation.validate(context);
    }
}
