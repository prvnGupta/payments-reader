package com.santanderuk.corinthian.services.payments.api.internaltransfer.services;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataResponse;
import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck.LynxFraudCheckService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.LacService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt.LynxNRTService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.DebitResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.MakePaymentService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static com.santanderuk.corinthian.services.payments.TestDataCreator.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
class InternalTransferServiceTest {

    private static final String LDAP_UID = "ldap-uid";
    private static final String REMOTE_IP_ADDRESS = "remoteIpAddress";
    InternalTransferRequest internalTransferRequest;
    InternalTransferAccountsDetails accountsDetails;
    SetupRequest setupRequest;
    private InternalTransferService internalTransferService;

    @Mock
    private LacService lacService;

    @Mock
    private SetupPaymentMapper mockSetUpPaymentMapper;

    @Mock
    private SetupPaymentClient mockSetupPaymentClient;

    @Mock
    private LynxFraudCheckService mockLynxFraudCheckService;

    @Mock
    private LynxNRTService mockLynxNRTService;

    @Mock
    private MakePaymentService mockMakePaymentService;

    @BeforeEach
    void setUp() throws IOException {
        internalTransferRequest = generateDefaultInternalTransferControllerRequest();
        accountsDetails = generateDefaultInternalTransferAccountsDetails();
        setupRequest = generateSetupPaymentDefaultRequest();
        internalTransferService = new InternalTransferService(lacService, mockSetUpPaymentMapper, mockSetupPaymentClient, mockLynxFraudCheckService, mockLynxNRTService, mockMakePaymentService);
    }

    @Test
    void testHappyPath() throws PaymentsFuncException, IOException, FraudException, GeneralException, LynxNRTException {

        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenReturn(accountsDetails);
        when(mockSetUpPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount())).thenReturn(setupRequest);
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        when(mockSetupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        LynxDataResponse lynxDataResponse = generateDefaultFraudCheckResponse();
        when(mockLynxFraudCheckService.callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID)).thenReturn(lynxDataResponse);
        DebitResponse debitResponse = generateDefaultDebitPaymentResponse();
        when(mockMakePaymentService.callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails)).thenReturn(debitResponse);
        doNothing().when(mockLynxNRTService).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, debitResponse.getStatus(), LDAP_UID, REMOTE_IP_ADDRESS);

        InternalTransferResponse internalTransferResponse = internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS);

        verify(lacService, times(1)).getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount());
        verify(mockSetUpPaymentMapper, times(1)).generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount());
        verify(mockSetupPaymentClient, times(1)).callSetup(setupRequest);
        verify(mockLynxFraudCheckService, times(1)).callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID);
        verify(mockMakePaymentService, times(1)).callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails);
        verify(mockLynxNRTService, times(1)).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, debitResponse.getStatus(), LDAP_UID, REMOTE_IP_ADDRESS);

        assertTrue(internalTransferResponse.getPaymentId().contains("MORTGAGE"));
    }

    @Test
    void testMakePaymentKOWeCallLynxNrtWithKo() throws PaymentsFuncException, IOException, FraudException, GeneralException, LynxNRTException {

        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenReturn(accountsDetails);
        when(mockSetUpPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount())).thenReturn(setupRequest);
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        when(mockSetupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        LynxDataResponse lynxDataResponse = generateDefaultFraudCheckResponse();
        when(mockLynxFraudCheckService.callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID)).thenReturn(lynxDataResponse);
        DebitResponse debitResponse = generateDebitPaymentKoResponseUnclearedFunds();
        when(mockMakePaymentService.callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails)).thenThrow(PaymentsFuncException.class);
        doNothing().when(mockLynxNRTService).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, debitResponse.getStatus(), LDAP_UID, REMOTE_IP_ADDRESS);

        assertThrows(PaymentsFuncException.class, () -> internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS));

        verify(lacService, times(1)).getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount());
        verify(mockSetUpPaymentMapper, times(1)).generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount());
        verify(mockSetupPaymentClient, times(1)).callSetup(setupRequest);
        verify(mockLynxFraudCheckService, times(1)).callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID);
        verify(mockMakePaymentService, times(1)).callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails);
        verify(mockLynxNRTService, times(1)).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, "KO", LDAP_UID, REMOTE_IP_ADDRESS);

    }

    @Test
    void testExceptionThrownIdSetupError() throws PaymentsFuncException, GeneralException {
        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenReturn(accountsDetails);
        when(mockSetUpPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount())).thenReturn(setupRequest);
        when(mockSetupPaymentClient.callSetup(setupRequest)).thenThrow(PaymentsFuncException.class);

        assertThrows(PaymentsFuncException.class, () -> internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS));

        verify(mockSetUpPaymentMapper, times(1)).generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount());
        verify(mockSetupPaymentClient, times(1)).callSetup(setupRequest);
    }

    @Test
    void testLacServiceError() throws GeneralException {
        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenThrow(GeneralException.class);
        assertThrows(GeneralException.class, () -> internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS));
    }

    @Test
    void testFraudCheckExceptionDeclinedThenCallLynxNrt() throws GeneralException, IOException, PaymentsFuncException, FraudException, LynxNRTException {
        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenReturn(accountsDetails);
        when(mockSetUpPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount())).thenReturn(setupRequest);
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        when(mockSetupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        when(mockLynxFraudCheckService.callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID)).thenThrow(new FraudException("TRANSACTION DECLINED BY FRAUD"));
        assertThrows(FraudException.class, () -> internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS));
        //Verify we dont call Debit Payment
        Mockito.verify(mockMakePaymentService, times(0)).callMakePayment(any(), any(), any(), any());

        //Verify we call LynxNRT
        Mockito.verify(mockLynxNRTService, times(1)).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, "KO", LDAP_UID, REMOTE_IP_ADDRESS);
    }

    @Test
    void testFraudCheckExceptionPendingWeDontCallLynxNrt() throws GeneralException, IOException, PaymentsFuncException, FraudException, LynxNRTException {
        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenReturn(accountsDetails);
        when(mockSetUpPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount())).thenReturn(setupRequest);
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        when(mockSetupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        when(mockLynxFraudCheckService.callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID)).thenThrow(new FraudException("TRANSACTION PENDING BY FRAUD"));
        assertThrows(FraudException.class, () -> internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS));
        //Verify we dont call Debit Payment
        Mockito.verify(mockMakePaymentService, times(0)).callMakePayment(any(), any(), any(), any());

        //Verify we call LynxNRT
        Mockito.verify(mockLynxNRTService, times(0)).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, "KO", LDAP_UID, REMOTE_IP_ADDRESS);
    }

    @Test
    void testFraudCheckUnknownExceptionPendingWeDontCallLynxNrt() throws GeneralException, IOException, PaymentsFuncException, FraudException, LynxNRTException {
        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenReturn(accountsDetails);
        when(mockSetUpPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount())).thenReturn(setupRequest);
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        when(mockSetupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        when(mockLynxFraudCheckService.callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID)).thenThrow(new FraudException("Exception while calling LynxFraud Core Api"));
        assertThrows(FraudException.class, () -> internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS));
        //Verify we dont call Debit Payment
        Mockito.verify(mockMakePaymentService, times(0)).callMakePayment(any(), any(), any(), any());

        //Verify we call LynxNRT
        Mockito.verify(mockLynxNRTService, times(0)).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, "KO", LDAP_UID, REMOTE_IP_ADDRESS);
    }

    @Test
    void testLynxNrtKOAfterDebitOK() throws GeneralException, IOException, PaymentsFuncException, FraudException, LynxNRTException {
        when(lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount())).thenReturn(accountsDetails);
        when(mockSetUpPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount())).thenReturn(setupRequest);
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        when(mockSetupPaymentClient.callSetup(setupRequest)).thenReturn(setupResponse);
        LynxDataResponse lynxDataResponse = generateDefaultFraudCheckResponse();
        when(mockLynxFraudCheckService.callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID)).thenReturn(lynxDataResponse);
        DebitResponse debitResponse = generateDefaultDebitPaymentResponse();
        when(mockMakePaymentService.callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails)).thenReturn(debitResponse);
        doThrow(LynxNRTException.class).when(mockLynxNRTService).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, debitResponse.getStatus(), LDAP_UID, REMOTE_IP_ADDRESS);

        InternalTransferResponse internalTransferResponse = internalTransferService.makePayment(internalTransferRequest, LDAP_UID, REMOTE_IP_ADDRESS);

        verify(lacService, times(1)).getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount());
        verify(mockSetUpPaymentMapper, times(1)).generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount());
        verify(mockSetupPaymentClient, times(1)).callSetup(setupRequest);
        verify(mockLynxFraudCheckService, times(1)).callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, LDAP_UID);
        verify(mockMakePaymentService, times(1)).callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails);
        verify(mockLynxNRTService, times(1)).mapAndCallLynxNRT(internalTransferRequest, accountsDetails, debitResponse.getStatus(), LDAP_UID, REMOTE_IP_ADDRESS);

        assertTrue(internalTransferResponse.getPaymentId().contains("MORTGAGE"));
    }
}
