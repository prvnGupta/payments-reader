package com.santanderuk.corinthian.services.payments.functional.regularoverpayment;

import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

@ActiveProfiles("test")
public class RegularOverpaymentGenerationFunctionalTest extends FunctionalTest {

    String setupRegularPaymentUrl;
    Header header;
    Header contentType;
    int accountNumber;

    @BeforeEach
    void setupThisTest() {
        accountNumber = 12345678;
        setupRegularPaymentUrl = String.format("http://localhost:%s/payments-service/regular-overpayment/%s", serverPort, accountNumber);
        header = new Header("authorization", jwtAuth);
        contentType = new Header("Content-Type", "application/json");
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
    }

    @Test
    public void testHappyPath() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        given().
                header(header).header(contentType).header(new Header("Content-Type", "application/json")).
                body(readFileContents("happy-path-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201).
                body("data.paymentDone", equalTo(true));
    }

    @Test
    public void testHappyPath_Issue5905() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-21578471.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response-21578471.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-21578471.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        given().
                header(header).header(contentType).header(new Header("Content-Type", "application/json")).
                body(readFileContents("happy-path-controller-request-21578471.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201).
                body("data.paymentDone", equalTo(true));
    }

    @Test
    public void testHappyPathRepayment() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-repayment-tracker.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        given().
                header(header).header(contentType).header(new Header("Content-Type", "application/json")).
                body(readFileContents("happy-path-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201).
                body("data.paymentDone", equalTo(true));
    }
}
