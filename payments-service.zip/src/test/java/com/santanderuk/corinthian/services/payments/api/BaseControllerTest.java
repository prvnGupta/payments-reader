package com.santanderuk.corinthian.services.payments.api;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerService;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.PaymentServiceConfig;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
public class BaseControllerTest {

    @Mock
    private PaymentServiceConfig config;

    @Mock
    private AnmfBelongToCustomerService anmfBelongToCustomerService;

    @Mock
    private AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;

    @Mock
    private EndpointConfiguration endpointConfiguration;

    @InjectMocks
    private BaseController baseController;

    @Test
    public void testWeCallTheCustomerServiceInformationService() throws OperativeSecurityException, ValidationsException, ConnectionException {

        when(config.isOperativeSecurity()).thenReturn(true);
        when(endpointConfiguration.getAnmfCustomerServiceUrl()).thenReturn("CustomerServiceUrl/{region}/");
        when(anmfBelongToCustomerService.anmfBelongsToCustomer(anyInt(), anyString(), anyString(), any())).thenReturn(true);

        baseController.checkOperativeSecurity(123456, "jwt", AnmfRegion.A);

        verify(anmfBelongToCustomerService, Mockito.times(1)).anmfBelongsToCustomer(anyInt(), anyString(), anyString(), any());
    }

    @Test
    public void testWeCallTheCustomerServiceInformationServiceBorrowerList() throws OperativeSecurityException, ValidationsException, ConnectionException {


        AnmfBelongsToCustomerWithBorrowerList response = new AnmfBelongsToCustomerWithBorrowerList();
        response.setAnmfBelongsToCustomer(true);

        when(config.isOperativeSecurity()).thenReturn(true);
        when(endpointConfiguration.getAnmfCustomerServiceUrl()).thenReturn("CustomerServiceUrl/{region}/");
        when(anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(anyInt(), anyString(), anyString(), any())).thenReturn(response);

        baseController.checkOperativeSecurityWithCustomerList(123456, "jwt", AnmfRegion.A);

        verify(anmfBelongToCustomerWithBorrowerListService, Mockito.times(1)).anmfBelongsToCustomerWithBorrowerList(anyInt(), anyString(), anyString(), any());
    }
}
