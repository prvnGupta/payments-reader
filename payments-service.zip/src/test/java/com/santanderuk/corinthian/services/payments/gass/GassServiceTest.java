package com.santanderuk.corinthian.services.payments.gass;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.rabbitmq.TestConsumerConfig;
import com.santanderuk.corinthian.services.payments.rabbitmq.TestConsumerGassRabbitMq;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.mockito.ArgumentMatchers.*;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@ActiveProfiles("test")
@DirtiesContext
public class GassServiceTest {
    protected String jwtAuth = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    @Autowired
    TestConsumerConfig config;

    @Autowired
    private TestConsumerGassRabbitMq testConsumer;

    @Autowired
    private GassService gassService;

    @MockBean
    private BksConnectClient bksConnectClient;

    @MockBean
    private AnmfCoreClient anmfCoreClient;

    @MockBean
    private HeartBeatClient heartBeatClient;

    @BeforeEach
    void setUp() throws Exception {
        testConsumer.resetQueue();
        Mockito.when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
    }

    @Test
    public void testCancelRegularOverpayment() throws IOException, InterruptedException, TimeoutException, ConnectionException {

        Mockito.when(bksConnectClient.getMccFromLdapUid(anyString(), anyString())).thenReturn(TestDataCreator.generateRetrieveMccResponse());
        Mockito.when(anmfCoreClient.fetchLoanPaymentPlan(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateLoanPaymentPlanResponse());

        String messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
        Thread.sleep(500);
        gassService.auditCancelRegularOverpayment(123456789, jwtAuth, "127.0.0.1", "1", "T", TestDataCreator.generateCustomerServiceInfoResponse(), TestDataCreator.createContextForTest());

        Thread.sleep(2000);
        messagesReceived = testConsumer.readMessage();

        assertThat(messagesReceived, containsString("<AuditRecordTrn><AUDITTRNGRPID>647</AUDITTRNGRPID><AUDITTRNTPNAME>Cancel regular overpayment</AUDITTRNTPNAME></AuditRecordTrn>"));
        assertThat(messagesReceived, containsString("<AuditRecordWho><AUDITRECINSTGRUSER><USRID>F554</USRID><COMPSYSID>168</COMPSYSID></AUDITRECINSTGRUSER><AUDITRECAUTHCDUSER><USRID>RABBITMQ</USRID><COMPSYSID>168</COMPSYSID></AUDITRECAUTHCDUSER></AuditRecordWho>"));
        assertThat(messagesReceived, containsString("<OPRTNSUCTYP>1</OPRTNSUCTYP>"));
        assertThat(messagesReceived, containsString("<TRNCLTREF>091586 123456789</TRNCLTREF>"));
        assertThat(messagesReceived, containsString("<KEYALTUID>pgwe51ZD</KEYALTUID>"));
        assertThat(messagesReceived, containsString("<KEYUSERID>F554</KEYUSERID>"));
        assertThat(messagesReceived, containsString("<KEYHLDGREF>091586 123456789</KEYHLDGREF>"));
        assertThat(messagesReceived, containsString("<KEYAMT>5000</KEYAMT>"));
        assertThat(messagesReceived, containsString("<AuditRecordWhere><DVCTYP>11</DVCTYP><DVCID>127.0.0.1</DVCID><APPSYSID>242</APPSYSID><ORGID>2</ORGID><ORGUTTP>98</ORGUTTP></AuditRecordWhere>"));
        assertThat(messagesReceived, containsString("</AuditRecordWhere><AuditRecordWhat><FRMTDDATA esc=\"Y\"><![CDATA["));

        String formattedData = URLDecoder.decode(messagesReceived.substring(messagesReceived.indexOf("<![CDATA[") + 9, messagesReceived.indexOf("]]>")), StandardCharsets.UTF_8);
        assertThat(formattedData, containsString("<customerNumber>F554</customerNumber>"));
        assertThat(formattedData, containsString("<multiChannelContractId>0015 9473 520 1152557</multiChannelContractId>"));
        assertThat(formattedData, containsString("<mortgageAccountNumber>091586 123456789</mortgageAccountNumber>"));
        assertThat(formattedData, containsString("<contractualMonthlyPaymentAmount>50.00</contractualMonthlyPaymentAmount>"));
        assertThat(formattedData, containsString("<overpaymentAmount>0.00</overpaymentAmount>"));
        assertThat(formattedData, containsString("<directDebitTotalAmount>50.00</directDebitTotalAmount>"));
        assertThat(formattedData, containsString("<overpaymentCancellationEffectiveDate>"));
        assertThat(formattedData, containsString("</overpaymentCancellationEffectiveDate>"));
        assertThat(formattedData, containsString("<overpaymentEffect>T</overpaymentEffect>"));
        assertThat(formattedData, containsString("<originAccount>772031 10308860</originAccount>"));
        assertThat(formattedData, containsString("<destinationAccount>123456789</destinationAccount>"));

        messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
    }

    @Test
    public void testAmendRegularOverpayment() throws IOException, InterruptedException, TimeoutException, ConnectionException {

        Mockito.when(bksConnectClient.getMccFromLdapUid(anyString(), anyString())).thenReturn(TestDataCreator.generateRetrieveMccResponse());
        Mockito.when(anmfCoreClient.fetchLoanPaymentPlan(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateLoanPaymentPlanResponse());

        String messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
        Thread.sleep(500);
        gassService.auditEditRegularOverpayment(123456789, jwtAuth, "127.0.0.1", TestDataCreator.generateEditRegControllerRequest(), "1", TestDataCreator.generateCustomerServiceInfoResponse(), TestDataCreator.createContextForTest());

        Thread.sleep(2000);
        messagesReceived = testConsumer.readMessage();

        assertThat(messagesReceived, containsString("<AuditRecordTrn><AUDITTRNGRPID>647</AUDITTRNGRPID><AUDITTRNTPNAME>Amend regular overpayment</AUDITTRNTPNAME></AuditRecordTrn>"));
        assertThat(messagesReceived, containsString("<AuditRecordWho><AUDITRECINSTGRUSER><USRID>F554</USRID><COMPSYSID>168</COMPSYSID></AUDITRECINSTGRUSER><AUDITRECAUTHCDUSER><USRID>RABBITMQ</USRID><COMPSYSID>168</COMPSYSID></AUDITRECAUTHCDUSER></AuditRecordWho>"));
        assertThat(messagesReceived, containsString("<OPRTNSUCTYP>1</OPRTNSUCTYP>"));
        assertThat(messagesReceived, containsString("<TRNCLTREF>091586 123456789</TRNCLTREF>"));
        assertThat(messagesReceived, containsString("<KEYALTUID>pgwe51ZD</KEYALTUID>"));
        assertThat(messagesReceived, containsString("<KEYUSERID>F554</KEYUSERID>"));
        assertThat(messagesReceived, containsString("<KEYHLDGREF>091586 123456789</KEYHLDGREF>"));
        assertThat(messagesReceived, containsString("<KEYAMT>15000</KEYAMT>"));
        assertThat(messagesReceived, containsString("<AuditRecordWhere><DVCTYP>11</DVCTYP><DVCID>127.0.0.1</DVCID><APPSYSID>242</APPSYSID><ORGID>2</ORGID><ORGUTTP>98</ORGUTTP></AuditRecordWhere>"));
        assertThat(messagesReceived, containsString("</AuditRecordWhere><AuditRecordWhat><FRMTDDATA esc=\"Y\"><![CDATA["));

        String formattedData = URLDecoder.decode(messagesReceived.substring(messagesReceived.indexOf("<![CDATA[") + 9, messagesReceived.indexOf("]]>")), StandardCharsets.UTF_8);
        assertThat(formattedData, containsString("<customerNumber>F554</customerNumber>"));
        assertThat(formattedData, containsString("<multiChannelContractId>0015 9473 520 1152557</multiChannelContractId>"));
        assertThat(formattedData, containsString("<mortgageAccountNumber>091586 123456789</mortgageAccountNumber>"));
        assertThat(formattedData, containsString("<contractualMonthlyPaymentAmount>50.00</contractualMonthlyPaymentAmount>"));
        assertThat(formattedData, containsString("<overpaymentAmount>100.00</overpaymentAmount>"));
        assertThat(formattedData, containsString("<directDebitTotalAmount>150.00</directDebitTotalAmount>"));
        assertThat(formattedData, containsString("<startDate>01/12/2018</startDate>"));
        assertThat(formattedData, containsString("<endDate>27/12/2021</endDate>"));
        assertThat(formattedData, containsString("<numberOfPayments>37</numberOfPayments>"));
        assertThat(formattedData, containsString("<overpaymentEffect>T</overpaymentEffect>"));
        assertThat(formattedData, containsString("<originAccount>772031 10308860</originAccount>"));
        assertThat(formattedData, containsString("<destinationAccount>123456789</destinationAccount>"));

        messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
    }

    @Test
    public void testAmendRegularOverpaymentMultiLoan() throws IOException, InterruptedException, TimeoutException, ConnectionException {

        Mockito.when(bksConnectClient.getMccFromLdapUid(anyString(), anyString())).thenReturn(TestDataCreator.generateRetrieveMccResponse());
        Mockito.when(anmfCoreClient.fetchLoanPaymentPlan(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateLoanPaymentPlanResponse());

        String messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
        Thread.sleep(500);
        gassService.auditEditRegularOverpayment(123456789, jwtAuth, "127.0.0.1", TestDataCreator.generateEditRegControllerRequestMultiLoan(), "1", TestDataCreator.generateCustomerServiceInfoResponse(), TestDataCreator.createContextForTest());

        Thread.sleep(2000);
        messagesReceived = testConsumer.readMessage();

        assertThat(messagesReceived, containsString("<AuditRecordTrn><AUDITTRNGRPID>647</AUDITTRNGRPID><AUDITTRNTPNAME>Amend regular overpayment</AUDITTRNTPNAME></AuditRecordTrn>"));
        assertThat(messagesReceived, containsString("<AuditRecordWho><AUDITRECINSTGRUSER><USRID>F554</USRID><COMPSYSID>168</COMPSYSID></AUDITRECINSTGRUSER><AUDITRECAUTHCDUSER><USRID>RABBITMQ</USRID><COMPSYSID>168</COMPSYSID></AUDITRECAUTHCDUSER></AuditRecordWho>"));
        assertThat(messagesReceived, containsString("<OPRTNSUCTYP>1</OPRTNSUCTYP>"));
        assertThat(messagesReceived, containsString("<TRNCLTREF>091586 123456789</TRNCLTREF>"));
        assertThat(messagesReceived, containsString("<KEYALTUID>pgwe51ZD</KEYALTUID>"));
        assertThat(messagesReceived, containsString("<KEYUSERID>F554</KEYUSERID>"));
        assertThat(messagesReceived, containsString("<KEYHLDGREF>091586 123456789</KEYHLDGREF>"));
        assertThat(messagesReceived, containsString("<KEYAMT>15000</KEYAMT>"));
        assertThat(messagesReceived, containsString("<AuditRecordWhere><DVCTYP>11</DVCTYP><DVCID>127.0.0.1</DVCID><APPSYSID>242</APPSYSID><ORGID>2</ORGID><ORGUTTP>98</ORGUTTP></AuditRecordWhere>"));
        assertThat(messagesReceived, containsString("</AuditRecordWhere><AuditRecordWhat><FRMTDDATA esc=\"Y\"><![CDATA["));

        String formattedData = URLDecoder.decode(messagesReceived.substring(messagesReceived.indexOf("<![CDATA[") + 9, messagesReceived.indexOf("]]>")), StandardCharsets.UTF_8);
        assertThat(formattedData, containsString("<customerNumber>F554</customerNumber>"));
        assertThat(formattedData, containsString("<multiChannelContractId>0015 9473 520 1152557</multiChannelContractId>"));
        assertThat(formattedData, containsString("<mortgageAccountNumber>091586 123456789</mortgageAccountNumber>"));
        assertThat(formattedData, containsString("<contractualMonthlyPaymentAmount>50.00</contractualMonthlyPaymentAmount>"));
        assertThat(formattedData, containsString("<overpaymentAmount>100.00</overpaymentAmount>"));
        assertThat(formattedData, containsString("<directDebitTotalAmount>150.00</directDebitTotalAmount>"));
        assertThat(formattedData, containsString("<startDate>01/12/2018</startDate>"));
        assertThat(formattedData, containsString("<endDate>27/12/2021</endDate>"));
        assertThat(formattedData, containsString("<numberOfPayments>37</numberOfPayments>"));
        assertThat(formattedData, containsString("<overpaymentEffect>T</overpaymentEffect>"));
        assertThat(formattedData, containsString("<originAccount>772031 10308860</originAccount>"));
        assertThat(formattedData, containsString("<destinationAccount>123456789</destinationAccount>"));

        messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
    }

    @Test
    public void testAmendRegularOverpaymentMultiLoanWithInterestOnly() throws IOException, InterruptedException, TimeoutException, ConnectionException {

        Mockito.when(bksConnectClient.getMccFromLdapUid(anyString(), anyString())).thenReturn(TestDataCreator.generateRetrieveMccResponse());
        Mockito.when(anmfCoreClient.fetchLoanPaymentPlan(anyInt(), anyString(), any())).thenReturn(TestDataCreator.generateLoanPaymentPlanResponse());

        String messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
        Thread.sleep(500);
        gassService.auditEditRegularOverpayment(123456789, jwtAuth, "127.0.0.1", TestDataCreator.generateEditRegControllerRequestMultiLoanWithInterestOnly(), "1", TestDataCreator.generateCustomerServiceInfoResponse(), TestDataCreator.createContextForTest());

        Thread.sleep(2000);
        messagesReceived = testConsumer.readMessage();

        assertThat(messagesReceived, containsString("<AuditRecordTrn><AUDITTRNGRPID>647</AUDITTRNGRPID><AUDITTRNTPNAME>Amend regular overpayment</AUDITTRNTPNAME></AuditRecordTrn>"));
        assertThat(messagesReceived, containsString("<AuditRecordWho><AUDITRECINSTGRUSER><USRID>F554</USRID><COMPSYSID>168</COMPSYSID></AUDITRECINSTGRUSER><AUDITRECAUTHCDUSER><USRID>RABBITMQ</USRID><COMPSYSID>168</COMPSYSID></AUDITRECAUTHCDUSER></AuditRecordWho>"));
        assertThat(messagesReceived, containsString("<OPRTNSUCTYP>1</OPRTNSUCTYP>"));
        assertThat(messagesReceived, containsString("<TRNCLTREF>091586 123456789</TRNCLTREF>"));
        assertThat(messagesReceived, containsString("<KEYALTUID>pgwe51ZD</KEYALTUID>"));
        assertThat(messagesReceived, containsString("<KEYUSERID>F554</KEYUSERID>"));
        assertThat(messagesReceived, containsString("<KEYHLDGREF>091586 123456789</KEYHLDGREF>"));
        assertThat(messagesReceived, containsString("<KEYAMT>15000</KEYAMT>"));
        assertThat(messagesReceived, containsString("<AuditRecordWhere><DVCTYP>11</DVCTYP><DVCID>127.0.0.1</DVCID><APPSYSID>242</APPSYSID><ORGID>2</ORGID><ORGUTTP>98</ORGUTTP></AuditRecordWhere>"));
        assertThat(messagesReceived, containsString("</AuditRecordWhere><AuditRecordWhat><FRMTDDATA esc=\"Y\"><![CDATA["));

        String formattedData = URLDecoder.decode(messagesReceived.substring(messagesReceived.indexOf("<![CDATA[") + 9, messagesReceived.indexOf("]]>")), StandardCharsets.UTF_8);
        assertThat(formattedData, containsString("<customerNumber>F554</customerNumber>"));
        assertThat(formattedData, containsString("<multiChannelContractId>0015 9473 520 1152557</multiChannelContractId>"));
        assertThat(formattedData, containsString("<mortgageAccountNumber>091586 123456789</mortgageAccountNumber>"));
        assertThat(formattedData, containsString("<contractualMonthlyPaymentAmount>50.00</contractualMonthlyPaymentAmount>"));
        assertThat(formattedData, containsString("<overpaymentAmount>100.00</overpaymentAmount>"));
        assertThat(formattedData, containsString("<directDebitTotalAmount>150.00</directDebitTotalAmount>"));
        assertThat(formattedData, containsString("<startDate>01/12/2018</startDate>"));
        assertThat(formattedData, containsString("<endDate>27/12/2021</endDate>"));
        assertThat(formattedData, containsString("<numberOfPayments>37</numberOfPayments>"));
        assertThat(formattedData, containsString("<overpaymentEffect>M</overpaymentEffect>"));
        assertThat(formattedData, containsString("<originAccount>772031 10308860</originAccount>"));
        assertThat(formattedData, containsString("<destinationAccount>123456789</destinationAccount>"));

        messagesReceived = testConsumer.readMessage();
        assertThat(messagesReceived, containsString("No messages in queue"));
    }
}
