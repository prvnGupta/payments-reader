package com.santanderuk.corinthian.services.payments.functional.regularoverpayment;


import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
@Slf4j
public class EditOverpaymentFunctionalTest extends FunctionalTest {

    String editRegularPaymentUrl;
    Header header;
    int accountNumber;


    @BeforeEach
    void setupThisTest() {
        accountNumber = 12345678;
        editRegularPaymentUrl = String.format("http://localhost:%s/payments-service/regular-overpayment/%s", serverPort, accountNumber);
        header = new Header("authorization", jwtAuth);
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
    }

    @Test
    public void testWeGet200WhenEditRegularOverpaymentHappyPath() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"));
    }

    @Test
    public void testWeGet200WhenEditRegularOverpaymentWhenOneDDExistingInstructionAndOneNoDD() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-two-instruction-one-DD-one-no-DD.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"));
    }

    @Test
    public void testEditRegularOverpaymentWhenTwoExistingInstructions() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-two-existing-instruction.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testEditRegularOverpaymentWhenNoExistingInstructions() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-no-existing-instruction.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testEditRegularOverpaymentWhenNoExistingDDInstructionsButOtherTypeExisting() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction-no-DD.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testEditRegularOverpaymentWhenErrorInPaymentArrangementEnquiryResponse() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-error.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testEditRegularOverpaymentWhenPaymentArrangementEnquiryServiceDown() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiryDown(accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ANMF_UNAVAILABLE"),
                        "info.message", equalTo("ANMF did not respond correctly"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testWeGet200WhenEditRegularOverpaymentForMultiLoan() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("multi-loan-happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"));
    }

    @Test
    public void testWeGet400WhenEditRegularOverpaymentForZeroOrderID() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");


        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("bad-request-min-order-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void shouldReturn200OkayWhenEditRegularOverpaymentIsSuccessful() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json", accountNumber);
        stubAnmfEditRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(200).
                body("info.status", equalTo("ok"));
    }

    @Test
    public void testWeGetCorrectErrorWhenANMFDown() {

        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json", accountNumber);
        stubAnmfEditRegularOverpaymentAnmfDown();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                put(editRegularPaymentUrl).
                then().
                statusCode(500).
                body("info.code", equalTo("ANMF_UNAVAILABLE"),
                        "info.message", equalTo("ANMF did not respond correctly"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testTryingToMakeAPaymentInRegionW() {
        stubHeartbeatRegionW();
        stubGetCustomerInfoWRegion();

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(editRegularPaymentUrl).
                then().
                statusCode(503).
                and().
                body(
                        "info.code", equalTo("MAINTENANCE_REGION_X"),
                        "info.message", equalTo("Maintenance region X"),
                        "info.status", equalTo("ko")
                );
    }


}
