package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.applyoverpayment.ApplyOverpaymentInAnmfService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.OneOffInternalTransferService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations.InternalTransferOneOffValidationsAndContextGeneratorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class MortgageOverpaymentInternalTransferServiceTest {

    @Mock
    OneOffInternalTransferService oneOffInternalTransferService;
    @Mock
    SimulationService simulationService;
    @Mock
    InternalTransferOneOffValidationsAndContextGeneratorService internalTransferOneOffValidationsAndContextGeneratorService;
    @Mock
    ApplyOverpaymentInAnmfService applyOverpaymentInAnmfService;

    @Mock
    PDFCreationService pdfCreationService;

    private MortgageOverpaymentInternalTransferService mortgageOverpaymentInternalTransferService;

    @BeforeEach
    void setUp() {
        mortgageOverpaymentInternalTransferService = new MortgageOverpaymentInternalTransferService(oneOffInternalTransferService, simulationService, internalTransferOneOffValidationsAndContextGeneratorService, applyOverpaymentInAnmfService, pdfCreationService);
    }

    @Test
    void testHappyPath() throws GeneralException, PaymentsFuncException, FraudException, IOException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenReturn(context);
        Mockito.doNothing().when(simulationService).createOverpaymentSimulationV1(context);
        Mockito.doNothing().when(simulationService).updatePaymentMethodV1(context);
        Mockito.when(oneOffInternalTransferService.makeInternalTransfer(context)).thenReturn("MORTGAGE2102111212");
        Mockito.doNothing().when(applyOverpaymentInAnmfService).applyInternalTransferOverpayment(context, "MORTGAGE2102111212");
        Mockito.when(pdfCreationService.createBase64PdfFileForInternalTransfer(context)).thenReturn("base64EncodedPDF");
        MortgageSingleOverpaymentInternalTransferResponse response = mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1");
        assertEquals("base64EncodedPDF", response.getBase64Pdf());
        assertTrue(response.isPaymentDone());
    }

    @Test
    void testBEValidationMultiLoanExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(new ValidationsException("EXC_MULTI_LOAN_MORTGAGE_ACCOUNT", "The mortgage has more than 1 active loan."));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        assertEquals("EXC_MULTI_LOAN_MORTGAGE_ACCOUNT", validationsException.getCode());
        assertEquals("The mortgage has more than 1 active loan.", validationsException.getMessage());
        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testBEValidationNumberOfOverpaymentsExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(new ValidationsException("EXC_MAX_NUM_OVP_REACHED", "Maximum number of overpayments done."));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        assertEquals("EXC_MAX_NUM_OVP_REACHED", validationsException.getCode());
        assertEquals("Maximum number of overpayments done.", validationsException.getMessage());
        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testBEValidationMinimumAmountExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(new ValidationsException("EXC_MIN_OVP_AMOUNT", "Chosen overpayment amount below permitted minimum amount."));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        assertEquals("EXC_MIN_OVP_AMOUNT", validationsException.getCode());
        assertEquals("Chosen overpayment amount below permitted minimum amount.", validationsException.getMessage());
        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testBEVValidationInsufficientBalanceExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(new ValidationsException(ValidationsException.Type.EXC_ACCOUNT_INSUFFICIENT_BALANCE));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        assertEquals("EXC_ACCOUNT_INSUFFICIENT_BALANCE", validationsException.getCode());
        assertEquals("The account selected does not have enough balance to make payment", validationsException.getMessage());

        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testHeartbeatExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(MaintenanceException.class);
        assertThrows(MaintenanceException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testConnectionExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(ConnectionException.class);
        assertThrows(ConnectionException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testGeneralExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(GeneralException.class);
        assertThrows(GeneralException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testAnmfBelongToCustomerExc() throws GeneralException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenThrow(new OperativeSecurityException("SECURITY_KO", "Mortgage account does not belong to customer"));
        OperativeSecurityException operativeSecurityException = assertThrows(OperativeSecurityException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        assertEquals("SECURITY_KO", operativeSecurityException.getCode());
        assertEquals("Mortgage account does not belong to customer", operativeSecurityException.getMessage());
        verify(simulationService, times(0)).createOverpaymentSimulationV1(any());
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }


    @Test
    void testSimulationUpdateChosenValuesExc() throws GeneralException, IOException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenReturn(context);
        Mockito.doThrow(GeneralException.class).when(simulationService).createOverpaymentSimulationV1(context);
        assertThrows(GeneralException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        verify(simulationService, times(0)).updatePaymentMethodV1(any());
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());


    }

    @Test
    void testSimulationUpdatePaymentMethodExc() throws GeneralException, IOException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenReturn(context);
        Mockito.doNothing().when(simulationService).createOverpaymentSimulationV1(context);
        Mockito.doThrow(ConnectionException.class).when(simulationService).updatePaymentMethodV1(context);
        assertThrows(ConnectionException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));
        verify(oneOffInternalTransferService, times(0)).makeInternalTransfer(any());
        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testMakeInternalTransferPaymentsExc() throws GeneralException, IOException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenReturn(context);
        Mockito.doNothing().when(simulationService).createOverpaymentSimulationV1(context);
        Mockito.doNothing().when(simulationService).updatePaymentMethodV1(context);
        Mockito.when(oneOffInternalTransferService.makeInternalTransfer(context)).thenThrow(PaymentsFuncException.class);
        assertThrows(PaymentsFuncException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));

        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

    @Test
    void testMakeInternalTransferFraudExc() throws GeneralException, IOException, PaymentsFuncException, FraudException {
        MortgageSingleOverpaymentInternalTransferRequest controllerRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        Mockito.when(internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, controllerRequest, "jwtToken", "127.0.0.1")).thenReturn(context);
        Mockito.doNothing().when(simulationService).createOverpaymentSimulationV1(context);
        Mockito.doNothing().when(simulationService).updatePaymentMethodV1(context);
        Mockito.when(oneOffInternalTransferService.makeInternalTransfer(context)).thenThrow(FraudException.class);
        assertThrows(FraudException.class, () -> mortgageOverpaymentInternalTransferService.makePayment(123456879, controllerRequest, "jwtToken", "127.0.0.1"));

        verify(applyOverpaymentInAnmfService, times(0)).applyInternalTransferOverpayment(any(), anyString());
    }

}
