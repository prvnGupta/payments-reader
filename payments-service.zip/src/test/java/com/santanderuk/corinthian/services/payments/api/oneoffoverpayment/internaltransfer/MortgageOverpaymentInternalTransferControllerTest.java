package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferResponseWrapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MortgageOverpaymentInternalTransferControllerTest {

    private MortgageOverpaymentInternalTransferController controller;
    protected String jwt = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";


    @Mock
    MortgageOverpaymentInternalTransferService service;
    @Mock
    HttpServletRequest httpServletRequest;

    @BeforeEach
    void setUp() {
        controller = new MortgageOverpaymentInternalTransferController(service);

    }

    @Test
    void testHappyPath() throws GeneralException, PaymentsFuncException, IOException, FraudException {
        when(service.makePayment(anyInt(), any(), anyString(), anyString())).thenReturn(TestDataCreator.generateDefaultServiceResponse());
        when(httpServletRequest.getHeader(anyString())).thenReturn("127.0.0.1");
        ResponseEntity<MortgageSingleOverpaymentInternalTransferResponseWrapper> response = controller.oneOffOverpaymentInternalTransfer(jwt, 123456789, TestDataCreator.generateMortgageSingleOverpaymentControllerRequest(), httpServletRequest);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(200, response.getStatusCodeValue());
        assertTrue(Objects.requireNonNull(response.getBody()).getData().isPaymentDone());
        assertEquals("base64EncodedPdf", response.getBody().getData().getBase64Pdf());
        assertEquals("ok", response.getBody().getInfo().getStatus());
    }
}
