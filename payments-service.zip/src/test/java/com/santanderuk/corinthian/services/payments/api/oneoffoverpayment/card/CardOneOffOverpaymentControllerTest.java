package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CardOneOffOverpaymentControllerTest {

    private CardOneOffOverpaymentController controller;
    protected String jwt = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";


    @Mock
    CardOneOffOverpaymentService service;
    @Mock
    HttpServletRequest httpServletRequest;

    @BeforeEach
    void setUp() {
        controller = new CardOneOffOverpaymentController(service);
    }

    @Test
    void testHappyPathChallenge() throws GeneralException, IOException {
        when(service.makeCardOneOffOverpayment(anyInt(), any(), anyString(), anyString(), anyString())).thenReturn(TestDataCreator.generateDefaultCardPaymentResponseChallenge());
        when(httpServletRequest.getHeader("X-FORWARDED-FOR")).thenReturn("127.0.0.1");
        when(httpServletRequest.getHeader("Origin")).thenReturn("rint");
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        ResponseEntity<CardPaymentResponseWrapper> response = controller.cardOneOffOverpayment(jwt, 123456789, cardOneOffPaymentRequest, httpServletRequest);
        Mockito.verify(service, times(1)).makeCardOneOffOverpayment(123456789, cardOneOffPaymentRequest, jwt, "127.0.0.1", "rint");
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(201, response.getStatusCodeValue());
        assertFalse(Objects.requireNonNull(response.getBody()).getData().isPaymentDone());
        assertEquals("https://test.sagepay.com/3ds-simulator/html_challenge", response.getBody().getData().getThreeDSDetails().getOutputUrl());
        assertEquals("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJlOWE4NmVlOS0wMjFlLTQ0N2MtYjczMS0wNjQzODNiN2M0NzAiLAogICJhY3NUcmFuc0lEIiA6ICJjMmM4MTRmMi0yYjE3LTQxMDQtODJiOS1mMWM5NWEyOWJlZTEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwNCIKfQ", response.getBody().getData().getThreeDSDetails().getOutputCode());
        assertEquals("", response.getBody().getData().getBase64Pdf());
        assertEquals("ok", response.getBody().getInfo().getStatus());
    }

    @Test
    void testOriginEmpty() throws GeneralException, IOException {
        when(service.makeCardOneOffOverpayment(anyInt(), any(), anyString(), anyString(), anyString())).thenReturn(TestDataCreator.generateDefaultCardPaymentResponseChallenge());
        when(httpServletRequest.getHeader("X-FORWARDED-FOR")).thenReturn("127.0.0.1");
        when(httpServletRequest.getHeader("Origin")).thenReturn("");
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        ResponseEntity<CardPaymentResponseWrapper> response = controller.cardOneOffOverpayment(jwt, 123456789, cardOneOffPaymentRequest, httpServletRequest);
        Mockito.verify(service, times(1)).makeCardOneOffOverpayment(123456789, cardOneOffPaymentRequest, jwt, "127.0.0.1", "");
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(201, response.getStatusCodeValue());
        assertFalse(Objects.requireNonNull(response.getBody()).getData().isPaymentDone());
        assertEquals("https://test.sagepay.com/3ds-simulator/html_challenge", response.getBody().getData().getThreeDSDetails().getOutputUrl());
        assertEquals("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJlOWE4NmVlOS0wMjFlLTQ0N2MtYjczMS0wNjQzODNiN2M0NzAiLAogICJhY3NUcmFuc0lEIiA6ICJjMmM4MTRmMi0yYjE3LTQxMDQtODJiOS1mMWM5NWEyOWJlZTEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwNCIKfQ", response.getBody().getData().getThreeDSDetails().getOutputCode());
        assertEquals("", response.getBody().getData().getBase64Pdf());
        assertEquals("ok", response.getBody().getInfo().getStatus());
    }

}
