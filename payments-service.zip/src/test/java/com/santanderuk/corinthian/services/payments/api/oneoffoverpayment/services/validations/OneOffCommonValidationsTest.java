package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferRequest;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OneOffCommonValidationsTest {

    OneOffCommonValidations oneOffCommonValidations;


    private final String jwtToken = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

    @Mock
    EndpointConfiguration endpointConfiguration;
    @Mock
    AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;
    @Mock
    OverpaymentsConfig overpaymentsConfig;

    @BeforeEach
    void setUp() {

        oneOffCommonValidations = new OneOffCommonValidations(overpaymentsConfig, endpointConfiguration, anmfBelongToCustomerWithBorrowerListService);
    }

    @Test
    void testMinimumAmountValidationSingleLoan() {

        MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest = TestDataCreator.generateMortgageSingleOverpaymentControllerRequest();
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(0).setLoanOverpaymentAmount(new BigDecimal("9.99"));
        Mockito.when(overpaymentsConfig.getMinimumOverpaymentAmount()).thenReturn(new BigDecimal(10));
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateMinimumOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails()));

        assertEquals("Chosen overpayment amount below permitted minimum amount.", exc.getMessage());
        assertEquals("EXC_MIN_OVP_AMOUNT", exc.getCode());
    }

    @Test
    void testMinimumAmountValidationMultiLoan() throws IOException {

        MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest = TestDataCreator.generateMortgageOneOffMultiLoanControllerRequest();
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(0).setLoanOverpaymentAmount(new BigDecimal("4.99"));
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(1).setLoanOverpaymentAmount(new BigDecimal("4.00"));
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(2).setLoanOverpaymentAmount(new BigDecimal("1.00"));
        Mockito.when(overpaymentsConfig.getMinimumOverpaymentAmount()).thenReturn(new BigDecimal(10));
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateMinimumOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails()));

        assertEquals("Chosen overpayment amount below permitted minimum amount.", exc.getMessage());
        assertEquals("EXC_MIN_OVP_AMOUNT", exc.getCode());
    }

    @Test
    void testMinimumAmountValidationMultiLoanMoreThanMinimum() throws IOException, ValidationsException {

        MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest = TestDataCreator.generateMortgageOneOffMultiLoanControllerRequest();
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(0).setLoanOverpaymentAmount(new BigDecimal("5"));
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(1).setLoanOverpaymentAmount(new BigDecimal("2.00"));
        mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails().get(2).setLoanOverpaymentAmount(new BigDecimal("3.00"));
        Mockito.when(overpaymentsConfig.getMinimumOverpaymentAmount()).thenReturn(new BigDecimal(10));
        oneOffCommonValidations.validateMinimumOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails());
    }

    @Test
    void testMortgageBelongToCustomerExc() throws IOException, ValidationsException, ConnectionException {
        String customerServiceUrl = "anmf/account/{account}/customer";
        when(endpointConfiguration.getAnmfCustomerServiceUrl()).thenReturn(customerServiceUrl);
        when(overpaymentsConfig.isOperativeSecurity()).thenReturn(true);
        when(anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(12345678, jwtToken, customerServiceUrl, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongsToCustomerWithCustomerListFalse());

        OperativeSecurityException operativeSecurityException = assertThrows(OperativeSecurityException.class, () -> oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A));

        assertEquals("Mortgage account does not belong to customer", operativeSecurityException.getMessage());
        assertEquals("SECURITY_KO", operativeSecurityException.getCode());
    }

    @Test
    void testMortgageBelongToCustomerOk() throws IOException, ValidationsException, ConnectionException, OperativeSecurityException {
        String customerServiceUrl = "anmf/account/{account}/customer";
        when(endpointConfiguration.getAnmfCustomerServiceUrl()).thenReturn(customerServiceUrl);
        when(overpaymentsConfig.isOperativeSecurity()).thenReturn(true);
        when(anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(12345678, jwtToken, customerServiceUrl, AnmfRegion.A)).thenReturn(TestDataCreator.generateAnmfBelongToCustomerWithCustomerInformationList());
        oneOffCommonValidations.validateMortgageBelongToCustomer(12345678, jwtToken, AnmfRegion.A);
    }


    @Test
    void testMaximumAmountValidation() throws IOException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateMaximumAmountAllowed(new BigDecimal("4950"), anmfAccountServiceResponse));

        assertEquals("The overpayment amount exceeds the maximum amount allowed.", exc.getMessage());
        assertEquals("EXC_MAX_AMOUNT_LIMIT", exc.getCode());
    }

    @Test
    void testMaximumAmountValidationOk() throws IOException, ValidationsException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();
        oneOffCommonValidations.validateMaximumAmountAllowed(new BigDecimal("3950"), anmfAccountServiceResponse);
    }

    @Test
    void testValidateNumberOfOverpaymentsDoneTodayOk() throws IOException, ValidationsException {
        when(overpaymentsConfig.getMaximumNumberOfOverpayments()).thenReturn(3);
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();
        oneOffCommonValidations.validateNumberOfSingleOverpaymentsDoneToday(anmfAccountServiceResponse);
    }

    @Test
    void testValidateLoanExceptionSingleLoan() throws IOException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateInputLoans(TestDataCreator.generateMortgageOneOffMultiLoanControllerRequest().getLoanDetails(), anmfAccountServiceResponse));
        assertEquals("invalid loan input", exc.getMessage());
        assertEquals("EXC_INVALID_LOAN_INPUT", exc.getCode());
    }

    @Test
    void testValidateLoanOkMultiLoan() throws IOException, ValidationsException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponseMultiloan();
        oneOffCommonValidations.validateInputLoans(TestDataCreator.generateMortgageOneOffMultiLoanControllerRequest().getLoanDetails(), anmfAccountServiceResponse);

    }


    @Test
    void testValidateLoanExcMultiLoanLessInput() throws IOException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponseMultiloan();
        List<LoanDetails> loanDetails = TestDataCreator.generateMortgageOneOffMultiLoanControllerRequest().getLoanDetails();
        loanDetails.remove(2);
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateInputLoans(loanDetails, anmfAccountServiceResponse));
        assertEquals("invalid loan input", exc.getMessage());
        assertEquals("EXC_INVALID_LOAN_INPUT", exc.getCode());
    }
    @Test
    void testValidateLoanExcMultiLoanDiffInput() throws IOException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponseMultiloan();
        List<LoanDetails> loanDetails = TestDataCreator.generateMortgageOneOffMultiLoanControllerRequest().getLoanDetails();
        loanDetails.get(2).setAppSeqNumber(1);
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateInputLoans(loanDetails, anmfAccountServiceResponse));
        assertEquals("invalid loan input", exc.getMessage());
        assertEquals("EXC_INVALID_LOAN_INPUT", exc.getCode());
    }
    @Test
    void testValidateLoanExcMultiLoanMoreInput() throws IOException {
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponseMultiloan();
        anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().remove(2);
        List<LoanDetails> loanDetails = TestDataCreator.generateMortgageOneOffMultiLoanControllerRequest().getLoanDetails();
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateInputLoans(loanDetails, anmfAccountServiceResponse));
        assertEquals("invalid loan input", exc.getMessage());
        assertEquals("EXC_INVALID_LOAN_INPUT", exc.getCode());
    }

    @Test
    void testValidateNumberOfOverpaymentsDoneTodayException() throws IOException {
        when(overpaymentsConfig.getMaximumNumberOfOverpayments()).thenReturn(3);
        AnmfAccountServiceResponse anmfAccountServiceResponse = TestDataCreator.generateDefaultAccountInfoResponse();
        anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().setOOverpayNum(3);
        ValidationsException exc = assertThrows(ValidationsException.class, () -> oneOffCommonValidations.validateNumberOfSingleOverpaymentsDoneToday(anmfAccountServiceResponse));
        assertEquals("Maximum number of overpayments done.", exc.getMessage());
        assertEquals("EXC_MAX_NUM_OVP_REACHED", exc.getCode());
    }


}