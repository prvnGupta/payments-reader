package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.LacService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request.CardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.confirmtransaction.request.ConfirmCardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cps.CPSCardPaymentRequest;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpayoPaymentServiceTest {

    OpayoPaymentService opayoPaymentService;

    @Mock
    OpayoPaymentClient opayoPaymentClient;

    @Mock
    OpayoPaymentMapper opayoPaymentMapper;

    @Mock
    LacService lacService;

    @Mock
    OpayoConfig opayoConfig;

    @BeforeEach
    void setUp() {
        opayoPaymentService = new OpayoPaymentService(opayoPaymentClient, opayoPaymentMapper, opayoConfig, lacService);
    }

    @Test
    void testMakeCardTransactionChallenge() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        String cardTransactionUrl = "cardTransactionUrl";
        CardTransactionRequest cardTransactionRequest = TestDataCreator.generateDefaultCardTransactionRequest();

        Mockito.when(opayoConfig.getCardTransactionUrl()).thenReturn(cardTransactionUrl);
        Mockito.when(opayoPaymentMapper.generateCardTransactionBaasApiRequest(context)).thenReturn(cardTransactionRequest);
        Mockito.when(opayoPaymentClient.makeCardTransaction(cardTransactionUrl, cardTransactionRequest)).thenReturn(TestDataCreator.generateChallengeCardTransactionResponse());

        assertNull(context.getCardTransactionResponse());
        opayoPaymentService.makeCardTransaction(context);
        Mockito.verify(opayoPaymentMapper, times(1)).generateCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(1)).makeCardTransaction(cardTransactionUrl, cardTransactionRequest);

        assertNotNull(context.getCardTransactionResponse());
        assertEquals("2021", context.getCardTransactionResponse().getStatus().getStatusCode());
        assertEquals("Please redirect your customer to the ACSURL to complete the 3DS Transaction", context.getCardTransactionResponse().getStatus().getStatusDetail());
    }

    @Test
    void testMakeCardTransactionFrictionlessOk() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        String cardTransactionUrl = "cardTransactionUrl";
        CardTransactionRequest cardTransactionRequest = TestDataCreator.generateDefaultCardTransactionRequest();

        Mockito.when(opayoConfig.getCardTransactionUrl()).thenReturn(cardTransactionUrl);
        Mockito.when(opayoPaymentMapper.generateCardTransactionBaasApiRequest(context)).thenReturn(cardTransactionRequest);
        Mockito.when(opayoPaymentClient.makeCardTransaction(cardTransactionUrl, cardTransactionRequest)).thenReturn(TestDataCreator.generateFrictionlessCardTransactionResponse());

        assertNull(context.getCardTransactionResponse());
        opayoPaymentService.makeCardTransaction(context);
        Mockito.verify(opayoPaymentMapper, times(1)).generateCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(1)).makeCardTransaction(cardTransactionUrl, cardTransactionRequest);

        assertNotNull(context.getCardTransactionResponse());
        assertEquals("0000", context.getCardTransactionResponse().getStatus().getStatusCode());
        assertEquals("The Authorisation was Successful.", context.getCardTransactionResponse().getStatus().getStatusDetail());
    }

    @Test
    void testMakeCardTransactionRejected() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        String cardTransactionUrl = "cardTransactionUrl";
        CardTransactionRequest cardTransactionRequest = TestDataCreator.generateDefaultCardTransactionRequest();

        Mockito.when(opayoConfig.getCardTransactionUrl()).thenReturn(cardTransactionUrl);
        Mockito.when(opayoPaymentMapper.generateCardTransactionBaasApiRequest(context)).thenReturn(cardTransactionRequest);
        Mockito.when(opayoPaymentClient.makeCardTransaction(cardTransactionUrl, cardTransactionRequest)).thenReturn(TestDataCreator.generateRejectedCardTransactionResponse());

        assertNull(context.getCardTransactionResponse());
        opayoPaymentService.makeCardTransaction(context);
        Mockito.verify(opayoPaymentMapper, times(1)).generateCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(1)).makeCardTransaction(cardTransactionUrl, cardTransactionRequest);

        assertNotNull(context.getCardTransactionResponse());
        assertEquals("2001", context.getCardTransactionResponse().getStatus().getStatusCode());
        assertEquals("Transaction rejected by the fraud rules you have in place.", context.getCardTransactionResponse().getStatus().getStatusDetail());
    }

    @Test
    void testConfirmCardTransactionOk() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialConfirmMortgageSingleOverpaymentContext();
        String confirmUrl = "/sanuk/internal/v1/card-transactions/{transactionId}/confirm";
        ConfirmCardTransactionRequest confirmCardTransactionRequest = TestDataCreator.generateDefaultConfirmCardTransactionRequest();

        Mockito.when(opayoConfig.getConfirmUrl()).thenReturn(confirmUrl);
        Mockito.when(opayoPaymentMapper.generateConfirmCardTransactionBaasApiRequest(context)).thenReturn(confirmCardTransactionRequest);
        Mockito.when(opayoPaymentClient.confirmCardTransaction("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", confirmCardTransactionRequest)).thenReturn(TestDataCreator.generateConfirmCardTransactionOkResponse());

        assertNull(context.getCardTransactionResponse());
        opayoPaymentService.confirmCardTransaction(context, "OPAYO2022100615004181713317643");
        Mockito.verify(opayoPaymentMapper, times(1)).generateConfirmCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(1)).confirmCardTransaction("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", confirmCardTransactionRequest);

        assertNotNull(context.getCardTransactionResponse());
        assertEquals("0000", context.getCardTransactionResponse().getStatus().getStatusCode());
        assertEquals("The Authorisation was Successful.", context.getCardTransactionResponse().getStatus().getStatusDetail());
    }

    @Test
    void testConfirmCardDeclined() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialConfirmMortgageSingleOverpaymentContext();
        String confirmUrl = "/sanuk/internal/v1/card-transactions/{transactionId}/confirm";
        ConfirmCardTransactionRequest confirmCardTransactionRequest = TestDataCreator.generateDefaultConfirmCardTransactionRequest();

        Mockito.when(opayoConfig.getConfirmUrl()).thenReturn(confirmUrl);
        Mockito.when(opayoPaymentMapper.generateConfirmCardTransactionBaasApiRequest(context)).thenReturn(confirmCardTransactionRequest);
        Mockito.when(opayoPaymentClient.confirmCardTransaction("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", confirmCardTransactionRequest)).thenReturn(TestDataCreator.generateDeclinedConfirmCardTransactionResponse());

        assertNull(context.getCardTransactionResponse());
        opayoPaymentService.confirmCardTransaction(context, "OPAYO2022100615004181713317643");
        Mockito.verify(opayoPaymentMapper, times(1)).generateConfirmCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(1)).confirmCardTransaction("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", confirmCardTransactionRequest);

        assertNotNull(context.getCardTransactionResponse());
        assertEquals("2000", context.getCardTransactionResponse().getStatus().getStatusCode());
        assertEquals("The Authorisation was Declined by the bank.", context.getCardTransactionResponse().getStatus().getStatusDetail());
    }

    @Test
    void testConfirmCardClientExc() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialConfirmMortgageSingleOverpaymentContext();
        String confirmUrl = "/sanuk/internal/v1/card-transactions/{transactionId}/confirm";
        ConfirmCardTransactionRequest confirmCardTransactionRequest = TestDataCreator.generateDefaultConfirmCardTransactionRequest();

        Mockito.when(opayoConfig.getConfirmUrl()).thenReturn(confirmUrl);
        Mockito.when(opayoPaymentMapper.generateConfirmCardTransactionBaasApiRequest(context)).thenReturn(confirmCardTransactionRequest);
        Mockito.when(opayoPaymentClient.confirmCardTransaction("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", confirmCardTransactionRequest)).thenThrow(new OpayoException("OPAYO_CLIENT_EXC", "Exception while calling confirm-transaction baas api"));

        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentService.confirmCardTransaction(context, "OPAYO2022100615004181713317643"));
        Mockito.verify(opayoPaymentMapper, times(1)).generateConfirmCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(1)).confirmCardTransaction("/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", confirmCardTransactionRequest);

        assertEquals("OPAYO_CLIENT_EXC", opayoException.getCode());
        assertEquals("Exception while calling confirm-transaction baas api", opayoException.getMessage());
    }

    @Test
    void testConfirmCardMapperExc() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialConfirmMortgageSingleOverpaymentContext();

        Mockito.when(opayoPaymentMapper.generateConfirmCardTransactionBaasApiRequest(context)).thenThrow(new OpayoException("OPAYO_MAPPER_EXC", "Exception While generating Opayo confirm-transaction request"));

        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentService.confirmCardTransaction(context, "OPAYO2022100615004181713317643"));
        Mockito.verify(opayoPaymentMapper, times(1)).generateConfirmCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(0)).confirmCardTransaction(anyString(), any());

        assertEquals("OPAYO_MAPPER_EXC", opayoException.getCode());
        assertEquals("Exception While generating Opayo confirm-transaction request", opayoException.getMessage());
    }

    @Test
    void testMakeCardTransactionClientExc() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        String cardTransactionUrl = "cardTransactionUrl";
        CardTransactionRequest cardTransactionRequest = TestDataCreator.generateDefaultCardTransactionRequest();

        Mockito.when(opayoPaymentMapper.generateCardTransactionBaasApiRequest(context)).thenReturn(cardTransactionRequest);
        Mockito.when(opayoConfig.getCardTransactionUrl()).thenReturn(cardTransactionUrl);
        Mockito.when(opayoPaymentClient.makeCardTransaction(cardTransactionUrl, cardTransactionRequest)).thenThrow(new OpayoException("OPAYO_CLIENT_EXC", "Exception while calling card-transaction baas api"));

        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentService.makeCardTransaction(context));
        Mockito.verify(opayoPaymentMapper, times(1)).generateCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(1)).makeCardTransaction(cardTransactionUrl, cardTransactionRequest);

        assertEquals("OPAYO_CLIENT_EXC", opayoException.getCode());
        assertEquals("Exception while calling card-transaction baas api", opayoException.getMessage());
    }

    @Test
    void testMakeCardTransactionMapperExc() throws IOException, OpayoException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();

        Mockito.when(opayoPaymentMapper.generateCardTransactionBaasApiRequest(context)).thenThrow(new OpayoException("OPAYO_MAPPER_EXC", "Exception While generating Opayo card-transaction request"));

        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentService.makeCardTransaction(context));
        Mockito.verify(opayoPaymentMapper, times(1)).generateCardTransactionBaasApiRequest(context);
        Mockito.verify(opayoPaymentClient, times(0)).makeCardTransaction(any(), any());

        assertEquals("OPAYO_MAPPER_EXC", opayoException.getCode());
        assertEquals("Exception While generating Opayo card-transaction request", opayoException.getMessage());
    }

    @Test
    void testUpdateCPS() throws IOException, GeneralException {
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();

        CPSCardPaymentRequest cpsCardPaymentRequest = getCPSCardPaymentRequest();

        when(opayoConfig.getAnmfSortcode()).thenReturn("091586");
        when(opayoPaymentMapper.generateCPSCardPaymentRequest(cardMortgageSingleOverpaymentsContext, "091586012345678")).thenReturn(cpsCardPaymentRequest);
        Mockito.doNothing().when(opayoPaymentClient).updateCPS(cpsCardPaymentRequest);

        opayoPaymentService.updateCPS(cardMortgageSingleOverpaymentsContext);

        verify(opayoPaymentMapper, times(1)).generateCPSCardPaymentRequest(cardMortgageSingleOverpaymentsContext, "091586012345678");
        verify(opayoPaymentClient, times(1)).updateCPS(cpsCardPaymentRequest);
    }

    @Test
    void testUpdateCPSClientExcNotThrown() throws IOException, GeneralException {
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();

        CPSCardPaymentRequest cpsCardPaymentRequest = getCPSCardPaymentRequest();

        when(opayoConfig.getAnmfSortcode()).thenReturn("091586");
        when(opayoPaymentMapper.generateCPSCardPaymentRequest(cardMortgageSingleOverpaymentsContext, "091586012345678")).thenReturn(cpsCardPaymentRequest);
        Mockito.doThrow(new OpayoException("OPAYO_CLIENT_EXC", "Exception while calling Update CPS baas api")).when(opayoPaymentClient).updateCPS(cpsCardPaymentRequest);

        opayoPaymentService.updateCPS(cardMortgageSingleOverpaymentsContext);

        verify(opayoPaymentMapper, times(1)).generateCPSCardPaymentRequest(cardMortgageSingleOverpaymentsContext, "091586012345678");
        verify(opayoPaymentClient, times(1)).updateCPS(cpsCardPaymentRequest);
    }

    @Test
    void testUpdateCPSMapperExcNotThrown() throws IOException, GeneralException {
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();

        when(opayoConfig.getAnmfSortcode()).thenReturn("091586");
        when(opayoPaymentMapper.generateCPSCardPaymentRequest(cardMortgageSingleOverpaymentsContext, "091586123456789")).thenThrow(new OpayoException("OPAYO_MAPPER_EXC", "Failed to generate Update CPS Request"));

        opayoPaymentService.updateCPS(cardMortgageSingleOverpaymentsContext);

        verify(opayoPaymentMapper, times(1)).generateCPSCardPaymentRequest(cardMortgageSingleOverpaymentsContext, "091586012345678");
        verify(opayoPaymentClient, times(0)).updateCPS(any());
    }

    private CPSCardPaymentRequest getCPSCardPaymentRequest() {
        CPSCardPaymentRequest cpsCardPaymentRequest = new CPSCardPaymentRequest();
        cpsCardPaymentRequest.setMerchantId("88120066");
        cpsCardPaymentRequest.setAgentCode("Corinthian");
        cpsCardPaymentRequest.setAmount(BigDecimal.valueOf(10));
        cpsCardPaymentRequest.setBankAuthorisationCode("999779");
        cpsCardPaymentRequest.setBirthDate("1972-07-08");
        cpsCardPaymentRequest.setCardId("AB35A8F8-9175-4100-A34F-1E80A2EF756A");
        cpsCardPaymentRequest.setContractAccountNumber("0042263");
        cpsCardPaymentRequest.setContractBranch("2898");
        cpsCardPaymentRequest.setContractEntity("0015");
        cpsCardPaymentRequest.setContractId("0003");
        cpsCardPaymentRequest.setContractProduct("103");
        cpsCardPaymentRequest.setCurrency("GBP");
        cpsCardPaymentRequest.setExpiryDate("0123");
        cpsCardPaymentRequest.setIssueNumber(0);
        cpsCardPaymentRequest.setLine1("88 Blaker");
        cpsCardPaymentRequest.setMerchantId("88120066");
        cpsCardPaymentRequest.setNumber("4462000000000003");
        cpsCardPaymentRequest.setNumberAnt("091586003300210");
        cpsCardPaymentRequest.setPersonName("JASON COXXXXXXXX");
        cpsCardPaymentRequest.setPersonNumber(16644039);
        cpsCardPaymentRequest.setPersonType("F");
        cpsCardPaymentRequest.setPostCodeIdentification("BN41 2AD");
        cpsCardPaymentRequest.setPostCodeRegular("BN41 2AD");
        cpsCardPaymentRequest.setPrintedName("Goku");
        cpsCardPaymentRequest.setProcess("MTG");
        cpsCardPaymentRequest.setStartDate("");
        cpsCardPaymentRequest.setStatusCode("0000");
        cpsCardPaymentRequest.setStatusDetail("The Authorisation was Successful.");
        cpsCardPaymentRequest.setTransactionId("OPAYO2022092216240467704187376");
        cpsCardPaymentRequest.setVendorCode("09e3683a38474237924e403e9a0e96");
        return cpsCardPaymentRequest;
    }
}
