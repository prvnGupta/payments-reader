package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;

@ExtendWith(MockitoExtension.class)
class SetupPaymentClientTest {

    SetupPaymentClient setupPaymentClient;
    @Mock
    private OverpaymentsConfig overpaymentsConfig;
    @Mock
    private RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        setupPaymentClient = new SetupPaymentClient(restTemplate, overpaymentsConfig);
    }

    @Test
    void testCallSetupPaymentOk() throws IOException, PaymentsFuncException {
        Mockito.when(overpaymentsConfig.getClientId()).thenReturn("client-id");
        Mockito.when(overpaymentsConfig.getSetupEndpoint()).thenReturn("https://dummyUrl.corp/sanuk/internal/core/payments/partenon-internal-transfer/setup");
        Mockito.when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(SetupResponse.class))).thenReturn(TestDataCreator.generateSetupPaymentResponseEntityOk());

        SetupResponse setupResponse = setupPaymentClient.callSetup(TestDataCreator.generateSetupPaymentDefaultRequest());

        assertEquals("Payment setup successful", setupResponse.getStatusDescription());

    }

    @Test
    void testCallSetupPaymentKo() throws IOException {
        Mockito.when(overpaymentsConfig.getClientId()).thenReturn("client-id");
        Mockito.when(overpaymentsConfig.getSetupEndpoint()).thenReturn("https://dummyUrl.corp/sanuk/internal/core/payments/partenon-internal-transfer/setup");
        Mockito.when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(SetupResponse.class))).thenReturn(TestDataCreator.generateSetupPaymentResponseEntityKo());

        PaymentsFuncException paymentsFuncException = assertThrows(PaymentsFuncException.class, () -> setupPaymentClient.callSetup(TestDataCreator.generateSetupPaymentDefaultRequest()));
        assertEquals("PAYMENT_ERROR_SPE", paymentsFuncException.getMessage());
    }

    @Test
    void testCallSetupPaymentException() {
        Mockito.when(overpaymentsConfig.getClientId()).thenReturn("client-id");
        Mockito.when(overpaymentsConfig.getSetupEndpoint()).thenReturn("https://dummyUrl.corp/sanuk/internal/core/payments/partenon-internal-transfer/setup");
        Mockito.when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), eq(SetupResponse.class))).thenThrow(RestClientException.class);

        PaymentsFuncException paymentsFuncException = assertThrows(PaymentsFuncException.class, () -> setupPaymentClient.callSetup(TestDataCreator.generateSetupPaymentDefaultRequest()));
        assertEquals("PAYMENT_ERROR_SPE", paymentsFuncException.getMessage());
    }
}
