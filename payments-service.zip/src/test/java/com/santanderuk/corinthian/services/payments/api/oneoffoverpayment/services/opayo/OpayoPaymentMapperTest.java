package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request.CardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.confirmtransaction.request.ConfirmCardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cps.CPSCardPaymentRequest;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.math.BigDecimal;

import static com.santanderuk.corinthian.services.payments.TestDataCreator.generateContextSimulationResponse;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@ActiveProfiles("test")
class OpayoPaymentMapperTest {

    @Mock
    OpayoConfig opayoConfig;
    @Mock
    OpayoUtils opayoUtils;


    private OpayoPaymentMapper opayoPaymentMapper;

    @BeforeEach
    void setUp() {
        opayoPaymentMapper = new OpayoPaymentMapper(opayoConfig, opayoUtils);
    }

    @Test
    void testHappyPathMapperCardTransaction() throws IOException, OpayoException {
        when(opayoUtils.generateVendorCode(anyString())).thenReturn("O20230113095559360804462000003");
        when(opayoConfig.isReusable()).thenReturn(false);
        when(opayoConfig.isSave()).thenReturn(false);
        when(opayoConfig.getSubject()).thenReturn("Santander mortgage overpayment");
        when(opayoConfig.getCurrency()).thenReturn("GBP");
        when(opayoConfig.getVendorName()).thenReturn("santandertest");
        when(opayoConfig.isGiftAid()).thenReturn(false);
        when(opayoConfig.getEntryMethod()).thenReturn("Ecommerce");
        when(opayoConfig.getAgentCode()).thenReturn("Corinthian");
        when(opayoConfig.getMerchantId()).thenReturn("88120066");
        when(opayoConfig.getApply3DSecure()).thenReturn("force");
        when(opayoConfig.getNotificationUrl()).thenReturn("/callback");
        when(opayoConfig.getTransType()).thenReturn("GoodsAndServicePurchase");


        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        context.getCardTransactionDetails().setUpdatedSimulationResponse(generateContextSimulationResponse());
        CardTransactionRequest cardTransactionRequest = opayoPaymentMapper.generateCardTransactionBaasApiRequest(context);

        //card data
        assertEquals("4462000000000003", cardTransactionRequest.getCardData().getNumber());
        assertEquals("123", cardTransactionRequest.getCardData().getCvv());
        assertEquals("James Smith", cardTransactionRequest.getCardData().getPrintedName());
        assertFalse(cardTransactionRequest.getCardData().isReusable());
        assertFalse(cardTransactionRequest.getCardData().isSave());
        assertEquals("01", cardTransactionRequest.getCardData().getExpiration().getMonth());
        assertEquals("26", cardTransactionRequest.getCardData().getExpiration().getYear());

        //payment data
        assertEquals("Santander mortgage overpayment", cardTransactionRequest.getPaymentData().getSubject());
        assertEquals("123456789", cardTransactionRequest.getPaymentData().getPayer().getAccount().getContract().getContractId());
        assertEquals("line 1 Westbury Farm Studios Group Westbury Farm ", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getLine1());
        assertEquals("line 2 Witan Gate Foxcovert Road", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getLine2());
        assertEquals("Milton Keynes", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getCity().getName());
        assertEquals("MK92BQ", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getPostCodeIdentification());
        assertEquals("GB", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getCountry().getCode());
        assertEquals("James", cardTransactionRequest.getPaymentData().getPayer().getPerson().getPersonName().getGivenName());
        assertEquals("Smith", cardTransactionRequest.getPaymentData().getPayer().getPerson().getPersonName().getLastName());
        assertEquals("1990-06-01", cardTransactionRequest.getPaymentData().getPayer().getPerson().getBirthDate());
        assertEquals("MK92BQ", cardTransactionRequest.getPaymentData().getPayer().getPerson().getPostcodeRegular());
        assertEquals("GBP", cardTransactionRequest.getPaymentData().getPaymentAmount().getCurrency());
        assertEquals(new BigDecimal("5000"), cardTransactionRequest.getPaymentData().getPaymentAmount().getAmount());

        //vendorData
        assertEquals("santandertest", cardTransactionRequest.getVendorData().getVendorName());
        assertEquals("O20230113095559360804462000003", cardTransactionRequest.getVendorData().getVendorCode());
        Mockito.verify(opayoUtils, times(1)).generateVendorCode("4462000000000003");

        // AdditionalData
        assertEquals("Corinthian", cardTransactionRequest.getAdditionalData().getAgentCode());
        assertEquals("Ecommerce", cardTransactionRequest.getAdditionalData().getEntryMethod());
        assertEquals("force", cardTransactionRequest.getAdditionalData().getApply3DSecure());
        assertEquals("88120066", cardTransactionRequest.getAdditionalData().getMerchantId());
        assertFalse(cardTransactionRequest.getAdditionalData().isGiftAid());
        assertEquals("GoodsAndServicePurchase", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getTransType());
        assertEquals("127.0.0.1", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserIP());
        assertEquals("text/html, application/json", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserAcceptHeader());
        assertEquals("en-GB", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserLanguage());
        assertEquals("False", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserJavascriptEnabled());
        assertEquals("Mozilla/5.0", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserUserAgent());
        assertEquals("Small", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getChallengeWindowSize());
        assertEquals("https://dummyUrl.com/callback", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getNotificationURL());
    }

    @Test
    void testHappyPathMapperBlankOrigin() throws IOException, OpayoException {
        when(opayoUtils.generateVendorCode(anyString())).thenReturn("O20230113095559360804462000003");
        when(opayoConfig.isReusable()).thenReturn(false);
        when(opayoConfig.isSave()).thenReturn(false);
        when(opayoConfig.getSubject()).thenReturn("Santander mortgage overpayment");
        when(opayoConfig.getCurrency()).thenReturn("GBP");
        when(opayoConfig.getVendorName()).thenReturn("santandertest");
        when(opayoConfig.isGiftAid()).thenReturn(false);
        when(opayoConfig.getEntryMethod()).thenReturn("Ecommerce");
        when(opayoConfig.getAgentCode()).thenReturn("Corinthian");
        when(opayoConfig.getMerchantId()).thenReturn("88120066");
        when(opayoConfig.getApply3DSecure()).thenReturn("force");
        when(opayoConfig.getNotificationUrl()).thenReturn("/callback");
        when(opayoConfig.getDefaultLiveDomain()).thenReturn("https://DefaultdummyUrl.com");
        when(opayoConfig.getTransType()).thenReturn("GoodsAndServicePurchase");


        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        context.setOrigin("");
        context.getCardTransactionDetails().setUpdatedSimulationResponse(generateContextSimulationResponse());
        CardTransactionRequest cardTransactionRequest = opayoPaymentMapper.generateCardTransactionBaasApiRequest(context);

        //card data
        assertEquals("4462000000000003", cardTransactionRequest.getCardData().getNumber());
        assertEquals("123", cardTransactionRequest.getCardData().getCvv());
        assertEquals("James Smith", cardTransactionRequest.getCardData().getPrintedName());
        assertFalse(cardTransactionRequest.getCardData().isReusable());
        assertFalse(cardTransactionRequest.getCardData().isSave());
        assertEquals("01", cardTransactionRequest.getCardData().getExpiration().getMonth());
        assertEquals("26", cardTransactionRequest.getCardData().getExpiration().getYear());

        //payment data
        assertEquals("Santander mortgage overpayment", cardTransactionRequest.getPaymentData().getSubject());
        assertEquals("123456789", cardTransactionRequest.getPaymentData().getPayer().getAccount().getContract().getContractId());
        assertEquals("line 1 Westbury Farm Studios Group Westbury Farm ", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getLine1());
        assertEquals("line 2 Witan Gate Foxcovert Road", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getLine2());
        assertEquals("Milton Keynes", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getCity().getName());
        assertEquals("MK92BQ", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getPostCodeIdentification());
        assertEquals("GB", cardTransactionRequest.getPaymentData().getPayer().getContactPoint().getPostalAddress().getCountry().getCode());
        assertEquals("James", cardTransactionRequest.getPaymentData().getPayer().getPerson().getPersonName().getGivenName());
        assertEquals("Smith", cardTransactionRequest.getPaymentData().getPayer().getPerson().getPersonName().getLastName());
        assertEquals("1990-06-01", cardTransactionRequest.getPaymentData().getPayer().getPerson().getBirthDate());
        assertEquals("MK92BQ", cardTransactionRequest.getPaymentData().getPayer().getPerson().getPostcodeRegular());
        assertEquals("GBP", cardTransactionRequest.getPaymentData().getPaymentAmount().getCurrency());
        assertEquals(new BigDecimal("5000"), cardTransactionRequest.getPaymentData().getPaymentAmount().getAmount());

        //vendorData
        assertEquals("santandertest", cardTransactionRequest.getVendorData().getVendorName());
        assertEquals("O20230113095559360804462000003", cardTransactionRequest.getVendorData().getVendorCode());
        Mockito.verify(opayoUtils, times(1)).generateVendorCode("4462000000000003");

        // AdditionalData
        assertEquals("Corinthian", cardTransactionRequest.getAdditionalData().getAgentCode());
        assertEquals("Ecommerce", cardTransactionRequest.getAdditionalData().getEntryMethod());
        assertEquals("force", cardTransactionRequest.getAdditionalData().getApply3DSecure());
        assertEquals("88120066", cardTransactionRequest.getAdditionalData().getMerchantId());
        assertFalse(cardTransactionRequest.getAdditionalData().isGiftAid());
        assertEquals("GoodsAndServicePurchase", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getTransType());
        assertEquals("127.0.0.1", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserIP());
        assertEquals("text/html, application/json", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserAcceptHeader());
        assertEquals("en-GB", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserLanguage());
        assertEquals("False", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserJavascriptEnabled());
        assertEquals("Mozilla/5.0", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getBrowserUserAgent());
        assertEquals("Small", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getChallengeWindowSize());
        assertEquals("https://DefaultdummyUrl.com/callback", cardTransactionRequest.getAdditionalData().getStrongCustomerAuthentication().getNotificationURL());
    }

    @Test
    void testZeroLeftPadMortgageAccount() throws IOException, OpayoException {
        when(opayoUtils.generateVendorCode(anyString())).thenReturn("O20230113095559360804462000003");
        when(opayoConfig.isReusable()).thenReturn(false);
        when(opayoConfig.isSave()).thenReturn(false);
        when(opayoConfig.getSubject()).thenReturn("Santander mortgage overpayment");
        when(opayoConfig.getCurrency()).thenReturn("GBP");
        when(opayoConfig.getVendorName()).thenReturn("santandertest");
        when(opayoConfig.isGiftAid()).thenReturn(false);
        when(opayoConfig.getEntryMethod()).thenReturn("Ecommerce");
        when(opayoConfig.getAgentCode()).thenReturn("Corinthian");
        when(opayoConfig.getMerchantId()).thenReturn("88120066");
        when(opayoConfig.getApply3DSecure()).thenReturn("force");
        when(opayoConfig.getNotificationUrl()).thenReturn("/callback");
        when(opayoConfig.getDefaultLiveDomain()).thenReturn("https://DefaultdummyUrl.com");
        when(opayoConfig.getTransType()).thenReturn("GoodsAndServicePurchase");


        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        context.setMortgageAccount(3333333);
        context.setOrigin("");
        context.getCardTransactionDetails().setUpdatedSimulationResponse(generateContextSimulationResponse());
        CardTransactionRequest cardTransactionRequest = opayoPaymentMapper.generateCardTransactionBaasApiRequest(context);

        assertEquals("003333333", cardTransactionRequest.getPaymentData().getPayer().getAccount().getContract().getContractId());

    }

    @Test
    void testHappyPathMapperConfirmTransaction() throws IOException, OpayoException {

        when(opayoConfig.getVendorName()).thenReturn("santandertest");
        when(opayoConfig.getConfirmType()).thenReturn("challenge");

        ConfirmCardTransactionRequest confirmCardTransactionRequest = opayoPaymentMapper.generateConfirmCardTransactionBaasApiRequest(TestDataCreator.generateInitialConfirmMortgageSingleOverpaymentContext());

        assertEquals("challenge", confirmCardTransactionRequest.getConfirmType());
        assertEquals("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcyIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI3NTA5OTg5My05ZmY4LTQ0MmItOTQ1NC1kZjM3MGQzZjU3M2QiLAogICJhY3NUcmFuc0lEIiA6ICI0MGMxZDExOS1kMTE2LTRiNzItODg5OS00YWUyYzBmNWY5OWMiLAogICJ0cmFuc1N0YXR1cyIgOiAiWSIKfQ", confirmCardTransactionRequest.getInputCode());
        //vendorData
        assertEquals("santandertest", confirmCardTransactionRequest.getVendorData().getVendorName());
        assertEquals("O20230113095559360804462000003", confirmCardTransactionRequest.getVendorData().getVendorCode());
        Mockito.verify(opayoUtils, times(0)).generateVendorCode(anyString());

    }

    @Test
    void testExcMapperConfirmTransaction() {

        when(opayoConfig.getVendorName()).thenThrow(NullPointerException.class);

        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentMapper.generateConfirmCardTransactionBaasApiRequest(TestDataCreator.generateInitialConfirmMortgageSingleOverpaymentContext()));
        assertEquals("OPAYO_MAPPER_EXC", opayoException.getCode());
        assertEquals("Exception While generating Opayo confirm-transaction request", opayoException.getMessage());

    }

    @Test
    void testExceptionCardTransactionRequestMapper() throws IOException {
        when(opayoConfig.isReusable()).thenReturn(false);
        when(opayoConfig.isSave()).thenReturn(false);
        when(opayoConfig.getSubject()).thenReturn("Santander mortgage overpayment");
        when(opayoConfig.getCurrency()).thenReturn("GBP");
        when(opayoConfig.getVendorName()).thenReturn("santandertest");
        when(opayoUtils.generateVendorCode("4462000000000003")).thenThrow(NullPointerException.class);

        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        context.getCardTransactionDetails().setUpdatedSimulationResponse(generateContextSimulationResponse());

        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentMapper.generateCardTransactionBaasApiRequest(context));
        assertEquals("OPAYO_MAPPER_EXC", opayoException.getCode());
        assertEquals("Exception While generating Opayo card-transaction request", opayoException.getMessage());


    }

    @Test
    void testGenerateCPSCardPaymentRequest() throws IOException, GeneralException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber("0015", "2898", "103", "0042263");
        context.setAnmfPartenonAccountNumber(partenonAccountNumber);
        String mortgageSortCodeAccount = "091586123456789";

        when(opayoConfig.getMerchantId()).thenReturn("88120066");
        when(opayoConfig.getAgentCode()).thenReturn("Corinthian");
        when(opayoConfig.getCurrency()).thenReturn("GBP");
        when(opayoConfig.getIssueNumber()).thenReturn(0);
        when(opayoConfig.getCpsProcess()).thenReturn("MTG");
        Mockito.verify(opayoUtils, times(0)).generateVendorCode(anyString());

        CPSCardPaymentRequest cpsCardPaymentRequest = opayoPaymentMapper.generateCPSCardPaymentRequest(context, mortgageSortCodeAccount);
        assertEquals("AB8E89BA-7594-4170-8529-32F1AFB0AFFC", cpsCardPaymentRequest.getCardId());
        assertEquals("Corinthian", cpsCardPaymentRequest.getAgentCode());
        assertEquals(new BigDecimal("5000"), cpsCardPaymentRequest.getAmount());
        assertEquals("999779", cpsCardPaymentRequest.getBankAuthorisationCode());
        assertEquals("1990-06-01", cpsCardPaymentRequest.getBirthDate());
        assertEquals("0042263", cpsCardPaymentRequest.getContractAccountNumber());
        assertEquals("2898", cpsCardPaymentRequest.getContractBranch());
        assertEquals("0015", cpsCardPaymentRequest.getContractEntity());
        assertEquals("0003", cpsCardPaymentRequest.getContractId());
        assertEquals("103", cpsCardPaymentRequest.getContractProduct());
        assertEquals("GBP", cpsCardPaymentRequest.getCurrency());
        assertEquals("1023", cpsCardPaymentRequest.getExpiryDate());
        assertEquals(0, cpsCardPaymentRequest.getIssueNumber());
        assertEquals("88120066", cpsCardPaymentRequest.getMerchantId());
        assertEquals("4462000000000003", cpsCardPaymentRequest.getNumber());
        assertEquals("091586123456789", cpsCardPaymentRequest.getNumberAnt());
        assertEquals("James Smith", cpsCardPaymentRequest.getPersonName());
        assertEquals(554, cpsCardPaymentRequest.getPersonNumber());
        assertEquals("42 Wickst", cpsCardPaymentRequest.getLine1());
        assertEquals("F", cpsCardPaymentRequest.getPersonType());
        assertEquals("MK60NW", cpsCardPaymentRequest.getPostCodeIdentification());
        assertEquals("MK60NW", cpsCardPaymentRequest.getPostCodeRegular());
        assertEquals("James Smith", cpsCardPaymentRequest.getPrintedName());
        assertEquals("MTG", cpsCardPaymentRequest.getProcess());
        assertEquals("0000", cpsCardPaymentRequest.getStatusCode());
        assertEquals("The Authorisation was Successful.", cpsCardPaymentRequest.getStatusDetail());
        assertEquals("OPAYO2022100710021957062894449", cpsCardPaymentRequest.getTransactionId());
        assertEquals("O20230113095559360804462000003", cpsCardPaymentRequest.getVendorCode());
    }

    @Test
    void testCPSConfirmExc_noCardTransactionResponse() throws IOException, GeneralException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        context.setCardTransactionResponse(null);
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber("0015", "2898", "103", "0042263");
        context.setAnmfPartenonAccountNumber(partenonAccountNumber);
        String mortgageSortCodeAccount = "091586123456789";

        when(opayoConfig.getMerchantId()).thenReturn("88120066");
        when(opayoConfig.getAgentCode()).thenReturn("Corinthian");
        when(opayoConfig.getCurrency()).thenReturn("GBP");
        when(opayoConfig.getIssueNumber()).thenReturn(0);
        when(opayoConfig.getCpsProcess()).thenReturn("MTG");
        Mockito.verify(opayoUtils, times(0)).generateVendorCode(anyString());

        CPSCardPaymentRequest cpsCardPaymentRequest = opayoPaymentMapper.generateCPSCardPaymentRequest(context, mortgageSortCodeAccount);
        assertEquals("00000000-0000-0000-0000-000000000000", cpsCardPaymentRequest.getCardId());
        assertEquals("Corinthian", cpsCardPaymentRequest.getAgentCode());
        assertEquals(new BigDecimal("5000"), cpsCardPaymentRequest.getAmount());
        assertEquals("999999", cpsCardPaymentRequest.getBankAuthorisationCode());
        assertEquals("1990-06-01", cpsCardPaymentRequest.getBirthDate());
        assertEquals("0042263", cpsCardPaymentRequest.getContractAccountNumber());
        assertEquals("2898", cpsCardPaymentRequest.getContractBranch());
        assertEquals("0015", cpsCardPaymentRequest.getContractEntity());
        assertEquals("0003", cpsCardPaymentRequest.getContractId());
        assertEquals("103", cpsCardPaymentRequest.getContractProduct());
        assertEquals("GBP", cpsCardPaymentRequest.getCurrency());
        assertEquals("1023", cpsCardPaymentRequest.getExpiryDate());
        assertEquals(0, cpsCardPaymentRequest.getIssueNumber());
        assertEquals("88120066", cpsCardPaymentRequest.getMerchantId());
        assertEquals("4462000000000003", cpsCardPaymentRequest.getNumber());
        assertEquals("091586123456789", cpsCardPaymentRequest.getNumberAnt());
        assertEquals("James Smith", cpsCardPaymentRequest.getPersonName());
        assertEquals(554, cpsCardPaymentRequest.getPersonNumber());
        assertEquals("42 Wickst", cpsCardPaymentRequest.getLine1());
        assertEquals("F", cpsCardPaymentRequest.getPersonType());
        assertEquals("MK60NW", cpsCardPaymentRequest.getPostCodeIdentification());
        assertEquals("MK60NW", cpsCardPaymentRequest.getPostCodeRegular());
        assertEquals("James Smith", cpsCardPaymentRequest.getPrintedName());
        assertEquals("MTG", cpsCardPaymentRequest.getProcess());
        assertEquals("9999", cpsCardPaymentRequest.getStatusCode());
        assertEquals("Error 500 from Confirm Baas Api", cpsCardPaymentRequest.getStatusDetail());
        assertEquals("", cpsCardPaymentRequest.getTransactionId());
        assertEquals("O20230113095559360804462000003", cpsCardPaymentRequest.getVendorCode());
    }

    @Test
    void testCPSRejected2Exception() throws IOException, GeneralException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStepRejected2();
        PartenonAccountNumber partenonAccountNumber = new PartenonAccountNumber("0015", "2898", "103", "0042263");
        context.setAnmfPartenonAccountNumber(partenonAccountNumber);
        String mortgageSortCodeAccount = "091586123456789";

        when(opayoConfig.getMerchantId()).thenReturn("88120066");
        when(opayoConfig.getAgentCode()).thenReturn("Corinthian");
        when(opayoConfig.getCurrency()).thenReturn("GBP");
        when(opayoConfig.getIssueNumber()).thenReturn(0);
        when(opayoConfig.getCpsProcess()).thenReturn("MTG");
        Mockito.verify(opayoUtils, times(0)).generateVendorCode(anyString());

        CPSCardPaymentRequest cpsCardPaymentRequest = opayoPaymentMapper.generateCPSCardPaymentRequest(context, mortgageSortCodeAccount);
        assertEquals("00000000-0000-0000-0000-000000000000", cpsCardPaymentRequest.getCardId());
        assertEquals("Corinthian", cpsCardPaymentRequest.getAgentCode());
        assertEquals(new BigDecimal("5000"), cpsCardPaymentRequest.getAmount());
        assertEquals("999999", cpsCardPaymentRequest.getBankAuthorisationCode());
        assertEquals("1990-06-01", cpsCardPaymentRequest.getBirthDate());
        assertEquals("0042263", cpsCardPaymentRequest.getContractAccountNumber());
        assertEquals("2898", cpsCardPaymentRequest.getContractBranch());
        assertEquals("0015", cpsCardPaymentRequest.getContractEntity());
        assertEquals("0003", cpsCardPaymentRequest.getContractId());
        assertEquals("103", cpsCardPaymentRequest.getContractProduct());
        assertEquals("GBP", cpsCardPaymentRequest.getCurrency());
        assertEquals("1023", cpsCardPaymentRequest.getExpiryDate());
        assertEquals(0, cpsCardPaymentRequest.getIssueNumber());
        assertEquals("88120066", cpsCardPaymentRequest.getMerchantId());
        assertEquals("4462000000000003", cpsCardPaymentRequest.getNumber());
        assertEquals("091586123456789", cpsCardPaymentRequest.getNumberAnt());
        assertEquals("James Smith", cpsCardPaymentRequest.getPersonName());
        assertEquals(554, cpsCardPaymentRequest.getPersonNumber());
        assertEquals("42 Wickst", cpsCardPaymentRequest.getLine1());
        assertEquals("F", cpsCardPaymentRequest.getPersonType());
        assertEquals("MK60NW", cpsCardPaymentRequest.getPostCodeIdentification());
        assertEquals("MK60NW", cpsCardPaymentRequest.getPostCodeRegular());
        assertEquals("James Smith", cpsCardPaymentRequest.getPrintedName());
        assertEquals("MTG", cpsCardPaymentRequest.getProcess());
        assertEquals("3336", cpsCardPaymentRequest.getStatusCode());
        assertEquals("3D-Authentication failed. Authentication has been rejected by the issuer.", cpsCardPaymentRequest.getStatusDetail());
        assertEquals("OPAYO2023012520452727728957813", cpsCardPaymentRequest.getTransactionId());
        assertEquals("O20230113095559360804462000003", cpsCardPaymentRequest.getVendorCode());
    }

    @Test
    void testThrowGeneralExceptionOnInvalidRequest() throws IOException {
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        String mortgageSortCodeAccount = "091586003300210";
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(null);
        assertThrows(GeneralException.class, () -> opayoPaymentMapper.generateCPSCardPaymentRequest(cardMortgageSingleOverpaymentsContext, mortgageSortCodeAccount));
    }

}
