package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac;

import com.santanderuk.corinthian.services.commons.clients.lac.LocalAccountConverterClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class LacServiceTest {

    @MockBean
    private EndpointConfiguration endpointConfiguration;

    @MockBean
    private LocalAccountConverterClient localAccountConverterClient;

    @SpyBean
    private InternalAccountFormatConverter internalAccountFormatConverter;

    private LacService lacService;

    @BeforeEach
    void setUp() {
        lacService = new LacService(endpointConfiguration, localAccountConverterClient, internalAccountFormatConverter);
        when(endpointConfiguration.getLacUrl()).thenReturn("url");
    }

    @Test
    void testGetAccountsDetailsHappyPath() throws GeneralException {
        LocalAccountNumber accountFrom = new LocalAccountNumber("090128", "12345678");
        LocalAccountNumber accountTo = new LocalAccountNumber("SAVING", "R15324808OZE");

        when(localAccountConverterClient.localAccountToPartenonFormat("url", "09012812345678")).thenReturn("001542473001234567");
        when(localAccountConverterClient.localAccountToPartenonFormat("url", "SAVINGR15324808")).thenReturn("001542473017654321");

        InternalTransferAccountsDetails accountsDetails = lacService.getAccountsDetails(accountFrom, accountTo);

        Mockito.verify(internalAccountFormatConverter, times(1)).convertLocalAccountNumberToStringFormat(accountFrom);
        Mockito.verify(internalAccountFormatConverter, times(1)).convertLocalAccountNumberToStringFormat(accountTo);

        Mockito.verify(localAccountConverterClient, times(1)).localAccountToPartenonFormat("url", "09012812345678");
        Mockito.verify(localAccountConverterClient, times(1)).localAccountToPartenonFormat("url", "SAVINGR15324808");

        Mockito.verify(internalAccountFormatConverter, times(1)).convertStringToPartenonAccountNumber("001542473001234567");
        Mockito.verify(internalAccountFormatConverter, times(1)).convertStringToPartenonAccountNumber("001542473017654321");

        Assertions.assertEquals("090128", accountsDetails.getAccountFrom().getLocalAccountNumber().getSortcode());
        Assertions.assertEquals("12345678", accountsDetails.getAccountFrom().getLocalAccountNumber().getAccountNumber());

        Assertions.assertEquals("0015", accountsDetails.getAccountFrom().getPartenonAccountNumber().getCompany());
        Assertions.assertEquals("4247", accountsDetails.getAccountFrom().getPartenonAccountNumber().getCentre());
        Assertions.assertEquals("300", accountsDetails.getAccountFrom().getPartenonAccountNumber().getProduct());
        Assertions.assertEquals("1234567", accountsDetails.getAccountFrom().getPartenonAccountNumber().getContract());

        Assertions.assertEquals("SAVING", accountsDetails.getAccountTo().getLocalAccountNumber().getSortcode());
        Assertions.assertEquals("R15324808OZE", accountsDetails.getAccountTo().getLocalAccountNumber().getAccountNumber());

        Assertions.assertEquals("0015", accountsDetails.getAccountTo().getPartenonAccountNumber().getCompany());
        Assertions.assertEquals("4247", accountsDetails.getAccountTo().getPartenonAccountNumber().getCentre());
        Assertions.assertEquals("301", accountsDetails.getAccountTo().getPartenonAccountNumber().getProduct());
        Assertions.assertEquals("7654321", accountsDetails.getAccountTo().getPartenonAccountNumber().getContract());
    }

    @Test
    void testGetAccountsDetailsHappyPathSavingOtherFormats() throws GeneralException {
        LocalAccountNumber accountFrom = new LocalAccountNumber("SAVING", "R12345678");
        LocalAccountNumber accountTo = new LocalAccountNumber("SAVING", "R15324808 OZE");

        when(localAccountConverterClient.localAccountToPartenonFormat("url", "SAVINGR12345678")).thenReturn("001542473001234567");
        when(localAccountConverterClient.localAccountToPartenonFormat("url", "SAVINGR15324808")).thenReturn("001542473017654321");

        InternalTransferAccountsDetails accountsDetails = lacService.getAccountsDetails(accountFrom, accountTo);

        Mockito.verify(internalAccountFormatConverter, times(1)).convertLocalAccountNumberToStringFormat(accountFrom);
        Mockito.verify(internalAccountFormatConverter, times(1)).convertLocalAccountNumberToStringFormat(accountTo);

        Mockito.verify(localAccountConverterClient, times(1)).localAccountToPartenonFormat("url", "SAVINGR12345678");
        Mockito.verify(localAccountConverterClient, times(1)).localAccountToPartenonFormat("url", "SAVINGR15324808");

        Mockito.verify(internalAccountFormatConverter, times(1)).convertStringToPartenonAccountNumber("001542473001234567");
        Mockito.verify(internalAccountFormatConverter, times(1)).convertStringToPartenonAccountNumber("001542473017654321");

        Assertions.assertEquals("SAVING", accountsDetails.getAccountFrom().getLocalAccountNumber().getSortcode());
        Assertions.assertEquals("R12345678", accountsDetails.getAccountFrom().getLocalAccountNumber().getAccountNumber());

        Assertions.assertEquals("0015", accountsDetails.getAccountFrom().getPartenonAccountNumber().getCompany());
        Assertions.assertEquals("4247", accountsDetails.getAccountFrom().getPartenonAccountNumber().getCentre());
        Assertions.assertEquals("300", accountsDetails.getAccountFrom().getPartenonAccountNumber().getProduct());
        Assertions.assertEquals("1234567", accountsDetails.getAccountFrom().getPartenonAccountNumber().getContract());

        Assertions.assertEquals("SAVING", accountsDetails.getAccountTo().getLocalAccountNumber().getSortcode());
        Assertions.assertEquals("R15324808 OZE", accountsDetails.getAccountTo().getLocalAccountNumber().getAccountNumber());

        Assertions.assertEquals("0015", accountsDetails.getAccountTo().getPartenonAccountNumber().getCompany());
        Assertions.assertEquals("4247", accountsDetails.getAccountTo().getPartenonAccountNumber().getCentre());
        Assertions.assertEquals("301", accountsDetails.getAccountTo().getPartenonAccountNumber().getProduct());
        Assertions.assertEquals("7654321", accountsDetails.getAccountTo().getPartenonAccountNumber().getContract());
    }

    @Test
    void testLacMapperException() {
        LocalAccountNumber accountFrom = new LocalAccountNumber("09012", "");
        LocalAccountNumber accountTo = new LocalAccountNumber("SAVING", "X1432768WAR");
        assertThrows(GeneralException.class, () -> lacService.getAccountsDetails(accountFrom, accountTo));
    }

    @Test
    void testLacClientException() throws ConnectionException {
        LocalAccountNumber accountFrom = new LocalAccountNumber("090128", "12345678");
        LocalAccountNumber accountTo = new LocalAccountNumber("SAVING", "X1432768WAR");

        when(localAccountConverterClient.localAccountToPartenonFormat("url", "09012812345678")).thenReturn("001542473001234567");
        when(localAccountConverterClient.localAccountToPartenonFormat("url", "SAVINGX1432768WAR")).thenThrow(ConnectionException.class);

        assertThrows(GeneralException.class, () -> lacService.getAccountsDetails(accountFrom, accountTo));
    }

    @Test
    void testGetPartenonAccountNumber() throws GeneralException {
        PartenonAccountNumber expectedPartenon = new PartenonAccountNumber("0015", "2898", "103", "0042263");

        when(localAccountConverterClient.localAccountToPartenonFormat(anyString(), anyString())).thenReturn("001528981030042263");
        PartenonAccountNumber actualPartenon = lacService.getPartenonAccountNumber("091586012345678");

        assertEquals(expectedPartenon.getContract(), actualPartenon.getContract());
        assertEquals(expectedPartenon.getCentre(), actualPartenon.getCentre());
        assertEquals(expectedPartenon.getProduct(), actualPartenon.getProduct());
        assertEquals(expectedPartenon.getCompany(), actualPartenon.getCompany());
    }
}
