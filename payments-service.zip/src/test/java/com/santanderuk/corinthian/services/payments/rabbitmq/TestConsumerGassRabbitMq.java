package com.santanderuk.corinthian.services.payments.rabbitmq;

import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.ConnectionFactory;
import com.rabbitmq.client.GetResponse;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeoutException;

@Slf4j
@Getter
@Setter
@Component
@Profile("test")
public class TestConsumerGassRabbitMq {
    @Autowired
    TestConsumerConfig config;

    public void resetQueue() throws IOException, TimeoutException {
        Channel channel = null;
        ConnectionFactory factory;
        Connection conn = null;
        try {
            String queue = config.getGassMqQueue();

            factory = getConnectionFactory();
            conn = getConnection(factory);
            channel = getChannel(conn);

            channel.queuePurge(queue);
        } finally {
            disconnectFromQueue(channel, conn);
        }
    }


    public String readMessage() throws IOException, TimeoutException {
        Channel channel = null;
        ConnectionFactory factory;
        Connection conn = null;
        try {
            String queue = config.getGassMqQueue();

            factory = getConnectionFactory();
            conn = getConnection(factory);
            channel = getChannel(conn);

            GetResponse result = channel.basicGet(queue, false);

            if (result != null) {
                channel.basicAck(result.getEnvelope().getDeliveryTag(), false);
                return new String(result.getBody(), StandardCharsets.UTF_8);
            } else {
                log.info("No messages in queue");
                return "No messages in queue";
            }
        } finally {
            disconnectFromQueue(channel, conn);
        }
    }

    private ConnectionFactory getConnectionFactory() {

        ConnectionFactory factory = new ConnectionFactory();
        factory.setUsername(config.getGassMqUsername());
        factory.setPassword(config.getGassMqPassword());
        factory.setHost(config.getGassMqHost());
        factory.setPort(config.getGassMqPort());
        return factory;
    }

    private Channel getChannel(Connection conn) throws IOException {
        return conn.createChannel();

    }

    private Connection getConnection(ConnectionFactory factory) throws IOException, TimeoutException {
        return factory.newConnection();
    }

    public void disconnectFromQueue(Channel channel, Connection conn) {
        if (channel != null && conn != null) {
            try {
                channel.close();
                conn.close();
            } catch (Exception e) {
                log.error("ERROR:- exception caught when trying to disconnectFromQueue. {} ", e.getCause(), e);
            }
        }
    }
}
