package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.CardTransactionResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cps.CPSCardPaymentRequest;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OpayoPaymentClientTest {

    OpayoPaymentClient opayoPaymentClient;

    @Mock
    RestTemplate restTemplate;

    @Mock
    OpayoConfig opayoConfig;

    @Mock
    OverpaymentsConfig overpaymentsConfig;

    @BeforeEach
    void setUp() {
        opayoPaymentClient = new OpayoPaymentClient(opayoConfig, overpaymentsConfig, restTemplate);
        when(overpaymentsConfig.getClientId()).thenReturn("clientId");
    }

    @Test
    void testCardTransactionChallenge() throws IOException, OpayoException {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(CardTransactionResponse.class))).thenReturn(TestDataCreator.generateChallengeCardTransactionResponseEntity());
        CardTransactionResponse cardTransactionResponse = opayoPaymentClient.makeCardTransaction("https://dummyUrl.com/sanuk/internal/v1/card-transactions/", TestDataCreator.generateDefaultCardTransactionRequest());
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(CardTransactionResponse.class));
        assertEquals("2021", cardTransactionResponse.getStatus().getStatusCode());
        assertEquals("Please redirect your customer to the ACSURL to complete the 3DS Transaction", cardTransactionResponse.getStatus().getStatusDetail());
    }

    @Test
    void testCardTransactionFrictionlessOk() throws IOException, OpayoException {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(CardTransactionResponse.class))).thenReturn(TestDataCreator.generateFrictionlessOkCardTransactionResponseEntity());
        CardTransactionResponse cardTransactionResponse = opayoPaymentClient.makeCardTransaction("https://dummyUrl.com/sanuk/internal/v1/card-transactions/", TestDataCreator.generateDefaultCardTransactionRequest());
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(CardTransactionResponse.class));
        assertEquals("0000", cardTransactionResponse.getStatus().getStatusCode());
        assertEquals("The Authorisation was Successful.", cardTransactionResponse.getStatus().getStatusDetail());
    }

    @Test
    void testCardTransactionRejected() throws IOException, OpayoException {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(CardTransactionResponse.class))).thenReturn(TestDataCreator.generateRejectedCardTransactionResponseEntity());
        CardTransactionResponse cardTransactionResponse = opayoPaymentClient.makeCardTransaction("https://dummyUrl.com/sanuk/internal/v1/card-transactions/", TestDataCreator.generateDefaultCardTransactionRequest());
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(CardTransactionResponse.class));
        assertEquals("2001", cardTransactionResponse.getStatus().getStatusCode());
        assertEquals("Transaction rejected by the fraud rules you have in place.", cardTransactionResponse.getStatus().getStatusDetail());
    }

    @Test
    void testCardTransactionExc() {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(CardTransactionResponse.class))).thenThrow(RestClientException.class);
        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentClient.makeCardTransaction("https://dummyUrl.com/sanuk/internal/v1/card-transactions/", TestDataCreator.generateDefaultCardTransactionRequest()));
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(CardTransactionResponse.class));
        assertEquals("OPAYO_CLIENT_EXC", opayoException.getCode());
        assertEquals("Exception while calling card-transaction baas api", opayoException.getMessage());
    }

    @Test
    void testConfirmCardTransactionOk() throws IOException, OpayoException {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(CardTransactionResponse.class))).thenReturn(TestDataCreator.generateConfirmCardTransactionOkResponseEntity());
        CardTransactionResponse cardTransactionResponse = opayoPaymentClient.confirmCardTransaction("https://dummyUrl.com/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", TestDataCreator.generateDefaultConfirmCardTransactionRequest());
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(CardTransactionResponse.class));
        assertEquals("0000", cardTransactionResponse.getStatus().getStatusCode());
        assertEquals("The Authorisation was Successful.", cardTransactionResponse.getStatus().getStatusDetail());
    }

    @Test
    void testConfirmCardTransactionDeclined() throws IOException, OpayoException {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(CardTransactionResponse.class))).thenReturn(TestDataCreator.generateDeclinedConfirmCardTransactionResponseEntity());
        CardTransactionResponse cardTransactionResponse = opayoPaymentClient.confirmCardTransaction("https://dummyUrl.com/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", TestDataCreator.generateDefaultConfirmCardTransactionRequest());
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(CardTransactionResponse.class));
        assertEquals("2000", cardTransactionResponse.getStatus().getStatusCode());
        assertEquals("The Authorisation was Declined by the bank.", cardTransactionResponse.getStatus().getStatusDetail());
    }

    @Test
    void testConfirmCardTransactionExc() {
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(CardTransactionResponse.class))).thenThrow(RestClientException.class);
        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentClient.confirmCardTransaction("https://dummyUrl.com/sanuk/internal/v1/card-transactions/OPAYO2022100615004181713317643/confirm", TestDataCreator.generateDefaultConfirmCardTransactionRequest()));
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(CardTransactionResponse.class));
        assertEquals("OPAYO_CLIENT_EXC", opayoException.getCode());
        assertEquals("Exception while calling confirm-transaction baas api", opayoException.getMessage());
    }

    @Test
    void testUpdateCpsExc() {
        when(opayoConfig.getUpdateCpsUrl()).thenReturn("url");
        Mockito.when(restTemplate.postForEntity(anyString(), any(), eq(Void.class))).thenThrow(RestClientException.class);
        OpayoException opayoException = assertThrows(OpayoException.class, () -> opayoPaymentClient.updateCPS(new CPSCardPaymentRequest()));
        Mockito.verify(restTemplate, times(1)).postForEntity(anyString(), any(), eq(Void.class));
        assertEquals("OPAYO_CLIENT_EXC", opayoException.getCode());
        assertEquals("Exception while calling Update CPS baas api", opayoException.getMessage());
    }

    @Test
    void testHappyPathUpdateCPS() throws OpayoException {
        when(opayoConfig.getUpdateCpsUrl()).thenReturn("url");
        CPSCardPaymentRequest cPSCardPaymentRequest = new CPSCardPaymentRequest();
        HttpEntity httpEntity = createHttpEntity(cPSCardPaymentRequest);
        when(restTemplate.postForEntity("url", httpEntity, Void.class)).thenReturn(generateOKResponseEntity());
        opayoPaymentClient.updateCPS(cPSCardPaymentRequest);
        verify(restTemplate, times(1)).postForEntity("url", httpEntity, Void.class);
    }

    private HttpEntity<CPSCardPaymentRequest> createHttpEntity(CPSCardPaymentRequest cardPaymentRequest) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-Client-Id", overpaymentsConfig.getClientId());
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(cardPaymentRequest, headers);
    }

    private ResponseEntity generateOKResponseEntity() {
        return new ResponseEntity<>(HttpStatus.OK);
    }

}
