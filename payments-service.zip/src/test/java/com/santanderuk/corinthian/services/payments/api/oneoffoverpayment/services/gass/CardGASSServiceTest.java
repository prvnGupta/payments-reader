package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model.GASSMessageData;
import com.santanderuk.corinthian.services.payments.config.GASSConfig;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class CardGASSServiceTest {

    CardGASSService cardGASSService;

    @Mock
    GASSClient gassClient;

    @Mock
    GASSConfig gassConfig;

    @Mock
    GassDataFetcher gassDataFetcher;

    @Mock
    OpayoConfig opayoConfig;


    @BeforeEach
    void setUp() {
        cardGASSService = new CardGASSService(gassDataFetcher, gassClient, gassConfig, opayoConfig);
    }

    @Test
    void testGassMessageData() throws IOException {
        when(gassDataFetcher.fetchMccId(anyString())).thenReturn("123456");
        when(gassConfig.getAppSysIdInternet()).thenReturn(String.valueOf(242));
        when(gassConfig.getDvcTypInternet()).thenReturn(String.valueOf(11));
        when(gassConfig.getTransactionNameDebitCardPayment()).thenReturn("Make Debit Card Payment");
        when(opayoConfig.getAnmfSortcode()).thenReturn("091586");
        when(gassConfig.getAuditTrnGrpId()).thenReturn(647);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        GASSMessageData gassMessageData = cardGASSService.generateGassMessage(cardMortgageSingleOverpaymentsContext);
        assertEquals("ldapUid", gassMessageData.getLdapUid());
        assertEquals("Make Debit Card Payment", gassMessageData.getAuditTrnTpName());
        assertEquals("F554", gassMessageData.getCustomerId());
        assertEquals("F554", gassMessageData.getUserId());
        assertEquals("123456", gassMessageData.getMccId());
        assertEquals("127.0.0.1", gassMessageData.getDeviceId());
        assertEquals(11, gassMessageData.getDeviceTyp());
        assertEquals(242, gassMessageData.getAppSysId());
        assertEquals(647, gassMessageData.getAudittrngrpid());
        assertEquals("091586 012345678", gassMessageData.getAnmfAccount());
        assertEquals("500000", gassMessageData.getAmount());
    }

    @Test
    void testGassMessageDataAmountWithDecimals() throws IOException {
        when(gassDataFetcher.fetchMccId(anyString())).thenReturn("123456");
        when(gassConfig.getAppSysIdInternet()).thenReturn(String.valueOf(242));
        when(gassConfig.getDvcTypInternet()).thenReturn(String.valueOf(11));
        when(gassConfig.getTransactionNameDebitCardPayment()).thenReturn("Make Debit Card Payment");
        when(opayoConfig.getAnmfSortcode()).thenReturn("091586");
        when(gassConfig.getAuditTrnGrpId()).thenReturn(647);
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        context.getCardTransactionDetails().getUpdatedSimulationResponse().setOTotPayment(new BigDecimal("123.12"));
        GASSMessageData gassMessageData = cardGASSService.generateGassMessage(context);
        assertEquals("ldapUid", gassMessageData.getLdapUid());
        assertEquals("Make Debit Card Payment", gassMessageData.getAuditTrnTpName());
        assertEquals("F554", gassMessageData.getCustomerId());
        assertEquals("F554", gassMessageData.getUserId());
        assertEquals("123456", gassMessageData.getMccId());
        assertEquals("127.0.0.1", gassMessageData.getDeviceId());
        assertEquals(11, gassMessageData.getDeviceTyp());
        assertEquals(242, gassMessageData.getAppSysId());
        assertEquals(647, gassMessageData.getAudittrngrpid());
        assertEquals("091586 012345678", gassMessageData.getAnmfAccount());
        assertEquals("12312", gassMessageData.getAmount());
    }

    @Test
    void testGassService() throws IOException {
        when(gassDataFetcher.fetchMccId(anyString())).thenReturn("123456");
        when(gassConfig.getAppSysIdInternet()).thenReturn(String.valueOf(242));
        when(gassConfig.getDvcTypInternet()).thenReturn(String.valueOf(11));
        when(gassConfig.getTransactionNameDebitCardPayment()).thenReturn("Make Debit Card Payment");
        when(opayoConfig.getAnmfSortcode()).thenReturn("091586");
        when(gassConfig.getAuditTrnGrpId()).thenReturn(647);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        cardGASSService.auditDebitCardPayment(cardMortgageSingleOverpaymentsContext, true);
    }

    @Test
    void testFormattedMsg() throws IOException {
        String expectedFrmtData =
                "<formattedData>" +
                        "<CardNumber>4462000000000003</CardNumber>" +
                        "<CardName>VisaDebit</CardName>" +
                        "<AddressLine1>42 Wickstead Avenue</AddressLine1>" +
                        "<PostCode>MK60NW</PostCode>" +
                        "<CustomerName>James Smith</CustomerName>" +
                        "<BeneficiaryName>James Smith</BeneficiaryName>" +
                        "<DateOfBirth>15/05/1979</DateOfBirth>" +
                        "<BorrowerList>" +
                        "<borrower>" +
                        "<name>MR Forename1 Forename2 Forename3 Surname</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>554</customerCode>" +
                        "</borrower>" +
                        "<borrower>" +
                        "<name>MRS SARAH JANE ANXXXXXXXX</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>555</customerCode>" +
                        "</borrower>" +
                        "</BorrowerList>" +
                        "<MCCID>123456</MCCID>" +
                        "<EarlyRepaymentCharge>true</EarlyRepaymentCharge>" +
                        "<EarlyRepaymentChargeAmount>7.93</EarlyRepaymentChargeAmount>" +
                        "<TransactionId>OPAYO2022100710021957062894449</TransactionId>" +
                        "<OverPaymentAmount>4992.07</OverPaymentAmount>" +
                        "<Currency>826</Currency>" +
                        "<TotalAmount>5000</TotalAmount>" +
                        "<PartenonFormatMortgageAccountNumber>001512345201234567</PartenonFormatMortgageAccountNumber>" +
                        "<ChannelType>INT</ChannelType>" +
                        "<OpayoResponseCode>000</OpayoResponseCode>" +
                        "<loanDetails>" +
                        "<loan>" +
                        "<loanSchema>3I</loanSchema>" +
                        "<loanApplicationSequenceNumber>2</loanApplicationSequenceNumber>" +
                        "<optionChosen>Reduce Mortgage Term</optionChosen>" +
                        "<loanErcAmount>7.93</loanErcAmount>" +
                        "<loanOverpaymentAmount>103.18</loanOverpaymentAmount>" +
                        "<loanTotalPaymentAmount>111.11</loanTotalPaymentAmount>" +
                        "<newMonthlyPayment>216.95</newMonthlyPayment>" +
                        "<newMortgageTerm>07/09/2039</newMortgageTerm>" +
                        "<interestSaving>3074.25</interestSaving>" +
                        "</loan>" +
                        "</loanDetails>" +
                        "</formattedData>";
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        String actualFrmtData = cardGASSService.getGassCardFormatData(cardMortgageSingleOverpaymentsContext, "123456");
        assertEquals(expectedFrmtData, actualFrmtData);
    }

    @Test
    void testMaskedCardNumber() throws IOException {
        String expectedFrmtData =
                "<formattedData>" +
                        "<CardNumber>446200******0003</CardNumber>" +
                        "<CardName>VisaDebit</CardName>" +
                        "<AddressLine1>42 Wickstead Avenue</AddressLine1>" +
                        "<PostCode>MK60NW</PostCode>" +
                        "<CustomerName>James Smith</CustomerName>" +
                        "<BeneficiaryName>James Smith</BeneficiaryName>" +
                        "<DateOfBirth>15/05/1979</DateOfBirth>" +
                        "<BorrowerList>" +
                        "<borrower>" +
                        "<name>MR Forename1 Forename2 Forename3 Surname</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>554</customerCode>" +
                        "</borrower>" +
                        "<borrower>" +
                        "<name>MRS SARAH JANE ANXXXXXXXX</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>555</customerCode>" +
                        "</borrower>" +
                        "</BorrowerList>" +
                        "<MCCID>123456</MCCID>" +
                        "<EarlyRepaymentCharge>true</EarlyRepaymentCharge>" +
                        "<EarlyRepaymentChargeAmount>7.93</EarlyRepaymentChargeAmount>" +
                        "<TransactionId>OPAYO2022100710021957062894449</TransactionId>" +
                        "<OverPaymentAmount>4992.07</OverPaymentAmount>" +
                        "<Currency>826</Currency>" +
                        "<TotalAmount>5000</TotalAmount>" +
                        "<PartenonFormatMortgageAccountNumber>001512345201234567</PartenonFormatMortgageAccountNumber>" +
                        "<ChannelType>INT</ChannelType>" +
                        "<OpayoResponseCode>000</OpayoResponseCode>" +
                        "<loanDetails>" +
                        "<loan>" +
                        "<loanSchema>3I</loanSchema>" +
                        "<loanApplicationSequenceNumber>2</loanApplicationSequenceNumber>" +
                        "<optionChosen>Reduce Mortgage Term</optionChosen>" +
                        "<loanErcAmount>7.93</loanErcAmount>" +
                        "<loanOverpaymentAmount>103.18</loanOverpaymentAmount>" +
                        "<loanTotalPaymentAmount>111.11</loanTotalPaymentAmount>" +
                        "<newMonthlyPayment>216.95</newMonthlyPayment>" +
                        "<newMortgageTerm>07/09/2039</newMortgageTerm>" +
                        "<interestSaving>3074.25</interestSaving>" +
                        "</loan>" +
                        "</loanDetails>" +
                        "</formattedData>";
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        cardMortgageSingleOverpaymentsContext.getCardTransactionDetails().setCardNumber("446200*0003");
        String actualFrmtData = cardGASSService.getGassCardFormatData(cardMortgageSingleOverpaymentsContext, "123456");
        assertEquals(expectedFrmtData, actualFrmtData);
    }

    @Test
    void testFormattedMsgCardTransactionResponseNull() throws IOException {
        String expectedFrmtData =
                "<formattedData>" +
                        "<CardNumber>4462000000000003</CardNumber>" +
                        "<CardName></CardName>" +
                        "<AddressLine1>42 Wickstead Avenue</AddressLine1>" +
                        "<PostCode>MK60NW</PostCode>" +
                        "<CustomerName>James Smith</CustomerName>" +
                        "<BeneficiaryName>James Smith</BeneficiaryName>" +
                        "<DateOfBirth>15/05/1979</DateOfBirth>" +
                        "<BorrowerList>" +
                        "<borrower>" +
                        "<name>MR Forename1 Forename2 Forename3 Surname</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>554</customerCode>" +
                        "</borrower>" +
                        "<borrower>" +
                        "<name>MRS SARAH JANE ANXXXXXXXX</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>555</customerCode>" +
                        "</borrower>" +
                        "</BorrowerList>" +
                        "<MCCID>123456</MCCID>" +
                        "<EarlyRepaymentCharge>true</EarlyRepaymentCharge>" +
                        "<EarlyRepaymentChargeAmount>7.93</EarlyRepaymentChargeAmount>" +
                        "<TransactionId></TransactionId>" +
                        "<OverPaymentAmount>4992.07</OverPaymentAmount>" +
                        "<Currency>826</Currency>" +
                        "<TotalAmount>5000</TotalAmount>" +
                        "<PartenonFormatMortgageAccountNumber>001512345201234567</PartenonFormatMortgageAccountNumber>" +
                        "<ChannelType>INT</ChannelType>" +
                        "<OpayoResponseCode>999</OpayoResponseCode>" +
                        "<loanDetails>" +
                        "<loan>" +
                        "<loanSchema>3I</loanSchema>" +
                        "<loanApplicationSequenceNumber>2</loanApplicationSequenceNumber>" +
                        "<optionChosen>Reduce Mortgage Term</optionChosen>" +
                        "<loanErcAmount>7.93</loanErcAmount>" +
                        "<loanOverpaymentAmount>103.18</loanOverpaymentAmount>" +
                        "<loanTotalPaymentAmount>111.11</loanTotalPaymentAmount>" +
                        "<newMonthlyPayment>216.95</newMonthlyPayment>" +
                        "<newMortgageTerm>07/09/2039</newMortgageTerm>" +
                        "<interestSaving>3074.25</interestSaving>" +
                        "</loan>" +
                        "</loanDetails>" +
                        "</formattedData>";
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCardMortgageSingleOverpaymentContextForCpsStep();
        context.setCardTransactionResponse(null);
        String actualFrmtData = cardGASSService.getGassCardFormatData(context, "123456");
        assertEquals(expectedFrmtData, actualFrmtData);
    }

    @Test
    void testMultiLoanFormattedMsg() throws IOException {
        String expectedFrmtData =
                "<formattedData>" +
                        "<CardNumber>4462000000000003</CardNumber>" +
                        "<CardName>VisaDebit</CardName>" +
                        "<AddressLine1>42 Wickstead Avenue</AddressLine1>" +
                        "<PostCode>MK60NW</PostCode>" +
                        "<CustomerName>James Smith</CustomerName>" +
                        "<BeneficiaryName>James Smith</BeneficiaryName>" +
                        "<DateOfBirth>15/05/1979</DateOfBirth>" +
                        "<BorrowerList>" +
                        "<borrower>" +
                        "<name>MR Forename1 Forename2 Forename3 Surname</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>554</customerCode>" +
                        "</borrower>" +
                        "<borrower>" +
                        "<name>MRS SARAH JANE ANXXXXXXXX</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>555</customerCode>" +
                        "</borrower>" +
                        "</BorrowerList>" +
                        "<MCCID>123456</MCCID>" +
                        "<EarlyRepaymentCharge>true</EarlyRepaymentCharge>" +
                        "<EarlyRepaymentChargeAmount>7.93</EarlyRepaymentChargeAmount>" +
                        "<TransactionId>OPAYO2022100710021957062894449</TransactionId>" +
                        "<OverPaymentAmount>4992.07</OverPaymentAmount>" +
                        "<Currency>826</Currency>" +
                        "<TotalAmount>5000</TotalAmount>" +
                        "<PartenonFormatMortgageAccountNumber>001512345201234567</PartenonFormatMortgageAccountNumber>" +
                        "<ChannelType>INT</ChannelType>" +
                        "<OpayoResponseCode>000</OpayoResponseCode>" +
                        "<loanDetails>" +
                        "<loan>" +
                        "<loanSchema>3I</loanSchema>" +
                        "<loanApplicationSequenceNumber>2</loanApplicationSequenceNumber>" +
                        "<optionChosen>Reduce Mortgage Term</optionChosen>" +
                        "<loanErcAmount>7.93</loanErcAmount>" +
                        "<loanOverpaymentAmount>103.18</loanOverpaymentAmount>" +
                        "<loanTotalPaymentAmount>111.11</loanTotalPaymentAmount>" +
                        "<newMonthlyPayment>216.95</newMonthlyPayment>" +
                        "<newMortgageTerm>07/09/2039</newMortgageTerm>" +
                        "<interestSaving>3074.25</interestSaving>" +
                        "</loan>" +
                        "<loan>" +
                        "<loanSchema>3T</loanSchema>" +
                        "<loanApplicationSequenceNumber>2</loanApplicationSequenceNumber>" +
                        "<optionChosen>Reduce Mortgage Term</optionChosen>" +
                        "<loanErcAmount>7.93</loanErcAmount>" +
                        "<loanOverpaymentAmount>214.29</loanOverpaymentAmount>" +
                        "<loanTotalPaymentAmount>222.22</loanTotalPaymentAmount>" +
                        "<newMonthlyPayment>1864.25</newMonthlyPayment>" +
                        "<newMortgageTerm>05/11/2038</newMortgageTerm>" +
                        "<interestSaving>805.53</interestSaving>" +
                        "</loan>" +
                        "</loanDetails>" +
                        "</formattedData>";
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextMultiLoan();
        String actualFrmtData = cardGASSService.getGassCardFormatData(cardMortgageSingleOverpaymentsContext, "123456");
        assertEquals(expectedFrmtData, actualFrmtData);
    }

    @Test
    void testWeDontShowLoansThatWeAreNotOverpaying() throws IOException {
        String expectedFrmtData =
                "<formattedData>" +
                        "<CardNumber>4462000000000003</CardNumber>" +
                        "<CardName>VisaDebit</CardName>" +
                        "<AddressLine1>42 Wickstead Avenue</AddressLine1>" +
                        "<PostCode>MK60NW</PostCode>" +
                        "<CustomerName>James Smith</CustomerName>" +
                        "<BeneficiaryName>James Smith</BeneficiaryName>" +
                        "<DateOfBirth>15/05/1979</DateOfBirth>" +
                        "<BorrowerList>" +
                        "<borrower>" +
                        "<name>MR Forename1 Forename2 Forename3 Surname</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>554</customerCode>" +
                        "</borrower>" +
                        "<borrower>" +
                        "<name>MRS SARAH JANE ANXXXXXXXX</name>" +
                        "<customerType>F</customerType>" +
                        "<customerCode>555</customerCode>" +
                        "</borrower>" +
                        "</BorrowerList>" +
                        "<MCCID>123456</MCCID>" +
                        "<EarlyRepaymentCharge>true</EarlyRepaymentCharge>" +
                        "<EarlyRepaymentChargeAmount>7.93</EarlyRepaymentChargeAmount>" +
                        "<TransactionId>OPAYO2022100710021957062894449</TransactionId>" +
                        "<OverPaymentAmount>4992.07</OverPaymentAmount>" +
                        "<Currency>826</Currency>" +
                        "<TotalAmount>5000</TotalAmount>" +
                        "<PartenonFormatMortgageAccountNumber>001512345201234567</PartenonFormatMortgageAccountNumber>" +
                        "<ChannelType>INT</ChannelType>" +
                        "<OpayoResponseCode>000</OpayoResponseCode>" +
                        "<loanDetails>" +
                        "<loan>" +
                        "<loanSchema>3T</loanSchema>" +
                        "<loanApplicationSequenceNumber>2</loanApplicationSequenceNumber>" +
                        "<optionChosen>Reduce Mortgage Term</optionChosen>" +
                        "<loanErcAmount>7.93</loanErcAmount>" +
                        "<loanOverpaymentAmount>214.29</loanOverpaymentAmount>" +
                        "<loanTotalPaymentAmount>222.22</loanTotalPaymentAmount>" +
                        "<newMonthlyPayment>1864.25</newMonthlyPayment>" +
                        "<newMortgageTerm>05/11/2038</newMortgageTerm>" +
                        "<interestSaving>805.53</interestSaving>" +
                        "</loan>" +
                        "</loanDetails>" +
                        "</formattedData>";
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateCardMortgageSingleOverpaymentContextMultiLoan();
        cardMortgageSingleOverpaymentsContext.getSimulationChosenValues().getLoanDetails().get(0).setLoanOverpaymentAmount(BigDecimal.ZERO);
        String actualFrmtData = cardGASSService.getGassCardFormatData(cardMortgageSingleOverpaymentsContext, "123456");
        assertEquals(expectedFrmtData, actualFrmtData);
    }

}
