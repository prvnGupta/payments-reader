package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class MakePaymentClientTest {

    private MakePaymentClient makePaymentClient;

    @MockBean
    private OverpaymentsConfig mockConfig;

    @MockBean
    private RestTemplate mockRestTemplate;

    @BeforeEach
    void setUp() {
        makePaymentClient = new MakePaymentClient(mockRestTemplate, mockConfig);
        when(mockConfig.getClientId()).thenReturn("client-id");
        when(mockConfig.getMakePaymentEndpoint()).thenReturn("url");
    }

    @Test
    void callDebitPayment_Ok() throws PaymentsFuncException {

        ResponseEntity<DebitResponse> responseEntity
                = new ResponseEntity<>(makePaymentResponse("ok", "Make payment Successful"), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(DebitResponse.class)))
                .thenReturn(responseEntity);

        DebitResponse response = makePaymentClient.callDebitPayment(TestDataCreator.generateDebitPaymentDefaultRequest());

        assertEquals("ok", response.getStatus());
        assertEquals("Make payment Successful", response.getStatusDescription());
    }

    @Test
    void shouldCatchPayFuncException_Unknown() {

        ResponseEntity<DebitResponse> responseEntity
                = new ResponseEntity<>(makePaymentResponse("FUNCERR", "Payment failed"), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(DebitResponse.class)))
                .thenReturn(responseEntity);

        PaymentsFuncException connectException = assertThrows(PaymentsFuncException.class, () -> makePaymentClient.callDebitPayment(TestDataCreator.generateDebitPaymentDefaultRequest()));
        assertEquals("PAYMENT_ERROR", connectException.getMessage());
    }

    @Test
    void shouldCatchPayFuncException_UnclearedFunds() {

        ResponseEntity<DebitResponse> responseEntity
                = new ResponseEntity<>(makePaymentResponse("NFAERR", "Payment failed"), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(DebitResponse.class)))
                .thenReturn(responseEntity);

        PaymentsFuncException connectException = assertThrows(PaymentsFuncException.class, () -> makePaymentClient.callDebitPayment(TestDataCreator.generateDebitPaymentDefaultRequest()));
        assertEquals("PAYMENT_ERROR_UCF", connectException.getMessage());
    }

    @Test
    void shouldCatchPayFuncException_BlockedAccount() {

        ResponseEntity<DebitResponse> responseEntity
                = new ResponseEntity<>(makePaymentResponse("ACCOUNTBLOCKED", "Payment failed"), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(DebitResponse.class)))
                .thenReturn(responseEntity);

        PaymentsFuncException connectException = assertThrows(PaymentsFuncException.class, () -> makePaymentClient.callDebitPayment(TestDataCreator.generateDebitPaymentDefaultRequest()));
        assertEquals("PAYMENT_ERROR_PBA", connectException.getMessage());
    }

    @Test
    void shouldCatchConnectionException() {
        when(mockRestTemplate.postForEntity(anyString(), any(), eq(DebitResponse.class)))
                .thenThrow(RestClientException.class);

        PaymentsFuncException paymentsFuncException = assertThrows(PaymentsFuncException.class, () -> makePaymentClient.callDebitPayment(TestDataCreator.generateDebitPaymentDefaultRequest()));
        assertEquals("Exception while calling Debit payment", paymentsFuncException.getMessage());
    }

    private DebitResponse makePaymentResponse(String status, String description) {
        DebitResponse response = new DebitResponse();
        response.setStatus(status);
        response.setStatusDescription(description);
        return response;
    }
}
