package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils.PaymentReferenceGenerator;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static com.santanderuk.corinthian.services.payments.TestDataCreator.*;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MakePaymentMapperTest {

    private MakePaymentMapper makePaymentMapper;

    @Mock
    private OverpaymentsConfig overpaymentsConfig;
    @Spy
    private PaymentReferenceGenerator paymentReferenceGenerator;

    @BeforeEach
    void setUp() {
        when(overpaymentsConfig.getMakePaymentSameHolder()).thenReturn("S");
        when(overpaymentsConfig.getMakePaymentBeneficiaryType()).thenReturn("W");
        makePaymentMapper = new MakePaymentMapper(overpaymentsConfig, paymentReferenceGenerator);
    }

    @Test
    void testWeMapCorrectly() throws IOException {

        SetupRequest setupRequest = generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        InternalTransferRequest internalTransferRequest = generateDefaultInternalTransferControllerRequest();

        DebitRequest debitRequest = makePaymentMapper.mapRequest(setupRequest, setupResponse, internalTransferRequest, TestDataCreator.generateDefaultInternalTransferAccountsDetails());

        assertAll(
                () -> assertEquals(setupRequest, debitRequest.getSetupRequest()),
                () -> assertEquals(setupResponse, debitRequest.getSetupResponse()),
                () -> assertEquals("S", debitRequest.getSameHolder()),
                () -> assertEquals("paymentReference", debitRequest.getReference()),
                () -> assertEquals("1", debitRequest.getPersonNumber()),
                () -> assertEquals("W", debitRequest.getBeneficiaryType()),
                () -> assertEquals("company", debitRequest.getBeneficiaryPartenonEntity()),
                () -> assertEquals("centre", debitRequest.getBeneficiaryPartenonCentre()),
                () -> assertEquals("product", debitRequest.getBeneficiaryPartenonProduct()),
                () -> assertEquals("contract", debitRequest.getBeneficiaryPartenonContract()),
                () -> assertEquals("centre", debitRequest.getCreditAccountBranch())
        );
    }

    @Test
    void testWeMapCorrectlyForInternalTransferSingleOverpayment() throws IOException {

        SetupRequest setupRequest = generateSetupPaymentDefaultRequest();
        SetupResponse setupResponse = generateSetupPaymentResponseOK();
        when(overpaymentsConfig.getMakePaymentBeneficiaryPartenonEntity()).thenReturn("7777");
        when(overpaymentsConfig.getMakePaymentBeneficiaryAccountBranch()).thenReturn("7775");

        DebitRequest debitRequest = makePaymentMapper.mapRequest(setupRequest, setupResponse, TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod());

        assertAll(
                () -> assertEquals(setupRequest, debitRequest.getSetupRequest()),
                () -> assertEquals(setupResponse, debitRequest.getSetupResponse()),
                () -> assertEquals("S", debitRequest.getSameHolder()),
                () -> assertEquals("123456789SURNAME  ", debitRequest.getReference()),
                () -> assertEquals("554", debitRequest.getPersonNumber()),
                () -> assertEquals("W", debitRequest.getBeneficiaryType()),
                () -> assertEquals("Surname", debitRequest.getBeneficiaryName()),
                () -> assertEquals("7777", debitRequest.getBeneficiaryPartenonEntity()),
                () -> assertEquals("centre", debitRequest.getBeneficiaryPartenonCentre()),
                () -> assertEquals("product", debitRequest.getBeneficiaryPartenonProduct()),
                () -> assertEquals("contract", debitRequest.getBeneficiaryPartenonContract()),
                () -> assertEquals("7775", debitRequest.getCreditAccountBranch())
        );
    }
}
