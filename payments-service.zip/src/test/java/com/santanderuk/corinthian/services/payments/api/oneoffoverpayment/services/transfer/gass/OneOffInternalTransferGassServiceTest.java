package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.gass;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.gassaudit.config.RabbitMqConfig;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.implementation.MakeInternalTransferGassMQServiceImplementation;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferGassItem;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.implementation.SetUpGassMQServiceImplementation;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferGassItem;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@ActiveProfiles("test")
class OneOffInternalTransferGassServiceTest {

    @MockBean
    RabbitMqConfig rabbitMqConfig;
    @SpyBean
    GassDataFetcher gassDataFetcher;
    @MockBean
    GassConfig gassConfig;
    @MockBean
    SetUpGassMQServiceImplementation setUpGassMQService;
    @MockBean
    MakeInternalTransferGassMQServiceImplementation makeInternalTransferGassMQService;


    @Autowired
    OneOffInternalTransferGassService oneOffInternalTransferGassService;

    @BeforeEach
    void setUp() {
    }

    @Test
    void testSetupGass() throws Exception {
        stubGassConfig();
        stubRabbitMqConfig();
        ArgumentCaptor<SetUpInternalTransferGassItem> setUpInternalTransferGassItemArgumentCaptor = ArgumentCaptor.forClass(SetUpInternalTransferGassItem.class);
        oneOffInternalTransferGassService.callGassSetup(TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment(), "1");
        Mockito.verify(setUpGassMQService, times(1)).sendToMQSetUpInternalTransfer(setUpInternalTransferGassItemArgumentCaptor.capture());
        Mockito.verify(makeInternalTransferGassMQService, times(0)).sendToMQMakeInternalTransfer(any());

        SetUpInternalTransferGassItem setUpInternalTransferGassItemArgumentCaptorValue = setUpInternalTransferGassItemArgumentCaptor.getValue();

        assertEquals("242", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getAppsysid());
        assertEquals("647", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getAudittrngrpid());
        assertEquals("Set up Internal Transfer", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getTrntpname());

        assertEquals("rmq-audit.santanderuk.pre.corp", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqHost());
        assertEquals(80, setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqPort());
        assertEquals("", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqVirtualHost());
        assertEquals("username", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqUsername());
        assertEquals("password", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqPassword());
        assertEquals("AVL.RABBITMQ.REQUEST", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqQueue());

        assertEquals("168", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getAuthcdcompsysid());
        assertEquals("RABBITMQ", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getAuthcduserid());
        assertEquals("168", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getCompsysid());
        assertEquals("11", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getDvctyp());
        assertEquals("98", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getOrguttp());
        assertEquals("2", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getOrgid());

        assertEquals("09012712345678", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getAccount());
        assertEquals("5000", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getAmount());
        assertEquals("127.0.0.1", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getClientIPAddress());
        assertEquals("F554", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getCustNumber());
        assertEquals("1", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getOprtnsuctyp());
        assertEquals("ldapUid", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getUserID());

        assertEquals("091586 123456789", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getDestinationAccount());
        assertEquals("7.93", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getEarlyRepaymentChargeAmount());
        assertEquals("Y", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getEarlyRepaymentChargeIndicator());
        assertEquals("0015 1234 520 1234567", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getMultiChannelContractId());
        assertEquals("09012712345678", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getOriginAccount());
        assertEquals("4992.07", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getOverpaymentAmount());
        assertEquals("5000", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getTotalPaymentAmount());
        assertEquals("554", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getCustomerCode());
        assertEquals("F", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getCustomerType());
        assertEquals("MR Forename1 Forename2 Forename3 Surname", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getName());
        assertEquals("3I", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanSchema());
        assertEquals(2, setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanApplicationSequenceNumber());
        assertEquals("Reduce Mortgage Term", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getOptionChosen());
        assertEquals("7.93", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanErcAmount());
        assertEquals("103.18", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanOverpaymentAmount());
        assertEquals("111.11", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanTotalPaymentAmount());
        assertEquals("216.95", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewMonthlyPayment());
        assertEquals("07/09/2039", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewLoanEndDate());
        assertEquals("3074.25", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getInterestSaving());
    }

    @Test
    void testEmptyIp() throws Exception {
        stubGassConfig();
        stubRabbitMqConfig();
        ArgumentCaptor<SetUpInternalTransferGassItem> setUpInternalTransferGassItemArgumentCaptor = ArgumentCaptor.forClass(SetUpInternalTransferGassItem.class);
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        context.setIpAddress("");
        oneOffInternalTransferGassService.callGassSetup(context, "1");
        Mockito.verify(setUpGassMQService, times(1)).sendToMQSetUpInternalTransfer(setUpInternalTransferGassItemArgumentCaptor.capture());
        Mockito.verify(makeInternalTransferGassMQService, times(0)).sendToMQMakeInternalTransfer(any());

        SetUpInternalTransferGassItem setUpInternalTransferGassItemArgumentCaptorValue = setUpInternalTransferGassItemArgumentCaptor.getValue();

        assertEquals("127.0.0.1", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getClientIPAddress());
    }

    @Test
    void testDebitGass() throws Exception {
        stubGassConfig();
        stubRabbitMqConfig();
        ArgumentCaptor<MakeInternalTransferGassItem> makeInternalTransferGassItemArgumentCaptor = ArgumentCaptor.forClass(MakeInternalTransferGassItem.class);
        oneOffInternalTransferGassService.callGassMakePayment(TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment(), "0");
        Mockito.verify(setUpGassMQService, times(0)).sendToMQSetUpInternalTransfer(any());
        Mockito.verify(makeInternalTransferGassMQService, times(1)).sendToMQMakeInternalTransfer(makeInternalTransferGassItemArgumentCaptor.capture());

        MakeInternalTransferGassItem makeInternalTransferGassItem = makeInternalTransferGassItemArgumentCaptor.getValue();

        assertEquals("242", makeInternalTransferGassItem.getGassCategorization().getAppsysid());
        assertEquals("647", makeInternalTransferGassItem.getGassCategorization().getAudittrngrpid());
        assertEquals("Make Internal Transfer", makeInternalTransferGassItem.getGassCategorization().getTrntpname());

        assertEquals("rmq-audit.santanderuk.pre.corp", makeInternalTransferGassItem.getGassMqDetails().getMqHost());
        assertEquals(80, makeInternalTransferGassItem.getGassMqDetails().getMqPort());
        assertEquals("", makeInternalTransferGassItem.getGassMqDetails().getMqVirtualHost());
        assertEquals("username", makeInternalTransferGassItem.getGassMqDetails().getMqUsername());
        assertEquals("password", makeInternalTransferGassItem.getGassMqDetails().getMqPassword());
        assertEquals("AVL.RABBITMQ.REQUEST", makeInternalTransferGassItem.getGassMqDetails().getMqQueue());

        assertEquals("168", makeInternalTransferGassItem.getGassDefaultValueFields().getAuthcdcompsysid());
        assertEquals("RABBITMQ", makeInternalTransferGassItem.getGassDefaultValueFields().getAuthcduserid());
        assertEquals("168", makeInternalTransferGassItem.getGassDefaultValueFields().getCompsysid());
        assertEquals("11", makeInternalTransferGassItem.getGassDefaultValueFields().getDvctyp());
        assertEquals("98", makeInternalTransferGassItem.getGassDefaultValueFields().getOrguttp());
        assertEquals("2", makeInternalTransferGassItem.getGassDefaultValueFields().getOrgid());

        assertEquals("09012712345678", makeInternalTransferGassItem.getGassMessage().getAccount());
        assertEquals("5000", makeInternalTransferGassItem.getGassMessage().getAmount());
        assertEquals("127.0.0.1", makeInternalTransferGassItem.getGassMessage().getClientIPAddress());
        assertEquals("F554", makeInternalTransferGassItem.getGassMessage().getCustNumber());
        assertEquals("0", makeInternalTransferGassItem.getGassMessage().getOprtnsuctyp());
        assertEquals("ldapUid", makeInternalTransferGassItem.getGassMessage().getUserID());

        assertEquals("091586 123456789", makeInternalTransferGassItem.getGassMessage().getFormattedData().getDestinationAccount());
        assertEquals("7.93", makeInternalTransferGassItem.getGassMessage().getFormattedData().getEarlyRepaymentChargeAmount());
        assertEquals("Y", makeInternalTransferGassItem.getGassMessage().getFormattedData().getEarlyRepaymentChargeIndicator());
        assertEquals("0015 1234 520 1234567", makeInternalTransferGassItem.getGassMessage().getFormattedData().getMultiChannelContractId());
        assertEquals("09012712345678", makeInternalTransferGassItem.getGassMessage().getFormattedData().getOriginAccount());
        assertEquals("4992.07", makeInternalTransferGassItem.getGassMessage().getFormattedData().getOverpaymentAmount());
        assertEquals("5000", makeInternalTransferGassItem.getGassMessage().getFormattedData().getTotalPaymentAmount());
        assertEquals("554", makeInternalTransferGassItem.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getCustomerCode());
        assertEquals("F", makeInternalTransferGassItem.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getCustomerType());
        assertEquals("MR Forename1 Forename2 Forename3 Surname", makeInternalTransferGassItem.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getName());
        assertEquals("3I", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanSchema());
        assertEquals(2, makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanApplicationSequenceNumber());
        assertEquals("Reduce Mortgage Term", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getOptionChosen());
        assertEquals("7.93", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanErcAmount());
        assertEquals("103.18", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanOverpaymentAmount());
        assertEquals("111.11", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanTotalPaymentAmount());
        assertEquals("216.95", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewMonthlyPayment());
        assertEquals("07/09/2039", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewLoanEndDate());
        assertEquals("3074.25", makeInternalTransferGassItem.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getInterestSaving());
    }

    @Test
    void testSetupGassForMultiLoan() throws Exception {
        stubGassConfig();
        stubRabbitMqConfig();
        ArgumentCaptor<SetUpInternalTransferGassItem> setUpInternalTransferGassItemArgumentCaptor = ArgumentCaptor.forClass(SetUpInternalTransferGassItem.class);
        oneOffInternalTransferGassService.callGassSetup(TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoan(), "1");
        Mockito.verify(setUpGassMQService, times(1)).sendToMQSetUpInternalTransfer(setUpInternalTransferGassItemArgumentCaptor.capture());
        Mockito.verify(makeInternalTransferGassMQService, times(0)).sendToMQMakeInternalTransfer(any());

        SetUpInternalTransferGassItem setUpInternalTransferGassItemArgumentCaptorValue = setUpInternalTransferGassItemArgumentCaptor.getValue();

        assertEquals("242", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getAppsysid());
        assertEquals("647", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getAudittrngrpid());
        assertEquals("Set up Internal Transfer", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getTrntpname());

        assertEquals("rmq-audit.santanderuk.pre.corp", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqHost());
        assertEquals(80, setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqPort());
        assertEquals("", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqVirtualHost());
        assertEquals("username", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqUsername());
        assertEquals("password", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqPassword());
        assertEquals("AVL.RABBITMQ.REQUEST", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqQueue());

        assertEquals("168", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getAuthcdcompsysid());
        assertEquals("RABBITMQ", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getAuthcduserid());
        assertEquals("168", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getCompsysid());
        assertEquals("11", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getDvctyp());
        assertEquals("98", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getOrguttp());
        assertEquals("2", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getOrgid());

        assertEquals("09012712345678", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getAccount());
        assertEquals("5000", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getAmount());
        assertEquals("127.0.0.1", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getClientIPAddress());
        assertEquals("F554", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getCustNumber());
        assertEquals("1", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getOprtnsuctyp());
        assertEquals("ldapUid", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getUserID());

        assertEquals("091586 123456789", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getDestinationAccount());
        assertEquals("7.93", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getEarlyRepaymentChargeAmount());
        assertEquals("Y", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getEarlyRepaymentChargeIndicator());
        assertEquals("0015 1234 520 1234567", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getMultiChannelContractId());
        assertEquals("09012712345678", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getOriginAccount());
        assertEquals("4992.07", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getOverpaymentAmount());
        assertEquals("5000", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getTotalPaymentAmount());
        assertEquals("554", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getCustomerCode());
        assertEquals("F", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getCustomerType());
        assertEquals("MR Forename1 Forename2 Forename3 Surname", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getBorrowerList().getBorrower().get(0).getName());
        assertEquals("3I", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanSchema());
        assertEquals(2, setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanApplicationSequenceNumber());
        assertEquals("Reduce Mortgage Term", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getOptionChosen());
        assertEquals("7.93", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanErcAmount());
        assertEquals("103.18", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanOverpaymentAmount());
        assertEquals("111.11", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanTotalPaymentAmount());
        assertEquals("216.95", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewMonthlyPayment());
        assertEquals("07/09/2039", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewLoanEndDate());
        assertEquals("3074.25", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getInterestSaving());
        assertEquals("3T", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getLoanSchema());
        assertEquals(2, setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getLoanApplicationSequenceNumber());
        assertEquals("Reduce Mortgage Term", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getOptionChosen());
        assertEquals("7.93", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getLoanErcAmount());
        assertEquals("214.29", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getLoanOverpaymentAmount());
        assertEquals("222.22", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getLoanTotalPaymentAmount());
        assertEquals("1864.25", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getNewMonthlyPayment());
        assertEquals("05/11/2038", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getNewLoanEndDate());
        assertEquals("805.53", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(1).getInterestSaving());
    }


    @Test
    void testWeDontShowLoansThatWeDontOverpay() throws Exception {
        stubGassConfig();
        stubRabbitMqConfig();
        ArgumentCaptor<SetUpInternalTransferGassItem> setUpInternalTransferGassItemArgumentCaptor = ArgumentCaptor.forClass(SetUpInternalTransferGassItem.class);
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoan();
        context.getSimulationChosenValues().getLoanDetails().get(0).setLoanOverpaymentAmount(BigDecimal.ZERO);


        oneOffInternalTransferGassService.callGassSetup(context, "1");
        Mockito.verify(setUpGassMQService, times(1)).sendToMQSetUpInternalTransfer(setUpInternalTransferGassItemArgumentCaptor.capture());
        Mockito.verify(makeInternalTransferGassMQService, times(0)).sendToMQMakeInternalTransfer(any());

        SetUpInternalTransferGassItem setUpInternalTransferGassItemArgumentCaptorValue = setUpInternalTransferGassItemArgumentCaptor.getValue();

        assertEquals("242", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getAppsysid());
        assertEquals("647", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getAudittrngrpid());
        assertEquals("Set up Internal Transfer", setUpInternalTransferGassItemArgumentCaptorValue.getGassCategorization().getTrntpname());

        assertEquals("rmq-audit.santanderuk.pre.corp", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqHost());
        assertEquals(80, setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqPort());
        assertEquals("", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqVirtualHost());
        assertEquals("username", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqUsername());
        assertEquals("password", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqPassword());
        assertEquals("AVL.RABBITMQ.REQUEST", setUpInternalTransferGassItemArgumentCaptorValue.getGassMqDetails().getMqQueue());

        assertEquals("168", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getAuthcdcompsysid());
        assertEquals("RABBITMQ", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getAuthcduserid());
        assertEquals("168", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getCompsysid());
        assertEquals("11", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getDvctyp());
        assertEquals("98", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getOrguttp());
        assertEquals("2", setUpInternalTransferGassItemArgumentCaptorValue.getGassDefaultValueFields().getOrgid());

        assertEquals("09012712345678", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getAccount());
        assertEquals("5000", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getAmount());
        assertEquals("127.0.0.1", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getClientIPAddress());
        assertEquals("F554", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getCustNumber());
        assertEquals("1", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getOprtnsuctyp());
        assertEquals("ldapUid", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getUserID());

        assertEquals("091586 123456789", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getDestinationAccount());
        assertEquals("7.93", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getEarlyRepaymentChargeAmount());
        assertEquals("Y", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getEarlyRepaymentChargeIndicator());
        assertEquals("0015 1234 520 1234567", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getMultiChannelContractId());
        assertEquals("09012712345678", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getOriginAccount());
        assertEquals("4992.07", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getOverpaymentAmount());
        assertEquals("5000", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getTotalPaymentAmount());
        assertEquals(1, setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().size());
        assertEquals("3T", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanSchema());
        assertEquals(2, setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanApplicationSequenceNumber());
        assertEquals("Reduce Mortgage Term", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getOptionChosen());
        assertEquals("7.93", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanErcAmount());
        assertEquals("214.29", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanOverpaymentAmount());
        assertEquals("222.22", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getLoanTotalPaymentAmount());
        assertEquals("1864.25", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewMonthlyPayment());
        assertEquals("05/11/2038", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getNewLoanEndDate());
        assertEquals("805.53", setUpInternalTransferGassItemArgumentCaptorValue.getGassMessage().getFormattedData().getLoanDetails().getLoan().get(0).getInterestSaving());
    }


    private void stubRabbitMqConfig() {
        when(rabbitMqConfig.getGassMqHost()).thenReturn("rmq-audit.santanderuk.pre.corp");
        when(rabbitMqConfig.getGassMqPort()).thenReturn(80);
        when(rabbitMqConfig.getGassMqVirtualHost()).thenReturn("");
        when(rabbitMqConfig.getGassMqUsername()).thenReturn("username");
        when(rabbitMqConfig.getGassMqPassword()).thenReturn("password");
        when(rabbitMqConfig.getGassMqQueue()).thenReturn("AVL.RABBITMQ.REQUEST");
    }

    private void stubGassConfig() {
        when(gassConfig.getGassAppsysid()).thenReturn("242");
        when(gassConfig.getGassTrngrpid()).thenReturn("647");
        when(gassConfig.getGassCompsysid()).thenReturn("168");
        when(gassConfig.getGassDvctyp()).thenReturn("11");
        when(gassConfig.getGassOrgid()).thenReturn("2");
        when(gassConfig.getGassOrguttp()).thenReturn("98");
        when(gassConfig.getGassAuthcduserid()).thenReturn("RABBITMQ");
        when(gassConfig.getGassAuthcdcompsysid()).thenReturn("168");
        when(gassConfig.getAnmfSortcode()).thenReturn("091586");

    }
}
