package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.InputStruc;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SimulationMapperTest {

    private SimulationMapper simulationMapper;

    @Mock
    private OverpaymentsConfig overpaymentsConfig;

    @BeforeEach
    void setUp() {
        simulationMapper = new SimulationMapper(overpaymentsConfig);
    }

    @Test
    void testGenerateSimulationRequest() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");
        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCreateSimulationRequest(TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan(), 1);
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(0, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(new BigDecimal("5000.00"), inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(1, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(0, inputStruc.getIOriginalSimulationId());
        assertEquals(2, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("3I", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("T", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(new BigDecimal("111.11"), inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());
    }

    @Test
    void testGenerateSimulationRequestVersion2() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        context.setSimIdV1(12345);
        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCreateSimulationRequest(context, 2);
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(0, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(new BigDecimal("5000.00"), inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(2, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(12345, inputStruc.getIOriginalSimulationId());
        assertEquals(2, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("3I", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("T", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(new BigDecimal("111.11"), inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());
    }

    @Test
    void testGenerateSimulationRequestMultiLoan() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");
        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCreateSimulationRequest(TestDataCreator.generateInitialMortgageSingleOverpaymentContextMultiLoan(), 1);
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(0, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(new BigDecimal("333.33"), inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(1, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(0, inputStruc.getIOriginalSimulationId());

        assertEquals(2, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("3I", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("T", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(new BigDecimal("111.11"), inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());

        assertEquals(2, inputStruc.getILoanData().get(1).getIApplSeqNo());
        assertEquals("3T", inputStruc.getILoanData().get(1).getILoanSch());
        assertEquals("T", inputStruc.getILoanData().get(1).getIChangeType());
        assertEquals(new BigDecimal("222.22"), inputStruc.getILoanData().get(1).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(1).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(1).getIErcWaiverRsn());
    }

    @Test
    void testGenerateCardSimulationRequest() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");

        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCardCreateSimulationRequest(TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext());
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(0, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(new BigDecimal("5000.00"), inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(1, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(0, inputStruc.getIOriginalSimulationId());
        assertEquals(2, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("3I", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("T", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(new BigDecimal("111.11"), inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());
    }

    @Test
    void testGenerateCardSimulationRequestMultiLoan() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");

        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCardCreateSimulationRequest(TestDataCreator.generateInitialCardMortgageSingleOverpaymentContextMultiLoan());
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(0, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(new BigDecimal("333.33"), inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(1, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(0, inputStruc.getIOriginalSimulationId());

        assertEquals(2, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("3I", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("T", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(new BigDecimal("111.11"), inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());

        assertEquals(2, inputStruc.getILoanData().get(1).getIApplSeqNo());
        assertEquals("3T", inputStruc.getILoanData().get(1).getILoanSch());
        assertEquals("T", inputStruc.getILoanData().get(1).getIChangeType());
        assertEquals(new BigDecimal("222.22"), inputStruc.getILoanData().get(1).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(1).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(1).getIErcWaiverRsn());
    }

    @Test
    void testGenerateUpdatePaymentMethodSimulationRequest() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");

        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateUpdatePaymentMethodSimulationRequest(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), 1);
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(6983663, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(BigDecimal.ZERO, inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(1, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("TT", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(0, inputStruc.getIOriginalSimulationId());
        assertEquals(0, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("AA", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("M", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(BigDecimal.ZERO, inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());
    }

    @Test
    void testGenerateUpdatePaymentMethodSimulationRequestV2() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");

        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateUpdatePaymentMethodSimulationRequest(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), 2);
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(7455598, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(BigDecimal.ZERO, inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(2, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("TT", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(6983663, inputStruc.getIOriginalSimulationId());
        assertEquals(0, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("AA", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("M", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(BigDecimal.ZERO, inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());
    }

    @Test
    void testGenerateUpdatePaymentMethodSimulationRequestMultiLoan() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");

        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateUpdatePaymentMethodSimulationRequest(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), 1);
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(6983663, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(BigDecimal.ZERO, inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(1, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("TT", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(0, inputStruc.getIOriginalSimulationId());
        assertEquals(0, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("AA", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("M", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(BigDecimal.ZERO, inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());
    }

    @Test
    void testGenerateCardUpdatePaymentMethodSimulationRequest() throws IOException {
        when(overpaymentsConfig.getCallingApplication()).thenReturn("OVERPAYMENTS");
        when(overpaymentsConfig.getChannelType()).thenReturn("5");
        when(overpaymentsConfig.getSimulationUserId()).thenReturn("ARKUSERU");

        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCardUpdatePaymentMethodSimulationRequest(TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext());
        InputStruc inputStruc = anmfSimulationRequest.getOverpaymentSimulationRequest().getInputStruc();

        assertEquals(7309685, inputStruc.getISimulationId());
        assertEquals(123456789, inputStruc.getIMortAccNo());
        assertEquals(BigDecimal.ZERO, inputStruc.getITotOvpAmount());
        assertEquals("I", inputStruc.getIErcCollOpt());
        assertEquals("5", inputStruc.getIChanTypeCd());
        assertEquals(1, inputStruc.getISimVersion());
        assertEquals("F", inputStruc.getIBdpType());
        assertEquals(554, inputStruc.getIBdpNumber());
        assertEquals("ldapUid", inputStruc.getIStaffId());
        assertEquals("OVERPAYMENTS", inputStruc.getICallingAppl());
        assertEquals("DC", inputStruc.getIPaymentData().getISimPayMeth());
        assertEquals("O", inputStruc.getIDistriType());
        assertEquals("", inputStruc.getIErcAllowImp());
        assertEquals("", inputStruc.getIKfiRefNo());
        assertEquals("ARKUSERU", inputStruc.getIUserId());
        assertEquals(0, inputStruc.getIOriginalSimulationId());
        assertEquals(0, inputStruc.getILoanData().get(0).getIApplSeqNo());
        assertEquals("AA", inputStruc.getILoanData().get(0).getILoanSch());
        assertEquals("M", inputStruc.getILoanData().get(0).getIChangeType());
        assertEquals(BigDecimal.ZERO, inputStruc.getILoanData().get(0).getILnOvpAmount());
        assertEquals("N", inputStruc.getILoanData().get(0).getIErcWaiver());
        assertEquals("", inputStruc.getILoanData().get(0).getIErcWaiverRsn());
    }
}
