package com.santanderuk.corinthian.services.payments.functional.internalTransfer;


import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import java.io.IOException;
import java.util.concurrent.TimeoutException;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class InternalTransferFunctionalTest extends FunctionalTest {

    String internalTransferUrl;
    Header header;

    @BeforeEach
    void setupThisTest() throws IOException, TimeoutException {
        internalTransferUrl = String.format("http://localhost:%s/payments-service/internal-transfer", serverPort);
        header = new Header("authorization", jwtAuth);
    }

    @Test
    public void shouldReturnInvalidFirstNameException() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/invalid-first-name.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("customerFirstName is invalid"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void shouldReturnInvalidLastNameException() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/invalid-last-name.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("customerLastName is invalid"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void shouldReturnInvalidBdpCustomerException() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/invalid-bdp-customer.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("bdpCustomer.customerType is invalid"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void shouldReturnInvalidPaymentReferenceException() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/invalid-reference.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("paymentReference is invalid"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void shouldReturnInvalidAmountException() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/invalid-amount.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("paymentAmount is invalid"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void shouldReturnInvalidOriginAccountException() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/invalid-origin.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("originAccount.sortcode is invalid"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void shouldReturnInvalidDestinationAccountException() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/invalid-destination.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("destinationAccount.accountNumber is invalid"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void noSecurityInHeadersIsValidated() {
        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(400);
    }

    @Test
    public void validRequestReturns200() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "response.paymentId", Matchers.containsString("MORTGAGE"),
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );
    }

    @Test
    public void validRequestSavingAccountReturns200() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request-saving-account.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "response.paymentId", Matchers.containsString("MORTGAGE"),
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );
    }

    @Test
    public void validRequestSavingAccountFormat2Returns200() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request-saving-account-2.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "response.paymentId", Matchers.containsString("MORTGAGE"),
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );
    }

    @Test
    public void validRequestSavingAccountFormat3Returns200() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request-saving-account-3.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "response.paymentId", Matchers.containsString("MORTGAGE"),
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );
    }

    @Test
    public void blockedOriginAccount() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentKoBlockedAccount();
        stubLynxNRTOK();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.message", equalTo("PAYMENT_ERROR_PBA"),
                        "info.code", equalTo("PAYMENT_ERROR"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testEverythingOKExceptLynxNRTCallReturnsOK() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTKO();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "response.paymentId", Matchers.containsString("MORTGAGE"),
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );
    }

    @Test
    public void testExceptionWhileDebitPayment() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentKoUnknownError();
        stubLynxNRTOK();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.message", equalTo("PAYMENT_ERROR"),
                        "info.code", equalTo("PAYMENT_ERROR"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testExceptionWhileDebitPaymentAndLynxNRTKO() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentKoUnclearedFunds();
        stubLynxNRTKO();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.message", equalTo("PAYMENT_ERROR_UCF"),
                        "info.code", equalTo("PAYMENT_ERROR"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void lynxFraudCallShouldFailAndWillThrowException() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckConnectionException();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.message", equalTo("Exception while calling LynxFraud Core Api"),
                        "info.code", equalTo("500"),
                        "info.status", equalTo("ko")
                );
    }


    @Test
    public void lynxFraudResponseDeclinedCallsLynxNrt() {
        stubLacOk();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOkDeclinedResponse();
        stubLynxNRTOK();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.message", equalTo("Exception while calling LynxFraud Core Api"),
                        "info.code", equalTo("500"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void setupKo() {
        stubLacOk();
        stubSetupPartenonPaymentKo("internal-transfer/setup-payment/setup-payment-response-ko.json");

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.message", equalTo("PAYMENT_ERROR_SPE"),
                        "info.code", equalTo("PAYMENT_ERROR"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void exceptionWhileCallingSetup() {
        stubLacOk();
        stubSetupPartenonPaymentExc();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer/valid-request.json"))
                .when()
                .post(internalTransferUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.message", equalTo("PAYMENT_ERROR_SPE"),
                        "info.code", equalTo("PAYMENT_ERROR"),
                        "info.status", equalTo("ko")
                );
    }
}
