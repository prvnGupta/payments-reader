package com.santanderuk.corinthian.services.payments.gass;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
public class GassDataFetcherTest {

    @Mock
    HeartBeatClient heartBeatClient;
    @Mock
    BksConnectClient bksConnectClient;
    @Mock
    GassConfig gassConfig;
    @Mock
    EndpointConfiguration endpointConfiguration;
    @Mock
    private AnmfCoreClient anmfCoreClient;

    @Test
    public void testFormatAmount() {
        GassDataFetcher gassDataFetcher = new GassDataFetcher(anmfCoreClient, heartBeatClient, bksConnectClient, gassConfig, endpointConfiguration);
        assertEquals("100", gassDataFetcher.fetchFormattedAmount(new BigDecimal("1")));
        assertEquals("100", gassDataFetcher.fetchFormattedAmount(new BigDecimal("1.0")));
        assertEquals("100", gassDataFetcher.fetchFormattedAmount(new BigDecimal("1.00")));
        assertEquals("101", gassDataFetcher.fetchFormattedAmount(new BigDecimal("1.01")));
        assertEquals("110", gassDataFetcher.fetchFormattedAmount(new BigDecimal("1.1")));
        assertEquals("53793", gassDataFetcher.fetchFormattedAmount(new BigDecimal("537.93")));
    }
}
