package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;


import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.springframework.test.util.AssertionErrors.assertTrue;

public class CreateUniqueNumberTest {
    @Test
    public void createUniqueNumberNotNullOk() {
        CreateUniqueNumber createUniqueNumber = new CreateUniqueNumber();
        assertFalse(createUniqueNumber.getUniqueNumber().isEmpty());
    }

    @Test
    public void checkFormat1() {
        CreateUniqueNumber createUniqueNumber = new CreateUniqueNumber();
        String upr = createUniqueNumber.getUniqueNumber();
        assertTrue("UPR '" + upr + "' doesn't match the reg", upr.matches("MORTGAGE[0-9]{10}"));
    }
}
