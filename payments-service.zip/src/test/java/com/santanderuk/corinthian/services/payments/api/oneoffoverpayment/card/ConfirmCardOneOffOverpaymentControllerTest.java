package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import java.util.Objects;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class ConfirmCardOneOffOverpaymentControllerTest {

    @Mock
    CardOneOffOverpaymentService cardOneOffOverpaymentService;

    @Mock
    private HttpServletRequest httpServletRequest;

    ConfirmCardOneOffOverpaymentController controller;

    @BeforeEach
    void setUp() {
        controller = new ConfirmCardOneOffOverpaymentController(cardOneOffOverpaymentService);
    }

    @Test
    void testHappyPath() throws GeneralException {
        var confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        when(httpServletRequest.getHeader(anyString())).thenReturn("127.0.0.1");
        when(cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, "OPAYO2022101716573142238673162", confirmCardOneOffPaymentRequest, "jwtToken", "127.0.0.1")).thenReturn(TestDataCreator.generateConfirmCardPaymentResponseOk());

        ResponseEntity<CardPaymentResponseWrapper> cardPaymentResponseResponseEntity = controller.confirmCardOneOffOverpayment("jwtToken", 12345678, "OPAYO2022101716573142238673162", confirmCardOneOffPaymentRequest, httpServletRequest);

        assertEquals(HttpStatus.CREATED, cardPaymentResponseResponseEntity.getStatusCode());
        assertEquals(201, cardPaymentResponseResponseEntity.getStatusCodeValue());
        assertTrue(Objects.requireNonNull(cardPaymentResponseResponseEntity.getBody()).getData().isPaymentDone());
        assertNull(cardPaymentResponseResponseEntity.getBody().getData().getThreeDSDetails());
        assertNull(cardPaymentResponseResponseEntity.getBody().getData().getTransactionId());
        assertEquals("some-data", cardPaymentResponseResponseEntity.getBody().getData().getBase64Pdf());
        assertEquals("ok", cardPaymentResponseResponseEntity.getBody().getInfo().getStatus());
    }

    @Test
    void testException() throws GeneralException {
        var confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        when(httpServletRequest.getHeader(anyString())).thenReturn("127.0.0.1");
        when(cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, "OPAYO2022101716573142238673162", confirmCardOneOffPaymentRequest, "jwtToken", "127.0.0.1")).thenThrow(new OpayoException("OPAYO_CLIENT_EXC", "Exception while calling confirm-transaction baas api"));

        GeneralException generalException = assertThrows(GeneralException.class, () -> controller.confirmCardOneOffOverpayment("jwtToken", 12345678, "OPAYO2022101716573142238673162", confirmCardOneOffPaymentRequest, httpServletRequest));

        assertEquals("OPAYO_CLIENT_EXC", generalException.getCode());
        assertEquals("Exception while calling confirm-transaction baas api", generalException.getMessage());
    }

}
