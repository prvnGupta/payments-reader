package com.santanderuk.corinthian.services.payments.functional.internalTransfer;


import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

@ActiveProfiles("test")
public class MortgageOverpaymentsInternalTransferFunctionalTest extends FunctionalTest {

    String internalTransferOneOffOverpaymentUrl;
    Header header;

    @BeforeEach
    void setupThisTest() {

        internalTransferOneOffOverpaymentUrl = String.format("http://localhost:%s/payments-service/34218165/internal-transfer-one-off-overpayment", serverPort);
        header = new Header("authorization", jwtAuth);
    }

    @Test
    public void testHappyPathReduceMonthlyPayment() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "data.paymentDone", equalTo(true),
                        "data.base64Pdf", not(equalTo("")),
                        "info.status", equalTo("ok")
                );
    }

    @Test
    public void testHappyPathReduceMonthlyPaymentWRegion() {
        stubHeartbeatRegionW();
        stubGetCustomerInfoWRegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "data.paymentDone", equalTo(true),
                        "data.base64Pdf", not(equalTo("")),
                        "info.status", equalTo("ok")
                );
    }

    @Test
    public void testHappyPathReduceTerm() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceTerm();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "data.paymentDone", equalTo(true),
                        "data.base64Pdf", not(equalTo(""))
                );
    }

    @Test
    public void testCustomerInfoExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoExc();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testAccountDetailsExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetailsExc();
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testRetrieveMccExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMccExc();
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testContractsInMccExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMccExc();
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testBalancesApiExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesExc();
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testLACExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacExc();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testSimulationExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationExc();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testHeartbeatExc() {
        stubHeartbeatRegionX();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(503);
    }


    @Test
    public void testSimulationError() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationError();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testUpdatePaymentMethodError() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodKO();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testUpdatePaymentMethodExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodExc();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(500);
    }

    @Test
    public void testMakePaymentKO() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentKoBlockedAccount();
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200);
    }

    @Test
    public void testFraudCheckKO() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOkDeclinedResponse();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200);
    }

    @Test
    public void testSetupPaymentKo() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentKo("internal-transfer/setup-payment/setup-payment-response-ko.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200);
    }

    @Test
    public void testSetupPaymentExc() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentExc();
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxNRTOK();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200);
    }

    @Test
    public void testLynxNRTExceptionIgnored() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTKO();
        stubSimulationApply();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "data.paymentDone", equalTo(true),
                        "data.base64Pdf", not(equalTo(""))
                );
    }

    @Test
    public void testApplyPaymentErrorDoesntThrowException() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");
        stubContractsInMcc("bks-connect/bks-connect-retrieve-mcc-ok-response-34218165.json");
        stubAccountBalancesOK("balance/balance-response-ok-34218165.json");
        stubLacOkForAccount09012686890994();
        stubLacOkForAccount09008520007437034218165Surname();
        stubSimulationReduceMonthlyPayment();
        stubSimulationUpdatePaymentMethodOK();
        stubSetupPartenonPaymentOk("internal-transfer/setup-payment/setup-payment-response-ok.json");
        stubLynxFraudCheckOk("internal-transfer/lynx-fraud/lynx-fraud-ok.json");
        stubMakePaymentOk("internal-transfer/make-payment/make-payment-ok.json");
        stubLynxNRTOK();
        stubSimulationApplyKo();

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body(readFileContents("internal-transfer-one-off-overpayment/reduce-monthly-payment-valid-request.json"))
                .when()
                .put(internalTransferOneOffOverpaymentUrl)
                .then()
                .statusCode(200)
                .and()
                .body(
                        "data.paymentDone", equalTo(true),
                        "data.base64Pdf", not(equalTo(""))
                );
    }
}
