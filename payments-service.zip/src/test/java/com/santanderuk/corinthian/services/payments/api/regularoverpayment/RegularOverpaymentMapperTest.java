package com.santanderuk.corinthian.services.payments.api.regularoverpayment;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.*;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.ILoanData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.OverpaymentArrangementRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.RegularOverpaymentInput;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.OPayArrOvpInst;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.config.PaymentServiceConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(SpringExtension.class)
public class RegularOverpaymentMapperTest {

    @Mock
    PaymentServiceConfig config;
    private RegularOverpaymentMapper regularOverpaymentMapper;

    @BeforeEach
    void before() {
        regularOverpaymentMapper = new RegularOverpaymentMapper(config);
        Mockito.when(config.getSetUpRegularInstructionSequence()).thenReturn("0");
        Mockito.when(config.getSetUpRegularInstructionCallingApp()).thenReturn("OVERPAYMENTS");
        Mockito.when(config.getSetUpRegularInstructionSourceApp()).thenReturn("SANTANDER OLB");
        Mockito.when(config.getSetUpRegularInstructionType()).thenReturn("D");
        Mockito.when(config.getSetUpRegularInstructionAction()).thenReturn("S");
        Mockito.when(config.getSetUpRegularInstructionChannelType()).thenReturn("5");
        Mockito.when(config.getSetUpRegularInstructionLoanOrder()).thenReturn("1");
        Mockito.when(config.getSetUpRegularInstructionStopErc()).thenReturn("Y");
        Mockito.when(config.getSetUpRegularUserId()).thenReturn("OVPDIGU");
        Mockito.when(config.getSetUpRegularInstructionToUse()).thenReturn("N");
    }

    @Test
    public void testMapperUntilFurtherNotice() {
        SetUpRegularOverpaymentServiceInput setUpRegularOverpaymentServiceInput = generateControllerInputUntilFurtherNotice("untilfurthernotice");
        AnmfRegularOverpaymentCUDRequest setUpExpectedRequest = generateCoreRequest("", "Y");
        String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();
        context.setControllerRequest(setUpRegularOverpaymentServiceInput);
        context.setJwtToken(jwtWithCustomer554);
        context.setAccount(123456789);
        context.setSequential(0);
        context.setInstructionAction("S");
        AnmfRegularOverpaymentCUDRequest setUpRequest = regularOverpaymentMapper.generateSetUpEditCoreRequest(context);

        RegularOverpaymentInput actualInputStruc = setUpRequest.getOverpaymentArrangementRequest().getInputStruc();
        RegularOverpaymentInput expectedInputStruc = setUpExpectedRequest.getOverpaymentArrangementRequest().getInputStruc();

        assertThat(actualInputStruc.getIBdpNumber(), equalTo(expectedInputStruc.getIBdpNumber()));
        assertThat(actualInputStruc.getIBdpType(), equalTo(expectedInputStruc.getIBdpType()));
        assertThat(actualInputStruc.getICallingAppl(), equalTo(expectedInputStruc.getICallingAppl()));
        assertThat(actualInputStruc.getIChannelType(), equalTo(expectedInputStruc.getIChannelType()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getIApplSeqNo(), equalTo(expectedInputStruc.getILoanDatas().get(0).getIApplSeqNo()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getILoanOrder(), equalTo(expectedInputStruc.getILoanDatas().get(0).getILoanOrder()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getILoanSch(), equalTo(expectedInputStruc.getILoanDatas().get(0).getILoanSch()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getIOvpInstStopErc(), equalTo(expectedInputStruc.getILoanDatas().get(0).getIOvpInstStopErc()));
        assertThat(actualInputStruc.getIMortAccNo(), equalTo(expectedInputStruc.getIMortAccNo()));
        assertThat(actualInputStruc.getIOvpInstEndDate(), equalTo(expectedInputStruc.getIOvpInstEndDate()));
        assertThat(actualInputStruc.getIOvpInstImpact(), equalTo(expectedInputStruc.getIOvpInstImpact()));
        assertThat(actualInputStruc.getIOvpInstNoEndDate(), equalTo(expectedInputStruc.getIOvpInstNoEndDate()));
        assertThat(actualInputStruc.getIOvpInstStartDate(), equalTo(expectedInputStruc.getIOvpInstStartDate()));
        assertThat(actualInputStruc.getIOvpInstSeq(), equalTo(expectedInputStruc.getIOvpInstSeq()));
        assertThat(actualInputStruc.getIOvpInstAction(), equalTo(expectedInputStruc.getIOvpInstAction()));
        assertThat(actualInputStruc.getIOvpInstToUse(), equalTo("N"));
        assertThat(actualInputStruc.getIUserId(), equalTo("OVPDIGU"));
    }

    @Test
    public void testMapperOvpInstImpactWithIOLoanTypeR() {
        SetUpRegularOverpaymentServiceInput setUpRegularOverpaymentServiceInput = generateControllerInputUntilFurtherNotice("untilfurthernotice");
        String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();
        context.setControllerRequest(setUpRegularOverpaymentServiceInput);
        context.setJwtToken(jwtWithCustomer554);
        context.setAccount(123456789);
        context.setSequential(0);
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setORepaymentType("R");
        AnmfRegularOverpaymentCUDRequest setUpRequest = regularOverpaymentMapper.generateSetUpEditCoreRequest(context);

        RegularOverpaymentInput actualInputStruc = setUpRequest.getOverpaymentArrangementRequest().getInputStruc();

        assertThat(actualInputStruc.getIOvpInstImpact(), equalTo("T"));
    }

    @Test
    public void testMapperOvpInstImpactForMultiLoanWithIOLoanTypeR() {
        SetUpRegularOverpaymentServiceInput setUpRegularOverpaymentServiceInput = generateControllerInputUntilFurtherNotice("untilfurthernotice");
        String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();
        context.setControllerRequest(setUpRegularOverpaymentServiceInput);
        context.setJwtToken(jwtWithCustomer554);
        context.setAccount(123456789);
        context.setSequential(0);
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setORepaymentType("R");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).setORepaymentType("R");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(2).setORepaymentType("I");
        AnmfRegularOverpaymentCUDRequest setUpRequest = regularOverpaymentMapper.generateSetUpEditCoreRequest(context);

        RegularOverpaymentInput actualInputStruc = setUpRequest.getOverpaymentArrangementRequest().getInputStruc();

        assertThat(actualInputStruc.getIOvpInstImpact(), equalTo("T"));
    }

    @Test
    public void testMapperOvpInstImpactForMultiLoanWithIOLoanTypeMixed() {
        SetUpRegularOverpaymentServiceInput setUpRegularOverpaymentServiceInput = generateControllerInputUntilFurtherNotice("untilfurthernotice");
        String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();
        context.setControllerRequest(setUpRegularOverpaymentServiceInput);
        context.setJwtToken(jwtWithCustomer554);
        context.setAccount(123456789);
        context.setSequential(0);
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).setORepaymentType("I");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).setORepaymentType("R");
        AnmfRegularOverpaymentCUDRequest setUpRequest = regularOverpaymentMapper.generateSetUpEditCoreRequest(context);

        RegularOverpaymentInput actualInputStruc = setUpRequest.getOverpaymentArrangementRequest().getInputStruc();

        assertThat(actualInputStruc.getIOvpInstImpact(), equalTo(""));
    }

    @Test
    public void testMapperUntilFixedEndDateSingleLoan() {
        SetUpRegularOverpaymentServiceInput setUpRegularOverpaymentServiceInput = generateControllerInputUntilFurtherNotice("31/12/2019");
        AnmfRegularOverpaymentCUDRequest setUpExpectedRequest = generateCoreRequest("31/12/2019", "N");
        String jwtWithCustomer554 = "Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IkludGVybmV0X1JTMjU2In0.eyJpc3MiOiJJbnRlcm5ldCIsInN1YiI6InBnd2U1MVpEIiwiYXVkIjpbImFubWYiLCJwYXltZW50cyIsImlvYyIsImlzYyIsImx5bngiXSwibmJmIjoxNTA3ODE2NDU4LCJleHAiOjE1MDc4MjAwNTgsImlhdCI6MTUwNzgxNjQ1OCwianRpIjoiNDNjNDM2YjQtNmEyOS00ZWQ1LWE0ZWItYTM2MWQwYTU4ZjhmIiwibWlzIjoiYTpCNDY1Nzg4MTczQ0UwNzAwMTA1MEQ4Qjg6RjU1NDowMDE1OmViYW5raW5nIn0.LFea7Gcr61387fm-ai4hBRS-dnfoIjujrBMmAL9WezDVve2ov5VzfYMYLGuPmLF7FROHQ9sTUjlpgiDNuvgw-oZlW4yaFf6OTQOgXVn6OZPLLvxRL8U2X65-JXvZpIV6n3vLA2lIsManE0jsjt7C2UvMiQsB0veeCbbwPSZRU1CJbjnuWF7KWhZy2zAqKq47rVOOosHveWAEuu0rxGS-aMN3xdYwbKOlIEEZen9Jgqr_YEE4FHlCovFmZXpp5dM_AKCxQaHUm_EhA3nd2tnRnemqSMybq04BPZIA7iSTiXc-VXKfCQSUNurdvxI9tol2_tPZdeWpKfY-KlA8ngvJ8g";

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();
        context.setControllerRequest(setUpRegularOverpaymentServiceInput);
        context.setJwtToken(jwtWithCustomer554);
        context.setAccount(123456789);
        context.setSequential(0);
        context.setInstructionAction("S");
        AnmfRegularOverpaymentCUDRequest setUpRequest = regularOverpaymentMapper.generateSetUpEditCoreRequest(context);

        RegularOverpaymentInput actualInputStruc = setUpRequest.getOverpaymentArrangementRequest().getInputStruc();
        RegularOverpaymentInput expectedInputStruc = setUpExpectedRequest.getOverpaymentArrangementRequest().getInputStruc();

        assertThat(actualInputStruc.getIBdpNumber(), equalTo(expectedInputStruc.getIBdpNumber()));
        assertThat(actualInputStruc.getIBdpType(), equalTo(expectedInputStruc.getIBdpType()));
        assertThat(actualInputStruc.getICallingAppl(), equalTo(expectedInputStruc.getICallingAppl()));
        assertThat(actualInputStruc.getISourceAppl(), equalTo(expectedInputStruc.getISourceAppl()));
        assertThat(actualInputStruc.getIChannelType(), equalTo(expectedInputStruc.getIChannelType()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getIApplSeqNo(), equalTo(expectedInputStruc.getILoanDatas().get(0).getIApplSeqNo()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getILoanOrder(), equalTo(expectedInputStruc.getILoanDatas().get(0).getILoanOrder()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getILoanSch(), equalTo(expectedInputStruc.getILoanDatas().get(0).getILoanSch()));
        assertThat(actualInputStruc.getILoanDatas().get(0).getIOvpInstStopErc(), equalTo(expectedInputStruc.getILoanDatas().get(0).getIOvpInstStopErc()));
        assertThat(actualInputStruc.getIMortAccNo(), equalTo(expectedInputStruc.getIMortAccNo()));
        assertThat(actualInputStruc.getIOvpInstEndDate(), equalTo(expectedInputStruc.getIOvpInstEndDate()));
        assertThat(actualInputStruc.getIOvpInstImpact(), equalTo(expectedInputStruc.getIOvpInstImpact()));
        assertThat(actualInputStruc.getIOvpInstNoEndDate(), equalTo(expectedInputStruc.getIOvpInstNoEndDate()));
        assertThat(actualInputStruc.getIOvpInstStartDate(), equalTo(expectedInputStruc.getIOvpInstStartDate()));
        assertThat(actualInputStruc.getIOvpInstSeq(), equalTo(expectedInputStruc.getIOvpInstSeq()));
        assertThat(actualInputStruc.getIOvpInstAction(), equalTo(expectedInputStruc.getIOvpInstAction()));
        assertThat(actualInputStruc.getIOvpInstToUse(), equalTo("N"));
        assertThat(actualInputStruc.getIUserId(), equalTo("OVPDIGU"));
    }

    @Test
    public void testMapperCreateDeleteRequest() {

        OPayArrOvpInst OPayArrOvpInst = new OPayArrOvpInst();
        OPayArrOvpInst.setOPayArrEndDate("12/03/2019");
        OPayArrOvpInst.setOPayArrImpact("YOUR_MUM");
        OPayArrOvpInst.setOPayArrNoEndDate("YES");
        OPayArrOvpInst.setOPayArrMonPay(10.00);

        OActiveLoan oActiveLoan = new OActiveLoan();
        oActiveLoan.setOApplSeqNo(1);
        oActiveLoan.setOLoanSch("SomeScheme");


        OStruc oStruc = new OStruc();
        oStruc.setOActiveLoans(Collections.singletonList(oActiveLoan));
        oStruc.setOContMonPay(new BigDecimal("20.00"));


        AnmfAccountServiceResponse anmfAccountServiceResponse = new AnmfAccountServiceResponse();
        AccountServiceResponse accoutResponse = new AccountServiceResponse();
        Response response = new Response();
        response.setOStruc(oStruc);
        accoutResponse.setResponse(response);
        anmfAccountServiceResponse.setAccountServiceResponse(accoutResponse);

        final var context = new RegularOverpaymentContext();
        context.setAnmfAccountResponse(anmfAccountServiceResponse);
        context.setJwtToken("jwt-token");
        context.setAccount(12345);
        context.setSequential(1);
        context.setInstructionAction("C");
        context.setInstruction(OPayArrOvpInst);

        AnmfRegularOverpaymentCUDRequest cudRequest =
                regularOverpaymentMapper.generateDeleteRequest(context);

        RegularOverpaymentInput actualInputStruc = cudRequest.getOverpaymentArrangementRequest().getInputStruc();

        assertEquals(0, actualInputStruc.getILoanDatas().size());
        assertThat(actualInputStruc.getIBdpNumber(), equalTo(999999999));
        assertThat(actualInputStruc.getIMortAccNo(), equalTo(12345));
        assertThat(actualInputStruc.getIOvpInstEndDate(), equalTo("12/03/2019"));
        assertThat(actualInputStruc.getIBdpType(), equalTo("F"));
        assertThat(actualInputStruc.getIOvpInstImpact(), equalTo("YOUR_MUM"));
        assertThat(actualInputStruc.getIOvpInstNoEndDate(), equalTo("Y"));
        assertThat(actualInputStruc.getIOvpInstSeq(), equalTo(1));
        assertThat(actualInputStruc.getIOvpInstAction(), equalTo("C"));
        assertThat(actualInputStruc.getIOvpInstToUse(), equalTo("N"));
        assertThat(actualInputStruc.getIUserId(), equalTo("OVPDIGU"));

    }

    private AnmfRegularOverpaymentCUDRequest generateCoreRequest(String endDate, String endDateFlag) {
        AnmfRegularOverpaymentCUDRequest coreRequest = new AnmfRegularOverpaymentCUDRequest();

        var overpaymentArrangementRequest = new OverpaymentArrangementRequest();

        RegularOverpaymentInput input = new RegularOverpaymentInput();

        input.setIOvpInstTotMonPay(new BigDecimal("150.00"));
        input.setIOvpInstStartDate("12/12/2111");
        input.setIOvpInstSeq(0);
        input.setIOvpInstToUse("N");
        input.setIOvpInstAction("S");
        input.setIOvpInstNoEndDate(endDateFlag);
        input.setIOvpInstImpact("");
        input.setIOvpInstEndDate(endDate);
        input.setIMortAccNo(123456789);
        input.setIBdpNumber(554);
        input.setICallingAppl("OVERPAYMENTS");
        input.setISourceAppl("SANTANDER OLB");
        input.setIChannelType("5");
        input.setIBdpType("F");
        ILoanData loanData = new ILoanData();
        loanData.setIOvpInstStopErc("Y");
        loanData.setILoanOrder(1);
        loanData.setILoanSch("3T");
        loanData.setIApplSeqNo("3");
        var loanList = new ArrayList<ILoanData>();
        loanList.add(loanData);
        input.setILoanDatas(loanList);

        overpaymentArrangementRequest.setInputStruc(input);
        coreRequest.setOverpaymentArrangementRequest(overpaymentArrangementRequest);

        return coreRequest;
    }

    private SetUpRegularOverpaymentServiceInput generateControllerInputUntilFurtherNotice(String endDate) {
        SetUpRegularOverpaymentServiceInput controllerInput = new SetUpRegularOverpaymentServiceInput();

        controllerInput.setEndDate(endDate);

        Loan loan = new Loan();
        loan.setAppSequenceNumber("3");
        loan.setLoanSchema("3T");
        loan.setLoanType("R");
        loan.setOrderId(1);
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        controllerInput.setLoans(loanList);

        controllerInput.setOverpaymentAmount(new BigDecimal("50.00"));
        controllerInput.setStartDate("12/12/2111");
        return controllerInput;
    }
}
