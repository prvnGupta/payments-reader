package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup;

import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class SetupPaymentMapperTest {

    @Mock
    private OverpaymentsConfig overpaymentsConfig;

    private SetupPaymentMapper setupPaymentMapper;

    @BeforeEach
    void setUp() {
        setupPaymentMapper = new SetupPaymentMapper(overpaymentsConfig);
    }

    @Test
    void testGenerateSetupRequest() {
        Mockito.when(overpaymentsConfig.getSetupDataCurrency()).thenReturn("GBP");
        Mockito.when(overpaymentsConfig.getSetupDataResidenceCountry()).thenReturn("S");
        Mockito.when(overpaymentsConfig.getSetupDataTransactionBranch()).thenReturn("0075");
        Mockito.when(overpaymentsConfig.getSetupDataExpensesIndicator()).thenReturn("O");
        Mockito.when(overpaymentsConfig.getSetupDataTransmissionType()).thenReturn("O");

        SetupRequest setupRequest = setupPaymentMapper.generateSetupRequest(new PartenonAccountNumber("0015", "4247", "300", "1234567"), new BigDecimal("123.45"));

        assertEquals("0015", setupRequest.getCompany());
        assertEquals("4247", setupRequest.getCentre());
        assertEquals("300", setupRequest.getProduct());
        assertEquals("1234567", setupRequest.getContract());

        assertEquals(123.45, setupRequest.getOverpaymentAmount());

        assertEquals("GBP", setupRequest.getCurrency());
        assertEquals("S", setupRequest.getResidenceCountry());
        assertEquals("0075", setupRequest.getTransactionBranch());
        assertEquals("O", setupRequest.getExpensesIndicator());
        assertEquals("O", setupRequest.getTransmissionType());

        setupRequest.setCurrency(overpaymentsConfig.getSetupDataCurrency());
        setupRequest.setResidenceCountry(overpaymentsConfig.getSetupDataResidenceCountry());
        setupRequest.setTransactionBranch(overpaymentsConfig.getSetupDataTransactionBranch());
        setupRequest.setExpensesIndicator(overpaymentsConfig.getSetupDataExpensesIndicator());
        setupRequest.setTransmissionType(overpaymentsConfig.getSetupDataTransmissionType());

    }
}
