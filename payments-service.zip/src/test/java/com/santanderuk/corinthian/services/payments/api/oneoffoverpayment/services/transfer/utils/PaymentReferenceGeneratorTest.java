package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

class PaymentReferenceGeneratorTest {
    private final PaymentReferenceGenerator paymentReferenceGenerator = new PaymentReferenceGenerator();

    @Test
    void happyPath() {
        assertEquals("123456789SURNAMEAA", paymentReferenceGenerator.generateSingleOverpaymentInternalTransferReference(123456789, "SurnameAA"));
    }

    @Test
    void happyPath1() {
        assertEquals("012345678SURNAMEAA", paymentReferenceGenerator.generateSingleOverpaymentInternalTransferReference(12345678, "SurnameAAA"));
    }

    @Test
    void happyPath2() {
        assertEquals("012345678SURNAM   ", paymentReferenceGenerator.generateSingleOverpaymentInternalTransferReference(12345678, "Surnam"));
    }

    @Test
    void happyPath3() {
        assertEquals("012345678SURNAMEAA", paymentReferenceGenerator.generateSingleOverpaymentInternalTransferReference(12345678, "SurnameAABB"));
    }
}
