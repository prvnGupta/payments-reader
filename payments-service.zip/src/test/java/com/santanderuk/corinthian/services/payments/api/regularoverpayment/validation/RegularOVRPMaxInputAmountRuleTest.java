package com.santanderuk.corinthian.services.payments.api.regularoverpayment.validation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.*;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class RegularOVRPMaxInputAmountRuleTest {

    private RegularOVRPMaxInputAmountRule rule;

    @BeforeEach
    void setUp() {
        rule = new RegularOVRPMaxInputAmountRule();
    }

    @Test
    public void testHappyPathForSingleLoan() throws GeneralException {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("18000"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        rule.validate(context);
    }

    @Test
    public void testHappyPathForAllERCMultiLoans() throws GeneralException {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("18000"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        Loan loan1 = new Loan();
        loan1.setLoanSchema("3R");
        loan1.setAppSequenceNumber("2");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        loanList.add(loan1);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        rule.validate(context);
    }

    @Test
    public void testHappyPathForNoERCMultiLoans() throws GeneralException {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("100"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        Loan loan1 = new Loan();
        loan1.setLoanSchema("3R");
        loan1.setAppSequenceNumber("2");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        loanList.add(loan1);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        rule.validate(context);
    }

    @Test
    public void testHappyPathForMixedMultiLoans() throws GeneralException {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("Y");
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("100"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        Loan loan1 = new Loan();
        loan1.setLoanSchema("3R");
        loan1.setAppSequenceNumber("2");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        loanList.add(loan1);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        rule.validate(context);
    }

    @Test
    public void validationCustomerInputAmountMinus3AmountForNoERCMultiLoans() {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("200"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        Loan loan1 = new Loan();
        loan1.setLoanSchema("3R");
        loan1.setAppSequenceNumber("2");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        loanList.add(loan1);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            rule.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS", e.getCode());
            assertEquals("The amount requested is more than the total balance minus 3 monthly payments", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void validationCustomerInputAmountERCAllowanceForMultiLoans() {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("21000"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        Loan loan1 = new Loan();
        loan1.setLoanSchema("3R");
        loan1.setAppSequenceNumber("2");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        loanList.add(loan1);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            rule.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE", e.getCode());
            assertEquals("The amount requested is more than the ERC Allowance", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void validationCustomerInputAmountMoreThenMinus3MonthsMixedERCMultiLoans() {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(1).getOErcDetailsGrp().setOErcApplFlag("Y");
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("21000"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        Loan loan1 = new Loan();
        loan1.setLoanSchema("3R");
        loan1.setAppSequenceNumber("2");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        loanList.add(loan1);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            rule.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS", e.getCode());
            assertEquals("The amount requested is more than the total balance minus 3 monthly payments", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void validationCustomerInputAmountMaxERCAllowanceForMixedERCMultiLoans() {

        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().add(setMultiLoansWithAllERC());
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("Y");
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().setOCapitalBalance(new BigDecimal("12500.73").setScale(2, RoundingMode.HALF_DOWN));
        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("21000"));
        input.setStartDate("01/02/2019");
        input.setEndDate("31/12/2022");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        Loan loan1 = new Loan();
        loan1.setLoanSchema("3R");
        loan1.setAppSequenceNumber("2");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        loanList.add(loan1);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            rule.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE", e.getCode());
            assertEquals("The amount requested is more than the ERC Allowance", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void testSetUpHasERCApplicableButTheRemainingAllowanceIsZero() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        // Removing the erc allowance amount
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp()
                .getOProdErc().setOTotProdErcAllow(new BigDecimal("0"));

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("135.00"));
        input.setStartDate("01/12/2018");
        input.setEndDate("31/12/2022");

        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            rule.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE", e.getCode());
            assertEquals("The amount requested is more than the ERC Allowance", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void ruleCustomerInputAmountMoreThanERCAllowance() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().getOProdErc().setOTotProdErcAllow(new BigDecimal("1"));

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("100.00"));

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            rule.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE", e.getCode());
            assertEquals("The amount requested is more than the ERC Allowance", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    @Test
    public void ruleCustomerInputAmountMoreThanBalanceMinus3Months() {
        RegularOverpaymentContext context = TestDataCreator.createContextForTest();

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setOverpaymentAmount(new BigDecimal("150.74"));
        input.setStartDate("01/12/2018");
        input.setEndDate("01/12/2018");
        Loan loan = new Loan();
        loan.setLoanSchema("3T");
        loan.setAppSequenceNumber("3");
        var loanList = new ArrayList<Loan>();
        loanList.add(loan);
        input.setLoans(loanList);
        context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().get(0).getOErcDetailsGrp().setOErcApplFlag("N");

        context.setControllerRequest(input);

        boolean exceptionThrown = false;
        try {
            rule.validate(context);
        } catch (ValidationsException e) {
            exceptionThrown = true;
            assertEquals("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS", e.getCode());
            assertEquals("The amount requested is more than the total balance minus 3 monthly payments", e.getMessage());
        }
        assertTrue(exceptionThrown);
    }

    private OActiveLoanDetail setMultiLoansWithAllERC() {

        OActiveLoanDetail oActiveLoanDetail = new OActiveLoanDetail();
        oActiveLoanDetail.setOStartDate("21/07/2018");
        oActiveLoanDetail.setOProductDesc("2 YEAR FIXED");
        oActiveLoanDetail.setORecBalance(new BigDecimal("549.23"));
        oActiveLoanDetail.setOArrearsBalance(new BigDecimal("450.77"));
        oActiveLoanDetail.setOCapitalBalance(new BigDecimal("300.00"));
        oActiveLoanDetail.setODrawdownLeft(new BigDecimal("500.00"));
        oActiveLoanDetail.setOInterestRate(new BigDecimal("1.09"));
        oActiveLoanDetail.setOBaseRate(new BigDecimal("0.5"));
        oActiveLoanDetail.setOBaseRateDiff(new BigDecimal("0.59"));
        oActiveLoanDetail.setOProductEndDate("01/04/2023");
        oActiveLoanDetail.setORedemptionDate("01/05/2056");
        oActiveLoanDetail.setORemainingInstlm(14);
        oActiveLoanDetail.setORepaymentType("I");

        var ercDetailsGrp = new OErcDetailsGrp();
        ercDetailsGrp.setOErcApplFlag("Y");
        ercDetailsGrp.setOErcAllowPerc("10.00%");
        OProdErc productErc = new OProdErc();
        ercDetailsGrp.setOProdErc(productErc);

        ercDetailsGrp.setOLoanErc(new OLoanErc());
        ercDetailsGrp.setORdmStmErc(new BigDecimal("365.36"));
        oActiveLoanDetail.setOErcDetailsGrp(ercDetailsGrp);

        ORevisionaryDetails revisionaryDetails = new ORevisionaryDetails();
        revisionaryDetails.setOReviBaseRate(new BigDecimal("2.75"));
        revisionaryDetails.setOReviStartDate("");
        revisionaryDetails.setOReviProdDesc("");
        oActiveLoanDetail.setORevisionaryDetails(revisionaryDetails);

        oActiveLoanDetail.setOLoanScheme("3R");
        oActiveLoanDetail.setOApplSeqNo(2);
        oActiveLoanDetail.setOProductCode("I");

        productErc.setOTotProdErcAllow(new BigDecimal("10000.00"));

        return oActiveLoanDetail;
    }
}
