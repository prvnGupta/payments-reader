package com.santanderuk.corinthian.services.payments.rabbitmq;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("test")
@Getter
public class TestConsumerConfig {

    @Value("${gassrabbitmq.host}")
    private String gassMqHost;

    @Value("${gassrabbitmq.gassqueue}")
    private String gassMqQueue;

    @Value("${gassrabbitmq.username}")
    private String gassMqUsername;

    @Value("${gassrabbitmq.password}")
    private String gassMqPassword;

    @Value("${gassrabbitmq.port}")
    private int gassMqPort;
}
