package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalServiceResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class CardOperationalServiceTest {

    @Mock
    CardOperationalClient cardOperationalClient;

    CardOperationalService cardOperationalService;

    @BeforeEach
    void setUp() {
        cardOperationalService = new CardOperationalService(cardOperationalClient);
    }

    @Test
    void testOwnSantanderCard() throws IOException, CardOperationalException {
        Mockito.when(cardOperationalClient.callCardOperational("4462000000000003")).thenReturn(TestDataCreator.generateCardOperationalOkResponse());
        CardOperationalServiceResponse cardOperationalServiceResponse = cardOperationalService.checkIfSantanderCard(TestDataCreator.generateDefaultCardPaymentInputRequestSecondBorrower());
        assertTrue(cardOperationalServiceResponse.isSantanderCard());
        assertTrue(cardOperationalServiceResponse.isOnwSantanderCard());
    }

    @Test
    void testSantanderCard() throws IOException, CardOperationalException {
        Mockito.when(cardOperationalClient.callCardOperational("4462000000000003")).thenReturn(TestDataCreator.generateCardOperationalOkResponse());
        CardOperationalServiceResponse cardOperationalServiceResponse = cardOperationalService.checkIfSantanderCard(TestDataCreator.generateDefaultCardPaymentInputRequest());
        assertTrue(cardOperationalServiceResponse.isSantanderCard());
        assertFalse(cardOperationalServiceResponse.isOnwSantanderCard());
    }

    @Test
    void testNonSantanderCard() throws IOException, CardOperationalException {
        Mockito.when(cardOperationalClient.callCardOperational("4462000000000003")).thenThrow(CardOperationalException.class);
        CardOperationalServiceResponse cardOperationalServiceResponse = cardOperationalService.checkIfSantanderCard(TestDataCreator.generateDefaultCardPaymentInputRequestSecondBorrower());
        assertFalse(cardOperationalServiceResponse.isSantanderCard());
        assertFalse(cardOperationalServiceResponse.isOnwSantanderCard());
    }
}
