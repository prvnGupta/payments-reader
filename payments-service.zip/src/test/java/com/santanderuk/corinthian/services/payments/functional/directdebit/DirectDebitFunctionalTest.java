package com.santanderuk.corinthian.services.payments.functional.directdebit;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class DirectDebitFunctionalTest extends FunctionalTest {

    String directDebitUrl;
    Header header;

    @BeforeEach
    void setUpThisTest() {
        directDebitUrl = String.format("http://localhost:%s/payments-service/34218165/change-direct-debit-details", serverPort);
        header = new Header("authorization", jwtAuth);
    }

    @Test
    void changeDirectDebitDetailsBadRequestOkayResponse() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"isInternalAccount\": true,\n" +
                        "  \"sortcode\": \"090126\",\n" +
                        "  \"accountNumber\": \"12345678\"\n" +
                        "}").
                when().put(directDebitUrl).
                then().statusCode(200).and().
                body("data.changed", equalTo(true),
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found")
                );
    }

    @Test
    void changeDirectDebitDetailsBadRequest() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"isInternalAccount\": true/false,\n" +
                        "  \"sortcode\": \"090126\",\n" +
                        "  \"accountNumber\": \"12345678\"\n" +
                        "}").
                when().put(directDebitUrl).
                then().statusCode(400);
    }

    @Test
    void changeDirectDebitDetailsUnsupportedMediaError() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        RestAssured.given().
                contentType(ContentType.XML).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"isInternalAccount\": true,\n" +
                        "  \"sortcode\": \"090126\",\n" +
                        "  \"accountNumber\": \"12345678\"\n" +
                        "}").
                when().put(directDebitUrl).
                then().statusCode(415);
    }

    @Test
    void changeDirectDebitDetailsBadRequestOperativeSecurityError() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoExc();
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"isInternalAccount\": true,\n" +
                        "  \"sortcode\": \"090126\",\n" +
                        "  \"accountNumber\": \"12345678\"\n" +
                        "}").
                when().put(directDebitUrl).
                then().statusCode(500);
    }

}
