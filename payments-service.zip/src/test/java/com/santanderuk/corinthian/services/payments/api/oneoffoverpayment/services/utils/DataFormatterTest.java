package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.utils;

import com.santanderuk.corinthian.services.commons.time.TimeMachine;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;

class DataFormatterTest {

    DataFormatter dataFormatter = new DataFormatter();

    @BeforeEach
    void setUp() {
        mockTodaysDate("08/06/2022 00:00");
    }

    @Test
    void testgetTodayFormattedDate() {
        assertEquals("08/06/2022", dataFormatter.getTodayFormattedDate());
    }

    @Test
    void testNewMortgageTerm() {
        mockTodaysDate("29/11/2022 00:00");
        assertEquals("4 years 0 months", dataFormatter.calculateTermRemaining("28/11/2026"));
        assertEquals("4 years 1 month", dataFormatter.calculateTermRemaining("30/11/2026"));
        assertEquals("4 years 0 months", dataFormatter.calculateTermRemaining("29/11/2026"));
        assertEquals("4 years 0 months", dataFormatter.calculateTermRemaining("07/11/2026"));
        assertEquals("6 years 1 month", dataFormatter.calculateTermRemaining("01/12/2028"));
    }

    @Test
    void testNewMortgageTerm2() {
        assertEquals("20 years 4 months", dataFormatter.calculateTermRemaining("08/10/2042"));
    }

    @Test
    void testNewMortgageTerm3() {
        assertEquals("20 years 5 months", dataFormatter.calculateTermRemaining("31/10/2042"));
    }

    @Test
    void testNewMortgageTerm4() {
        assertEquals("19 years 11 months", dataFormatter.calculateTermRemaining("30/04/2042"));
    }

    @Test
    void testNewMortgageTerm4b() {
        assertEquals("20 years 0 months", dataFormatter.calculateTermRemaining("31/05/2042"));
    }

    @Test
    void testNewMortgageTerm4c() {
        mockTodaysDate("05/11/2022 00:00");
        assertEquals("1 year 1 month", dataFormatter.calculateTermRemaining("07/11/2023"));
    }

    @Test
    void testNewMortgageTerm5() {
        assertEquals("20 years 0 months", dataFormatter.calculateTermRemaining("08/06/2042"));
    }

    @Test
    void testNewMortgageTerm6() {
        assertEquals("0 years 1 month", dataFormatter.calculateTermRemaining("08/07/2022"));
    }

    @Test
    void testNewMortgageTerm7() {
        assertEquals("0 years 1 month", dataFormatter.calculateTermRemaining("09/06/2022"));
    }

    @Test
    void testNewMortgageTerm8() {
        assertEquals("1 year 1 month", dataFormatter.calculateTermRemaining("09/06/2023"));
    }

    @Test
    void testNewMortgageTerm9() {
        assertEquals("1 year 0 months", dataFormatter.calculateTermRemaining("08/06/2023"));
    }

    @Test
    void testNewMortgageTerm10() {
        assertEquals("1 year 0 months", dataFormatter.calculateTermRemaining("09/05/2023"));
    }

    private void mockTodaysDate(String mockedDate) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        LocalDateTime mockedDateForThisTest = LocalDateTime.parse(mockedDate, formatter);
        TimeMachine.useFixedClockAt(mockedDateForThisTest);
    }
}
