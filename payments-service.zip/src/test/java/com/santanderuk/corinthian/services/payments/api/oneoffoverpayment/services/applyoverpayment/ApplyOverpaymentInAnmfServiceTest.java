package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.applyoverpayment;

import com.santanderuk.corinthian.hub.paymentsmqwriter.interfaces.PaymentMqWriterServiceInterface;
import com.santanderuk.corinthian.hub.paymentsmqwriter.model.MqPaymentItem;
import com.santanderuk.corinthian.services.commons.anmfclient.ApplyOverpaymentClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationMapper;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationService;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsMqConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ApplyOverpaymentInAnmfServiceTest {

    public static final String URL = "https://dummy/mortgage-payments/payments";
    ApplyOverpaymentInAnmfService applyOverpaymentInAnmfService;

    @Mock
    EndpointConfiguration endpointConfiguration;
    @Mock
    HeartBeatClient heartBeatClient;
    @Mock
    ApplyOverpaymentMapper applyOverpaymentMapper;
    @Mock
    ApplyOverpaymentClient applyOverpaymentClient;
    @Mock
    OverpaymentsMqConfig overpaymentsMqConfig;
    @Mock
    PaymentMqWriterServiceInterface paymentMqWriterService;
    @Mock
    SimulationService simulationService;
    @Mock
    SimulationMapper simulationMapper;

    @BeforeEach
    void setUp() {
        applyOverpaymentInAnmfService = new ApplyOverpaymentInAnmfService(endpointConfiguration, heartBeatClient, applyOverpaymentMapper, applyOverpaymentClient, overpaymentsMqConfig, paymentMqWriterService, simulationService, simulationMapper);
    }

    @Test
    void testWeCallMapper() throws IOException, MaintenanceException, ConnectionException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        when(applyOverpaymentMapper.generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr")).thenReturn(TestDataCreator.generateDefaultAnmfPaymentRequest());
        when(endpointConfiguration.getAnmfApplyOverpaymentUrl()).thenReturn(URL);
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(applyOverpaymentMapper, times(1)).generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr");
    }

    @Test
    void testWeCallClientInARegion() throws IOException, MaintenanceException, ConnectionException {
        when(overpaymentsMqConfig.getApplyPaymentEmergeUser()).thenReturn("eMergeUser");
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        ApplyOverpaymentRequest applyOverpaymentRequest = TestDataCreator.generateDefaultAnmfPaymentRequest();
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(endpointConfiguration.getAnmfApplyOverpaymentUrl()).thenReturn(URL);
        when(applyOverpaymentMapper.generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr")).thenReturn(applyOverpaymentRequest);
        when(applyOverpaymentClient.pay(URL, applyOverpaymentRequest, "eMergeUser")).thenReturn(TestDataCreator.generateApplyPaymentSuccessResponse());
        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(applyOverpaymentClient, times(1)).pay(URL, applyOverpaymentRequest, "eMergeUser");
    }

    @Test
    void testWeCallSimulationV2AndUpdatePaymentMethodARegion() throws IOException, GeneralException {
        when(overpaymentsMqConfig.getApplyPaymentEmergeUser()).thenReturn("eMergeUser");
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        ApplyOverpaymentRequest applyOverpaymentRequest = TestDataCreator.generateDefaultAnmfPaymentRequest();
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(endpointConfiguration.getAnmfApplyOverpaymentUrl()).thenReturn(URL);
        when(applyOverpaymentMapper.generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr")).thenReturn(applyOverpaymentRequest);
        when(applyOverpaymentClient.pay(URL, applyOverpaymentRequest, "eMergeUser")).thenReturn(TestDataCreator.generateApplyPaymentSuccessResponse());

        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(simulationService, times(1)).createOverpaymentSimulationV2(mortgageSingleOverpaymentsContext);
        verify(simulationService, times(1)).updatePaymentMethodV2(mortgageSingleOverpaymentsContext);
        verify(applyOverpaymentClient, times(1)).pay(URL, applyOverpaymentRequest, "eMergeUser");
    }

    @Test
    void testWeDontCallSimulationV2AndUpdatePaymentMethodV2InWRegion() throws IOException, GeneralException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        ApplyOverpaymentRequest applyOverpaymentRequest = TestDataCreator.generateDefaultAnmfPaymentRequest();

        when(simulationMapper.generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 2)).thenReturn(TestDataCreator.generateDefaultAnmfSimulationV2Request());
        when(simulationMapper.generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 2)).thenReturn(TestDataCreator.generateDefaultAnmfUpdatePaymentMethodV2Request());

        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.W);
        when(overpaymentsMqConfig.getPaymentsMqHost()).thenReturn("host");
        when(overpaymentsMqConfig.getPaymentsMqPassword()).thenReturn("password");
        when(overpaymentsMqConfig.getPaymentsMqPort()).thenReturn(80);
        when(overpaymentsMqConfig.getPaymentsMqQueue()).thenReturn("queue");
        when(overpaymentsMqConfig.getPaymentsMqUsername()).thenReturn("username");
        when(overpaymentsMqConfig.getPaymentsMqVirtualHost()).thenReturn("virtualHost");
        when(applyOverpaymentMapper.generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr")).thenReturn(applyOverpaymentRequest);
        var mqPaymentItemCaptor = ArgumentCaptor.forClass(MqPaymentItem.class);
        when(paymentMqWriterService.sendPaymentToMQ(mqPaymentItemCaptor.capture())).thenReturn("ok");

        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(applyOverpaymentClient, times(0)).pay(anyString(), any(), anyString());
        verify(simulationService, times(0)).createOverpaymentSimulationV2(mortgageSingleOverpaymentsContext);
        verify(simulationService, times(0)).updatePaymentMethodV2(mortgageSingleOverpaymentsContext);
        verify(simulationMapper, times(1)).generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 2);
        verify(simulationMapper, times(1)).generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 2);
        verify(paymentMqWriterService, times(1)).sendPaymentToMQ(any());
        assertEquals("{\"anmfSimulationRequest\":{\"OverpaymentSimulationRequest\":{\"input_struc\":{\"i_simulation_id\":0,\"i_mort_acc_no\":34218165,\"i_ovp_date\":\"09/11/2023\",\"i_tot_ovp_amount\":11,\"i_original_simulation_id\":7309684,\"i_erc_coll_opt\":\"O\",\"i_chan_type_cd\":\"5\",\"i_sim_version\":2,\"i_bdp_type\":\"F\",\"i_bdp_number\":554,\"i_staff_id\":\"pgwe51ZD\",\"i_calling_appl\":\"OVERPAYMENTS\",\"i_distri_type\":\"O\",\"i_erc_allow_imp\":\"\",\"i_kfi_ref_no\":\"\",\"i_payment_data\":{\"i_sim_pay_meth\":\"\"},\"i_user_id\":\"OVPDIGU\",\"i_loan_data\":[{\"i_loan_sch\":\"3R\",\"i_appl_seq_no\":2,\"i_ln_ovp_amount\":11,\"i_change_type\":\"M\",\"i_erc_waiver\":\"N\",\"i_erc_waiver_rsn\":\"\"}]}}},\"anmfUpdateSimulationRequest\":{\"OverpaymentSimulationRequest\":{\"input_struc\":{\"i_simulation_id\":0,\"i_mort_acc_no\":34218165,\"i_ovp_date\":\"09/11/2023\",\"i_tot_ovp_amount\":0,\"i_original_simulation_id\":7309684,\"i_erc_coll_opt\":\"O\",\"i_chan_type_cd\":\"5\",\"i_sim_version\":2,\"i_bdp_type\":\"F\",\"i_bdp_number\":554,\"i_staff_id\":\"pgwe51ZD\",\"i_calling_appl\":\"OVERPAYMENTS\",\"i_distri_type\":\"O\",\"i_erc_allow_imp\":\"\",\"i_kfi_ref_no\":\"\",\"i_payment_data\":{\"i_sim_pay_meth\":\"TT\"},\"i_user_id\":\"OVPDIGU\",\"i_loan_data\":[{\"i_loan_sch\":\"AA\",\"i_appl_seq_no\":0,\"i_ln_ovp_amount\":0,\"i_change_type\":\"M\",\"i_erc_waiver\":\"N\",\"i_erc_waiver_rsn\":\"\"}]}}},\"applyOverpaymentRequest\":{\"CreateWsPayReceived\":{\"request\":{\"i_struc\":{\"IO32129\":{\"I_ACCOUNT_NO\":11708128,\"I_PMT_TYPE_IN\":\"OVR\",\"I_SIM_PMT_METH\":\"TT\",\"I_SIMULATOR_ID\":85692,\"I_SIM_VAL_DATE\":\"08/06/2022\",\"I_IGN_BACS_NTCE\":\"\",\"I_AMOUNT\":123.12,\"I_BANK_SORT_CODE_1\":0,\"I_BANK_SORT_CODE_2\":0,\"I_BANK_SORT_CODE_3\":0,\"I_BANK_ACCOUNT\":0,\"I_CHEQUE_NUMBER\":\"\",\"I_CHAPS_NO_1\":\"\",\"I_CHAPS_NO_2\":\"\",\"I_CHAPS_NO_3\":\"\",\"I_TRIG_CPLX_RUL\":\"\",\"I_UPR\":\"MORTGAGE2206081638\"}}}}}}", mqPaymentItemCaptor.getValue().getMessage());
    }

    @Test
    void testWeDontCallClientInWRegion() throws IOException, MaintenanceException, ConnectionException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        ApplyOverpaymentRequest applyOverpaymentRequest = TestDataCreator.generateDefaultAnmfPaymentRequest();

        doReturn(AnmfRegion.W).when(heartBeatClient).fetchCurrentRegion();
        doReturn("host").when(overpaymentsMqConfig).getPaymentsMqHost();
        doReturn("password").when(overpaymentsMqConfig).getPaymentsMqPassword();
        doReturn(80).when(overpaymentsMqConfig).getPaymentsMqPort();
        doReturn("queue").when(overpaymentsMqConfig).getPaymentsMqQueue();
        doReturn("username").when(overpaymentsMqConfig).getPaymentsMqUsername();
        doReturn("virtualHost").when(overpaymentsMqConfig).getPaymentsMqVirtualHost();
        doReturn(applyOverpaymentRequest).when(applyOverpaymentMapper).generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr");
        doReturn(TestDataCreator.generateDefaultAnmfSimulationV2Request()).when(simulationMapper).generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 2);
        doReturn(TestDataCreator.generateDefaultAnmfUpdatePaymentMethodV2Request()).when(simulationMapper).generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 2);

        var mqPaymentItemCaptor = ArgumentCaptor.forClass(MqPaymentItem.class);
        when(paymentMqWriterService.sendPaymentToMQ(mqPaymentItemCaptor.capture())).thenReturn("ok");

        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(simulationMapper, times(1)).generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 2);
        verify(simulationMapper, times(1)).generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 2);
        verify(applyOverpaymentClient, times(0)).pay(anyString(), any(), anyString());
        verify(paymentMqWriterService, times(1)).sendPaymentToMQ(any());
        assertEquals(80, mqPaymentItemCaptor.getValue().getRabbitMqPort());
        assertEquals("virtualHost", mqPaymentItemCaptor.getValue().getRabbitMqVirtualHost());
        assertEquals("username", mqPaymentItemCaptor.getValue().getRabbitMqUsername());
        assertEquals("password", mqPaymentItemCaptor.getValue().getRabbitMqPassword());
        assertEquals("host", mqPaymentItemCaptor.getValue().getRabbitMqHost());
        assertEquals("queue", mqPaymentItemCaptor.getValue().getRabbitMqQueue());
        assertEquals("{\"anmfSimulationRequest\":{\"OverpaymentSimulationRequest\":{\"input_struc\":{\"i_simulation_id\":0,\"i_mort_acc_no\":34218165,\"i_ovp_date\":\"09/11/2023\",\"i_tot_ovp_amount\":11,\"i_original_simulation_id\":7309684,\"i_erc_coll_opt\":\"O\",\"i_chan_type_cd\":\"5\",\"i_sim_version\":2,\"i_bdp_type\":\"F\",\"i_bdp_number\":554,\"i_staff_id\":\"pgwe51ZD\",\"i_calling_appl\":\"OVERPAYMENTS\",\"i_distri_type\":\"O\",\"i_erc_allow_imp\":\"\",\"i_kfi_ref_no\":\"\",\"i_payment_data\":{\"i_sim_pay_meth\":\"\"},\"i_user_id\":\"OVPDIGU\",\"i_loan_data\":[{\"i_loan_sch\":\"3R\",\"i_appl_seq_no\":2,\"i_ln_ovp_amount\":11,\"i_change_type\":\"M\",\"i_erc_waiver\":\"N\",\"i_erc_waiver_rsn\":\"\"}]}}},\"anmfUpdateSimulationRequest\":{\"OverpaymentSimulationRequest\":{\"input_struc\":{\"i_simulation_id\":0,\"i_mort_acc_no\":34218165,\"i_ovp_date\":\"09/11/2023\",\"i_tot_ovp_amount\":0,\"i_original_simulation_id\":7309684,\"i_erc_coll_opt\":\"O\",\"i_chan_type_cd\":\"5\",\"i_sim_version\":2,\"i_bdp_type\":\"F\",\"i_bdp_number\":554,\"i_staff_id\":\"pgwe51ZD\",\"i_calling_appl\":\"OVERPAYMENTS\",\"i_distri_type\":\"O\",\"i_erc_allow_imp\":\"\",\"i_kfi_ref_no\":\"\",\"i_payment_data\":{\"i_sim_pay_meth\":\"TT\"},\"i_user_id\":\"OVPDIGU\",\"i_loan_data\":[{\"i_loan_sch\":\"AA\",\"i_appl_seq_no\":0,\"i_ln_ovp_amount\":0,\"i_change_type\":\"M\",\"i_erc_waiver\":\"N\",\"i_erc_waiver_rsn\":\"\"}]}}},\"applyOverpaymentRequest\":{\"CreateWsPayReceived\":{\"request\":{\"i_struc\":{\"IO32129\":{\"I_ACCOUNT_NO\":11708128,\"I_PMT_TYPE_IN\":\"OVR\",\"I_SIM_PMT_METH\":\"TT\",\"I_SIMULATOR_ID\":85692,\"I_SIM_VAL_DATE\":\"08/06/2022\",\"I_IGN_BACS_NTCE\":\"\",\"I_AMOUNT\":123.12,\"I_BANK_SORT_CODE_1\":0,\"I_BANK_SORT_CODE_2\":0,\"I_BANK_SORT_CODE_3\":0,\"I_BANK_ACCOUNT\":0,\"I_CHEQUE_NUMBER\":\"\",\"I_CHAPS_NO_1\":\"\",\"I_CHAPS_NO_2\":\"\",\"I_CHAPS_NO_3\":\"\",\"I_TRIG_CPLX_RUL\":\"\",\"I_UPR\":\"MORTGAGE2206081638\"}}}}}}", mqPaymentItemCaptor.getValue().getMessage());
    }

    @Test
    void testHeartbeatException() throws IOException, MaintenanceException, ConnectionException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        ApplyOverpaymentRequest applyOverpaymentRequest = TestDataCreator.generateDefaultAnmfPaymentRequest();

        when(heartBeatClient.fetchCurrentRegion()).thenThrow(MaintenanceException.class);
        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(applyOverpaymentClient, times(0)).pay(anyString(), any(), anyString());
        verify(paymentMqWriterService, times(0)).sendPaymentToMQ(any());

    }

    @Test
    void testApplyPaymentOnlineException() throws IOException, MaintenanceException, ConnectionException {
        when(overpaymentsMqConfig.getApplyPaymentEmergeUser()).thenReturn("eMergeUser");
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        ApplyOverpaymentRequest applyOverpaymentRequest = TestDataCreator.generateDefaultAnmfPaymentRequest();
        when(applyOverpaymentMapper.generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr")).thenReturn(applyOverpaymentRequest);
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(endpointConfiguration.getAnmfApplyOverpaymentUrl()).thenReturn(URL);
        when(applyOverpaymentClient.pay(URL, applyOverpaymentRequest, "eMergeUser")).thenThrow(ConnectionException.class);
        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(applyOverpaymentClient, times(1)).pay(anyString(), any(), anyString());
        verify(paymentMqWriterService, times(0)).sendPaymentToMQ(any());

    }

    @Test
    void testApplyPaymentOnlineError() throws IOException, MaintenanceException, ConnectionException {
        when(overpaymentsMqConfig.getApplyPaymentEmergeUser()).thenReturn("eMergeUser");
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        ApplyOverpaymentRequest applyOverpaymentRequest = TestDataCreator.generateDefaultAnmfPaymentRequest();
        when(applyOverpaymentMapper.generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, "upr")).thenReturn(applyOverpaymentRequest);
        when(heartBeatClient.fetchCurrentRegion()).thenReturn(AnmfRegion.A);
        when(endpointConfiguration.getAnmfApplyOverpaymentUrl()).thenReturn(URL);
        when(applyOverpaymentClient.pay(URL, applyOverpaymentRequest, "eMergeUser")).thenReturn(TestDataCreator.generateApplyPaymentKOResponse());
        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, "upr");
        verify(applyOverpaymentClient, times(1)).pay(anyString(), any(), anyString());
        verify(paymentMqWriterService, times(0)).sendPaymentToMQ(any());

    }
}
