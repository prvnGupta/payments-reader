package com.santanderuk.corinthian.services.payments.functional.regularoverpayment;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class SetUpRegularOverpaymentInputValidationTest extends FunctionalTest {

    private String setupRegularPaymentUrl;
    private Header header;

    @BeforeEach
    void setupThisTest() {
        int accountNumber = 12345678;
        setupRegularPaymentUrl = String.format("http://localhost:%s/payments-service/regular-overpayment/%s", serverPort, accountNumber);
        header = new Header("authorization", jwtAuth);
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
    }

    @Test
    public void testRequestValidations() {
        stubSetUpRegularARegion();

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("validation-errors-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testRequestValidationsEndDate() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request-wrong-end-date-parse-exception.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testRequestValidationsTotalOverPaymentAmountInBetween() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-recently-switched.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("controller-request-regular-total-too-low.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testRequestValidationsTotalOverPaymentAmountEqual() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-recently-switched.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("controller-request-regular-total-too-low.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testRequestValidationsTotalOverPaymentAmountForNoERCMultiLoans() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-no-erc-allowance-applicable.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("multi-loan-validation-error-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("The amount requested is more than the total balance minus 3 monthly payments"),
                        "info.code", equalTo("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testRequestValidationsTotalOverPaymentAmountForAllERCMultiLoans() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-multi-with-erc-allowance.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("multi-loan-validation-error-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("The amount requested is more than the ERC Allowance"),
                        "info.code", equalTo("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testRequestValidationsTotalOverPaymentAmountForMixedERCMultiLoans() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-multi-mixed-erc-allow.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("multi-loan-validation-error-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("The amount requested is more than the total balance minus 3 monthly payments"),
                        "info.code", equalTo("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testRequestValidationsTotalOverPaymentAmountForMixedERCMultiLoans2() {
        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-multi-mixed-more-erc-allow.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("multi-loan-validation-error-controller-request.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("The amount requested is more than the ERC Allowance"),
                        "info.code", equalTo("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE"),
                        "info.status", equalTo("ko")
                );
    }

    @Test
    public void testForJira5906() {
        // https://uk-jira.almuk.santanderuk.corp/browse/CORINTHIAN-5906
        // Maximun payment allowed is 5189.6 (included)

        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("bugs/5906/anmf-account-details-response.json");
        stubAnmfLoanPaymentPlan("bugs/5906/anmf-loan-payment-plan-response.json");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        // Maximun payment allowed is 5189.6 (included)
        // In this test we send 5189.59 so it should be ok
        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("bugs/5906/request-overpayment-5189.59.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201)
                .and()
                .body(
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );

        // Maximun payment allowed is 5189.6 (included)
        // In this test we send 5189.6 (one decimal) so it should be ok
        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("bugs/5906/request-overpayment-5189.6.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201)
                .and()
                .body(
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );

        // Maximun payment allowed is 5189.6 (included)
        // In this test we send 5189.60 (two decimal) so it should be ok
        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("bugs/5906/request-overpayment-5189.60.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201)
                .and()
                .body(
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );

        // Maximun payment allowed is 5189.6 (included)
        // In this test we send 5189.61 so it should NOT be ok
        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("bugs/5906/request-overpayment-5189.61.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("The amount requested is more than the ERC Allowance"),
                        "info.code", equalTo("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE"),
                        "info.status", equalTo("ko")
                );
    }


    @Test
    public void testForJira5906whenMaximumPayAllowedEqualToTotalBalMinus3MonthlyPayments() {
        // https://uk-jira.almuk.santanderuk.corp/browse/CORINTHIAN-5906
        // Maximun payment allowed is 52142.10

        stubSetUpRegularARegion();
        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("bugs/5906/anmf-account-details-response-3-monthly-payments.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        // max amount 52412.10
        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("bugs/5906/request-overpayment-52142.10.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201)
                .and()
                .body(
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );
        // 52412.09
        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("bugs/5906/request-overpayment-52142.09.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201)
                .and()
                .body(
                        "info.message", equalTo("Data found"),
                        "info.code", equalTo(""),
                        "info.status", equalTo("ok")
                );

        // more then max amount.. 52142.11
        given().
                contentType(ContentType.JSON).
                header(header).
                body(readFileContents("bugs/5906/request-overpayment-52142.11.json")).
                when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400)
                .and()
                .body(
                        "info.message", equalTo("The amount requested is more than the total balance minus 3 monthly payments"),
                        "info.code", equalTo("EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS"),
                        "info.status", equalTo("ko")
                );

    }

}
