package com.santanderuk.corinthian.services.payments.functional.regularoverpayment;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;


@ActiveProfiles("test")
public class CancelRegularPaymentFunctionalTest extends FunctionalTest {

    String cancelRegularPaymentUrl;
    Header header;
    int accountNumber;

    @BeforeEach
    void setupThisTest() {
        accountNumber = 12345678;
        cancelRegularPaymentUrl = String.format("http://localhost:%s/payments-service/regular-overpayment/%s", serverPort, accountNumber);
        header = new Header("authorization", jwtAuth);
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");
    }

    @Test
    public void testWeGet200WhenDeleteRegularOverpaymentHappyPath() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");


        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json", accountNumber);
        stubAnmfCancelRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(200).
                and().
                body(
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "info.status", equalTo("ok")
                );

    }

    @Test
    public void testWeGet200WhenDeleteRegularOverpaymentHappyPathWithOtherInstructionTypes() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-two-instruction-one-DD-one-no-DD.json", accountNumber);
        stubAnmfCancelRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(200).
                and().
                body(
                        "info.code", equalTo(""),
                        "info.message", equalTo("Data found"),
                        "info.status", equalTo("ok")
                );

    }

    @Test
    public void testWeGet500WhenMoreThanOneOverpaymentInstructionAvailableForAccount() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");


        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-two-existing-instruction.json", accountNumber);
        stubAnmfCancelRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );

    }

    @Test
    public void testWeGet500WhenNoOverpaymentInstructionAvailableForCancellation() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");


        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-no-existing-instruction.json", accountNumber);
        stubAnmfCancelRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );

    }

    @Test
    public void testWeGet500WhenNoOverpaymentInstructionAvailableForCancellationNoDD() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");


        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction-no-DD.json", accountNumber);
        stubAnmfCancelRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );

    }


    @Test
    public void testWeGet500WhenDeleteRegularOverpaymentDown() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-existing-instruction.json", accountNumber);
        stubAnmfCancelRegularOverpaymentAnmfDown();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ANMF_UNAVAILABLE"),
                        "info.message", equalTo("ANMF did not respond correctly"),
                        "info.status", equalTo("ko")
                );

    }


    @Test
    public void testWeGet500WhenPaymentArrangementEnquiryError() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiry("payment-arrangement-enquiry/payment-arrangement-enquiry-error.json", accountNumber);
        stubAnmfCancelRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT"),
                        "info.message", equalTo("Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup"),
                        "info.status", equalTo("ko")
                );

    }


    @Test
    public void testWeGet500WhenPaymentArrangementEnquiryDown() {

        stubGetCustomerInfoARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubPaymentsArrangementEnquiryDown(accountNumber);
        stubAnmfCancelRegularOverpayment();

        given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json")).
                when().
                delete(cancelRegularPaymentUrl).
                then().
                statusCode(500).
                and().
                body(
                        "info.code", equalTo("ANMF_UNAVAILABLE"),
                        "info.message", equalTo("ANMF did not respond correctly"),
                        "info.status", equalTo("ko")
                );

    }

    @Test
    public void testTryingToMakeAPaymentInRegionW() {
        stubHeartbeatRegionW();
        stubGetCustomerInfoWRegion();
        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(cancelRegularPaymentUrl).
                then().
                statusCode(503);
    }


}
