package com.santanderuk.corinthian.services.payments.functional.cardpayment;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.test.context.ActiveProfiles;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.jupiter.api.Assertions.*;

@ActiveProfiles("cacheTest")
public class ConfirmCardPaymentFunctionalTest extends FunctionalTest {

    String confirmCardPaymentUrl;
    String cardPaymentUrl;
    Header header;
    @Autowired
    CacheManager cacheManagerLongLife;

    @BeforeEach
    void setUpThisTest() {
        cardPaymentUrl = String.format("http://localhost:%s/payments-service/34218165/card-one-off-overpayment", serverPort);
        confirmCardPaymentUrl = String.format("http://localhost:%s/payments-service/34218165/confirm-card-one-off-overpayment/OPAYO2022100615004181713317643", serverPort);
        header = new Header("authorization", jwtAuth);
    }

    @Test
    void testHappyPath() {
        makeCardTransactionChallengeCall();

        checkCardTransactionDetailAreInCache();

        stubConfirmTransactionOkResponse();
        stubLacOkForAccount("091586034218165");
        stubUpdateCPSOkResponse();
        stubSimulationReduceTerm();
        stubSimulationUpdatePaymentMethodOKCard();
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");

        RestAssured.given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body("{\"cres\": \"ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcyIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJkZTE5ODFkMC1mYTc2LTRjYmQtYTVhZi01MTZmYWQ4MDY1NjMiLAogICJhY3NUcmFuc0lEIiA6ICIyZTUzYjUxNi01M2VlLTQzZTMtODI3OC00NDQ1ODY1ODU4NTIiLAogICJ0cmFuc1N0YXR1cyIgOiAiWSIKfQ\"}")
                .when().post(confirmCardPaymentUrl).then()
                .statusCode(201)
                .and()
                .body(
                        "data.paymentDone", equalTo(true),
                        "data.transactionId", equalTo(""),
                        "data.threeDSDetails", equalTo(null),
                        "data.base64Pdf", containsString("JVBERi0xLjQKJfbk/N8KMSAwIG9iago8PAovTGFuZyAoZW4tR0IpCi9NZXRhZGF0YSAyIDAgUgovUGFnZXMgMyAwIFIKL1R5cGUgL0NhdGFsb2cKL1ZpZXdlclByZWZlcmVuY2VzIDw8Ci9EaXJlY3Rpb24gL0wyUgo+Pgo+PgplbmRvYmoKNCAwIG9iago8PAovQ3JlYXRpb"),
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found"));

        checkCardTransactionDetailsDeleted();
    }

    @Test
    void testConfirmDeclined() {

        makeCardTransactionChallengeCall();

        checkCardTransactionDetailAreInCache();

        stubConfirmTransactionDeclinedResponse();
        stubLacOkForAccount("091586034218165");
        stubUpdateCPSOkResponse();
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");

        RestAssured.given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body("{\"cres\": \"ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcyIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJkZTE5ODFkMC1mYTc2LTRjYmQtYTVhZi01MTZmYWQ4MDY1NjMiLAogICJhY3NUcmFuc0lEIiA6ICIyZTUzYjUxNi01M2VlLTQzZTMtODI3OC00NDQ1ODY1ODU4NTIiLAogICJ0cmFuc1N0YXR1cyIgOiAiWSIKfQ\"}")
                .when()
                .post(confirmCardPaymentUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("CARD_TRANSACTION_KO"),
                        "info.message", equalTo("Could not process card-payment")
                );

        checkCardTransactionDetailsDeleted();

    }

    @Test
    void testConfirmException() {

        makeCardTransactionChallengeCall();

        checkCardTransactionDetailAreInCache();

        stubConfirmErrorResponse();
        stubLacOkForAccount("091586034218165");
        stubUpdateCPSOkResponse();
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok-34218165.json");

        RestAssured.given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body("{\"cres\": \"ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcyIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJkZTE5ODFkMC1mYTc2LTRjYmQtYTVhZi01MTZmYWQ4MDY1NjMiLAogICJhY3NUcmFuc0lEIiA6ICIyZTUzYjUxNi01M2VlLTQzZTMtODI3OC00NDQ1ODY1ODU4NTIiLAogICJ0cmFuc1N0YXR1cyIgOiAiWSIKfQ\"}")
                .when()
                .post(confirmCardPaymentUrl)
                .then()
                .statusCode(500)
                .and()
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("CONFIRM_EXC"),
                        "info.message", equalTo("Failed call to Confirm baas Api")
                );

        checkCardTransactionDetailsDeleted();

    }

    private void makeCardTransactionChallengeCall() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubCardTransactionChallengeResponse();
        stubCardOperationalSantanderCard();
        stubLacOkForAccount("091586034218165");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubUpdateCPSOkResponse();
        stubSimulationReduceTerm();
        stubSimulationUpdatePaymentMethodOKCard();
        RestAssured.given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header)
                .body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F555\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}")
                .when()
                .post(cardPaymentUrl)
                .then()
                .statusCode(201)
                .and()
                .body(
                        "data.paymentDone", equalTo(false),
                        "data.transactionId", equalTo("OPAYO2022100615004181713317643"),
                        "data.threeDSDetails.outputUrl", equalTo("https://test.sagepay.com/3ds-simulator/html_challenge"),
                        "data.threeDSDetails.outputCode", equalTo("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJlOWE4NmVlOS0wMjFlLTQ0N2MtYjczMS0wNjQzODNiN2M0NzAiLAogICJhY3NUcmFuc0lEIiA6ICJjMmM4MTRmMi0yYjE3LTQxMDQtODJiOS1mMWM5NWEyOWJlZTEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwNCIKfQ"),
                        "data.base64Pdf", equalTo(""),
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found")
                );
    }

    @Test
    void shouldReturnInvalidCres() {
        RestAssured.given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .header(header).body("{\"cres\":\"\"}")
                .when()
                .post(confirmCardPaymentUrl)
                .then().statusCode(400)
                .and()
                .body(
                        "info.status", equalTo("ko"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.message", equalTo("cres is invalid")
                );
    }

    private void checkCardTransactionDetailAreInCache() {
        Cache cacheGetRegularOverpayment = cacheManagerLongLife.getCache("card-transaction");
        Cache.ValueWrapper valueWrapper = cacheGetRegularOverpayment.get("card-transaction-OPAYO2022100615004181713317643");
        CardTransactionDetails cachedBeforeConfirm = (CardTransactionDetails) valueWrapper.get();

        assertNotNull(cachedBeforeConfirm);
        assertEquals("ANXXXXXXXX", cachedBeforeConfirm.getCardHolderLastName());
        assertEquals("SARAH", cachedBeforeConfirm.getCardHolderFirstName());
    }

    private void checkCardTransactionDetailsDeleted() {
        Cache cacheGetRegularOverpayment = cacheManagerLongLife.getCache("card-transaction");
        Cache.ValueWrapper valueWrapper = cacheGetRegularOverpayment.get("card-transaction-OPAYO2022100615004181713317643");
        Cache.ValueWrapper valueWrapperAfter = cacheGetRegularOverpayment.get("card-transaction-OPAYO2022100615004181713317643");
        assertNull(valueWrapperAfter);
    }
}
