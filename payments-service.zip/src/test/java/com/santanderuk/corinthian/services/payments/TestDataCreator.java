package com.santanderuk.corinthian.services.payments;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.*;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.AnmfLoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.LoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.OutputStruc;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.ANMFPaymentArrangementResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.request.AnmfPaymentHolidayAmendCancelRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymentholidayamendcancel.response.AnmfPaymentHolidayAmendCancelResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.paymenyholiday.AnmfPaymentHolidayResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.BdpCustomer;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalAccountDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.CreateUniqueNumber;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.DebitRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.DebitResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.ThreeDSDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.*;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request.CardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.CardTransactionResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.confirmtransaction.request.ConfirmCardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationData;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationDataMultiLoan;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationDataSingleLoan;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFLoan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationDataMapper.MORTGAGE_SORT_CODE_BY_DEFAULT;
import static com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationDataMapper.PAYMENT_METHOD_DEBIT_CARD;
import static com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationFileCreator.STRING_DEBIT_CARD;

public class TestDataCreator {

    public static RegularOverpaymentContext createContextForTest() {
        RegularOverpaymentContext context = new RegularOverpaymentContext();
        context.setAnmfAccountResponse(buildAccountInfoResponse());
        context.setAnmfLoanPaymentPlanResponse(buildLoanPaymentPlanResponse());
        return context;
    }

    public static AnmfAccountServiceResponse buildAccountInfoResponse() {

        AnmfAccountServiceResponse anmfAccountServiceResponse = new AnmfAccountServiceResponse();

        AccountServiceResponse accountServiceResponse = new AccountServiceResponse();
        Response response = new Response();
        OStruc oStruc = new OStruc();

        EStruc eStruct = new EStruc();
        eStruct.setECode("");
        eStruct.setEMessage("");
        eStruct.setEProgname("");

        oStruc.setEStruc(eStruct);
        oStruc.setOCapitalBalance(new BigDecimal("300.73").setScale(2, RoundingMode.HALF_DOWN));
        oStruc.setOArrearsBalance(new BigDecimal(0).setScale(2, RoundingMode.HALF_DOWN));
        oStruc.setOContMonPay(new BigDecimal("50.00"));
        oStruc.setONextMonthlyPayment(new BigDecimal("60.00"));
        oStruc.setOSecondMonthlyPayment(new BigDecimal("65.00"));

        OLinkedAccount oLinkedAccount = new OLinkedAccount();
        oLinkedAccount.setOLegSysAcNo(new BigInteger("123456789"));
        oLinkedAccount.setOLinkType("S");
        oStruc.setOLinkedAccount(Collections.singletonList(oLinkedAccount));

        oStruc.setORecBalance(new BigDecimal(0));
        oStruc.setOSundriesArrears(new BigDecimal(0));
        oStruc.setOSundriesRec(new BigDecimal(0));
        oStruc.setONextPaymentDt("12/12/2018");

        oStruc.setOActiveLoanDetails(buildActiveLoanDetails());

        response.setOStruc(oStruc);
        accountServiceResponse.setResponse(response);
        anmfAccountServiceResponse.setAccountServiceResponse(accountServiceResponse);


        return anmfAccountServiceResponse;
    }

    public static List<OActiveLoanDetail> buildActiveLoanDetails() {


        List<OActiveLoanDetail> activeLoanDetails = new ArrayList<>(3);

        OActiveLoanDetail oActiveLoanDetail1 = new OActiveLoanDetail();
        oActiveLoanDetail1.setOStartDate("21/07/2018");
        oActiveLoanDetail1.setOProductDesc("4 YEAR FIXED");
        oActiveLoanDetail1.setORecBalance(new BigDecimal("549.23"));
        oActiveLoanDetail1.setOArrearsBalance(new BigDecimal("450.77"));
        oActiveLoanDetail1.setOCapitalBalance(new BigDecimal("300.00"));
        oActiveLoanDetail1.setODrawdownLeft(new BigDecimal("500.00"));
        oActiveLoanDetail1.setOInterestRate(new BigDecimal("1.09"));
        oActiveLoanDetail1.setOBaseRate(new BigDecimal("0.5"));
        oActiveLoanDetail1.setOBaseRateDiff(new BigDecimal("0.59"));
        oActiveLoanDetail1.setOProductEndDate("01/04/2023");
        oActiveLoanDetail1.setORedemptionDate("01/05/2056");
        oActiveLoanDetail1.setORemainingInstlm(14);
        oActiveLoanDetail1.setORepaymentType("I");

        var ercDetailsGrp = new OErcDetailsGrp();
        ercDetailsGrp.setOErcApplFlag("Y");
        ercDetailsGrp.setOErcAllowPerc("10.00%");
        ercDetailsGrp.setOProdErc(new OProdErc());
        ercDetailsGrp.getOProdErc().setOTotProdErcAllow(new BigDecimal("10000.00"));
        ercDetailsGrp.setOLoanErc(new OLoanErc());
        ercDetailsGrp.setORdmStmErc(new BigDecimal("365.36"));
        oActiveLoanDetail1.setOErcDetailsGrp(ercDetailsGrp);

        oActiveLoanDetail1.setORevisionaryDetails(new ORevisionaryDetails());
        oActiveLoanDetail1.getORevisionaryDetails().setOReviBaseRate(new BigDecimal("2.75"));
        oActiveLoanDetail1.getORevisionaryDetails().setOReviStartDate("");
        oActiveLoanDetail1.getORevisionaryDetails().setOReviProdDesc("");
        oActiveLoanDetail1.setOLoanScheme("3T");
        oActiveLoanDetail1.setOApplSeqNo(3);
        oActiveLoanDetail1.setOProductCode("R");

        OActiveLoanDetail oActiveLoanDetail2 = new OActiveLoanDetail();
        oActiveLoanDetail2.setOStartDate("21/07/2018");
        oActiveLoanDetail2.setOProductDesc("2 YEAR FIXED");
        oActiveLoanDetail2.setORecBalance(new BigDecimal("549.23"));
        oActiveLoanDetail2.setOArrearsBalance(new BigDecimal("450.77"));
        oActiveLoanDetail2.setOCapitalBalance(new BigDecimal("300.00"));
        oActiveLoanDetail2.setODrawdownLeft(new BigDecimal("500.00"));
        oActiveLoanDetail2.setOInterestRate(new BigDecimal("1.09"));
        oActiveLoanDetail2.setOBaseRate(new BigDecimal("0.5"));
        oActiveLoanDetail2.setOBaseRateDiff(new BigDecimal("0.59"));
        oActiveLoanDetail2.setOProductEndDate("01/04/2023");
        oActiveLoanDetail2.setORedemptionDate("01/05/2056");
        oActiveLoanDetail2.setORemainingInstlm(14);
        oActiveLoanDetail2.setORepaymentType("R");

        var ercDetailsGrp2 = new OErcDetailsGrp();
        ercDetailsGrp2.setOErcApplFlag("Y");
        ercDetailsGrp2.setOErcAllowPerc("10.00%");
        ercDetailsGrp2.setOProdErc(new OProdErc());
        ercDetailsGrp2.getOProdErc().setOTotProdErcAllow(new BigDecimal("0.00"));
        ercDetailsGrp2.setOLoanErc(new OLoanErc());
        ercDetailsGrp2.setORdmStmErc(new BigDecimal("365.36"));
        oActiveLoanDetail2.setOErcDetailsGrp(ercDetailsGrp2);

        oActiveLoanDetail2.setORevisionaryDetails(new ORevisionaryDetails());
        oActiveLoanDetail2.getORevisionaryDetails().setOReviBaseRate(new BigDecimal("2.75"));
        oActiveLoanDetail2.getORevisionaryDetails().setOReviStartDate("");
        oActiveLoanDetail2.getORevisionaryDetails().setOReviProdDesc("");

        oActiveLoanDetail2.setOLoanScheme("3T");
        oActiveLoanDetail2.setOApplSeqNo(3);
        oActiveLoanDetail2.setOProductCode("R");


        OActiveLoanDetail oActiveLoanDetail3 = new OActiveLoanDetail();
        oActiveLoanDetail3.setOStartDate("21/07/2018");
        oActiveLoanDetail3.setOProductDesc("3 YEAR FIXED");
        oActiveLoanDetail3.setORecBalance(new BigDecimal("549.23"));
        oActiveLoanDetail3.setOArrearsBalance(new BigDecimal("450.77"));
        oActiveLoanDetail3.setOCapitalBalance(new BigDecimal("300.00"));
        oActiveLoanDetail3.setODrawdownLeft(new BigDecimal("500.00"));
        oActiveLoanDetail3.setOInterestRate(new BigDecimal("1.09"));
        oActiveLoanDetail3.setOBaseRate(new BigDecimal("0.5"));
        oActiveLoanDetail3.setOBaseRateDiff(new BigDecimal("0.59"));
        oActiveLoanDetail3.setOProductEndDate("01/04/2023");
        oActiveLoanDetail3.setORedemptionDate("01/05/2056");
        oActiveLoanDetail3.setORemainingInstlm(14);
        oActiveLoanDetail3.setORepaymentType("I");

        var ercDetailsGrp3 = new OErcDetailsGrp();
        ercDetailsGrp3.setOErcApplFlag("Y");
        ercDetailsGrp3.setOErcAllowPerc("10.00%");
        ercDetailsGrp3.setOProdErc(new OProdErc());
        ercDetailsGrp3.getOProdErc().setOTotProdErcAllow(new BigDecimal("0.00"));
        ercDetailsGrp3.setOLoanErc(new OLoanErc());
        ercDetailsGrp3.setORdmStmErc(new BigDecimal("365.36"));
        oActiveLoanDetail3.setOErcDetailsGrp(ercDetailsGrp3);

        oActiveLoanDetail3.setORevisionaryDetails(new ORevisionaryDetails());
        oActiveLoanDetail3.getORevisionaryDetails().setOReviBaseRate(new BigDecimal("2.75"));
        oActiveLoanDetail3.getORevisionaryDetails().setOReviStartDate("");
        oActiveLoanDetail3.getORevisionaryDetails().setOReviProdDesc("");

        oActiveLoanDetail3.setOLoanScheme("3F");
        oActiveLoanDetail3.setOApplSeqNo(3);
        oActiveLoanDetail3.setOProductCode("R");


        activeLoanDetails.add(oActiveLoanDetail1);
        activeLoanDetails.add(oActiveLoanDetail2);
        activeLoanDetails.add(oActiveLoanDetail3);

        return activeLoanDetails;
    }


    public static AnmfLoanPaymentPlanResponse buildLoanPaymentPlanResponse() {
        AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse = new AnmfLoanPaymentPlanResponse();
        LoanPaymentPlanResponse loanPaymentPlanResponse = new LoanPaymentPlanResponse();
        OutputStruc loanPaymentPlanResponseOutputStruct = new OutputStruc();
        loanPaymentPlanResponseOutputStruct.setOBacsCycle("N");
        loanPaymentPlanResponseOutputStruct.setONextAvailPaymentDt("01/12/2018");
        loanPaymentPlanResponseOutputStruct.setONextPaymentDate("01/11/2018");
        loanPaymentPlanResponseOutputStruct.setOLastPaymentDate("01/10/2018");
        loanPaymentPlanResponse.setOutputStruc(loanPaymentPlanResponseOutputStruct);
        anmfLoanPaymentPlanResponse.setLoanPaymentPlanResponse(loanPaymentPlanResponse);
        return anmfLoanPaymentPlanResponse;
    }

    public static AnmfPaymentHolidayResponse generateDefaultPaymentHolidayDetailsCoreResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-details/anmf-payment-holiday-details.json", AnmfPaymentHolidayResponse.class);
    }

    public static CardOneOffPaymentRequest generateDefaultCardPaymentInputRequest() throws IOException {
        return FixtureReader.get("card-payment/card-payment-input-request-default.json", CardOneOffPaymentRequest.class);
    }

    public static CardOneOffPaymentRequest generateDefaultCardPaymentInputRequestSecondBorrower() throws IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = FixtureReader.get("card-payment/card-payment-input-request-default.json", CardOneOffPaymentRequest.class);
        cardOneOffPaymentRequest.getCardDetails().setCustomerId("F555");
        return cardOneOffPaymentRequest;
    }

    public static AnmfPaymentHolidayResponse generateCancelledPaymentHolidayDetailsCoreResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-details/anmf-payment-holiday-details-cancelled.json", AnmfPaymentHolidayResponse.class);
    }

    public static AnmfPaymentHolidayResponse generateCompletedPaymentHolidayDetailsCoreResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-details/anmf-payment-holiday-details-completed.json", AnmfPaymentHolidayResponse.class);
    }

    public static AnmfPaymentHolidayResponse generateCompletedOneMonthStillEligibleCoreResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-details/anmf-payment-holiday-details-completed-one-month-still-eligible.json", AnmfPaymentHolidayResponse.class);
    }

    public static AnmfPaymentHolidayResponse generateActivePaymentHolidayDetailsCoreResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-details/anmf-payment-holiday-details-active.json", AnmfPaymentHolidayResponse.class);
    }


    public static AnmfPaymentHolidayResponse generateActiveNoPendingPaymentHolidayDetailsCoreResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-details/anmf-payment-holiday-active-no-pending.json", AnmfPaymentHolidayResponse.class);
    }

    public static AnmfLoanPaymentPlanResponse generateLoanPaymentPlanResponse() throws IOException {
        return FixtureReader.get("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json", AnmfLoanPaymentPlanResponse.class);
    }

    public static CustomerDetailsResponse generateCustomerServiceInfoResponse() throws IOException {
        return FixtureReader.get("anmf-borrower/mortgage-customer-details-2-borrowers-response.json", CustomerDetailsResponse.class);
    }


    public static CustomerDetailsResponse generateCustomerServiceInfoResponseOnlyOneBorrower() throws IOException {
        return FixtureReader.get("anmf-borrower/mortgage-customer-details-default-response.json", CustomerDetailsResponse.class);
    }


    public static AnmfPaymentHolidayAmendCancelResponse generateAmendCancelPaymentHolidayCoreResponse() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-details/anmf-payment-holiday-amend-cancel.json", AnmfPaymentHolidayAmendCancelResponse.class);
    }


    public static AnmfBelongsToCustomerWithBorrowerList generateAnmfBelongToCustomerWithCustomerInformationList() throws IOException {
        AnmfBelongsToCustomerWithBorrowerList response = new AnmfBelongsToCustomerWithBorrowerList();
        response.setCustomerDetailsResponse(generateCustomerServiceInfoResponse());
        response.setAnmfBelongsToCustomer(true);
        return response;
    }

    public static AnmfBelongsToCustomerWithBorrowerList generateAnmfBelongToCustomerWithCustomerInformationListLongName() throws IOException {
        AnmfBelongsToCustomerWithBorrowerList response = new AnmfBelongsToCustomerWithBorrowerList();
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0).setOSurname("ThisIsALongSurnameThatMustBeTruncated");
        response.setCustomerDetailsResponse(customerDetailsResponse);
        response.setAnmfBelongsToCustomer(true);
        return response;
    }

    public static AnmfBelongsToCustomerWithBorrowerList generateAnmfBelongToCustomerWithCustomerInformationListOnlyOneBorrower() throws IOException {
        AnmfBelongsToCustomerWithBorrowerList response = new AnmfBelongsToCustomerWithBorrowerList();
        response.setCustomerDetailsResponse(generateCustomerServiceInfoResponseOnlyOneBorrower());
        response.setAnmfBelongsToCustomer(true);
        return response;
    }

    public static AnmfBelongsToCustomerWithBorrowerList generateAnmfBelongsToCustomerWithCustomerListFalse() throws IOException {
        AnmfBelongsToCustomerWithBorrowerList response = new AnmfBelongsToCustomerWithBorrowerList();
        response.setCustomerDetailsResponse(generateCustomerServiceInfoResponse());
        response.setAnmfBelongsToCustomer(false);
        return response;
    }

    public static RetrieveMccResponse generateRetrieveMccResponse() throws IOException {
        return FixtureReader.get("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json", RetrieveMccResponse.class);
    }

    public static AnmfPaymentHolidayAmendCancelRequest generateAmendCanceAnmfCoreRequest() throws IOException {
        return FixtureReader.get("anmf-payment-holiday-cancel-request/anmf-payment-holiday-cancel-core-request.json", AnmfPaymentHolidayAmendCancelRequest.class);
    }

    public static SetUpRegularOverpaymentServiceInput generateEditRegControllerRequest() throws IOException {
        return FixtureReader.get("happy-path-controller-request.json", SetUpRegularOverpaymentServiceInput.class);
    }

    public static SetUpRegularOverpaymentServiceInput generateEditRegControllerRequestMultiLoan() throws IOException {
        return FixtureReader.get("multi-loan-happy-path-controller-request.json", SetUpRegularOverpaymentServiceInput.class);
    }

    public static SetUpRegularOverpaymentServiceInput generateEditRegControllerRequestMultiLoanWithInterestOnly() throws IOException {
        return FixtureReader.get("multi-loan-happy-path-controller-request-with-interest-only.json", SetUpRegularOverpaymentServiceInput.class);
    }

    public static SetupRequest generateSetupPaymentDefaultRequest() throws IOException {
        return FixtureReader.get("internal-transfer/setup-payment/setup-payment-default-request.json", SetupRequest.class);
    }

    public static SetupResponse generateSetupPaymentResponseOK() throws IOException {
        return FixtureReader.get("internal-transfer/setup-payment/setup-payment-response-ok.json", SetupResponse.class);
    }

    public static SetupResponse generateSetupPaymentResponseKO() throws IOException {
        return FixtureReader.get("internal-transfer/setup-payment/setup-payment-response-ko.json", SetupResponse.class);
    }

    public static ResponseEntity<SetupResponse> generateSetupPaymentResponseEntityOk() throws IOException {
        return new ResponseEntity<>(generateSetupPaymentResponseOK(), HttpStatus.OK);
    }

    public static ResponseEntity<SetupResponse> generateSetupPaymentResponseEntityKo() throws IOException {
        return new ResponseEntity<>(generateSetupPaymentResponseKO(), HttpStatus.OK);
    }

    public static InternalTransferRequest generateDefaultInternalTransferControllerRequest() {
        InternalTransferRequest internalTransferRequest = new InternalTransferRequest();
        internalTransferRequest.setOriginAccount(new LocalAccountNumber("090127", "1234567"));
        internalTransferRequest.setDestinationAccount(new LocalAccountNumber("SAVING", "X1412345WAR"));
        internalTransferRequest.setPaymentAmount(new BigDecimal("123.45"));
        internalTransferRequest.setPaymentReference("paymentReference");
        internalTransferRequest.setCustomerFirstName("Sponge");
        internalTransferRequest.setCustomerLastName("Bob");
        BdpCustomer bdpCustomer = new BdpCustomer();
        bdpCustomer.setCustomerNumber(1);
        bdpCustomer.setCustomerType("F");
        internalTransferRequest.setBdpCustomer(bdpCustomer);
        return internalTransferRequest;
    }

    public static InternalTransferAccountsDetails generateDefaultInternalTransferAccountsDetails() {
        InternalTransferAccountsDetails accountsDetails = new InternalTransferAccountsDetails();
        InternalAccountDetails accountFrom = new InternalAccountDetails();
        accountFrom.setPartenonAccountNumber(new PartenonAccountNumber("0015", "4247", "300", "1234567"));
        accountFrom.setLocalAccountNumber(new LocalAccountNumber("090127", "12345678"));
        InternalAccountDetails accountTo = new InternalAccountDetails();
        accountTo.setPartenonAccountNumber(new PartenonAccountNumber("company", "centre", "product", "contract"));
        accountTo.setLocalAccountNumber(new LocalAccountNumber("SAVING", "X1412345WAR"));
        accountsDetails.setAccountFrom(accountFrom);
        accountsDetails.setAccountTo(accountTo);
        return accountsDetails;

    }


    public static DebitRequest generateDebitPaymentDefaultRequest() {
        DebitRequest debitRequest = new DebitRequest();
        debitRequest.setSetupRequest(new SetupRequest());
        debitRequest.setSetupResponse(new SetupResponse());
        debitRequest.setSameHolder("Sameholder");
        debitRequest.setReference("reference");
        debitRequest.setCheckDigit("");
        debitRequest.setBeneficiaryName("Mr Blobby");
        debitRequest.setPersonNumber("346255551");
        debitRequest.setBeneficiaryType("BenType");
        debitRequest.setBeneficiaryPartenonEntity("0005");
        debitRequest.setBeneficiaryPartenonCentre("2056");
        debitRequest.setBeneficiaryPartenonProduct("301");
        debitRequest.setBeneficiaryPartenonContract("9497732");
        debitRequest.setCreditAccountBranch("0015");
        return debitRequest;
    }

    public static LynxDataResponse generateDefaultFraudCheckResponse() throws IOException {
        return FixtureReader.get("internal-transfer/lynx-fraud/lynx-fraud-ok.json", LynxDataResponse.class);
    }

    public static DebitResponse generateDefaultDebitPaymentResponse() throws IOException {

        return FixtureReader.get("internal-transfer/make-payment/make-payment-ok.json", DebitResponse.class);
    }

    public static DebitResponse generateDebitPaymentKoResponseUnclearedFunds() throws IOException {

        return FixtureReader.get("internal-transfer/make-payment/make-payment-ko-uncleared-funds.json", DebitResponse.class);
    }

    public static ANMFPaymentArrangementResponse generatePaymentArrangementEnquiryResponse(String fixture) throws IOException {
        return FixtureReader.get(fixture, ANMFPaymentArrangementResponse.class);
    }

    public static MortgageSingleOverpaymentInternalTransferRequest generateMortgageSingleOverpaymentControllerRequest() {
        MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest = new MortgageSingleOverpaymentInternalTransferRequest();
        mortgageSingleOverpaymentInternalTransferRequest.setErcCollectionOption("O");
        mortgageSingleOverpaymentInternalTransferRequest.setOriginAccount(new LocalAccountNumber("090127", "88889999"));
        mortgageSingleOverpaymentInternalTransferRequest.setLoanDetails(generateDefaultLoanDetailsRequest1LoanChangeTypeM());
        return mortgageSingleOverpaymentInternalTransferRequest;

    }

    public static MortgageSingleOverpaymentInternalTransferRequest generateMortgageOneOffMultiLoanControllerRequest() throws IOException {
        return FixtureReader.get("controller-requests/single-ovp/int-transfer-one-off-multiloan.json", MortgageSingleOverpaymentInternalTransferRequest.class);

    }

    public static CardOneOffPaymentRequest generateCardMortgageSingleOverpaymentControllerRequest() {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = new CardOneOffPaymentRequest();
        cardOneOffPaymentRequest.setErcCollectionOption("O");
        cardOneOffPaymentRequest.setLoanDetails(generateDefaultLoanDetailsRequest1LoanChangeTypeM());
        cardOneOffPaymentRequest.setCardDetails(generateCardDetailsRequest());
        return cardOneOffPaymentRequest;

    }

    private static List<LoanDetails> generateDefaultLoanDetailsRequest1LoanChangeTypeM() {
        List<LoanDetails> loanDetailsList = new ArrayList<>(1);
        LoanDetails loanDetails = new LoanDetails();
        loanDetails.setLoanScheme("3T");
        loanDetails.setAppSeqNumber(1);
        loanDetails.setLoanOverpaymentAmount(new BigDecimal("111.11"));
        loanDetails.setLoanChangeType("M");
        loanDetailsList.add(loanDetails);
        return loanDetailsList;
    }

    private static List<LoanDetails> generateDefaultLoanDetailsRequest1LoanChangeTypeT() {
        List<LoanDetails> loanDetailsList = new ArrayList<>(1);
        LoanDetails loanDetails = new LoanDetails();
        loanDetails.setLoanScheme("3I");
        loanDetails.setAppSeqNumber(2);
        loanDetails.setLoanOverpaymentAmount(new BigDecimal("111.11"));
        loanDetails.setLoanChangeType("T");
        loanDetailsList.add(loanDetails);
        return loanDetailsList;
    }

    private static List<LoanDetails> generateDefaultLoanDetailsRequest2LoanChangeTypeT() {
        List<LoanDetails> loanDetailsList = new ArrayList<>(2);

        LoanDetails loanDetails = new LoanDetails();
        loanDetails.setLoanScheme("3I");
        loanDetails.setAppSeqNumber(2);
        loanDetails.setLoanOverpaymentAmount(new BigDecimal("111.11"));
        loanDetails.setLoanChangeType("T");

        LoanDetails loanDetails2 = new LoanDetails();
        loanDetails2.setLoanScheme("3T");
        loanDetails2.setAppSeqNumber(2);
        loanDetails2.setLoanOverpaymentAmount(new BigDecimal("222.22"));
        loanDetails2.setLoanChangeType("T");

        loanDetailsList.add(loanDetails);
        loanDetailsList.add(loanDetails2);
        return loanDetailsList;
    }

    private static List<LoanDetails> generateDefaultLoanDetailsRequest2LoanChangeTypeM() {
        List<LoanDetails> loanDetailsList = new ArrayList<>(2);

        LoanDetails loanDetails = new LoanDetails();
        loanDetails.setLoanScheme("3I");
        loanDetails.setAppSeqNumber(2);
        loanDetails.setLoanOverpaymentAmount(new BigDecimal("111.11"));
        loanDetails.setLoanChangeType("M");

        LoanDetails loanDetails2 = new LoanDetails();
        loanDetails2.setLoanScheme("3T");
        loanDetails2.setAppSeqNumber(2);
        loanDetails2.setLoanOverpaymentAmount(new BigDecimal("222.22"));
        loanDetails2.setLoanChangeType("M");

        loanDetailsList.add(loanDetails);
        loanDetailsList.add(loanDetails2);
        return loanDetailsList;
    }

    public static CardOneOffPaymentRequest generateCardMortgageSingleOverpaymentControllerRequestSecondBorrowerIsCardHolder() {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = new CardOneOffPaymentRequest();
        cardOneOffPaymentRequest.setErcCollectionOption("O");
        cardOneOffPaymentRequest.setLoanDetails(generateDefaultLoanDetailsRequest1LoanChangeTypeM());
        cardOneOffPaymentRequest.setCardDetails(generateCardDetailsRequestSecondBorrowerIsCardHolder());

        return cardOneOffPaymentRequest;

    }

    public static CardDetails generateCardDetailsRequest() {
        CardDetails cardDetails = new CardDetails();
        cardDetails.setCardNumber("1111222233334444");
        cardDetails.setCvv("123");
        cardDetails.setExpiryDate("10/23");
        cardDetails.setCustomerId("F554");
        cardDetails.setAddress(generateNewCadrDetailsAddress());
        return cardDetails;

    }

    public static CardDetails generateCardDetailsRequestSecondBorrowerIsCardHolder() {
        CardDetails cardDetails = new CardDetails();
        cardDetails.setCardNumber("1111222233334444");
        cardDetails.setCvv("123");
        cardDetails.setExpiryDate("10/23");
        cardDetails.setCustomerId("F555");
        cardDetails.setAddress(generateNewCadrDetailsAddress());
        return cardDetails;

    }

    public static Address generateNewCadrDetailsAddress() {
        Address address = new Address();
        address.setLine1("line1");
        address.setLine2("line2");
        address.setCity("Milton");
        address.setPostcode("MK92BQ");
        return address;
    }

    public static AnmfAccountServiceResponse generateDefaultAccountInfoResponse() throws IOException {
        return FixtureReader.get("anmf-account-info/anmf-account-details-response.json", AnmfAccountServiceResponse.class);
    }

    public static AnmfAccountServiceResponse generateDefaultAccountInfoResponseMultiloan() throws IOException {
        return FixtureReader.get("anmf-account-info/anmf-account-details-response-multi-mixed-erc-allow.json", AnmfAccountServiceResponse.class);
    }

    public static AnmfAccountServiceResponse generateDefaultAccountInfoResponseMultiloanPDF() throws IOException {
        return FixtureReader.get("anmf-account-info/anmf-account-details-response-multi-loan-pdf.json", AnmfAccountServiceResponse.class);
    }

    public static MortgageSingleOverpaymentsContext generateInitialMortgageSingleOverpaymentContextSingleLoan() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = new MortgageSingleOverpaymentsContext();

        mortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        mortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        mortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        mortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        mortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        mortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        mortgageSingleOverpaymentsContext.setSimulationChosenValues(TestDataCreator.generateSimulationChosenValues());
        mortgageSingleOverpaymentsContext.setAnmfRegion(AnmfRegion.A);
        mortgageSingleOverpaymentsContext.setInternalTransferAccountsDetails(generateDefaultInternalTransferAccountsDetails());
        mortgageSingleOverpaymentsContext.setMccPartenonAccount(generateMcc());
        mortgageSingleOverpaymentsContext.setAccountFromAlias("123 CURRENT ACCOUNT");
        mortgageSingleOverpaymentsContext.setMccId("0015 1234 520 1234567");

        return mortgageSingleOverpaymentsContext;

    }

    public static MortgageSingleOverpaymentsContext generateInitialMortgageSingleOverpaymentContextMultiLoan() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = new MortgageSingleOverpaymentsContext();

        mortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        mortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        mortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        mortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        mortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        mortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        mortgageSingleOverpaymentsContext.setSimulationChosenValues(TestDataCreator.generateSimulationChosenValuesMultiLoan());
        mortgageSingleOverpaymentsContext.setAnmfRegion(AnmfRegion.A);
        mortgageSingleOverpaymentsContext.setInternalTransferAccountsDetails(generateDefaultInternalTransferAccountsDetails());
        mortgageSingleOverpaymentsContext.setMccPartenonAccount(generateMcc());
        mortgageSingleOverpaymentsContext.setAccountFromAlias("123 CURRENT ACCOUNT");
        mortgageSingleOverpaymentsContext.setMccId("0015 1234 520 1234567");

        return mortgageSingleOverpaymentsContext;

    }

    public static MortgageSingleOverpaymentsContext generateInitialMortgageSingleOverpaymentContextMultiLoanPDFLoanChangeTypeT() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = new MortgageSingleOverpaymentsContext();

        mortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        mortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        mortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        mortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        mortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponseMultiloanPDF());
        mortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        mortgageSingleOverpaymentsContext.setSimulationChosenValues(TestDataCreator.generateSimulationChosenValuesMultiLoanPDFLoanChangeTypeT());
        mortgageSingleOverpaymentsContext.setAnmfRegion(AnmfRegion.A);
        mortgageSingleOverpaymentsContext.setInternalTransferAccountsDetails(generateDefaultInternalTransferAccountsDetails());
        mortgageSingleOverpaymentsContext.setMccPartenonAccount(generateMcc());
        mortgageSingleOverpaymentsContext.setAccountFromAlias("123 CURRENT ACCOUNT");
        mortgageSingleOverpaymentsContext.setMccId("0015 1234 520 1234567");

        return mortgageSingleOverpaymentsContext;

    }

    public static MortgageSingleOverpaymentsContext generateInitialMortgageSingleOverpaymentContextMultiLoanPDFLoanChangeTypeM() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = new MortgageSingleOverpaymentsContext();

        mortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        mortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        mortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        mortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        mortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponseMultiloanPDF());
        mortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        mortgageSingleOverpaymentsContext.setSimulationChosenValues(TestDataCreator.generateSimulationChosenValuesMultiLoanPDFLoanChangeTypeM());
        mortgageSingleOverpaymentsContext.setAnmfRegion(AnmfRegion.A);
        mortgageSingleOverpaymentsContext.setInternalTransferAccountsDetails(generateDefaultInternalTransferAccountsDetails());
        mortgageSingleOverpaymentsContext.setMccPartenonAccount(generateMcc());
        mortgageSingleOverpaymentsContext.setAccountFromAlias("123 CURRENT ACCOUNT");
        mortgageSingleOverpaymentsContext.setMccId("0015 1234 520 1234567");

        return mortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateInitialConfirmMortgageSingleOverpaymentContext() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValues());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(generateCardTransactionDetails());
        cardMortgageSingleOverpaymentsContext.setCres("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcyIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICI3NTA5OTg5My05ZmY4LTQ0MmItOTQ1NC1kZjM3MGQzZjU3M2QiLAogICJhY3NUcmFuc0lEIiA6ICI0MGMxZDExOS1kMTE2LTRiNzItODg5OS00YWUyYzBmNWY5OWMiLAogICJ0cmFuc1N0YXR1cyIgOiAiWSIKfQ");


        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateInitialCardMortgageSingleOverpaymentContext() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValues());
        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(generateCardTransactionDetails());
        cardMortgageSingleOverpaymentsContext.setOrigin("https://dummyUrl.com");

        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateInitialCardMortgageSingleOverpaymentContextMultiLoan() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValuesMultiLoan());
        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(generateCardTransactionDetails());
        cardMortgageSingleOverpaymentsContext.setOrigin("https://dummyUrl.com");

        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateInitialCardMortgageSingleOverpaymentContextMultiLoanPdf() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValuesMultiLoanPDFLoanChangeTypeT());
        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(generateCardTransactionDetailsMultiLoanPdf());
        cardMortgageSingleOverpaymentsContext.setOrigin("https://dummyUrl.com");

        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateCompleteCardMortgageSingleOverpaymentContext() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValues());
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        CardTransactionDetails cardTransactionDetails = generateDefaultCardTransactionDetails();
        cardTransactionDetails.setUpdatedSimulationResponse(generateContextSimulationResponseReduceTerm());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(cardTransactionDetails);
        cardMortgageSingleOverpaymentsContext.setAnmfPartenonAccountNumber(generateDefaultAnmfPartenonAccountNumber());
        cardMortgageSingleOverpaymentsContext.setCardTransactionResponse(generateFrictionlessCardTransactionResponse());

        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateCompleteCardMortgageSingleOverpaymentContextMultiLoanPDF() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponseMultiloanPDF());
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValuesMultiLoan());
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        CardTransactionDetails cardTransactionDetails = generateDefaultCardTransactionDetails();
        cardTransactionDetails.setUpdatedSimulationResponse(generateContextSimulationResponseReduceTermMultiLoan());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(cardTransactionDetails);
        cardMortgageSingleOverpaymentsContext.setAnmfPartenonAccountNumber(generateDefaultAnmfPartenonAccountNumber());
        cardMortgageSingleOverpaymentsContext.setCardTransactionResponse(generateFrictionlessCardTransactionResponse());

        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateCompleteCardMortgageSingleOverpaymentContextChallenge() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setMortgageAccount(123456789);
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValues());
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        CardTransactionDetails cardTransactionDetails = generateDefaultCardTransactionDetails();
        cardTransactionDetails.setUpdatedSimulationResponse(generateContextSimulationResponseReduceTerm());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(cardTransactionDetails);
        cardMortgageSingleOverpaymentsContext.setAnmfPartenonAccountNumber(generateDefaultAnmfPartenonAccountNumber());
        cardMortgageSingleOverpaymentsContext.setCardTransactionResponse(generateChallengeCardTransactionResponse());

        return cardMortgageSingleOverpaymentsContext;

    }

    public static PartenonAccountNumber generateDefaultAnmfPartenonAccountNumber() {
        return new PartenonAccountNumber("0015", "4247", "103", "1122334");
    }

    public static CardMortgageSingleOverpaymentsContext generateCardMortgageSingleOverpaymentContextForCpsStepRejected2() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setMortgageAccount(12345678);
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValues());

        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        CardTransactionDetails cardTransactionDetails = generateCardTransactionDetails();
        cardTransactionDetails.setUpdatedSimulationResponse(generateContextSimulationResponse());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(cardTransactionDetails);
        cardMortgageSingleOverpaymentsContext.setCardTransactionResponse(generateRejected2Response());
        cardMortgageSingleOverpaymentsContext.setAnmfPartenonAccountNumber(generateMcc());
        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateCardMortgageSingleOverpaymentContextForCpsStep() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setMortgageAccount(12345678);
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValues());

        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        CardTransactionDetails cardTransactionDetails = generateCardTransactionDetails();
        cardTransactionDetails.setUpdatedSimulationResponse(generateContextSimulationResponse());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(cardTransactionDetails);
        cardMortgageSingleOverpaymentsContext.setCardTransactionResponse(generateFrictionlessCardTransactionResponse());
        cardMortgageSingleOverpaymentsContext.setAnmfPartenonAccountNumber(generateMcc());
        return cardMortgageSingleOverpaymentsContext;

    }

    public static CardMortgageSingleOverpaymentsContext generateCardMortgageSingleOverpaymentContextMultiLoan() throws IOException {
        CustomerDetailsResponse customerDetailsResponse = generateCustomerServiceInfoResponse();
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();

        cardMortgageSingleOverpaymentsContext.setMortgageAccount(12345678);
        cardMortgageSingleOverpaymentsContext.setLdapUid("ldapUid");
        cardMortgageSingleOverpaymentsContext.setIpAddress("127.0.0.1");
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(generateDefaultAccountInfoResponse());
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().get(0));
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(generateSimulationChosenValuesMultiLoan());

        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(generateDefaultCardPaymentInputRequestSecondBorrower());
        CardTransactionDetails cardTransactionDetails = generateCardTransactionDetails();
        cardTransactionDetails.setUpdatedSimulationResponse(generateContextMultiLoanSimulationResponse());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(cardTransactionDetails);
        cardMortgageSingleOverpaymentsContext.setCardTransactionResponse(generateFrictionlessCardTransactionResponse());
        cardMortgageSingleOverpaymentsContext.setAnmfPartenonAccountNumber(generateMcc());
        return cardMortgageSingleOverpaymentsContext;
    }

    public static CardTransactionDetails generateCardTransactionDetails() {
        CardTransactionDetails cardTransactionDetails = new CardTransactionDetails();
        Address address = new Address();
        address.setCity("Milton Keynes");
        address.setLine1("42 Wickstead Avenue");
        address.setLine2("Grange farm");
        address.setPostcode("MK60NW");

        cardTransactionDetails.setExpiryDate("10/23");
        cardTransactionDetails.setOverpaymentAmount(new BigDecimal("5000.00"));
        cardTransactionDetails.setErcCollectionOption("M");
        cardTransactionDetails.setLoanDetails(generateDefaultLoanDetailsRequest1LoanChangeTypeM());
        cardTransactionDetails.setVendorCode("O20230113095559360804462000003");
        cardTransactionDetails.setCardHolderCustomerId("724602394");
        cardTransactionDetails.setCardHolderFirstName("James");
        cardTransactionDetails.setCardHolderLastName("Smith");
        cardTransactionDetails.setCardHolderBirthDate("01/06/1990");
        cardTransactionDetails.setCardNumber("4462000000000003");
        cardTransactionDetails.setAddress(address);

        return cardTransactionDetails;
    }

    public static CardTransactionDetails generateCardTransactionDetailsMultiLoanPdf() throws IOException {
        CardTransactionDetails cardTransactionDetails = new CardTransactionDetails();
        Address address = new Address();
        address.setCity("Milton Keynes");
        address.setLine1("42 Wickstead Avenue");
        address.setLine2("Grange farm");
        address.setPostcode("MK60NW");

        cardTransactionDetails.setExpiryDate("10/23");
        cardTransactionDetails.setOverpaymentAmount(new BigDecimal("5000.00"));
        cardTransactionDetails.setErcCollectionOption("M");
        cardTransactionDetails.setLoanDetails(generateDefaultLoanDetailsRequest2LoanChangeTypeT());
        cardTransactionDetails.setVendorCode("O20230113095559360804462000003");
        cardTransactionDetails.setCardHolderCustomerId("724602394");
        cardTransactionDetails.setCardHolderFirstName("James");
        cardTransactionDetails.setCardHolderLastName("Smith");
        cardTransactionDetails.setCardHolderBirthDate("01/06/1990");
        cardTransactionDetails.setCardNumber("4462000000000003");
        cardTransactionDetails.setAddress(address);
        cardTransactionDetails.setUpdatedSimulationResponse(generateContextSimulationResponseReduceTermMultiLoan());

        return cardTransactionDetails;
    }

    public static CardTransactionDetails generateDefaultCardTransactionDetails() throws IOException {
        return FixtureReader.get("opayo/redisPersistenceExample.json", CardTransactionDetails.class);
    }

    public static PartenonAccountNumber generateMcc() {
        return new PartenonAccountNumber("0015", "1234", "520", "1234567");
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForUpdatePaymentMethod() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateInitialMortgageSingleOverpaymentContextSingleLoan();
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponse());
        mortgageSingleOverpaymentsContext.setSimIdV1(6983663);
        mortgageSingleOverpaymentsContext.setSimIdV2(7455598);
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForUpdatePaymentMethodReduceMonthlyPaymentMultiLoan() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateInitialMortgageSingleOverpaymentContextMultiLoanPDFLoanChangeTypeM();
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceMonthlyPaymentMultiLoan());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForUpdatePaymentMethodReduceTermMultiLoan() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateInitialMortgageSingleOverpaymentContextMultiLoanPDFLoanChangeTypeT();
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceTermMultiLoan());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForUpdatePaymentMethodReduceBalanceMultiLoan() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateInitialMortgageSingleOverpaymentContextMultiLoanPDFLoanChangeTypeT();
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceBalanceMultiLoan());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForApplyOverpayment() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForPDFReduceTerm() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceTerm());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForPDFReduceBalance() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceBalance());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForPDFReduceMonthlyPayments() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceMonthlyPayment());
        mortgageSingleOverpaymentsContext.getSimulationChosenValues().setLoanDetails(generateDefaultLoanDetailsRequest1LoanChangeTypeM());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceMonthlyPayments() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateMortgageSingleOverpaymentContextForUpdatePaymentMethodReduceMonthlyPaymentMultiLoan();
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceMonthlyPaymentMultiLoan());
        mortgageSingleOverpaymentsContext.getSimulationChosenValues().setLoanDetails(generateDefaultLoanDetailsRequest2LoanChangeTypeM());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceTerm() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateMortgageSingleOverpaymentContextForUpdatePaymentMethodReduceTermMultiLoan();
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceTermMultiLoan());
        mortgageSingleOverpaymentsContext.getSimulationChosenValues().setLoanDetails(generateDefaultLoanDetailsRequest2LoanChangeTypeT());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceBalance() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateMortgageSingleOverpaymentContextForUpdatePaymentMethodReduceBalanceMultiLoan();
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextSimulationResponseReduceBalanceMultiLoan());
        mortgageSingleOverpaymentsContext.getSimulationChosenValues().setLoanDetails(generateDefaultLoanDetailsRequest2LoanChangeTypeT());
        return mortgageSingleOverpaymentsContext;
    }

    public static MortgageSingleOverpaymentsContext generateMortgageSingleOverpaymentContextForMultiLoan() throws IOException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = generateInitialMortgageSingleOverpaymentContextMultiLoan();
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(generateContextMultiLoanSimulationResponse());
        mortgageSingleOverpaymentsContext.setDebitResponse(generateDebitResponse());
        return mortgageSingleOverpaymentsContext;
    }

    public static DebitResponse generateDebitResponse() {
        DebitResponse debitResponse = new DebitResponse();
        debitResponse.setStatus("ok");
        debitResponse.setStatusDescription("ok");
        CreateUniqueNumber createUniqueNumber = new CreateUniqueNumber();
        debitResponse.setCreateUniqueNumber(createUniqueNumber);
        return debitResponse;

    }

    public static SimulationChosenValues generateSimulationChosenValues() {
        SimulationChosenValues simulationChosenValues = new SimulationChosenValues();
        simulationChosenValues.setErcCollectionOption("I");
        simulationChosenValues.setLoanDetails(generateDefaultLoanDetailsRequest1LoanChangeTypeT());
        simulationChosenValues.setPaymentAmount(new BigDecimal("5000.00"));
        return simulationChosenValues;
    }

    public static SimulationChosenValues generateSimulationChosenValuesMultiLoan() {
        SimulationChosenValues simulationChosenValues = new SimulationChosenValues();
        simulationChosenValues.setErcCollectionOption("I");
        simulationChosenValues.setLoanDetails(generateDefaultLoanDetailsRequest2LoanChangeTypeT());
        simulationChosenValues.setPaymentAmount(new BigDecimal("333.33"));
        return simulationChosenValues;
    }

    public static SimulationChosenValues generateSimulationChosenValuesMultiLoanPDFLoanChangeTypeT() {
        SimulationChosenValues simulationChosenValues = new SimulationChosenValues();
        simulationChosenValues.setErcCollectionOption("I");
        simulationChosenValues.setLoanDetails(generateDefaultLoanDetailsRequest2LoanChangeTypeT());
        simulationChosenValues.setPaymentAmount(new BigDecimal("5000.00"));
        return simulationChosenValues;
    }

    public static SimulationChosenValues generateSimulationChosenValuesMultiLoanPDFLoanChangeTypeM() {
        SimulationChosenValues simulationChosenValues = new SimulationChosenValues();
        simulationChosenValues.setErcCollectionOption("I");
        simulationChosenValues.setLoanDetails(generateDefaultLoanDetailsRequest2LoanChangeTypeM());
        simulationChosenValues.setPaymentAmount(new BigDecimal("5000.00"));
        return simulationChosenValues;
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextSimulationResponse() throws IOException {
        return FixtureReader.get("anmf-simulation/default-ok-response.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextSimulationResponseReduceTerm() throws IOException {
        return FixtureReader.get("anmf-simulation/reduceTerm.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextSimulationResponseReduceMonthlyPayment() throws IOException {
        return FixtureReader.get("anmf-simulation/reduceMonthlyPayment.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextSimulationResponseReduceBalance() throws IOException {
        return FixtureReader.get("anmf-simulation/reduceBalance.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextSimulationResponseReduceTermMultiLoan() throws IOException {
        return FixtureReader.get("anmf-simulation/reduceTermMultiLoan.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextSimulationResponseReduceMonthlyPaymentMultiLoan() throws IOException {
        return FixtureReader.get("anmf-simulation/reduceMonthlyPaymentMultiLoan.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextSimulationResponseReduceBalanceMultiLoan() throws IOException {
        return FixtureReader.get("anmf-simulation/reduceBalanceMultiLoan.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static ANMFSimulationResponse generateDefaultSimulationResponse() throws IOException {
        return FixtureReader.get("anmf-simulation/default-ok-response.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationResponse generateUpdatePaymentMethodErrorResponse() throws IOException {
        return FixtureReader.get("anmf-simulation/update-payment-method-ko.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationResponse generateKoSimulationResponse() throws IOException {
        return FixtureReader.get("anmf-simulation/default-ko-response.json", ANMFSimulationResponse.class);
    }

    public static ANMFSimulationRequest generateDefaultAnmfSimulationRequest() throws IOException {
        return FixtureReader.get("anmf-simulation/default-request.json", ANMFSimulationRequest.class);
    }

    public static ANMFSimulationRequest generateDefaultAnmfSimulationV2Request() throws IOException {
        return FixtureReader.get("anmf-simulation/default-request-v2.json", ANMFSimulationRequest.class);
    }

    public static ANMFSimulationRequest generateDefaultAnmfUpdatePaymentMethodV2Request() throws IOException {
        return FixtureReader.get("anmf-simulation/default-update-payment-method-request-v2.json", ANMFSimulationRequest.class);
    }

    public static ApplyOverpaymentRequest generateDefaultAnmfPaymentRequest() throws IOException {
        return FixtureReader.get("anmf-payment/default-request.json", ApplyOverpaymentRequest.class);
    }

    public static ApplyOverpaymentResponse generateApplyPaymentSuccessResponse() throws IOException {
        return FixtureReader.get("anmf-payment/default-ok-response.json", ApplyOverpaymentResponse.class);
    }

    public static ApplyOverpaymentResponse generateApplyPaymentKOResponse() throws IOException {
        return FixtureReader.get("anmf-payment/default-ko-response.json", ApplyOverpaymentResponse.class);
    }

    public static ContractsInMccControllerResponse generateContractsInMccResponse() throws IOException {
        return FixtureReader.get("bks-connect/bks-connect-contracts-in-mcc-response-one-account.json", ContractsInMccControllerResponse.class);
    }

    public static com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc generateContextMultiLoanSimulationResponse() throws IOException {
        return FixtureReader.get("anmf-simulation/default-multi-loan-response.json", ANMFSimulationResponse.class).getOverpaymentSimulationResponse().getOutputStruc();
    }

    public static PDFCreationDataSingleLoan generateDefaultPdfCreationDataForTermReduction() {
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = new PDFCreationDataSingleLoan();

        pdfCreationDataSingleLoan.setChosenHeader("T");
        pdfCreationDataSingleLoan.setMonthlyPaymentSaving("£0.00");
        pdfCreationDataSingleLoan.setMortgageTerm("20 years 3 months (New)");
        pdfCreationDataSingleLoan.setInterestSaving("£3,074.25");
        PDFCreationData pdfCreationData = new PDFCreationData();

        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");

        pdfCreationData.setFirstPayment("£216.97");
        pdfCreationData.setSecondPayment("£216.96");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("08/06/2022");

        pdfCreationDataSingleLoan.setPdfCreationData(pdfCreationData);
        return pdfCreationDataSingleLoan;
    }

    public static PDFCreationDataSingleLoan generateDefaultPdfCreationDataForMonthlyPaymentReduction() {
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = new PDFCreationDataSingleLoan();
        PDFCreationData pdfCreationData = new PDFCreationData();

        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setFirstPayment("£216.97");
        pdfCreationData.setSecondPayment("£216.96");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("08/06/2022");


        pdfCreationDataSingleLoan.setChosenHeader("M");
        pdfCreationDataSingleLoan.setMonthlyPaymentSaving("£4.08");
        pdfCreationDataSingleLoan.setMortgageTerm("20 years 3 months (No change)");
        pdfCreationDataSingleLoan.setInterestSaving("£3,074.25");
        pdfCreationDataSingleLoan.setPdfCreationData(pdfCreationData);
        return pdfCreationDataSingleLoan;
    }

    public static PDFCreationDataSingleLoan generateDefaultPdfCreationDataForBalanceReduction() {
        PDFCreationData pdfCreationData = new PDFCreationData();

        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setFirstPayment("£216.97");
        pdfCreationData.setSecondPayment("£216.96");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("08/06/2022");

        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = new PDFCreationDataSingleLoan();
        pdfCreationDataSingleLoan.setChosenHeader("B");
        pdfCreationDataSingleLoan.setMonthlyPaymentSaving("£0.00");
        pdfCreationDataSingleLoan.setMortgageTerm("20 years 3 months (No change)");
        pdfCreationDataSingleLoan.setInterestSaving("£3,074.25");
        pdfCreationDataSingleLoan.setPdfCreationData(pdfCreationData);
        return pdfCreationDataSingleLoan;
    }

    public static PDFCreationDataMultiLoan generateDefaultPdfCreationDataForTermReductionMultiLoan() {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();

        List<PDFLoan> loanDetails = new ArrayList<>();
        PDFLoan obj1 = new PDFLoan();
        obj1.setDescription("2 year fixed at 1.90%");
        obj1.setBalanceBeforeOverpayment("£5,000.00");
        obj1.setOverpayment("£111.11");
        obj1.setOverpaymentInBigDecimal(new BigDecimal("111.11"));
        obj1.setChosenHeader("T");
        obj1.setMonthlyPaymentSaving("£0.00");
        obj1.setMortgageTerm("20 years 3 months (New)");
        obj1.setInterestSaving("£3,074.25");
        PDFLoan obj2 = new PDFLoan();
        obj2.setDescription("2 year fixed at 1.90%");
        obj2.setBalanceBeforeOverpayment("£5,000.00");
        obj2.setOverpayment("£222.22");
        obj2.setOverpaymentInBigDecimal(new BigDecimal("222.22"));
        obj2.setChosenHeader("T");
        obj2.setMonthlyPaymentSaving("£0.00");
        obj2.setMortgageTerm("20 years 3 months (New)");
        obj2.setInterestSaving("£805.53");
        loanDetails.add(obj1);
        loanDetails.add(obj2);
        pdfCreationDataMultiLoan.setLoanDetails(loanDetails);

        PDFCreationData pdfCreationData = new PDFCreationData();
        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setFirstPayment("£2,081.22");
        pdfCreationData.setSecondPayment("£2,081.21");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("07/10/2023");

        pdfCreationDataMultiLoan.setPdfCreationData(pdfCreationData);

        return pdfCreationDataMultiLoan;
    }

    public static PDFCreationDataMultiLoan generateDefaultPdfCreationDataForTermReductionThreeLoanOneOverpaying() {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();

        List<PDFLoan> loanDetails = new ArrayList<>();
        PDFLoan obj1 = new PDFLoan();
        obj1.setDescription("2 year fixed at 1.90%");
        obj1.setBalanceBeforeOverpayment("£5,000.00");
        obj1.setOverpayment("£0.0");
        obj1.setOverpaymentInBigDecimal(new BigDecimal("0.0"));
        obj1.setChosenHeader("T");
        obj1.setMonthlyPaymentSaving("£0.00");
        obj1.setMortgageTerm("20 years 3 months (New)");
        obj1.setInterestSaving("£3,074.25");
        PDFLoan obj2 = new PDFLoan();
        obj2.setDescription("2 year fixed at 1.90%");
        obj2.setBalanceBeforeOverpayment("£5,000.00");
        obj2.setOverpayment("£222.22");
        obj2.setOverpaymentInBigDecimal(new BigDecimal("222.22"));
        obj2.setChosenHeader("T");
        obj2.setMonthlyPaymentSaving("£0.00");
        obj2.setMortgageTerm("20 years 3 months (New)");
        obj2.setInterestSaving("£805.53");
        PDFLoan obj3 = new PDFLoan();
        obj3.setDescription("2 year fixed at 1.90%");
        obj3.setBalanceBeforeOverpayment("£5,000.00");
        obj3.setOverpayment("£0.00");
        obj3.setOverpaymentInBigDecimal(new BigDecimal("0.00"));
        obj3.setChosenHeader("T");
        obj3.setMonthlyPaymentSaving("£0.00");
        obj3.setMortgageTerm("20 years 3 months (New)");
        obj3.setInterestSaving("£805.53");
        loanDetails.add(obj1);
        loanDetails.add(obj2);
        loanDetails.add(obj3);
        pdfCreationDataMultiLoan.setLoanDetails(loanDetails);

        PDFCreationData pdfCreationData = new PDFCreationData();
        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setFirstPayment("£2,081.22");
        pdfCreationData.setSecondPayment("£2,081.21");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("07/10/2023");

        pdfCreationDataMultiLoan.setPdfCreationData(pdfCreationData);

        return pdfCreationDataMultiLoan;
    }

    public static PDFCreationDataMultiLoan generateDefaultPdfCreationDataForTermReductionThreeLoanTwoOverpaying() {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();

        List<PDFLoan> loanDetails = new ArrayList<>();
        PDFLoan obj1 = new PDFLoan();
        obj1.setDescription("2 year fixed at 1.90%");
        obj1.setBalanceBeforeOverpayment("£5,000.00");
        obj1.setOverpayment("£111.11");
        obj1.setOverpaymentInBigDecimal(new BigDecimal("111.11"));
        obj1.setChosenHeader("T");
        obj1.setMonthlyPaymentSaving("£0.00");
        obj1.setMortgageTerm("20 years 3 months (New)");
        obj1.setInterestSaving("£3,074.25");
        PDFLoan obj2 = new PDFLoan();
        obj2.setDescription("2 year fixed at 1.90%");
        obj2.setBalanceBeforeOverpayment("£5,000.00");
        obj2.setOverpayment("£222.22");
        obj2.setOverpaymentInBigDecimal(new BigDecimal("222.22"));
        obj2.setChosenHeader("T");
        obj2.setMonthlyPaymentSaving("£0.00");
        obj2.setMortgageTerm("20 years 3 months (New)");
        obj2.setInterestSaving("£805.53");
        PDFLoan obj3 = new PDFLoan();
        obj3.setDescription("2 year fixed at 1.90%");
        obj3.setBalanceBeforeOverpayment("£5,000.00");
        obj3.setOverpayment("£0.00");
        obj3.setOverpaymentInBigDecimal(new BigDecimal("0.00"));
        obj3.setChosenHeader("T");
        obj3.setMonthlyPaymentSaving("£0.00");
        obj3.setMortgageTerm("20 years 3 months (New)");
        obj3.setInterestSaving("£805.53");
        loanDetails.add(obj1);
        loanDetails.add(obj2);
        loanDetails.add(obj3);
        pdfCreationDataMultiLoan.setLoanDetails(loanDetails);

        PDFCreationData pdfCreationData = new PDFCreationData();
        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setFirstPayment("£2,081.22");
        pdfCreationData.setSecondPayment("£2,081.21");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("07/10/2023");

        pdfCreationDataMultiLoan.setPdfCreationData(pdfCreationData);

        return pdfCreationDataMultiLoan;
    }

    public static PDFCreationDataMultiLoan generateDefaultPdfCreationDataForReduceMonthlyPaymentMultiLoan() {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();


        List<PDFLoan> loanDetails = new ArrayList<>();
        PDFLoan obj1 = new PDFLoan();
        obj1.setDescription("2 year fixed at 1.90%");
        obj1.setBalanceBeforeOverpayment("£5,000.00");
        obj1.setOverpayment("£111.11");
        obj1.setOverpaymentInBigDecimal(new BigDecimal("111.11"));
        obj1.setChosenHeader("M");
        obj1.setMonthlyPaymentSaving("£0.00");
        obj1.setMortgageTerm("20 years 3 months (No change)");
        obj1.setInterestSaving("£3,074.25");
        PDFLoan obj2 = new PDFLoan();
        obj2.setDescription("2 year fixed at 1.90%");
        obj2.setBalanceBeforeOverpayment("£5,000.00");
        obj2.setOverpayment("£222.22");
        obj2.setOverpaymentInBigDecimal(new BigDecimal("222.22"));
        obj2.setChosenHeader("M");
        obj2.setMonthlyPaymentSaving("£0.00");
        obj2.setMortgageTerm("20 years 3 months (No change)");
        obj2.setInterestSaving("£805.53");
        loanDetails.add(obj1);
        loanDetails.add(obj2);
        pdfCreationDataMultiLoan.setLoanDetails(loanDetails);

        PDFCreationData pdfCreationData = new PDFCreationData();
        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setFirstPayment("£2,081.22");
        pdfCreationData.setSecondPayment("£2,081.21");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("07/10/2023");

        pdfCreationDataMultiLoan.setPdfCreationData(pdfCreationData);

        return pdfCreationDataMultiLoan;
    }

    public static PDFCreationDataMultiLoan generateDefaultPdfCreationDataForReduceBalanceMultiLoan() {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();

        List<PDFLoan> loanDetails = new ArrayList<>();
        PDFLoan obj1 = new PDFLoan();
        obj1.setDescription("2 year fixed at 1.90%");
        obj1.setBalanceBeforeOverpayment("£5,000.00");
        obj1.setOverpayment("£111.11");
        obj1.setOverpaymentInBigDecimal(new BigDecimal("111.11"));
        obj1.setChosenHeader("B");
        obj1.setMonthlyPaymentSaving("£0.00");
        obj1.setMortgageTerm("20 years 3 months (No change)");
        obj1.setInterestSaving("£3,074.25");
        PDFLoan obj2 = new PDFLoan();
        obj2.setDescription("2 year fixed at 1.90%");
        obj2.setBalanceBeforeOverpayment("£5,000.00");
        obj2.setOverpayment("£222.22");
        obj2.setOverpaymentInBigDecimal(new BigDecimal("222.22"));
        obj2.setChosenHeader("B");
        obj2.setMonthlyPaymentSaving("£0.00");
        obj2.setMortgageTerm("20 years 3 months (No change)");
        obj2.setInterestSaving("£805.53");
        loanDetails.add(obj1);
        loanDetails.add(obj2);
        pdfCreationDataMultiLoan.setLoanDetails(loanDetails);


        PDFCreationData pdfCreationData = new PDFCreationData();

        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setFirstPayment("£2,081.22");
        pdfCreationData.setSecondPayment("£2,081.21");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection("sanaccount");
        pdfCreationData.setPaymentMethod("09-01-27 012345678");
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("07/10/2023");

        pdfCreationDataMultiLoan.setPdfCreationData(pdfCreationData);

        return pdfCreationDataMultiLoan;
    }

    public static PDFCreationDataMultiLoan generateDefaultPdfCreationDataForTermReductionMultiLoanCardPayment() {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();


        List<PDFLoan> loanDetails = new ArrayList<>();
        PDFLoan obj1 = new PDFLoan();
        obj1.setDescription("2 year fixed at 1.90%");
        obj1.setBalanceBeforeOverpayment("£5,000.00");
        obj1.setOverpayment("£111.11");
        obj1.setOverpaymentInBigDecimal(new BigDecimal("111.11"));
        obj1.setChosenHeader("T");
        obj1.setMonthlyPaymentSaving("£0.00");
        obj1.setMortgageTerm("20 years 3 months (New)");
        obj1.setInterestSaving("£3,074.25");
        PDFLoan obj2 = new PDFLoan();
        obj2.setDescription("2 year fixed at 1.90%");
        obj2.setBalanceBeforeOverpayment("£5,000.00");
        obj2.setOverpayment("£222.22");
        obj2.setOverpaymentInBigDecimal(new BigDecimal("222.22"));
        obj2.setChosenHeader("T");
        obj2.setMonthlyPaymentSaving("£0.00");
        obj2.setMortgageTerm("20 years 3 months (New)");
        obj2.setInterestSaving("£805.53");
        loanDetails.add(obj1);
        loanDetails.add(obj2);
        pdfCreationDataMultiLoan.setLoanDetails(loanDetails);

        PDFCreationData pdfCreationData = new PDFCreationData();

        pdfCreationData.setSortCode("09-15-86");
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setFirstPayment("£2,081.22");
        pdfCreationData.setSecondPayment("£2,081.21");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection(STRING_DEBIT_CARD);
        pdfCreationData.setPaymentMethod(PAYMENT_METHOD_DEBIT_CARD);
        pdfCreationData.setPaymentMethodName("123 CURRENT ACCOUNT");
        pdfCreationData.setPaymentTakenOn("07/10/2023");

        pdfCreationDataMultiLoan.setPdfCreationData(pdfCreationData);

        return pdfCreationDataMultiLoan;
    }

    public static PDFCreationDataSingleLoan generatePdfCreationDataForDebitCard() {
        PDFCreationData pdfCreationData = new PDFCreationData();

        pdfCreationData.setSortCode(MORTGAGE_SORT_CODE_BY_DEFAULT);
        pdfCreationData.setAccountNumber("123456789");
        pdfCreationData.setTotalPayment("£5,000.00");
        pdfCreationData.setTotalOverpayment("£4,992.07");
        pdfCreationData.setTotalEarlyRepayment("£7.93");
        pdfCreationData.setFirstPayment("£216.97");
        pdfCreationData.setSecondPayment("£216.96");
        pdfCreationData.setFuturePayment("£216.95");
        pdfCreationData.setNewOutstandingBalance("£36,410.89");
        pdfCreationData.setPaymentMethodSelection(STRING_DEBIT_CARD);
        pdfCreationData.setPaymentMethod(PAYMENT_METHOD_DEBIT_CARD);
        pdfCreationData.setPaymentTakenOn("02/11/2022");

        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = new PDFCreationDataSingleLoan();
        pdfCreationDataSingleLoan.setChosenHeader("T");
        pdfCreationDataSingleLoan.setMonthlyPaymentSaving("£0.00");
        pdfCreationDataSingleLoan.setMortgageTerm("20 years 3 months (New)");
        pdfCreationDataSingleLoan.setInterestSaving("£3,074.25");
        pdfCreationDataSingleLoan.setPdfCreationData(pdfCreationData);
        return pdfCreationDataSingleLoan;
    }

    public static MortgageSingleOverpaymentInternalTransferResponse generateDefaultServiceResponse() {
        MortgageSingleOverpaymentInternalTransferResponse mortgageSingleOverpaymentInternalTransferResponse = new MortgageSingleOverpaymentInternalTransferResponse();
        mortgageSingleOverpaymentInternalTransferResponse.setPaymentDone(true);
        mortgageSingleOverpaymentInternalTransferResponse.setBase64Pdf("base64EncodedPdf");
        return mortgageSingleOverpaymentInternalTransferResponse;
    }

    public static CardTransactionRequest generateDefaultCardTransactionRequest() throws IOException {
        return FixtureReader.get("opayo/card-transaction/request/request.json", CardTransactionRequest.class);
    }

    public static ConfirmCardTransactionRequest generateDefaultConfirmCardTransactionRequest() throws IOException {
        return FixtureReader.get("opayo/confirm/request/request.json", ConfirmCardTransactionRequest.class);
    }

    public static CardTransactionResponse generateChallengeCardTransactionResponse() throws IOException {
        return FixtureReader.get("opayo/card-transaction/response/challenge.json", CardTransactionResponse.class);
    }

    public static CardTransactionResponse generateRejectedCardTransactionResponse() throws IOException {
        return FixtureReader.get("opayo/card-transaction/response/rejected.json", CardTransactionResponse.class);
    }


    public static CardTransactionResponse generateDeclinedConfirmCardTransactionResponse() throws IOException {
        return FixtureReader.get("opayo/confirm/response/declined.json", CardTransactionResponse.class);
    }

    public static CardTransactionResponse generateFrictionlessCardTransactionResponse() throws IOException {
        return FixtureReader.get("opayo/card-transaction/response/frictionless-ok.json", CardTransactionResponse.class);
    }

    public static CardTransactionResponse generateRejected2Response() throws IOException {
        return FixtureReader.get("opayo/card-transaction/response/rejected2.json", CardTransactionResponse.class);
    }

    public static CardTransactionResponse generateConfirmCardTransactionOkResponse() throws IOException {
        return FixtureReader.get("opayo/confirm/response/authorised.json", CardTransactionResponse.class);
    }

    public static ResponseEntity<CardTransactionResponse> generateChallengeCardTransactionResponseEntity() throws IOException {
        return new ResponseEntity<>(generateChallengeCardTransactionResponse(), HttpStatus.ACCEPTED);
    }

    public static ResponseEntity<CardTransactionResponse> generateFrictionlessOkCardTransactionResponseEntity() throws IOException {
        return new ResponseEntity<>(generateFrictionlessCardTransactionResponse(), HttpStatus.ACCEPTED);
    }

    public static ResponseEntity<CardTransactionResponse> generateConfirmCardTransactionOkResponseEntity() throws IOException {
        return new ResponseEntity<>(generateConfirmCardTransactionOkResponse(), HttpStatus.ACCEPTED);
    }

    public static ResponseEntity<CardTransactionResponse> generateRejectedCardTransactionResponseEntity() throws IOException {
        return new ResponseEntity<>(generateRejectedCardTransactionResponse(), HttpStatus.ACCEPTED);
    }

    public static ResponseEntity<CardTransactionResponse> generateDeclinedConfirmCardTransactionResponseEntity() throws IOException {
        return new ResponseEntity<>(generateDeclinedConfirmCardTransactionResponse(), HttpStatus.ACCEPTED);
    }

    public static CardPaymentResponse generateDefaultCardPaymentResponseChallenge() {
        var cardPaymentResponse = new CardPaymentResponse();
        cardPaymentResponse.setPaymentDone(false);
        cardPaymentResponse.setThreeDSDetails(generate3DSDetail());
        cardPaymentResponse.setTransactionId("OPAYO2022100615004181713317643");
        cardPaymentResponse.setBase64Pdf("");
        return cardPaymentResponse;

    }

    public static CardPaymentResponse generateConfirmCardPaymentResponseOk() {
        var cardPaymentResponse = new CardPaymentResponse();
        cardPaymentResponse.setPaymentDone(true);
        cardPaymentResponse.setThreeDSDetails(null);
        cardPaymentResponse.setTransactionId(null);
        cardPaymentResponse.setBase64Pdf("some-data");
        return cardPaymentResponse;

    }

    public static ThreeDSDetails generate3DSDetail() {
        return new ThreeDSDetails("https://test.sagepay.com/3ds-simulator/html_challenge", "ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJlOWE4NmVlOS0wMjFlLTQ0N2MtYjczMS0wNjQzODNiN2M0NzAiLAogICJhY3NUcmFuc0lEIiA6ICJjMmM4MTRmMi0yYjE3LTQxMDQtODJiOS1mMWM5NWEyOWJlZTEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwNCIKfQ");
    }

    public static ConfirmCardOneOffPaymentRequest generateConfirmCardPaymentRequest() {
        var confirmCardOneOffPaymentRequest = new ConfirmCardOneOffPaymentRequest();
        confirmCardOneOffPaymentRequest.setCres("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcyIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJkZTE5ODFkMC1mYTc2LTRjYmQtYTVhZi01MTZmYWQ4MDY1NjMiLAogICJhY3NUcmFuc0lEIiA6ICIyZTUzYjUxNi01M2VlLTQzZTMtODI3OC00NDQ1ODY1ODU4NTIiLAogICJ0cmFuc1N0YXR1cyIgOiAiWSIKfQ");
        return confirmCardOneOffPaymentRequest;
    }


    public static ResponseEntity<CardOperationalResponse> generateCardOperationalEntityOk() throws IOException {
        return new ResponseEntity<>(generateCardOperationalOkResponse(), HttpStatus.OK);
    }

    public static CardOperationalResponse generateCardOperationalOkResponse() throws IOException {
        return FixtureReader.get("card-operational/santanderCard.json", CardOperationalResponse.class);
    }

}
