package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataRequest;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataResponse;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.net.ConnectException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class LynxFraudCheckClientTest {

    private LynxFraudCheckClient lynxFraudCheckClient;

    @MockBean
    private OverpaymentsConfig mockConfig;

    @MockBean
    private RestTemplate mockRestTemplate;

    @BeforeEach
    void setUp() {
        lynxFraudCheckClient = new LynxFraudCheckClient(mockRestTemplate, mockConfig);
        when(mockConfig.getClientId()).thenReturn("client-id");
        when(mockConfig.getLynxFraudEndpoint()).thenReturn("url");
    }

    @Test
    void callFraudCheck_Ok() throws ConnectException, FraudException {
        ResponseEntity<LynxDataResponse> responseEntity
                = new ResponseEntity<>(generateResponseForFraudCheck("ok"), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(LynxDataResponse.class)))
                .thenReturn(responseEntity);

        LynxDataResponse res = lynxFraudCheckClient.callFraudCheck(new LynxDataRequest());

        assertEquals("ok", res.getResponseCode());
        assertEquals("1234567894513132", res.getLynxReference());
    }

    @Test
    void callFraudCheck_Ko() {

        ResponseEntity<LynxDataResponse> responseEntity
                = new ResponseEntity<>(generateResponseForFraudCheck("KO"), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(LynxDataResponse.class)))
                .thenReturn(responseEntity);

        FraudException fraudException = assertThrows(FraudException.class, () -> lynxFraudCheckClient.callFraudCheck(new LynxDataRequest()));
        assertEquals("TRANSACTION DECLINED BY FRAUD", fraudException.getMessage());
    }


    @Test
    void callFraudCheck_Pending() {

        ResponseEntity<LynxDataResponse> responseEntity
                = new ResponseEntity<>(generateResponseForFraudCheck("PE"), HttpStatus.OK);

        when(mockRestTemplate.postForEntity(anyString(), any(), eq(LynxDataResponse.class)))
                .thenReturn(responseEntity);

        FraudException fraudException = assertThrows(FraudException.class, () -> lynxFraudCheckClient.callFraudCheck(new LynxDataRequest()));
        assertEquals("TRANSACTION PENDING BY FRAUD", fraudException.getMessage());
    }

    @Test
    void testUnknownException() {
        when(mockRestTemplate.postForEntity(anyString(), any(), eq(LynxDataResponse.class)))
                .thenThrow(RestClientException.class);

        FraudException fraudException = assertThrows(FraudException.class, () -> lynxFraudCheckClient.callFraudCheck(new LynxDataRequest()));
        assertEquals("Exception while calling LynxFraud Core Api", fraudException.getMessage());
    }

    private LynxDataResponse generateResponseForFraudCheck(String responseCode) {
        LynxDataResponse response = new LynxDataResponse();
        response.setLynxReference("1234567894513132");
        response.setResponseCode(responseCode);

        return response;
    }
}
