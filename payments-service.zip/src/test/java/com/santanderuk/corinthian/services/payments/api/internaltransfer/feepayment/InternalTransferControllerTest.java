package com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment;

class InternalTransferControllerTest {

}
