package com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Borrower;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted.CreateEditRegularOverpaymentRegularOverpaymentFormattedData;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.math.BigDecimal;
import java.util.ArrayList;

import static org.mockito.ArgumentMatchers.*;

@ExtendWith(SpringExtension.class)
class RegularOverpaymentFormattedDataGeneratorTest {

    RegularOverpaymentFormattedDataGenerator service;

    @Mock
    GassDataFetcher gassDataFetcher;

    @BeforeEach
    void setUp() {
        service = new RegularOverpaymentFormattedDataGenerator(gassDataFetcher);
        Mockito.when(gassDataFetcher.toFormattedDataBorrowerList(any())).thenReturn(new Borrower());
        Mockito.when(gassDataFetcher.fetchOriginAccount(anyInt())).thenReturn("65432");
        Mockito.when(gassDataFetcher.fetchMortgageAccountNumber(anyInt())).thenReturn("1234");
        Mockito.when(gassDataFetcher.fetchCustomerNumber(anyString())).thenReturn("12345");
    }

    @Test
    void createEditRegularOverpaymentFormattedData() {
        //arrange
        SetUpRegularOverpaymentServiceInput controllerRequest = createControllerRequest();
        CustomerDetailsResponse customerDetailsResponse = createAnmfCustomersInfoResponse();

        //act
        CreateEditRegularOverpaymentRegularOverpaymentFormattedData gassData = service.createEditRegularOverpaymentFormattedData(12345678, "jwtToken", controllerRequest, customerDetailsResponse, TestDataCreator.createContextForTest());

        //assert
        Assertions.assertEquals("3", gassData.getFormattedLoans().get(0).getLoanSchema());
        Assertions.assertEquals(1, gassData.getFormattedLoans().get(0).getOrderId());

        Assertions.assertEquals("2", gassData.getFormattedLoans().get(1).getLoanSchema());
        Assertions.assertEquals(2, gassData.getFormattedLoans().get(1).getOrderId());

        Assertions.assertEquals("1", gassData.getFormattedLoans().get(2).getLoanSchema());
        Assertions.assertEquals(3, gassData.getFormattedLoans().get(2).getOrderId());
    }

    private CustomerDetailsResponse createAnmfCustomersInfoResponse() {
        ArrayList<OCustomer> oCustomerList = new ArrayList<>();
        oCustomerList.add(new OCustomer());

        com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc customerOutputStruc = new com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OStruc();
        customerOutputStruc.setOCustomerList(oCustomerList);

        CustomerServiceResponse customerServiceResponse = new CustomerServiceResponse();
        customerServiceResponse.setOStruc(customerOutputStruc);

        CustomerDetailsResponse response = new CustomerDetailsResponse();
        response.setCustomerServiceResponse(customerServiceResponse);

        return response;
    }

    private SetUpRegularOverpaymentServiceInput createControllerRequest() {
        Loan loan1 = new Loan();
        loan1.setLoanSchema("1");
        loan1.setOrderId(3);
        loan1.setLoanType("R");
        loan1.setAppSequenceNumber("1");

        Loan loan2 = new Loan();
        loan2.setLoanSchema("3");
        loan2.setOrderId(1);
        loan2.setLoanType("R");
        loan2.setAppSequenceNumber("2");

        Loan loan3 = new Loan();
        loan3.setLoanSchema("2");
        loan3.setOrderId(2);
        loan3.setLoanType("R");
        loan3.setAppSequenceNumber("3");

        ArrayList<Loan> loans = new ArrayList<>();
        loans.add(loan1);
        loans.add(loan2);
        loans.add(loan3);

        SetUpRegularOverpaymentServiceInput input = new SetUpRegularOverpaymentServiceInput();
        input.setLoans(loans);
        input.setOverpaymentAmount(new BigDecimal("123.45"));
        input.setStartDate("01/04/2021");
        input.setEndDate("01/04/2022");
        return input;
    }
}
