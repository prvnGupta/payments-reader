package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalAccountDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.utils.DataFormatter;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;


@ExtendWith(MockitoExtension.class)
class PDFCreationDataMapperTest {

    PDFCreationDataMapper pdfCreationDataAccess;

    @Mock
    DataFormatter dataFormatter;

    @BeforeEach
    void setUp() {
        pdfCreationDataAccess = new PDFCreationDataMapper(dataFormatter);
    }

    @Test
    void testHappyPath() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("08/06/2022");
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataSingleLoan(TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment());

        assertEquals("09-15-86", pdfCreationDataSingleLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£5,000.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£4,992.07", pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£7.93", pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("T", pdfCreationDataSingleLoan.getChosenHeader());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataSingleLoan.getMortgageTerm());
        assertEquals("£3,074.25", pdfCreationDataSingleLoan.getInterestSaving());
        assertEquals("£216.97", pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£216.96", pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£216.95", pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£36,410.89", pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("09-01-27 012345678", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("08/06/2022", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn());

    }

    @Test
    void testHappyPathSavingAccount() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("08/06/2022");
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();

        InternalAccountDetails savingAccount = new InternalAccountDetails();
        savingAccount.setLocalAccountNumber(new LocalAccountNumber("SAVING", "X14123458WAR"));
        savingAccount.setPartenonAccountNumber(new PartenonAccountNumber("company", "centre", "product", "contract"));
        context.getInternalTransferAccountsDetails().setAccountFrom(savingAccount);

        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataSingleLoan(context);

        assertEquals("09-15-86", pdfCreationDataSingleLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£5,000.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£4,992.07", pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£7.93", pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("T", pdfCreationDataSingleLoan.getChosenHeader());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataSingleLoan.getMortgageTerm());
        assertEquals("£3,074.25", pdfCreationDataSingleLoan.getInterestSaving());
        assertEquals("£216.97", pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£216.96", pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£216.95", pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£36,410.89", pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("SAVING X14123458 WAR", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("08/06/2022", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn());

    }

    @Test
    void testReduceTerm() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("08/06/2022");
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataSingleLoan(TestDataCreator.generateMortgageSingleOverpaymentContextForPDFReduceTerm());

        assertEquals("09-15-86", pdfCreationDataSingleLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£111.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£111.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("T", pdfCreationDataSingleLoan.getChosenHeader());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataSingleLoan.getMortgageTerm());
        assertEquals("£44.70", pdfCreationDataSingleLoan.getInterestSaving());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£28,442.21", pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("09-01-27 012345678", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("08/06/2022", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn());

    }

    @Test
    void testReduceMonthlyPayment() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("08/06/2022");
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataSingleLoan(TestDataCreator.generateMortgageSingleOverpaymentContextForPDFReduceMonthlyPayments());

        assertEquals("09-15-86", pdfCreationDataSingleLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£11.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£11.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("M", pdfCreationDataSingleLoan.getChosenHeader());
        assertEquals("£0.72", pdfCreationDataSingleLoan.getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (No change)", pdfCreationDataSingleLoan.getMortgageTerm());
        assertEquals("£1.92", pdfCreationDataSingleLoan.getInterestSaving());
        assertEquals("£180.50", pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£180.29", pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£180.29", pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£28,542.21", pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("09-01-27 012345678", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("08/06/2022", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn());

    }


    @Test
    void testReduceBalance() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("08/06/2022");
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataSingleLoan(TestDataCreator.generateMortgageSingleOverpaymentContextForPDFReduceBalance());

        assertEquals("09-15-86", pdfCreationDataSingleLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£11.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£11.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("B", pdfCreationDataSingleLoan.getChosenHeader());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (No change)", pdfCreationDataSingleLoan.getMortgageTerm());
        assertEquals("£4.49", pdfCreationDataSingleLoan.getInterestSaving());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£28,542.21", pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("09-01-27 012345678", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("08/06/2022", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn());

    }
    @Test
    void testDebitCardPayment() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("02/11/2022");
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataForCardPayment(TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext());

        assertEquals("09-15-86", pdfCreationDataSingleLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£111.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£111.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("T", pdfCreationDataSingleLoan.getChosenHeader());
        assertEquals("£0.00", pdfCreationDataSingleLoan.getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataSingleLoan.getMortgageTerm());
        assertEquals("£44.70", pdfCreationDataSingleLoan.getInterestSaving());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£181.01", pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£28,442.21", pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("debitcard", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("Debit card", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("02/11/2022", pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn());

    }

    @Test
    void testDebitCardPaymentMultiLoan() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("07/10/2023");
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = pdfCreationDataAccess.getPdfCreationDataForCardPaymentMultiLoan(TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContextMultiLoanPDF());

        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(0).getDescription());
        assertEquals("£91,351.16", pdfCreationDataMultiLoan.getLoanDetails().get(0).getBalanceBeforeOverpayment());
        assertEquals("£103.18", pdfCreationDataMultiLoan.getLoanDetails().get(0).getOverpayment());
        assertEquals("T", pdfCreationDataMultiLoan.getLoanDetails().get(0).getChosenHeader());
        assertEquals("£0.00", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMortgageTerm());
        assertEquals("£2,854.25", pdfCreationDataMultiLoan.getLoanDetails().get(0).getInterestSaving());

        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(1).getDescription());
        assertEquals("£91,351.26", pdfCreationDataMultiLoan.getLoanDetails().get(1).getBalanceBeforeOverpayment());
        assertEquals("£214.29", pdfCreationDataMultiLoan.getLoanDetails().get(1).getOverpayment());
        assertEquals("T", pdfCreationDataMultiLoan.getLoanDetails().get(1).getChosenHeader());
        assertEquals("£0.00", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMortgageTerm());
        assertEquals("£3,705.53", pdfCreationDataMultiLoan.getLoanDetails().get(1).getInterestSaving());


        assertEquals("09-15-86", pdfCreationDataMultiLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataMultiLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£4,992.07", pdfCreationDataMultiLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£7.93", pdfCreationDataMultiLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("£5,000.00", pdfCreationDataMultiLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£1,234.50", pdfCreationDataMultiLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£1,324.50", pdfCreationDataMultiLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£2,083.90", pdfCreationDataMultiLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£35,610.99", pdfCreationDataMultiLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("debitcard", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("Debit card", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("07/10/2023", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentTakenOn());

    }

    @Test
    void testReduceMonthlyPaymentMultiLoan() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("07/10/2023");
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = pdfCreationDataAccess.getPdfCreationDataMultiLoan(TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceMonthlyPayments());


        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(0).getDescription());
        assertEquals("£91,351.16", pdfCreationDataMultiLoan.getLoanDetails().get(0).getBalanceBeforeOverpayment());
        assertEquals("£103.18", pdfCreationDataMultiLoan.getLoanDetails().get(0).getOverpayment());
        assertEquals("M", pdfCreationDataMultiLoan.getLoanDetails().get(0).getChosenHeader());
        assertEquals("£11.00", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (No change)", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMortgageTerm());
        assertEquals("£2,974.25", pdfCreationDataMultiLoan.getLoanDetails().get(0).getInterestSaving());

        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(1).getDescription());
        assertEquals("£91,351.26", pdfCreationDataMultiLoan.getLoanDetails().get(1).getBalanceBeforeOverpayment());
        assertEquals("£214.29", pdfCreationDataMultiLoan.getLoanDetails().get(1).getOverpayment());
        assertEquals("M", pdfCreationDataMultiLoan.getLoanDetails().get(1).getChosenHeader());
        assertEquals("£20.00", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (No change)", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMortgageTerm());
        assertEquals("£3,805.53", pdfCreationDataMultiLoan.getLoanDetails().get(1).getInterestSaving());


        assertEquals("09-15-86", pdfCreationDataMultiLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataMultiLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£4,992.07", pdfCreationDataMultiLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£7.93", pdfCreationDataMultiLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("£5,000.00", pdfCreationDataMultiLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£1,123.45", pdfCreationDataMultiLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£1,223.56", pdfCreationDataMultiLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£2,083.90", pdfCreationDataMultiLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£36,810.99", pdfCreationDataMultiLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("09-01-27 012345678", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("07/10/2023", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentTakenOn());
    }

    @Test
    void testReduceTermMultiLoan() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("07/10/2023");
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = pdfCreationDataAccess.getPdfCreationDataMultiLoan(TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceTerm());


        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(0).getDescription());
        assertEquals("£91,351.16", pdfCreationDataMultiLoan.getLoanDetails().get(0).getBalanceBeforeOverpayment());
        assertEquals("£103.18", pdfCreationDataMultiLoan.getLoanDetails().get(0).getOverpayment());
        assertEquals("T", pdfCreationDataMultiLoan.getLoanDetails().get(0).getChosenHeader());
        assertEquals("£0.00", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMortgageTerm());
        assertEquals("£2,854.25", pdfCreationDataMultiLoan.getLoanDetails().get(0).getInterestSaving());

        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(1).getDescription());
        assertEquals("£91,351.26", pdfCreationDataMultiLoan.getLoanDetails().get(1).getBalanceBeforeOverpayment());
        assertEquals("£214.29", pdfCreationDataMultiLoan.getLoanDetails().get(1).getOverpayment());
        assertEquals("T", pdfCreationDataMultiLoan.getLoanDetails().get(1).getChosenHeader());
        assertEquals("£0.00", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (New)", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMortgageTerm());
        assertEquals("£3,705.53", pdfCreationDataMultiLoan.getLoanDetails().get(1).getInterestSaving());


        assertEquals("09-15-86", pdfCreationDataMultiLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataMultiLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£4,992.07", pdfCreationDataMultiLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£7.93", pdfCreationDataMultiLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("£5,000.00", pdfCreationDataMultiLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£1,234.50", pdfCreationDataMultiLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£1,324.50", pdfCreationDataMultiLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£2,083.90", pdfCreationDataMultiLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£35,610.99", pdfCreationDataMultiLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("09-01-27 012345678", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("07/10/2023", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentTakenOn());
    }

    @Test
    void testReduceBalanceMultiLoan() throws IOException {
        Mockito.when(dataFormatter.calculateTermRemaining(anyString())).thenReturn("20 years 3 months");
        Mockito.when(dataFormatter.getTodayFormattedDate()).thenReturn("07/10/2023");
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = pdfCreationDataAccess.getPdfCreationDataMultiLoan(TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceBalance());


        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(0).getDescription());
        assertEquals("£91,351.16", pdfCreationDataMultiLoan.getLoanDetails().get(0).getBalanceBeforeOverpayment());
        assertEquals("£103.18", pdfCreationDataMultiLoan.getLoanDetails().get(0).getOverpayment());
        assertEquals("B", pdfCreationDataMultiLoan.getLoanDetails().get(0).getChosenHeader());
        assertEquals("£0.00", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (No change)", pdfCreationDataMultiLoan.getLoanDetails().get(0).getMortgageTerm());
        assertEquals("£2,904.25", pdfCreationDataMultiLoan.getLoanDetails().get(0).getInterestSaving());

        assertEquals("FLEXIBLE(VARIABLE) at 1.09%", pdfCreationDataMultiLoan.getLoanDetails().get(1).getDescription());
        assertEquals("£91,351.26", pdfCreationDataMultiLoan.getLoanDetails().get(1).getBalanceBeforeOverpayment());
        assertEquals("£214.29", pdfCreationDataMultiLoan.getLoanDetails().get(1).getOverpayment());
        assertEquals("B", pdfCreationDataMultiLoan.getLoanDetails().get(1).getChosenHeader());
        assertEquals("£0.00", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMonthlyPaymentSaving());
        assertEquals("20 years 3 months (No change)", pdfCreationDataMultiLoan.getLoanDetails().get(1).getMortgageTerm());
        assertEquals("£3,685.53", pdfCreationDataMultiLoan.getLoanDetails().get(1).getInterestSaving());

        assertEquals("09-15-86", pdfCreationDataMultiLoan.getPdfCreationData().getSortCode());
        assertEquals("123456789", pdfCreationDataMultiLoan.getPdfCreationData().getAccountNumber());
        assertEquals("£4,992.07", pdfCreationDataMultiLoan.getPdfCreationData().getTotalOverpayment());
        assertEquals("£7.93", pdfCreationDataMultiLoan.getPdfCreationData().getTotalEarlyRepayment());
        assertEquals("£5,000.00", pdfCreationDataMultiLoan.getPdfCreationData().getTotalPayment());
        assertEquals("£1,122.11", pdfCreationDataMultiLoan.getPdfCreationData().getFirstPayment());
        assertEquals("£1,133.22", pdfCreationDataMultiLoan.getPdfCreationData().getSecondPayment());
        assertEquals("£2,083.90", pdfCreationDataMultiLoan.getPdfCreationData().getFuturePayment());
        assertEquals("£35,510.99", pdfCreationDataMultiLoan.getPdfCreationData().getNewOutstandingBalance());
        assertEquals("sanaccount", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodSelection());
        assertEquals("09-01-27 012345678", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethod());
        assertEquals("123 CURRENT ACCOUNT", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodName());
        assertEquals("07/10/2023", pdfCreationDataMultiLoan.getPdfCreationData().getPaymentTakenOn());
    }

}
