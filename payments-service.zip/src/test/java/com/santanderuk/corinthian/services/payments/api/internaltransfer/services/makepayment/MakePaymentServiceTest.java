package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;

import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static com.santanderuk.corinthian.services.payments.TestDataCreator.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class MakePaymentServiceTest {

    InternalTransferAccountsDetails accountsDetails;
    SetupRequest setupRequest;
    SetupResponse setupResponse;
    InternalTransferRequest internalTransferRequest;
    DebitRequest debitRequest;

    private MakePaymentService makePaymentService;

    @Mock
    private MakePaymentMapper mockMakePaymentMapper;

    @Mock
    private MakePaymentClient mockMakePaymentClient;

    @BeforeEach
    void setUp() throws IOException {
        setupRequest = generateSetupPaymentDefaultRequest();
        setupResponse = generateSetupPaymentResponseOK();
        internalTransferRequest = generateDefaultInternalTransferControllerRequest();
        debitRequest = generateDebitPaymentDefaultRequest();
        accountsDetails = generateDefaultInternalTransferAccountsDetails();
        makePaymentService = new MakePaymentService(mockMakePaymentMapper, mockMakePaymentClient);
    }

    @Test
    void testWeCallMakePaymentRequestMapper() throws PaymentsFuncException {
        when(mockMakePaymentMapper.mapRequest(setupRequest, setupResponse, internalTransferRequest, accountsDetails)).thenReturn(debitRequest);

        makePaymentService.callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails);

        verify(mockMakePaymentMapper, times(1)).mapRequest(setupRequest, setupResponse, internalTransferRequest, accountsDetails);
        verify(mockMakePaymentClient, times(1)).callDebitPayment(debitRequest);
    }

    @Test
    void testWeCallMakePaymentRequestMapperForInternalTransferMortgageOverpayment() throws PaymentsFuncException, IOException {
        MortgageSingleOverpaymentsContext context = generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        when(mockMakePaymentMapper.mapRequest(setupRequest, setupResponse, context)).thenReturn(debitRequest);

        makePaymentService.callMakePayment(setupRequest, setupResponse, context);

        verify(mockMakePaymentMapper, times(1)).mapRequest(setupRequest, setupResponse, context);
        verify(mockMakePaymentClient, times(1)).callDebitPayment(debitRequest);
    }

    @Test
    void testWeThrowPaymentFunctionalExc() throws PaymentsFuncException {
        when(mockMakePaymentMapper.mapRequest(setupRequest, setupResponse, internalTransferRequest, accountsDetails)).thenReturn(debitRequest);
        when(mockMakePaymentClient.callDebitPayment(debitRequest)).thenThrow(PaymentsFuncException.class);

        assertThrows(PaymentsFuncException.class, () -> makePaymentService.callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails));
    }

    @Test
    void testWeThrowPaymentFunctionalExcForInternalTransferMortgageOverpayment() throws PaymentsFuncException, IOException {

        MortgageSingleOverpaymentsContext context = generateMortgageSingleOverpaymentContextForUpdatePaymentMethod();
        when(mockMakePaymentMapper.mapRequest(setupRequest, setupResponse, context)).thenReturn(debitRequest);
        when(mockMakePaymentClient.callDebitPayment(debitRequest)).thenThrow(PaymentsFuncException.class);

        assertThrows(PaymentsFuncException.class, () -> makePaymentService.callMakePayment(setupRequest, setupResponse, context));
    }
}
