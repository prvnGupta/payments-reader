package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt;

import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.io.lynxNRT.LynxNRTDataRequest;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils.PaymentReferenceGenerator;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;

import static java.lang.Double.parseDouble;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(SpringExtension.class)
class LynxNRTDataMapperTest {

    public static final String STRING_EMPTY = "";
    private LynxNRTDataMapper lynxNRTDataMapper;
    private InternalTransferRequest request;
    private InternalTransferAccountsDetails accountsDetails;
    @SpyBean
    private InternalAccountFormatConverter internalAccountFormatConverter;
    @SpyBean
    private PaymentReferenceGenerator paymentReferenceGenerator;
    @Mock
    private OverpaymentsConfig overpaymentsConfig;

    @BeforeEach
    void setUp() {
        Clock fixedClock = Clock.fixed(Instant.parse("2020-04-12T17:45:34Z"), ZoneOffset.UTC);
        when(overpaymentsConfig.getSetupDataCurrency()).thenReturn("GBP");
        when(overpaymentsConfig.getLynxNRTCategoryName()).thenReturn("corinthian.anmfproductfee");
        lynxNRTDataMapper = new LynxNRTDataMapper(overpaymentsConfig, fixedClock, internalAccountFormatConverter, overpaymentsConfig, paymentReferenceGenerator);
        request = TestDataCreator.generateDefaultInternalTransferControllerRequest();
        accountsDetails = TestDataCreator.generateDefaultInternalTransferAccountsDetails();
    }

    @Test
    void testWeMapLynxNRTDataCorrectly() throws LynxNRTException {

        LynxNRTDataRequest lynxNRTDataRequest = lynxNRTDataMapper.decorateLynxNRTRequestData(request, accountsDetails, "OK", "ldapUid", "remoteIpAddress");

        assertAll(
                () -> assertEquals("0015", lynxNRTDataRequest.getPartenonFromEmpresa()),
                () -> assertEquals("4247", lynxNRTDataRequest.getPartenonFromCentro()),
                () -> assertEquals("300", lynxNRTDataRequest.getPartenonFromProduct()),
                () -> assertEquals("1234567", lynxNRTDataRequest.getPartenonFromContract()),
                () -> assertEquals("company", lynxNRTDataRequest.getPartenonToEmpresa()),
                () -> assertEquals("centre", lynxNRTDataRequest.getPartenonToCentro()),
                () -> assertEquals("product", lynxNRTDataRequest.getPartenonToProduct()),
                () -> assertEquals("contract", lynxNRTDataRequest.getPartenonToContract()),
                () -> assertEquals(parseDouble("123.45"), lynxNRTDataRequest.getDAmount()),
                () -> assertEquals("Sponge Bob", lynxNRTDataRequest.getPaymentName()),
                () -> assertEquals("GBP", lynxNRTDataRequest.getCurrency()),
                () -> assertEquals("paymentReference", lynxNRTDataRequest.getPaymentReference()),
                () -> assertEquals("12-04-2020", lynxNRTDataRequest.getPaymentDate()),
                () -> assertEquals("F", lynxNRTDataRequest.getCustomerTipoDePersona()),
                () -> assertEquals("ldapUid", lynxNRTDataRequest.getUserID()),
                () -> assertEquals("remoteIpAddress", lynxNRTDataRequest.getClientIP()),
                () -> assertEquals("000", lynxNRTDataRequest.getResponseCode()),
                () -> assertEquals("Transaction completed successfully", lynxNRTDataRequest.getResponseMessage()),
                () -> assertEquals(STRING_EMPTY, lynxNRTDataRequest.getServerID()),
                () -> assertEquals(STRING_EMPTY, lynxNRTDataRequest.getSessionID()),
                () -> assertEquals(STRING_EMPTY, lynxNRTDataRequest.getSessionIDSec()),
                () -> assertEquals("09012712345678", lynxNRTDataRequest.getFromSortCodeAccount()),
                () -> assertEquals("corinthian.anmfproductfee", lynxNRTDataRequest.getCategoryName())
        );
    }

    @Test
    void testWeMapCorrectlyForFraudCheckKoResponse() throws LynxNRTException {
        LynxNRTDataRequest lynxNRTDataRequest = lynxNRTDataMapper.decorateLynxNRTRequestData(request, accountsDetails, "NOT OK", "ldapUid", "remoteIpAddress");

        assertEquals("999", lynxNRTDataRequest.getResponseCode());
        assertEquals("Transaction Failed", lynxNRTDataRequest.getResponseMessage());
    }

    @Test
    void testWeMapLynxNRTDataCorrectlyMortgageSingleOverpayment() throws IOException, LynxNRTException {

        LynxNRTDataRequest lynxNRTDataRequest = lynxNRTDataMapper.decorateLynxNRTRequestData(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), "OK");

        assertAll(
                () -> assertEquals("0015", lynxNRTDataRequest.getPartenonFromEmpresa()),
                () -> assertEquals("4247", lynxNRTDataRequest.getPartenonFromCentro()),
                () -> assertEquals("300", lynxNRTDataRequest.getPartenonFromProduct()),
                () -> assertEquals("1234567", lynxNRTDataRequest.getPartenonFromContract()),
                () -> assertEquals("company", lynxNRTDataRequest.getPartenonToEmpresa()),
                () -> assertEquals("centre", lynxNRTDataRequest.getPartenonToCentro()),
                () -> assertEquals("product", lynxNRTDataRequest.getPartenonToProduct()),
                () -> assertEquals("contract", lynxNRTDataRequest.getPartenonToContract()),
                () -> assertEquals(parseDouble("5000.0"), lynxNRTDataRequest.getDAmount()),
                () -> assertEquals("Forename1 Surname", lynxNRTDataRequest.getPaymentName()),
                () -> assertEquals("GBP", lynxNRTDataRequest.getCurrency()),
                () -> assertEquals("123456789SURNAME  ", lynxNRTDataRequest.getPaymentReference()),
                () -> assertEquals("12-04-2020", lynxNRTDataRequest.getPaymentDate()),
                () -> assertEquals("F", lynxNRTDataRequest.getCustomerTipoDePersona()),
                () -> assertEquals("ldapUid", lynxNRTDataRequest.getUserID()),
                () -> assertEquals("127.0.0.1", lynxNRTDataRequest.getClientIP()),
                () -> assertEquals("000", lynxNRTDataRequest.getResponseCode()),
                () -> assertEquals("Transaction completed successfully", lynxNRTDataRequest.getResponseMessage()),
                () -> assertEquals(STRING_EMPTY, lynxNRTDataRequest.getServerID()),
                () -> assertEquals(STRING_EMPTY, lynxNRTDataRequest.getSessionID()),
                () -> assertEquals(STRING_EMPTY, lynxNRTDataRequest.getSessionIDSec()),
                () -> assertEquals("09012712345678", lynxNRTDataRequest.getFromSortCodeAccount()),
                () -> assertEquals("corinthian.anmfproductfee", lynxNRTDataRequest.getCategoryName())
        );
    }

    @Test
    void testWeMapCorrectlyForFraudCheckKoResponseMortgageSingleOverpayment() throws LynxNRTException, IOException {
        LynxNRTDataRequest lynxNRTDataRequest = lynxNRTDataMapper.decorateLynxNRTRequestData(TestDataCreator.generateMortgageSingleOverpaymentContextForUpdatePaymentMethod(), "NOT OK");

        assertEquals("999", lynxNRTDataRequest.getResponseCode());
        assertEquals("Transaction Failed", lynxNRTDataRequest.getResponseMessage());
    }


}
