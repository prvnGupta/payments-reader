package com.santanderuk.corinthian.services.payments.functional.version;

import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;

@ActiveProfiles("test")
public class VersionFunctionalTest extends FunctionalTest {

    String healthUrl;

    @BeforeEach
    void setup() {
        healthUrl = String.format("http://localhost:%s/payments-service/version", serverPort);
    }

    @Test
    public void customVersionReturnsUp() {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200);

    }

}
