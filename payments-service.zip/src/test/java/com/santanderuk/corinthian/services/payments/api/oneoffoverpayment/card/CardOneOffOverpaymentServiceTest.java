package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.ConfirmCardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.CardGASSService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.CardDataRedisPersistence;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoPaymentService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations.CardOneOffValidationsAndContextGeneratorService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CardOneOffOverpaymentServiceTest {

    CardOneOffOverpaymentService cardOneOffOverpaymentService;

    @Mock
    CardOneOffValidationsAndContextGeneratorService cardOneOffValidationsAndContextGeneratorService;
    @Mock
    OpayoPaymentService opayoPaymentService;
    @Mock
    SimulationService simulationService;
    @Mock
    CardDataRedisPersistence cardDataRedisPersistence;
    @Mock
    CardGASSService cardGassService;
    @Mock
    PDFCreationService pdfCreationService;
    @Mock
    ClearPaymentCache clearPaymentCache;

    @BeforeEach
    void setUp() {
        cardOneOffOverpaymentService = new CardOneOffOverpaymentService(cardOneOffValidationsAndContextGeneratorService, opayoPaymentService, simulationService, cardDataRedisPersistence, pdfCreationService, cardGassService, clearPaymentCache);
    }

    @Test
    void testHappyPathResponseFrictionless() throws IOException, GeneralException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin")).thenReturn(context);
        doNothing().when(simulationService).createCardOverpaymentSimulation(context);
        doNothing().when(opayoPaymentService).makeCardTransaction(context);
        doNothing().when(opayoPaymentService).updateCPS(context);
        doNothing().when(simulationService).updatePaymentMethodCard(context);
        doNothing().when(cardGassService).auditDebitCardPayment(context, true);
        when(pdfCreationService.createBase64PdfFileForCardPayment(context)).thenReturn("base64EncodedPdf");

        CardPaymentResponse response = cardOneOffOverpaymentService.makeCardOneOffOverpayment(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin");
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin");
        verify(opayoPaymentService, times(1)).makeCardTransaction(context);
        verify(opayoPaymentService, times(1)).updateCPS(context);
        verify(simulationService, times(1)).createCardOverpaymentSimulation(context);
        verify(simulationService, times(1)).updatePaymentMethodCard(context);
        verify(cardDataRedisPersistence, times(0)).cacheCardTransaction(anyString(), any());
        verify(cardGassService, times(1)).auditDebitCardPayment(context, true);
        verify(pdfCreationService, times(1)).createBase64PdfFileForCardPayment(context);

        assertTrue(response.isPaymentDone());
        assertEquals("", response.getTransactionId());
        assertNull(response.getThreeDSDetails());
        assertEquals("base64EncodedPdf", response.getBase64Pdf());
    }

    @Test
    void testHappyPathResponseChallenge() throws IOException, GeneralException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContextChallenge();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin")).thenReturn(context);
        doNothing().when(simulationService).createCardOverpaymentSimulation(context);
        doNothing().when(opayoPaymentService).makeCardTransaction(context);

        CardPaymentResponse response = cardOneOffOverpaymentService.makeCardOneOffOverpayment(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin");
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin");
        verify(simulationService, times(1)).createCardOverpaymentSimulation(context);
        verify(opayoPaymentService, times(1)).makeCardTransaction(context);
        verify(opayoPaymentService, times(0)).updateCPS(any());
        verify(simulationService, times(0)).updatePaymentMethodCard(any());
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction(anyString(), any());

        assertFalse(response.isPaymentDone());
        assertEquals("", response.getBase64Pdf());
        assertEquals("OPAYO2022100615004181713317643", response.getTransactionId());
        assertEquals("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJlOWE4NmVlOS0wMjFlLTQ0N2MtYjczMS0wNjQzODNiN2M0NzAiLAogICJhY3NUcmFuc0lEIiA6ICJjMmM4MTRmMi0yYjE3LTQxMDQtODJiOS1mMWM5NWEyOWJlZTEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwNCIKfQ", response.getThreeDSDetails().getOutputCode());
        assertEquals("https://test.sagepay.com/3ds-simulator/html_challenge", response.getThreeDSDetails().getOutputUrl());
    }

    @Test
    void shouldReturnHappyPathResponseConfirm() throws IOException, GeneralException {
        ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        String transactionId = "OPAYO2022100615004181713317643";
        CardTransactionDetails cardTransactionDetails = TestDataCreator.generateCardTransactionDetails();

        when(cardDataRedisPersistence.cacheCardTransaction(transactionId, null)).thenReturn(cardTransactionDetails);

        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1")).thenReturn(context);
        doNothing().when(opayoPaymentService).confirmCardTransaction(context, transactionId);
        doNothing().when(opayoPaymentService).updateCPS(context);
        doNothing().when(simulationService).updatePaymentMethodCard(context);
        doNothing().when(cardGassService).auditDebitCardPayment(context, true);
        when(pdfCreationService.createBase64PdfFileForCardPayment(context)).thenReturn("base64EncodedPdf");

        CardPaymentResponse response = cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, transactionId, confirmCardOneOffPaymentRequest, "jwt-token", "127.0.0.1");
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction(transactionId, null);
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1");
        verify(simulationService, times(0)).createCardOverpaymentSimulation(any());
        verify(opayoPaymentService, times(1)).confirmCardTransaction(context, transactionId);
        verify(opayoPaymentService, times(1)).updateCPS(context);
        verify(simulationService, times(1)).updatePaymentMethodCard(context);
        verify(cardGassService, times(1)).auditDebitCardPayment(context, true);
        verify(pdfCreationService, times(1)).createBase64PdfFileForCardPayment(context);
        verify(clearPaymentCache, times(1)).deleteCardTransactionCache("OPAYO2022100615004181713317643");

        assertTrue(response.isPaymentDone());
        assertEquals("", response.getTransactionId());
        assertNull(response.getThreeDSDetails());
        assertEquals("base64EncodedPdf", response.getBase64Pdf());
    }

    @Test
    void testConfirmOpayoExc() throws IOException, GeneralException {
        ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        String transactionId = "OPAYO2022100615005581713317643";
        CardTransactionDetails cardTransactionDetails = TestDataCreator.generateCardTransactionDetails();
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext();

        when(cardDataRedisPersistence.cacheCardTransaction(transactionId, null)).thenReturn(cardTransactionDetails);
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1")).thenReturn(context);
        doThrow(new OpayoException("OPAYO_CLIENT_EXC", "Exception while calling confirm-transaction baas api")).when(opayoPaymentService).confirmCardTransaction(context, transactionId);

        GeneralException generalException = assertThrows(GeneralException.class, () -> cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, transactionId, confirmCardOneOffPaymentRequest, "jwt-token", "127.0.0.1"));
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction(transactionId, null);
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1");
        verify(simulationService, times(0)).createCardOverpaymentSimulation(any());
        verify(opayoPaymentService, times(1)).confirmCardTransaction(context, transactionId);

        verify(opayoPaymentService, times(1)).updateCPS(context);
        verify(simulationService, times(0)).updatePaymentMethodCard(any());
        verify(cardGassService, times(1)).auditDebitCardPayment(context, false);
        verify(clearPaymentCache, times(1)).deleteCardTransactionCache("OPAYO2022100615005581713317643");

        assertEquals("CONFIRM_EXC", generalException.getCode());
        assertEquals("Failed call to Confirm baas Api", generalException.getMessage());
    }

    @Test
    void testConfirmDifferentAnmfAccountExc() throws GeneralException {
        ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        String transactionId = "OPAYO2022100615004181713317643";
        CardTransactionDetails cardTransactionDetails = TestDataCreator.generateCardTransactionDetails();

        when(cardDataRedisPersistence.cacheCardTransaction(transactionId, null)).thenReturn(cardTransactionDetails);
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1")).thenThrow(new ValidationsException("EXC_INVALID_MORTGAGE_ACCOUNT", "different mortgage account"));

        GeneralException generalException = assertThrows(GeneralException.class, () -> cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, transactionId, confirmCardOneOffPaymentRequest, "jwt-token", "127.0.0.1"));
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction(transactionId, null);
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1");
        verify(opayoPaymentService, times(0)).confirmCardTransaction(any(), anyString());
        verify(opayoPaymentService, times(0)).updateCPS(any());
        verify(simulationService, times(0)).createCardOverpaymentSimulation(any());
        verify(simulationService, times(0)).updatePaymentMethodCard(any());
        verify(cardGassService, times(0)).auditDebitCardPayment(any(), anyBoolean());

        assertEquals("CONFIRM_EXC", generalException.getCode());
        assertEquals("Payment could not be confirmed", generalException.getMessage());
    }

    @Test
    void testConfirmAnmfBelongToCustomerExc() throws GeneralException {
        ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        String transactionId = "OPAYO2022100615004181713317643";
        CardTransactionDetails cardTransactionDetails = TestDataCreator.generateCardTransactionDetails();

        when(cardDataRedisPersistence.cacheCardTransaction(transactionId, null)).thenReturn(cardTransactionDetails);
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1")).thenThrow(new OperativeSecurityException("SECURITY_KO", "Mortgage account does not belong to customer"));

        GeneralException generalException = assertThrows(GeneralException.class, () -> cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, transactionId, confirmCardOneOffPaymentRequest, "jwt-token", "127.0.0.1"));
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction(transactionId, null);
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1");
        verify(opayoPaymentService, times(0)).confirmCardTransaction(any(), anyString());
        verify(opayoPaymentService, times(0)).updateCPS(any());
        verify(simulationService, times(0)).createCardOverpaymentSimulation(any());
        verify(simulationService, times(0)).updatePaymentMethodCard(any());
        verify(cardGassService, times(0)).auditDebitCardPayment(any(), anyBoolean());
        assertEquals("CONFIRM_EXC", generalException.getCode());
        assertEquals("Payment could not be confirmed", generalException.getMessage());
    }

    @Test
    void testConfirmHeartbeatExc() throws GeneralException {
        ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        String transactionId = "OPAYO2022100615004181713317643";
        CardTransactionDetails cardTransactionDetails = TestDataCreator.generateCardTransactionDetails();

        when(cardDataRedisPersistence.cacheCardTransaction(transactionId, null)).thenReturn(cardTransactionDetails);
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1")).thenThrow(MaintenanceException.class);

        GeneralException generalException = assertThrows(GeneralException.class, () -> cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, transactionId, confirmCardOneOffPaymentRequest, "jwt-token", "127.0.0.1"));
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction(transactionId, null);
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContextForConfirm(12345678, confirmCardOneOffPaymentRequest, cardTransactionDetails, "jwt-token", "127.0.0.1");
        verify(opayoPaymentService, times(0)).confirmCardTransaction(any(), anyString());
        verify(opayoPaymentService, times(0)).updateCPS(any());
        verify(simulationService, times(0)).createCardOverpaymentSimulation(any());
        verify(simulationService, times(0)).updatePaymentMethodCard(any());
        verify(cardGassService, times(0)).auditDebitCardPayment(any(), anyBoolean());
        assertEquals("CONFIRM_EXC", generalException.getCode());
        assertEquals("Payment could not be confirmed", generalException.getMessage());
    }

    @Test
    void testConfirmValidationsServiceRedisPersistenceExc() throws GeneralException {
        ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest = TestDataCreator.generateConfirmCardPaymentRequest();
        String transactionId = "OPAYO2022100615004181713317643";

        when(cardDataRedisPersistence.cacheCardTransaction(transactionId, null)).thenThrow(new GeneralException("CONFIRM_CARD_PAYMENT_KO", "Error confirming 3ds payment"));

        GeneralException generalException = assertThrows(GeneralException.class, () -> cardOneOffOverpaymentService.confirmCardOneOffOverpayment(12345678, transactionId, confirmCardOneOffPaymentRequest, "jwt-token", "127.0.0.1"));
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction(transactionId, null);
        verify(cardOneOffValidationsAndContextGeneratorService, times(0)).validateRequestAndGenerateContextForConfirm(anyInt(), any(), any(), anyString(), anyString());
        verify(opayoPaymentService, times(0)).confirmCardTransaction(any(), anyString());
        verify(opayoPaymentService, times(0)).updateCPS(any());
        verify(simulationService, times(0)).createCardOverpaymentSimulation(any());
        verify(simulationService, times(0)).updatePaymentMethodCard(any());
        verify(cardGassService, times(0)).auditDebitCardPayment(any(), anyBoolean());

        assertEquals("CONFIRM_EXC", generalException.getCode());
        assertEquals("Payment could not be confirmed", generalException.getMessage());

    }

    @Test
    void testExcCallingOpayoMakeTransaction() throws IOException, GeneralException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin")).thenReturn(context);
        doThrow(new OpayoException("OPAYO_CLIENT_EXC", "Exception while calling card-transaction baas api")).when(opayoPaymentService).makeCardTransaction(context);

        GeneralException generalException = assertThrows(GeneralException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin"));
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin");
        verify(simulationService, times(1)).createCardOverpaymentSimulation(any());
        verify(opayoPaymentService, times(1)).makeCardTransaction(context);
        verify(opayoPaymentService, times(0)).updateCPS(any());
        verify(simulationService, times(0)).updatePaymentMethodCard(any());
        verify(cardGassService, times(0)).auditDebitCardPayment(any(), anyBoolean());
        verify(cardDataRedisPersistence, times(0)).cacheCardTransaction(anyString(), any());

        assertEquals("CARD_TRANSACTION_KO", generalException.getCode());
        assertEquals("Could not process card-payment", generalException.getMessage());
    }

    @Test
    void testBEValidationMultiLoanExc() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin")).thenThrow(new ValidationsException("EXC_MULTI_LOAN_MORTGAGE_ACCOUNT", "The mortgage has more than 1 active loan."));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin"));
        verify(opayoPaymentService, times(0)).makeCardTransaction(any());
        assertEquals("EXC_MULTI_LOAN_MORTGAGE_ACCOUNT", validationsException.getCode());
        assertEquals("The mortgage has more than 1 active loan.", validationsException.getMessage());

    }

    @Test
    void testBEValidationNumberOfOverpaymentsExc() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin")).thenThrow(new ValidationsException("EXC_MAX_NUM_OVP_REACHED", "Maximum number of overpayments done."));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin"));
        verify(opayoPaymentService, times(0)).makeCardTransaction(any());
        assertEquals("EXC_MAX_NUM_OVP_REACHED", validationsException.getCode());
        assertEquals("Maximum number of overpayments done.", validationsException.getMessage());

    }

    @Test
    void testBEValidationMinimumAmountExc() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin")).thenThrow(new ValidationsException("EXC_MIN_OVP_AMOUNT", "Chosen overpayment amount below permitted minimum amount."));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin"));
        verify(opayoPaymentService, times(0)).makeCardTransaction(any());
        assertEquals("EXC_MIN_OVP_AMOUNT", validationsException.getCode());
        assertEquals("Chosen overpayment amount below permitted minimum amount.", validationsException.getMessage());

    }

    @Test
    void testBEVValidationInsufficientBalanceExc() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin")).thenThrow(new ValidationsException(ValidationsException.Type.EXC_ACCOUNT_INSUFFICIENT_BALANCE));
        ValidationsException validationsException = assertThrows(ValidationsException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin"));
        verify(opayoPaymentService, times(0)).makeCardTransaction(any());
        assertEquals("EXC_ACCOUNT_INSUFFICIENT_BALANCE", validationsException.getCode());
        assertEquals("The account selected does not have enough balance to make payment", validationsException.getMessage());

    }

    @Test
    void testHeartbeatExc() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin")).thenThrow(MaintenanceException.class);
        assertThrows(MaintenanceException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin"));
        verify(simulationService, times(0)).createCardOverpaymentSimulation(any());
        verify(opayoPaymentService, times(0)).makeCardTransaction(any());
    }

    @Test
    void testSimulationException() throws GeneralException, IOException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(anyInt(), any(), anyString(), anyString(), anyString())).thenReturn(context);
        doThrow(new GeneralException("EXC_SIMULATION_ERROR_RESPONSE", "Error creating overpayment simulation")).when(simulationService).createCardOverpaymentSimulation(context);
        assertThrows(GeneralException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin"));
        verify(simulationService, times(1)).createCardOverpaymentSimulation(any());
        verify(opayoPaymentService, times(0)).makeCardTransaction(any());
    }

    @Test
    void testAnmfBelongToCustomerExc() throws GeneralException, IOException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin")).thenThrow(new OperativeSecurityException("SECURITY_KO", "Mortgage account does not belong to customer"));
        OperativeSecurityException operativeSecurityException = assertThrows(OperativeSecurityException.class, () -> cardOneOffOverpaymentService.makeCardOneOffOverpayment(123456879, cardOneOffPaymentRequest, "jwtToken", "127.0.0.1", "origin"));
        verify(opayoPaymentService, times(0)).makeCardTransaction(any());
        assertEquals("SECURITY_KO", operativeSecurityException.getCode());
        assertEquals("Mortgage account does not belong to customer", operativeSecurityException.getMessage());
    }

}
