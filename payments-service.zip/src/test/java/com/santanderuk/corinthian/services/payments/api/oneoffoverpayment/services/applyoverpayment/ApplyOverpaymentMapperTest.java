package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.applyoverpayment;

import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.IO32129;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import static org.junit.jupiter.api.Assertions.assertEquals;

@ExtendWith(MockitoExtension.class)
class ApplyOverpaymentMapperTest {

    private ApplyOverpaymentMapper applyOverpaymentMapper;

    @BeforeEach
    void setUp() {
        applyOverpaymentMapper = new ApplyOverpaymentMapper();
    }

    @Test
    void testGenerateUpdateChosenValuesRequest() throws IOException {

        ApplyOverpaymentRequest anmfPaymentRequest = applyOverpaymentMapper.generateApplyOverpaymentRequest(TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment(), "upr");
        IO32129 io32129 = anmfPaymentRequest.getCreateWsPayReceivedRequest().getRequest().getInputStruct().getIo32129();

        assertEquals(123456789, io32129.getIAccountNo());
        assertEquals("OVR", io32129.getIPmtTypeIn());
        assertEquals("TT", io32129.getISimPmtMeth());
        assertEquals(7455598, io32129.getISimulatorId());
        assertEquals(getTodayDateInANMFFormat(), io32129.getISimValDate());
        assertEquals(new BigDecimal("5000"), io32129.getIAmount());
        assertEquals("upr", io32129.getIUpr());
    }

    private String getTodayDateInANMFFormat() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

}
