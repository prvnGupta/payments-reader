package com.santanderuk.corinthian.services.payments.functional.health;

import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;

@ActiveProfiles("test")
public class HealthFunctionalTest extends FunctionalTest {

    String healthUrl;
    String healthUrlz;

    @BeforeEach
    void setup() {
        healthUrl = String.format("http://localhost:%s/payments-service/health", serverPort);
        healthUrlz = String.format("http://localhost:%s/payments-service/healthz", serverPort);
    }

    @Test
    public void customHealthCheckReturnsUp() {

        given().
                when().
                get(healthUrl).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));

    }

    @Test
    public void customHealthZCheckReturnsUp() {

        given().
                when().
                get(healthUrlz).
                then().
                statusCode(200).
                and().
                body(equalTo("Up"));

    }

}
