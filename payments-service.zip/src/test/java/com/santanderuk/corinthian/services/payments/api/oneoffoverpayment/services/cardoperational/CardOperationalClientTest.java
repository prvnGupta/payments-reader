package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalResponse;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;

@ExtendWith(MockitoExtension.class)
class CardOperationalClientTest {

    CardOperationalClient client;

    @Mock
    OverpaymentsConfig overpaymentsConfig;
    @Mock
    RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        client = new CardOperationalClient(overpaymentsConfig, restTemplate);
    }

    @Test
    void testHappyPathSantanderCard() throws IOException, CardOperationalException {
        Mockito.when(overpaymentsConfig.getClientId()).thenReturn("client-id");
        Mockito.when(overpaymentsConfig.getCardOperationalEndpoint()).thenReturn("https://dummy-url.santanderuk.pre.corp/sanuk/internal/v1.0/card/operationality-details");
        Mockito.when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenReturn(TestDataCreator.generateCardOperationalEntityOk());
        CardOperationalResponse cardOperationalResponse = client.callCardOperational("1122334455667788");
        assertEquals("F555", cardOperationalResponse.getOperationalityDetails().getFnumber());
    }

    @Test
    void testHappyPathNonSantanderCard() throws IOException, CardOperationalException {
        Mockito.when(overpaymentsConfig.getClientId()).thenReturn("client-id");
        Mockito.when(overpaymentsConfig.getCardOperationalEndpoint()).thenReturn("https://dummy-url.santanderuk.pre.corp/sanuk/internal/v1.0/card/operationality-details");
        Mockito.when(restTemplate.postForEntity(anyString(), any(HttpEntity.class), any(Class.class))).thenThrow(RestClientException.class);
        CardOperationalException cardOperationalException = assertThrows(CardOperationalException.class, () -> client.callCardOperational("1122334455667788"));
        assertEquals("Non Santander Card", cardOperationalException.getMessage());
        assertEquals("CARD_OPERATIONAL", cardOperationalException.getCode());
    }
}
