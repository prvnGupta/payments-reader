package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation;

import com.santanderuk.corinthian.services.commons.anmfclient.SimulationClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SimulationServiceTest {

    @Mock
    SimulationMapper simulationMapper;
    @Mock
    SimulationClient simulationClient;
    @Mock
    EndpointConfiguration endpointConfiguration;

    private SimulationService service;

    @BeforeEach
    void setUp() {
        when(endpointConfiguration.getAnmfSimulationUrl()).thenReturn("simulation/{region}/simulate");
        service = new SimulationService(simulationClient, endpointConfiguration, simulationMapper);
    }

    @Test
    void testCreateSimulation() throws IOException, GeneralException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 1)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateDefaultSimulationResponse());

        assertNull(mortgageSingleOverpaymentsContext.getUpdatedSimulationResponse());

        service.createOverpaymentSimulationV1(mortgageSingleOverpaymentsContext);

        assertEquals(6983663, mortgageSingleOverpaymentsContext.getUpdatedSimulationResponse().getOSimulationId());

        assertEquals(anmfSimulationRequest, anmfSimulationRequestArgumentCaptor.getValue());
    }

    @Test
    void testCardCreateSimulation() throws IOException, GeneralException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCardCreateSimulationRequest(cardMortgageSingleOverpaymentsContext)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateDefaultSimulationResponse());

        assertNull(cardMortgageSingleOverpaymentsContext.getCardTransactionDetails().getUpdatedSimulationResponse());

        service.createCardOverpaymentSimulation(cardMortgageSingleOverpaymentsContext);

        assertEquals(6983663, cardMortgageSingleOverpaymentsContext.getCardTransactionDetails().getUpdatedSimulationResponse().getOSimulationId());

        assertEquals(anmfSimulationRequest, anmfSimulationRequestArgumentCaptor.getValue());
    }

    @Test
    void testCreateSimulationException() throws IOException, ConnectionException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 1)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenThrow(ConnectionException.class);
        assertThrows(ConnectionException.class, () -> service.createOverpaymentSimulationV1(mortgageSingleOverpaymentsContext));
        assertEquals(anmfSimulationRequest, anmfSimulationRequestArgumentCaptor.getValue());
    }

    @Test
    void testCardCreateSimulationException() throws IOException, GeneralException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCardCreateSimulationRequest(cardMortgageSingleOverpaymentsContext)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenThrow(ConnectionException.class);
        GeneralException generalException = assertThrows(GeneralException.class, () -> service.createCardOverpaymentSimulation(cardMortgageSingleOverpaymentsContext));
        assertEquals("EXC_SIMULATION_ERROR_RESPONSE", generalException.getCode());
        assertEquals("Error creating overpayment simulation", generalException.getMessage());
    }

    @Test
    void testCreateSimulationError() throws IOException, ConnectionException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 1)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateKoSimulationResponse());
        GeneralException generalException = assertThrows(GeneralException.class, () -> service.createOverpaymentSimulationV1(mortgageSingleOverpaymentsContext));
        assertEquals("EXC_SIMULATION_ERROR_RESPONSE", generalException.getCode());
        assertEquals("Error received from simulation core service", generalException.getMessage());
    }

    @Test
    void testCardCreateSimulationError() throws IOException, GeneralException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCardCreateSimulationRequest(cardMortgageSingleOverpaymentsContext)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateKoSimulationResponse());
        GeneralException generalException = assertThrows(GeneralException.class, () -> service.createCardOverpaymentSimulation(cardMortgageSingleOverpaymentsContext));
        assertEquals("EXC_SIMULATION_ERROR_RESPONSE", generalException.getCode());
        assertEquals("Error creating overpayment simulation", generalException.getMessage());
    }

    @Test
    void testUpdatePaymentMethod() throws IOException, GeneralException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 1)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateDefaultSimulationResponse());

        service.updatePaymentMethodV1(mortgageSingleOverpaymentsContext);

        assertEquals(anmfSimulationRequest, anmfSimulationRequestArgumentCaptor.getValue());
    }

    @Test
    void testCardUpdatePaymentMethod() throws IOException, GeneralException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCardUpdatePaymentMethodSimulationRequest(cardMortgageSingleOverpaymentsContext)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateDefaultSimulationResponse());

        service.updatePaymentMethodCard(cardMortgageSingleOverpaymentsContext);

        assertEquals(anmfSimulationRequest, anmfSimulationRequestArgumentCaptor.getValue());
    }

    @Test
    void testUpdatePaymentMethodException() throws IOException, ConnectionException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 1)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenThrow(ConnectionException.class);
        assertThrows(ConnectionException.class, () -> service.updatePaymentMethodV1(mortgageSingleOverpaymentsContext));
        assertEquals(anmfSimulationRequest, anmfSimulationRequestArgumentCaptor.getValue());
    }

    @Test
    void testCardUpdatePaymentMethodExceptionDoesntThrowException() throws IOException, GeneralException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCardUpdatePaymentMethodSimulationRequest(cardMortgageSingleOverpaymentsContext)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenThrow(ConnectionException.class);
        service.updatePaymentMethodCard(cardMortgageSingleOverpaymentsContext);

    }

    @Test
    void testUpdatePaymentMethodError() throws IOException, ConnectionException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = TestDataCreator.generateInitialMortgageSingleOverpaymentContextSingleLoan();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 1)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateUpdatePaymentMethodErrorResponse());
        assertThrows(GeneralException.class, () -> service.updatePaymentMethodV1(mortgageSingleOverpaymentsContext));
        assertEquals(anmfSimulationRequest, anmfSimulationRequestArgumentCaptor.getValue());
    }

    @Test
    void testCardUpdatePaymentMethodErrorDoesntThrowException() throws IOException, ConnectionException {
        var anmfSimulationRequestArgumentCaptor = ArgumentCaptor.forClass(ANMFSimulationRequest.class);
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContext();
        ANMFSimulationRequest anmfSimulationRequest = TestDataCreator.generateDefaultAnmfSimulationRequest();
        when(simulationMapper.generateCardUpdatePaymentMethodSimulationRequest(cardMortgageSingleOverpaymentsContext)).thenReturn(anmfSimulationRequest);
        when(simulationClient.simulate(anyString(), anmfSimulationRequestArgumentCaptor.capture(), any())).thenReturn(TestDataCreator.generateUpdatePaymentMethodErrorResponse());
        service.updatePaymentMethodCard(cardMortgageSingleOverpaymentsContext);
    }
}
