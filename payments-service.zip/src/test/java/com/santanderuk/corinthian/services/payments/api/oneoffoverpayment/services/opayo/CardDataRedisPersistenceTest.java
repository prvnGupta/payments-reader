package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class CardDataRedisPersistenceTest {

    @Mock
    OpayoUtils opayoUtils;

    CardDataRedisPersistence cardDataRedisPersistence;

    @BeforeEach
    void setUp() {
        cardDataRedisPersistence = new CardDataRedisPersistence(opayoUtils);
    }

    @Test
    void testWeEncryptCardNumber() throws IOException, GeneralException {
        Mockito.when(opayoUtils.encryptGivenText(anyString())).thenReturn("encryptedCardNumber");
        cardDataRedisPersistence.cacheCardTransaction("OPAYO2022100615004181713317643", TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContextChallenge());
        verify(opayoUtils, times(1)).encryptGivenText("4462000000000003");
    }
}
