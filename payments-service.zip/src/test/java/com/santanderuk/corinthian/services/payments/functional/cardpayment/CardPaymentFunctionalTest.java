package com.santanderuk.corinthian.services.payments.functional.cardpayment;

import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

@ActiveProfiles("test")
public class CardPaymentFunctionalTest extends FunctionalTest {

    String cardPaymentUrl;
    Header header;

    @BeforeEach
    void setUpThisTest() {
        cardPaymentUrl = String.format("http://localhost:%s/payments-service/34218165/card-one-off-overpayment", serverPort);
        header = new Header("authorization", jwtAuth);
    }

    @Test
    void shouldReturnHappyPathResponseOkayChallenge() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubSimulationReduceTerm();
        stubCardTransactionChallengeResponse();
        stubCardOperationalNonSantanderCard();
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F000000555\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(201).and().
                body("data.paymentDone", equalTo(false),
                        "data.transactionId", equalTo("OPAYO2022100615004181713317643"),
                        "data.threeDSDetails.outputUrl", equalTo("https://test.sagepay.com/3ds-simulator/html_challenge"),
                        "data.threeDSDetails.outputCode", equalTo("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJlOWE4NmVlOS0wMjFlLTQ0N2MtYjczMS0wNjQzODNiN2M0NzAiLAogICJhY3NUcmFuc0lEIiA6ICJjMmM4MTRmMi0yYjE3LTQxMDQtODJiOS1mMWM5NWEyOWJlZTEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwNCIKfQ"),
                        "data.base64Pdf", equalTo(""),
                        "data.usingOwnSantanderCard", equalTo(false),
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found")
                );


    }

    @Test
    void cardTransactionException() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubSimulationReduceTerm();
        stubCardOperationalNonSantanderCard();
        stubCardTransactionException();
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F000000555\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(500).and().
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("CARD_TRANSACTION_KO"),
                        "info.message", equalTo("Could not process card-payment")
                );
    }

    @Test
    void shouldReturnHappyPathResponseOkayFrictionlessOkSecondBorrowerCardHolder() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubCardTransactionFrictionlessOkResponse();
        stubLacOkForAccount("091586034218165");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubUpdateCPSOkResponse();
        stubSimulationReduceTerm();
        stubSimulationUpdatePaymentMethodOKCard();

        stubCardOperationalSantanderCard();
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F555\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(201).and().
                body("data.paymentDone", equalTo(true),
                        "data.transactionId", equalTo(""),
                        "data.threeDSDetails", equalTo(null),
                        "data.base64Pdf", containsString("JVBERi0xLjQKJfbk/N8KMSAwIG9iago8PAovTGFuZyAoZW4tR0IpCi9NZXRhZGF0YSAyIDAgUgovUGFnZXMgMyAwIFIKL1R5cGUgL0NhdGFsb2cKL1ZpZXdlclByZWZlcmVuY2VzIDw8Ci9EaXJlY3Rpb24gL0wyUgo+Pgo+PgplbmRvYmoKNCAwIG9iago8PAovQ3JlYXRpb"),
                        "data.usingOwnSantanderCard", equalTo(true),
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found")
                );
    }

    @Test
    void shouldReturnHappyPathResponseOkayFrictionlessOk() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubCardTransactionFrictionlessOkResponse();
        stubLacOkForAccount("091586034218165");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubUpdateCPSOkResponse();
        stubSimulationReduceTerm();
        stubSimulationUpdatePaymentMethodOKCard();
        stubCardOperationalSantanderCard();

        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F000000554\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(201).and().
                body("data.paymentDone", equalTo(true),
                        "data.transactionId", equalTo(""),
                        "data.threeDSDetails", equalTo(null),
                        "data.base64Pdf", containsString("JVBERi0xLjQKJfbk/N8KMSAwIG9iago8PAovTGFuZyAoZW4tR0IpCi9NZXRhZGF0YSAyIDAgUgovUGFnZXMgMyAwIFIKL1R5cGUgL0NhdGFsb2cKL1ZpZXdlclByZWZlcmVuY2VzIDw8Ci9EaXJlY3Rpb24gL0wyUgo+Pgo+PgplbmRvYmoKNCAwIG9iago8PAovQ3JlYXRpb"),
                        "data.usingOwnSantanderCard", equalTo(false),
                        "info.status", equalTo("ok"),
                        "info.message", equalTo("Data found")
                );
    }

    @Test
    void cardTransactionRejected() {
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion(34218165);
        stubSimulationReduceTerm();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-34218165.json");
        stubCardTransactionRejectedResponse();
        stubLacOkForAccount("091586034218165");
        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubUpdateCPSOkResponse();
        stubCardOperationalNonSantanderCard();
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F000000555\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(500).and().
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("CARD_TRANSACTION_KO"),
                        "info.message", equalTo("Could not process card-payment")
                );
    }


    @Test
    void shouldReturnInvalidCardNumber() {
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"paymentAmount\": 11,\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"changeType\": \"M\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"12345678122343331232\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F000000555\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(400).and().
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.message", equalTo("cardDetails.cardNumber is invalid")
                );
    }

    @Test
    void shouldReturnInvalidCVV() {
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"01/26\",\n" +
                        "    \"customerId\": \"F000000554\",\n" +
                        "    \"cvv\": \"13\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(400).and().
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.message", equalTo("cardDetails.cvv is invalid")
                );
    }

    @Test
    void shouldReturnInvalidExpiryDate() {
        RestAssured.given().
                contentType(ContentType.JSON).
                accept(ContentType.JSON).
                header(header).
                body("{\n" +
                        "  \"ercCollectionOption\": \"O\",\n" +
                        "  \"cardDetails\": {\n" +
                        "    \"cardNumber\": \"1234567890123456\",\n" +
                        "    \"expiryDate\": \"00/26\",\n" +
                        "    \"customerId\": \"F000000554\",\n" +
                        "    \"cvv\": \"123\",\n" +
                        "    \"address\": {\n" +
                        "      \"line1\": \"line 1\",\n" +
                        "      \"line2\": \"Witan Gate\",\n" +
                        "      \"city\": \"Milton Keynes\",\n" +
                        "      \"postcode\": \"MK9 2BQ\"\n" +
                        "    }\n" +
                        "  },\n" +
                        "  \"loanDetails\": [\n" +
                        "    {\n" +
                        "      \"loanScheme\": \"3R\",\n" +
                        "      \"appSeqNumber\": 2,\n" +
                        "      \"loanOverpaymentAmount\": 11,\n" +
                        "      \"loanChangeType\": \"M\"\n" +
                        "    }\n" +
                        "  ]\n" +
                        "}").
                when().post(cardPaymentUrl).
                then().statusCode(400).and().
                body("info.status", equalTo("ko"),
                        "info.code", equalTo("BAD_REQUEST"),
                        "info.message", equalTo("cardDetails.expiryDate is invalid")
                );
    }
}
