package com.santanderuk.corinthian.services.payments.functional.regularoverpayment;

import com.jayway.restassured.http.ContentType;
import com.jayway.restassured.response.Header;
import com.santanderuk.corinthian.services.payments.functional.FunctionalTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

import static com.jayway.restassured.RestAssured.given;

@ActiveProfiles("test")
public class RegularOverpaymentFunctionalTest extends FunctionalTest {

    String setupRegularPaymentUrl;
    Header header;
    int accountNumber;

    @BeforeEach
    void setupThisTest() {
        accountNumber = 12345678;
        setupRegularPaymentUrl = String.format("http://localhost:%s/payments-service/regular-overpayment/%s", serverPort, accountNumber);
        header = new Header("authorization", jwtAuth);
        stubHeartbeatRegionA();
        stubGetCustomerInfoARegion();
    }

    @Test
    public void testHappyPath() {
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201);
    }

    @Test
    public void testANMFSetUpFunctionalError() {

        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-setup-regular-response-error.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(202);
    }

    @Test
    public void testANMFSetUpTechnicalError() {
        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(500);
    }

    @Test
    public void testAmountIsNotInRequest() {
        stubSetUpRegularARegion();
        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("set-up-regular-amount-doesnt-exist.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }


    @Test
    public void testStartDateDoesNotMatchValidation() {
        stubSetUpRegularARegion();
        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("set-up-regular-start-date-does-not-match-validation.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testRegionX() {
        stubHeartbeatRegionX();
        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(503);
    }

    @Test
    public void testSentNotAcceptableStartingDate() {
        stubSetUpRegularARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("customer-sent-wrong-starting-date.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testSentNotAcceptableEndingDate() {
        stubSetUpRegularARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("customer-sent-wrong-ending-date.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testSentUntilFurtherNoticesAsEndingDate() {
//        stubSetUpRegularARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request-until-further-notice.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201);
    }


    @Test
    public void testSentWrongLoanPart() {
        stubSetUpRegularARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("customer-sent-wrong-loan-part.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testSetUpAnmfPaymentsFails() {
        stubSetUpRegularBadResponse();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(500);
    }

    @Test
    public void testSetUpHasERCApplicableButTheRemaingAllowanceIsZero() {
        stubSetUpRegularARegion();
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-zero-erc-allowance-remaining.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(400);
    }

    @Test
    public void testSetUpHasERCApplicableAndTheRemaingAllowanceIsEnoughForMakingAPayment() {
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-with-erc-allowance.json");

        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201);
    }

    @Test
    public void testSetUpNoERCApplicable() {
        stubAnmfAccountDetails("anmf-account-info/anmf-account-details-response-no-erc-allowance-applicable.json");
        stubAnmfLoanPaymentPlan("anmf-loan-payment-plan/anmf-loan-payment-plan-response.json");

        stubBksConnectClientRetrieveMcc("bksconnect/retrievemcc/bksconnect-retrievemcc-ok.json");
        stubAnmfSetupRegular("anmf-regular/anmf-regular-instruction.json");

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(201);
    }

    @Test
    public void testTryingToMakeAPaymentInRegionW() {
        stubHeartbeatRegionW();
        stubGetCustomerInfoWRegion();

        given().
                contentType(ContentType.JSON).
                header(header).body(readFileContents("happy-path-controller-request.json"))
                .when().
                post(setupRegularPaymentUrl).
                then().
                statusCode(503);
    }
}
