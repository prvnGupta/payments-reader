package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Base64;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;

@ExtendWith(SpringExtension.class)
@SpringBootTest
@ActiveProfiles("test")
class PDFCreationServiceTest {
    @Autowired
    PDFCreationService pdfCreationService;

    @MockBean
    PDFCreationDataMapper pdfCreationDataMapper;


    @Test
    void testHappyPath() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataSingleLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForTermReduction());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your payment will show up on your account and statement"));
        assertTrue(text.contains("at the latest by the end of the next working day subject to normal bank checks. Please do not"));
        assertTrue(text.contains("attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));

        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different rate"));
        assertTrue(text.contains("of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("Your payment:"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Early repayment charge"));
        assertTrue(text.contains("£7.93"));

        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£216.97"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£216.96"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("08/06/2022"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathMultiLoan() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceTerm();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataMultiLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForTermReductionMultiLoan());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your account will be updated within the next 3 working"));
        assertTrue(text.contains("days subject to normal bank checks. Please do not attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));
        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different"));
        assertTrue(text.contains("rate of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£111.11"));
        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£222.22"));
        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£805.53"));

        assertTrue(text.contains("Total overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Total early repayment charge"));
        assertTrue(text.contains("£7.93"));
        assertTrue(text.contains("Your total payment"));
        assertTrue(text.contains("£5,000.00"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three monthly payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£2,081.22"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£2,081.21"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("07/10/2023"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathThreeLoanOneOverpaying() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceTerm();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataMultiLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForTermReductionThreeLoanOneOverpaying());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your account will be updated within the next 3 working"));
        assertTrue(text.contains("days subject to normal bank checks. Please do not attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));
        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different"));
        assertTrue(text.contains("rate of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£222.22"));
        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£805.53"));

        assertTrue(text.contains("Total overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Total early repayment charge"));
        assertTrue(text.contains("£7.93"));
        assertTrue(text.contains("Your total payment"));
        assertTrue(text.contains("£5,000.00"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three monthly payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£2,081.22"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£2,081.21"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("07/10/2023"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathThreeLoanTwoOverpaying() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceTerm();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataMultiLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForTermReductionThreeLoanTwoOverpaying());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your account will be updated within the next 3 working"));
        assertTrue(text.contains("days subject to normal bank checks. Please do not attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));
        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different"));
        assertTrue(text.contains("rate of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£111.11"));
        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£222.22"));
        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£805.53"));

        assertTrue(text.contains("Total overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Total early repayment charge"));
        assertTrue(text.contains("£7.93"));
        assertTrue(text.contains("Your total payment"));
        assertTrue(text.contains("£5,000.00"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three monthly payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£2,081.22"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£2,081.21"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("07/10/2023"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathMultiLoanReduceMonthlyPayment() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceMonthlyPayments();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataMultiLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForReduceMonthlyPaymentMultiLoan());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your account will be updated within the next 3 working"));
        assertTrue(text.contains("days subject to normal bank checks. Please do not attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));
        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different"));
        assertTrue(text.contains("rate of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£111.11"));
        assertTrue(text.contains("You have chosen to reduce your monthly payments:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (No change)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£222.22"));
        assertTrue(text.contains("You have chosen to reduce your monthly payments:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (No change)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£805.53"));

        assertTrue(text.contains("Total overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Total early repayment charge"));
        assertTrue(text.contains("£7.93"));
        assertTrue(text.contains("Your total payment"));
        assertTrue(text.contains("£5,000.00"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three monthly payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£2,081.22"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£2,081.21"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("07/10/2023"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathMultiLoanReduceBalance() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForMultiLoanPDFReduceBalance();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataMultiLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForReduceBalanceMultiLoan());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your account will be updated within the next 3 working"));
        assertTrue(text.contains("days subject to normal bank checks. Please do not attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));
        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different"));
        assertTrue(text.contains("rate of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£111.11"));
        assertTrue(text.contains("You have chosen to reduce your balance:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (No change)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£222.22"));
        assertTrue(text.contains("You have chosen to reduce your balance:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (No change)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£805.53"));

        assertTrue(text.contains("Total overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Total early repayment charge"));
        assertTrue(text.contains("£7.93"));
        assertTrue(text.contains("Your total payment"));
        assertTrue(text.contains("£5,000.00"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three monthly payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£2,081.22"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£2,081.21"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("07/10/2023"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathMultiLoanCardPayment() throws IOException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateInitialCardMortgageSingleOverpaymentContextMultiLoanPdf();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataForCardPaymentMultiLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForTermReductionMultiLoanCardPayment());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForCardPayment(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your account will be updated within the next 3 working"));
        assertTrue(text.contains("days subject to normal bank checks. Please do not attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));
        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different"));
        assertTrue(text.contains("rate of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("Overpayment summary"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£111.11"));
        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("2 year fixed at 1.90%"));
        assertTrue(text.contains("Balance (before overpayment)"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£222.22"));
        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£805.53"));

        assertTrue(text.contains("Total overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Total early repayment charge"));
        assertTrue(text.contains("£7.93"));
        assertTrue(text.contains("Your total payment"));
        assertTrue(text.contains("£5,000.00"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three monthly payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£2,081.22"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£2,081.21"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Payment method:"));
        assertTrue(text.contains("Debit card"));

        assertTrue(text.contains("Overpayment requested date:"));
        assertTrue(text.contains("07/10/2023"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathReduceMonthlyPayment() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataSingleLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForMonthlyPaymentReduction());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your payment will show up on your account and statement"));
        assertTrue(text.contains("at the latest by the end of the next working day subject to normal bank checks. Please do not"));
        assertTrue(text.contains("attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));

        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different rate"));
        assertTrue(text.contains("of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("Your payment:"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Early repayment charge"));
        assertTrue(text.contains("£7.93"));

        assertTrue(text.contains("You have chosen to reduce your monthly payments:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£4.08"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (No change)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£216.97"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£216.96"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("08/06/2022"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testHappyPathReduceBalance() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataSingleLoan(context)).thenReturn(TestDataCreator.generateDefaultPdfCreationDataForBalanceReduction());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your payment will show up on your account and statement"));
        assertTrue(text.contains("at the latest by the end of the next working day subject to normal bank checks. Please do not"));
        assertTrue(text.contains("attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));

        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different rate"));
        assertTrue(text.contains("of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("Your payment:"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Early repayment charge"));
        assertTrue(text.contains("£7.93"));

        assertTrue(text.contains("You have chosen to reduce your balance:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (No change)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£216.97"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£216.96"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Account to make overpayment from:"));
        assertTrue(text.contains("09-01-27 012345678"));
        assertTrue(text.contains("123 CURRENT ACCOUNT"));

        assertTrue(text.contains("Payment to be taken on:"));
        assertTrue(text.contains("08/06/2022"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }
    @Test
    void testHappyPathDebitCardPayment() throws IOException {
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContext();
        Mockito.when(pdfCreationDataMapper.getPdfCreationDataForCardPayment(context)).thenReturn(TestDataCreator.generatePdfCreationDataForDebitCard());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForCardPayment(context);
        assertTrue(base64PdfFile.length() > 0);

        byte[] decodedBytes = Base64.getDecoder().decode(base64PdfFile.getBytes());

        FileOutputStream fos = new FileOutputStream("test.pdf");
        fos.write(decodedBytes);
        fos.flush();
        fos.close();

        PDDocument doc = PDDocument.load(new File("test.pdf"));
        PDFTextStripper pdfStripper = new PDFTextStripper();
        String text = pdfStripper.getText(doc);
        doc.close();

        assertTrue(text.contains("Your overpayment details"));

        assertTrue(text.contains("Your payment is being processed. Your payment will show up on your account and statement"));
        assertTrue(text.contains("within the next 3 working days subject to normal bank checks. Please do not"));
        assertTrue(text.contains("attempt this transaction again."));

        assertTrue(text.contains("If for any reason you need your payment returned, you must request this within 28 days."));

        assertTrue(text.contains("After 28 days you will be required to apply for an additional loan, which may be at a different rate"));
        assertTrue(text.contains("of interest than your current mortgage."));

        assertTrue(text.contains("Mortgage account details:"));
        assertTrue(text.contains("Sort code"));
        assertTrue(text.contains("09-15-86"));
        assertTrue(text.contains("Account number"));
        assertTrue(text.contains("123456789"));

        assertTrue(text.contains("Your payment:"));
        assertTrue(text.contains("£5,000.00"));
        assertTrue(text.contains("Overpayment"));
        assertTrue(text.contains("£4,992.07"));
        assertTrue(text.contains("Early repayment charge"));
        assertTrue(text.contains("£7.93"));

        assertTrue(text.contains("You have chosen to pay off your mortgage sooner:"));
        assertTrue(text.contains("Monthly payment saving"));
        assertTrue(text.contains("£0.00"));
        assertTrue(text.contains("Mortgage term"));
        assertTrue(text.contains("20 years 3 months (New)"));
        assertTrue(text.contains("Interest saving"));
        assertTrue(text.contains("£3,074.25"));

        assertTrue(text.contains("Your new monthly payments:"));
        assertTrue(text.contains("Your next two Direct Debits may vary slightly from your normal monthly payment"));
        assertTrue(text.contains("Your next three payments are as follows:"));
        assertTrue(text.contains("1st payment"));
        assertTrue(text.contains("£216.97"));
        assertTrue(text.contains("2nd payment"));
        assertTrue(text.contains("£216.96"));
        assertTrue(text.contains("Future monthly payment"));
        assertTrue(text.contains("£216.95"));

        assertTrue(text.contains("Your new outstanding balance after overpayment:"));
        assertTrue(text.contains("£36,410.89"));

        assertTrue(text.contains("Payment method:"));
        assertTrue(text.contains("Debit card"));

        assertTrue(text.contains("Overpayment requested date:"));
        assertTrue(text.contains("02/11/2022"));


        File testPdf = new File("test.pdf");
        boolean deleted = testPdf.delete();
        assertTrue(deleted);
    }

    @Test
    void testException() throws IOException {
        MortgageSingleOverpaymentsContext context = TestDataCreator.generateMortgageSingleOverpaymentContextForApplyOverpayment();
        Mockito.doThrow(NullPointerException.class).when(pdfCreationDataMapper).getPdfCreationDataSingleLoan(any());
        String base64PdfFile = pdfCreationService.createBase64PdfFileForInternalTransfer(context);
        assertEquals("", base64PdfFile);
    }
}
