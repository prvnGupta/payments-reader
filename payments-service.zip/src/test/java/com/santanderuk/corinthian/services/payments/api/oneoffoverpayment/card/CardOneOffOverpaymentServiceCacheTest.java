package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.TestDataCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.CardDataRedisPersistence;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoPaymentService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations.CardOneOffValidationsAndContextGeneratorService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.*;

@ExtendWith(SpringExtension.class)
@ActiveProfiles("test")
@SpringBootTest
class CardOneOffOverpaymentServiceCacheTest {

    @Autowired
    CardOneOffOverpaymentService cardOneOffOverpaymentService;

    @MockBean
    CardOneOffValidationsAndContextGeneratorService cardOneOffValidationsAndContextGeneratorService;
    @MockBean
    OpayoPaymentService opayoPaymentService;
    @MockBean
    SimulationService simulationService;
    @MockBean
    CardDataRedisPersistence cardDataRedisPersistence;
    @MockBean
    ClearPaymentCache clearPaymentCache;


    @Test
    void shouldCacheTransactionDetailsAfterChallenge() throws IOException, GeneralException {
        CardOneOffPaymentRequest cardOneOffPaymentRequest = TestDataCreator.generateDefaultCardPaymentInputRequest();
        CardMortgageSingleOverpaymentsContext context = TestDataCreator.generateCompleteCardMortgageSingleOverpaymentContextChallenge();
        when(cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin")).thenReturn(context);
        Mockito.doNothing().when(opayoPaymentService).makeCardTransaction(context);
        Mockito.doNothing().when(opayoPaymentService).updateCPS(context);
        Mockito.doNothing().when(simulationService).createCardOverpaymentSimulation(context);
        Mockito.doNothing().when(simulationService).updatePaymentMethodCard(context);

        CardPaymentResponse response = cardOneOffOverpaymentService.makeCardOneOffOverpayment(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin");
        verify(cardOneOffValidationsAndContextGeneratorService, times(1)).validateRequestAndGenerateContext(12345678, cardOneOffPaymentRequest, "jwt-token", "127.0.0.1", "origin");
        verify(simulationService, times(1)).createCardOverpaymentSimulation(context);
        verify(opayoPaymentService, times(1)).makeCardTransaction(context);
        verify(opayoPaymentService, times(0)).updateCPS(context);
        verify(simulationService, times(0)).updatePaymentMethodCard(context);
        verify(cardDataRedisPersistence, times(1)).cacheCardTransaction("OPAYO2022100615004181713317643", context);
        verify(clearPaymentCache, times(0)).deleteCardTransactionCache("OPAYO2022100615004181713317643");

        assertFalse(response.isPaymentDone());
        assertEquals("", response.getBase64Pdf());
        assertEquals("OPAYO2022100615004181713317643", response.getTransactionId());
        assertEquals("ewogICJtZXNzYWdlVHlwZSIgOiAiQ1JlcSIsCiAgIm1lc3NhZ2VWZXJzaW9uIiA6ICIyLjIuMCIsCiAgInRocmVlRFNTZXJ2ZXJUcmFuc0lEIiA6ICJlOWE4NmVlOS0wMjFlLTQ0N2MtYjczMS0wNjQzODNiN2M0NzAiLAogICJhY3NUcmFuc0lEIiA6ICJjMmM4MTRmMi0yYjE3LTQxMDQtODJiOS1mMWM5NWEyOWJlZTEiLAogICJjaGFsbGVuZ2VXaW5kb3dTaXplIiA6ICIwNCIKfQ", response.getThreeDSDetails().getOutputCode());
        assertEquals("https://test.sagepay.com/3ds-simulator/html_challenge", response.getThreeDSDetails().getOutputUrl());
    }
}
