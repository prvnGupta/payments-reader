package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OLoanData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalAccountDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.utils.DataFormatter;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationFileCreator.STRING_DEBIT_CARD;

@Component
public class PDFCreationDataMapper {

    public static final String PAYMENT_METHOD_SANACCOUNT = "sanaccount";
    public static final String PAYMENT_METHOD_DEBIT_CARD = "Debit card";
    public static final String MORTGAGE_SORT_CODE_BY_DEFAULT = "09-15-86";
    public static final String STRING_DASH = "-";
    public static final String BIG_DECIMAL_TO_AMOUNT_FORMAT = "%1$,.2f";
    public static final String STRING_POUND = "£";
    public static final String STRING_MORTGAGE_TERM_NEW = " (New)";
    public static final String STRING_MORTGAGE_TERM_NO_CHANGE = " (No change)";
    public static final String STRING_SPACE = " ";
    public static final String STRING_SAVING = "SAVING";
    private final DataFormatter dataFormatter;

    public PDFCreationDataMapper(DataFormatter dataFormatter) {
        this.dataFormatter = dataFormatter;
    }

    private static String getSortCode(String account) {
        return account.substring(0, 2) + STRING_DASH +
                account.substring(2, 4) + STRING_DASH +
                account.substring(4, 6);
    }

    private static String bigDecimalAmountToString(BigDecimal amount) {
        return STRING_POUND + String.format(BIG_DECIMAL_TO_AMOUNT_FORMAT, amount);
    }

    public PDFCreationDataSingleLoan getPdfCreationDataSingleLoan(MortgageSingleOverpaymentsContext context) {
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = new PDFCreationDataSingleLoan();
        OutputStruc updatedSimulationResponse = context.getUpdatedSimulationResponse();

        // Chosen
        pdfCreationDataSingleLoan.setChosenHeader(getChosenAction(context));
        pdfCreationDataSingleLoan.setMonthlyPaymentSaving(bigDecimalAmountToString(updatedSimulationResponse.getOLoanData().get(0).getOLnCurrMonPay().subtract(updatedSimulationResponse.getOLoanData().get(0).getOLnSimMonPay())));
        pdfCreationDataSingleLoan.setMortgageTerm(dataFormatter.calculateTermRemaining(updatedSimulationResponse.getOLoanData().get(0).getOLnSimMatDt()));
        if (updatedSimulationResponse.getOLoanData().get(0).getOLnCurrMatDt().equalsIgnoreCase(updatedSimulationResponse.getOLoanData().get(0).getOLnSimMatDt())) {
            // if the term has changed add the string
            pdfCreationDataSingleLoan.setMortgageTerm(pdfCreationDataSingleLoan.getMortgageTerm() + STRING_MORTGAGE_TERM_NO_CHANGE);
        } else {
            pdfCreationDataSingleLoan.setMortgageTerm(pdfCreationDataSingleLoan.getMortgageTerm() + STRING_MORTGAGE_TERM_NEW);
        }
        pdfCreationDataSingleLoan.setInterestSaving(bigDecimalAmountToString(updatedSimulationResponse.getOTotIntBefSim().subtract(updatedSimulationResponse.getOTotIntAftSim())));
        pdfCreationDataSingleLoan.setPdfCreationData(getPdfCommonData(context));
        return pdfCreationDataSingleLoan;
    }

    public PDFCreationDataMultiLoan getPdfCreationDataMultiLoan(MortgageSingleOverpaymentsContext context) {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();

        pdfCreationDataMultiLoan.setLoanDetails(getPdfLoans(context.getSimulationChosenValues(), context.getAnmfAccountServiceResponse(), context.getUpdatedSimulationResponse()));
        pdfCreationDataMultiLoan.setPdfCreationData(getPdfCommonData(context));

        return pdfCreationDataMultiLoan;
    }

    private List<PDFLoan> getPdfLoans(SimulationChosenValues simulationChosenValues, AnmfAccountServiceResponse anmfAccountServiceResponse, OutputStruc updatedSimulationResponse) {
        List<PDFLoan> loanDetails = new ArrayList<>(updatedSimulationResponse.getOLoanData().size());
        for (int i = 0; i < updatedSimulationResponse.getOLoanData().size(); i++) {
            OLoanData oLoanData = updatedSimulationResponse.getOLoanData().get(i);
            LoanDetails loanDetailsObject = getLoanChosenValues(oLoanData, simulationChosenValues);
            OActiveLoanDetail oActiveLoanDetail = getLoanDetailsFromAccountsService(oLoanData, anmfAccountServiceResponse);
            PDFLoan pdfLoan = new PDFLoan();
            pdfLoan.setDescription(Objects.requireNonNull(oActiveLoanDetail).getOProductDesc() + " at " + oActiveLoanDetail.getOInterestRate().setScale(2, RoundingMode.HALF_DOWN).toString() + "%");
            pdfLoan.setBalanceBeforeOverpayment(bigDecimalAmountToString(oActiveLoanDetail.getOOutstandingBalance()));
            pdfLoan.setOverpaymentInBigDecimal(calculateOverpaymentAmount(Objects.requireNonNull(loanDetailsObject).getLoanOverpaymentAmount(), oLoanData.getOLnErc(), simulationChosenValues.getErcCollectionOption()));
            pdfLoan.setOverpayment(bigDecimalAmountToString(pdfLoan.getOverpaymentInBigDecimal()));
            pdfLoan.setChosenHeader(getChosenActionMultiLoan(loanDetailsObject, oLoanData));
            pdfLoan.setMonthlyPaymentSaving(bigDecimalAmountToString(oLoanData.getOLnCurrMonPay().subtract(oLoanData.getOLnSimMonPay())));
            pdfLoan.setMortgageTerm(dataFormatter.calculateTermRemaining(oLoanData.getOLnSimMatDt()));
            if (oLoanData.getOLnCurrMatDt().equalsIgnoreCase(oLoanData.getOLnSimMatDt())) {
                pdfLoan.setMortgageTerm(pdfLoan.getMortgageTerm() + STRING_MORTGAGE_TERM_NO_CHANGE);
            } else {
                pdfLoan.setMortgageTerm(pdfLoan.getMortgageTerm() + STRING_MORTGAGE_TERM_NEW);
            }
            pdfLoan.setInterestSaving(bigDecimalAmountToString(oLoanData.getOLnIntBefSim().subtract(oLoanData.getOLnIntAftSim())));
            loanDetails.add(pdfLoan);
        }
        return loanDetails;
    }

    private BigDecimal calculateOverpaymentAmount(BigDecimal loanOverpaymentAmount, BigDecimal oLnErc, String ercCollectionOption) {
        return ercCollectionOption.equalsIgnoreCase("I") ? loanOverpaymentAmount.subtract(oLnErc).setScale(2, RoundingMode.HALF_DOWN) : loanOverpaymentAmount;
    }

    private PDFCreationData getPdfCommonData(MortgageSingleOverpaymentsContext context) {
        PDFCreationData pdfCreationData = new PDFCreationData();

        String mortgageAccount = StringUtils.leftPad(String.valueOf(context.getMortgageAccount()), 9, '0');

        pdfCreationData.setSortCode(MORTGAGE_SORT_CODE_BY_DEFAULT);
        pdfCreationData.setAccountNumber(mortgageAccount);

        // Your payment
        OutputStruc updatedSimulationResponse = context.getUpdatedSimulationResponse();

        pdfCreationData.setTotalPayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotPayment()));
        pdfCreationData.setTotalOverpayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotOvpAmount()));
        pdfCreationData.setTotalEarlyRepayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotErc()));

        // New monthly payment
        pdfCreationData.setFirstPayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotNextMonPay()));
        pdfCreationData.setSecondPayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotSecondMonPay()));
        pdfCreationData.setFuturePayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotSimMonPay()));
        // New outstanding balance
        pdfCreationData.setNewOutstandingBalance(bigDecimalAmountToString(updatedSimulationResponse.getOCapBalAftSim()));

        // Payment method
        InternalAccountDetails selectedAccount = context.getInternalTransferAccountsDetails().getAccountFrom();
        pdfCreationData.setPaymentMethodSelection(PAYMENT_METHOD_SANACCOUNT);
        pdfCreationData.setPaymentMethod(getFormattedPaymentMethod(selectedAccount));
        pdfCreationData.setPaymentMethodName(context.getAccountFromAlias());

        // Payment to be taken on
        pdfCreationData.setPaymentTakenOn(dataFormatter.getTodayFormattedDate());

        return pdfCreationData;
    }

    private LoanDetails getLoanChosenValues(OLoanData oLoanData, SimulationChosenValues simulationChosenValues) {
        for (LoanDetails currObj : simulationChosenValues.getLoanDetails()) {
            if (oLoanData.getOLoanSch().equalsIgnoreCase(currObj.getLoanScheme()) && oLoanData.getOApplSeqNo() == currObj.getAppSeqNumber()) {
                return currObj;
            }
        }
        return null;
    }

    private OActiveLoanDetail getLoanDetailsFromAccountsService(OLoanData oLoanData, AnmfAccountServiceResponse anmfAccountServiceResponse) {
        for (OActiveLoanDetail currObj : anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails()) {
            if (oLoanData.getOLoanSch().equalsIgnoreCase(currObj.getOLoanScheme()) && oLoanData.getOApplSeqNo() == currObj.getOApplSeqNo()) {
                return currObj;
            }
        }
        return null;
    }

    public PDFCreationDataSingleLoan getPdfCreationDataForCardPayment(CardMortgageSingleOverpaymentsContext context) {
        PDFCreationDataSingleLoan pdfCreationData = new PDFCreationDataSingleLoan();

        OutputStruc updatedSimulationResponse = context.getCardTransactionDetails().getUpdatedSimulationResponse();
        // Chosen
        pdfCreationData.setChosenHeader(getChosenActionForCardPayment(context));
        pdfCreationData.setMortgageTerm(dataFormatter.calculateTermRemaining(updatedSimulationResponse.getOLoanData().get(0).getOLnSimMatDt()));
        pdfCreationData.setMonthlyPaymentSaving(bigDecimalAmountToString(updatedSimulationResponse.getOLoanData().get(0).getOLnCurrMonPay().subtract(updatedSimulationResponse.getOLoanData().get(0).getOLnSimMonPay())));
        if (updatedSimulationResponse.getOLoanData().get(0).getOLnCurrMatDt().equalsIgnoreCase(updatedSimulationResponse.getOLoanData().get(0).getOLnSimMatDt())) {
            // if the term has changed add the string
            pdfCreationData.setMortgageTerm(pdfCreationData.getMortgageTerm() + STRING_MORTGAGE_TERM_NO_CHANGE);
        } else {
            pdfCreationData.setMortgageTerm(pdfCreationData.getMortgageTerm() + STRING_MORTGAGE_TERM_NEW);
        }
        pdfCreationData.setInterestSaving(bigDecimalAmountToString(updatedSimulationResponse.getOTotIntBefSim().subtract(updatedSimulationResponse.getOTotIntAftSim())));
        // New monthly payment
        pdfCreationData.setPdfCreationData(getPdfCreationCommonDataForCardPayment(context));

        return pdfCreationData;
    }

    public PDFCreationData getPdfCreationCommonDataForCardPayment(CardMortgageSingleOverpaymentsContext context) {
        var pdfCreationData = new PDFCreationData();

        var mortgageAccount = StringUtils.leftPad(String.valueOf(context.getMortgageAccount()), 9, '0');
        pdfCreationData.setSortCode(MORTGAGE_SORT_CODE_BY_DEFAULT);
        pdfCreationData.setAccountNumber(mortgageAccount);

        // Your payment
        OutputStruc updatedSimulationResponse = context.getCardTransactionDetails().getUpdatedSimulationResponse();
        pdfCreationData.setTotalPayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotPayment()));
        pdfCreationData.setTotalOverpayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotOvpAmount()));
        pdfCreationData.setTotalEarlyRepayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotErc()));

        // New monthly payment
        pdfCreationData.setFuturePayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotSimMonPay()));
        pdfCreationData.setFirstPayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotNextMonPay()));
        pdfCreationData.setSecondPayment(bigDecimalAmountToString(updatedSimulationResponse.getOTotSecondMonPay()));
        // New outstanding balance
        pdfCreationData.setNewOutstandingBalance(bigDecimalAmountToString(updatedSimulationResponse.getOCapBalAftSim()));

        pdfCreationData.setPaymentMethodSelection(STRING_DEBIT_CARD);
        pdfCreationData.setPaymentMethod(PAYMENT_METHOD_DEBIT_CARD);

        // Payment to be taken on
        pdfCreationData.setPaymentTakenOn(dataFormatter.getTodayFormattedDate());

        return pdfCreationData;
    }

    public PDFCreationDataMultiLoan getPdfCreationDataForCardPaymentMultiLoan(CardMortgageSingleOverpaymentsContext context) {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = new PDFCreationDataMultiLoan();
        pdfCreationDataMultiLoan.setLoanDetails(getPdfLoans(context.getSimulationChosenValues(), context.getAnmfAccountServiceResponse(), context.getCardTransactionDetails().getUpdatedSimulationResponse()));
        pdfCreationDataMultiLoan.setPdfCreationData(getPdfCreationCommonDataForCardPayment(context));
        return pdfCreationDataMultiLoan;
    }

    private String getFormattedPaymentMethod(InternalAccountDetails selectedAccount) {
        if (isSavingAccount(selectedAccount)) {
            return formatSavingAccount(selectedAccount);
        } else {
            return getSortCode(selectedAccount.getLocalAccountNumber().getSortcode()) + STRING_SPACE + StringUtils.leftPad(String.valueOf(selectedAccount.getLocalAccountNumber().getAccountNumber()), 9, '0');
        }
    }

    private boolean isSavingAccount(InternalAccountDetails selectedAccount) {
        return selectedAccount.getLocalAccountNumber().getSortcode().equalsIgnoreCase(STRING_SAVING);
    }

    private String getChosenAction(MortgageSingleOverpaymentsContext context) {
        if (context.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType().equalsIgnoreCase("T")) {
            return context.getUpdatedSimulationResponse().getOLoanData().get(0).getOLnCurrMatDt().equalsIgnoreCase(context.getUpdatedSimulationResponse().getOLoanData().get(0).getOLnSimMatDt()) ? "B" : "T";
        } else {
            return context.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType();
        }
    }

    private String getChosenActionMultiLoan(LoanDetails loanDetailsObject, OLoanData oLoanData) {
        if (loanDetailsObject.getLoanChangeType().equalsIgnoreCase("T")) {
            return oLoanData.getOLnCurrMatDt().equalsIgnoreCase(oLoanData.getOLnSimMatDt()) ? "B" : "T";
        } else {
            return loanDetailsObject.getLoanChangeType();
        }
    }

    private String getChosenActionForCardPayment(CardMortgageSingleOverpaymentsContext context) {
        if (context.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType().equalsIgnoreCase("T")) {
            return context.getCardTransactionDetails().getUpdatedSimulationResponse().getOLoanData().get(0).getOLnCurrMatDt().equalsIgnoreCase(context.getCardTransactionDetails().getUpdatedSimulationResponse().getOLoanData().get(0).getOLnSimMatDt()) ? "B" : "T";
        } else {
            return context.getSimulationChosenValues().getLoanDetails().get(0).getLoanChangeType();
        }
    }

    private String formatSavingAccount(InternalAccountDetails selectedAccount) {
        String account = selectedAccount.getLocalAccountNumber().getAccountNumber();
        return selectedAccount.getLocalAccountNumber().getSortcode() + STRING_SPACE + account.substring(0, 9) + STRING_SPACE + account.substring(9);
    }
}
