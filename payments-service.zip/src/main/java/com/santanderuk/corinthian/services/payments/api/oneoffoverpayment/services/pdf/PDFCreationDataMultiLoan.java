package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class PDFCreationDataMultiLoan {
    private PDFCreationData pdfCreationData;
    private List<PDFLoan> loanDetails;
}
