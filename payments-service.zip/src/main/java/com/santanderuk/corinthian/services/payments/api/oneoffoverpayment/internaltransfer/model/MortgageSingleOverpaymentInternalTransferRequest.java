package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MortgageSingleOverpaymentInternalTransferRequest extends ModelBase {

    private static final long serialVersionUID = 3723743973734275993L;

    @NotBlank
    private String ercCollectionOption;

    @Valid
    List<LoanDetails> loanDetails;

    @Valid
    private LocalAccountNumber originAccount;

}
