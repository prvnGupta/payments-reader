
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Amount extends ModelBase {

    private static final long serialVersionUID = 3902140689123902121L;
    private Object amount;
    private Object saleAmount;
    private Object surchargeAmount;
    private Object currency;

}
