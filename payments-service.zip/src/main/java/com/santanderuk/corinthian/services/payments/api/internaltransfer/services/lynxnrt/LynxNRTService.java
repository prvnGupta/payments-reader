package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt;

import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.io.lynxNRT.LynxNRTDataRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.springframework.stereotype.Service;

@Service
public class LynxNRTService {

    private final LynxNRTDataMapper lynxNRTDataMapper;
    private final LynxNrtClient lynxNrtClient;

    public LynxNRTService(LynxNRTDataMapper lynxNRTDataMapper, LynxNrtClient lynxNrtClient) {
        this.lynxNRTDataMapper = lynxNRTDataMapper;
        this.lynxNrtClient = lynxNrtClient;
    }

    public void mapAndCallLynxNRT(InternalTransferRequest inputRequest, InternalTransferAccountsDetails accountsDetails, String status, String ldapUid, String remoteIpAddress) throws LynxNRTException {
        LynxNRTDataRequest lynxNRTDataRequest = lynxNRTDataMapper.decorateLynxNRTRequestData(inputRequest, accountsDetails, status, ldapUid, remoteIpAddress);
        lynxNrtClient.callLynxNRTClient(lynxNRTDataRequest);
    }

    public void mapAndCallLynxNRT(MortgageSingleOverpaymentsContext context, String status) throws LynxNRTException {
        LynxNRTDataRequest lynxNRTDataRequest = lynxNRTDataMapper.decorateLynxNRTRequestData(context, status);
        lynxNrtClient.callLynxNRTClient(lynxNRTDataRequest);
    }
}
