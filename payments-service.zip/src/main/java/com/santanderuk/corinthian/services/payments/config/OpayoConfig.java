package com.santanderuk.corinthian.services.payments.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


@Getter
@Configuration
public class OpayoConfig {

    @Value("${opayo.confirm-transaction.confirmType}")
    private String confirmType;

    @Value("${opayo.card-transaction.reusable}")
    private boolean reusable;

    @Value("${opayo.card-transaction.save}")
    private boolean save;

    @Value("${opayo.card-transaction.subject}")
    private String subject;

    @Value("${opayo.card-transaction.currency}")
    private String currency;

    @Value("${opayo.card-transaction.vendorName}")
    private String vendorName;

    @Value("${opayo.card-transaction.agentCode}")
    private String agentCode;

    @Value("${opayo.card-transaction.merchantId}")
    private String merchantId;

    @Value("${opayo.card-transaction.entryMethod}")
    private String entryMethod;

    @Value("${opayo.card-transaction.apply3DSecure}")
    private String apply3DSecure;

    @Value("${opayo.card-transaction.notificationUrl}")
    private String notificationUrl;

    @Value("${opayo.card-transaction.default-live-domain}")
    private String defaultLiveDomain;

    @Value("${opayo.card-transaction.transType}")
    private String transType;

    @Value("${opayo.card-transaction.giftAid}")
    private boolean giftAid;

    @Value("${opayo.cps.process}")
    private String cpsProcess;

    @Value("${opayo.cps.issueNumber}")
    private int issueNumber;

    @Value("${opayo.endpoints.card-transaction}")
    private String cardTransactionUrl;

    @Value("${opayo.endpoints.cps}")
    private String updateCpsUrl;

    @Value("${opayo.endpoints.confirm}")
    private String confirmUrl;

    @Value("${opayo.anmfSortcode}")
    private String anmfSortcode;

}
