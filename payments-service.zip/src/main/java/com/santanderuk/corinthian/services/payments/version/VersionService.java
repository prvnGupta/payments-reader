package com.santanderuk.corinthian.services.payments.version;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.Properties;

@Service
@Slf4j
public class VersionService {

    public VersionResponse getInfo() {
        return mapperFromPropertiesToResponse(loadProperties());
    }

    private VersionResponse mapperFromPropertiesToResponse(final Properties properties) {
        final String buildTime = properties.getProperty("git.build.time");
        final String gitHash = properties.getProperty("git.commit.id");
        final String buildVersion = properties.getProperty("build.version");
        final String serviceName = properties.getProperty("build.artifact");

        final VersionResponse response = new VersionResponse();
        response.setBuildTime(buildTime);
        response.setGitHash(gitHash);
        response.setBuildVersion(buildVersion);
        response.setServiceName(serviceName);
        return response;
    }

    private Properties loadProperties() {
        final Properties properties = new Properties();

        final InputStream buildInfoFile = Thread.currentThread().getContextClassLoader().getResourceAsStream("META-INF/build-info.properties");
        final InputStream gitInfoFile = Thread.currentThread().getContextClassLoader().getResourceAsStream("git.properties");

        try {
            properties.load(buildInfoFile);
        } catch (Exception e) {
            log.error("Failed to load build properties : {}", e.getMessage());
        }

        try {
            properties.load(gitInfoFile);
        } catch (Exception e) {
            log.error("Failed to load git info file : {}", e.getMessage());
        }
        return properties;
    }
}
