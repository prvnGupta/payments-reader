package com.santanderuk.corinthian.services.payments.api.regularoverpayment.service;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDResponse;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.Centre;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.MccContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentFunctionalValidation;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentMapper;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass.RegularOverpaymentFormattedDataMapper;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass.RegularOverpaymentGassMapper;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass.RegularOverpaymentGassService;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.RegularOverpaymentData;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Slf4j
@Service
public class SetupRegularOverpaymentService {
    public static final String SUCCESS_GASS_STATUS = "1";
    public static final String ERROR_GASS_STATUS = "2";

    protected final AnmfCoreClient anmfCoreClient;
    protected final RegularOverpaymentMapper regularOverpaymentMapper;
    protected final HeartBeatClient heartBeatClient;
    private final RegularOverpaymentGassMapper regularOverpaymentGassMapper;
    private final RegularOverpaymentFormattedDataMapper regularOverpaymentFormattedDataMapper;
    private final RegularOverpaymentGassService regularOverpaymentGassService;
    private final BksConnectClient bksConnectClient;
    private final RegularOverpaymentFunctionalValidation functionalValidation;
    private final ClearRegularOverpaymentCache clearRegularOverpaymentCache;

    private final EndpointConfiguration endpointConfiguration;

    @Autowired
    public SetupRegularOverpaymentService(RegularOverpaymentGassMapper regularOverpaymentGassMapper, RegularOverpaymentFormattedDataMapper regularOverpaymentFormattedDataMapper, AnmfCoreClient anmfCoreClient, RegularOverpaymentMapper regularOverpaymentMapper, RegularOverpaymentGassService regularOverpaymentGassService, BksConnectClient bksConnectClient, RegularOverpaymentFunctionalValidation functionalValidation, HeartBeatClient heartBeatClient, ClearRegularOverpaymentCache clearRegularOverpaymentCache, EndpointConfiguration endpointConfiguration) {
        this.regularOverpaymentGassMapper = regularOverpaymentGassMapper;
        this.regularOverpaymentFormattedDataMapper = regularOverpaymentFormattedDataMapper;
        this.anmfCoreClient = anmfCoreClient;
        this.regularOverpaymentMapper = regularOverpaymentMapper;
        this.regularOverpaymentGassService = regularOverpaymentGassService;
        this.bksConnectClient = bksConnectClient;
        this.functionalValidation = functionalValidation;
        this.heartBeatClient = heartBeatClient;
        this.clearRegularOverpaymentCache = clearRegularOverpaymentCache;
        this.endpointConfiguration = endpointConfiguration;
    }

    public RegularOverpaymentData setUpRegularOverpayment(final RegularOverpaymentContext context) throws GeneralException, IOException {

        fetchAllTheDataNeededForThisService(context);

        functionalValidation.validate(context);

        boolean paymentDone = false;
        try {
            paymentDone = processSetUpPetition(context);
        } catch (GeneralException e) {
            throwGeneralExceptionSpecifyingErrorConnectingWithSetUpAnmf(e);
        } finally {
            if (paymentDone) {
                context.setResultIndicatorForGass(SUCCESS_GASS_STATUS);
            } else {
                context.setResultIndicatorForGass(ERROR_GASS_STATUS);
            }
            saveTransactionToGass(context);
        }
        return new RegularOverpaymentData(paymentDone);
    }

    private void throwGeneralExceptionSpecifyingErrorConnectingWithSetUpAnmf(final GeneralException e) throws GeneralException {
        log.error("Error while calling Set up regular overpayment service");
        throw new GeneralException("ERROR_SETUP_REGULAR_ANMF", "Error while calling setup regular overpayment anmf core service", e);
    }

    private void fetchAllTheDataNeededForThisService(final RegularOverpaymentContext context) throws GeneralException {
        addAnmfResponsesToContext(context);
        addLdapUidToContext(context);
        addMccContractToContext(context);
    }

    public boolean processSetUpPetition(final RegularOverpaymentContext context) throws ConnectionException {
        log.debug("calling set-up regular overpayment service");
        final AnmfRegularOverpaymentCUDResponse response = setUpRegularOverpaymentInAnmf(context);
        clearRegularOverpaymentCache.deleteRegularOverpaymentCache(context.getAccount());
        context.setAnmfSetupRegularResponse(response);
        if (thereIsAnErrorInAnmfResponse(response)) {
            logErrorInAnmfResponse(response);
            return false;
        } else {
            log.info("Setup Regular overpayment completed ok");
            return true;
        }
    }


    private void saveTransactionToGass(final RegularOverpaymentContext context) throws GeneralException {
        context.setFormattedData(regularOverpaymentFormattedDataMapper.toFormattedData(context));
        regularOverpaymentGassService.callGass(
                regularOverpaymentGassMapper.toRegularOverpaymentGassItem(context)
        );
    }

    private void logErrorInAnmfResponse(final AnmfRegularOverpaymentCUDResponse response) {
        final String anmfErrorCode = response.getOverpaymentArrangementResponse().getOutputStruc().getEStruc().getECode();
        log.error("ANMFSimulation - > Error received from ANMF with error code: \"{}\" Complete message received from ANMF: {}", anmfErrorCode, response);
    }

    private boolean thereIsAnErrorInAnmfResponse(final AnmfRegularOverpaymentCUDResponse anmfSetupRegularResponse) {
        final String anmfErrorCode = anmfSetupRegularResponse.getOverpaymentArrangementResponse().getOutputStruc().getEStruc().getECode();

        return anmfErrorCode.length() != 0;
    }

    private AnmfRegularOverpaymentCUDResponse setUpRegularOverpaymentInAnmf(final RegularOverpaymentContext context) throws ConnectionException {
        final AnmfRegularOverpaymentCUDRequest setUpRequest = regularOverpaymentMapper.generateSetUpEditCoreRequest(context);
        return anmfCoreClient.setupRegularPayment(setUpRequest, endpointConfiguration.getAnmfSetupEditCancelRegularOverpaymentUrl());
        //Check ANMF Error code
    }

    private void addLdapUidToContext(final RegularOverpaymentContext context) throws GeneralException {
        final String ldapUid = JwtUtilities.getLdapUidFromJWT(context.getJwtToken());

        context.setLdapUid(ldapUid);
    }

    private void addMccContractToContext(final RegularOverpaymentContext context) throws ConnectionException {
        final RetrieveMccResponse retrieveMccControllerResponse = bksConnectClient.getMccFromLdapUid(endpointConfiguration.getRetrieveMccUrl(), context.getLdapUid());
        final MccContract mccContract = getMccContractFromRetrieveMccController(retrieveMccControllerResponse);

        context.setMccContract(mccContract);
    }

    private MccContract getMccContractFromRetrieveMccController(final RetrieveMccResponse retrieveMccControllerResponse) {
        final MccContract mccContract = new MccContract();
        final PartenonContract partenonContract = new PartenonContract();
        final Centre centre = new Centre();
        centre.setCompany(retrieveMccControllerResponse.getDataResponse().getMccContract().getPartenonContract().getCentre().getCompany());
        centre.setCentreCode(retrieveMccControllerResponse.getDataResponse().getMccContract().getPartenonContract().getCentre().getCentreCode());
        partenonContract.setCentre(centre);
        partenonContract.setProductTypeCode(retrieveMccControllerResponse.getDataResponse().getMccContract().getPartenonContract().getProductTypeCode());
        partenonContract.setContractNumber(retrieveMccControllerResponse.getDataResponse().getMccContract().getPartenonContract().getContractNumber());
        mccContract.setPartenonContract(partenonContract);

        return mccContract;
    }

    private void addAnmfResponsesToContext(final RegularOverpaymentContext context) throws ConnectionException {
        final int accountNumber = context.getAccount();
        final AnmfRegion region = context.getAnmfRegion();

        context.setAnmfAccountResponse(
                anmfCoreClient.fetchMortgageAccountDetailsV5(accountNumber, endpointConfiguration.getAnmfAccountInfoUrl(), region)
        );
        context.setAnmfLoanPaymentPlanResponse(
                anmfCoreClient.fetchLoanPaymentPlan(accountNumber, endpointConfiguration.getAnmfLoanPaymentPlanUrl(), region)
        );
    }
}
