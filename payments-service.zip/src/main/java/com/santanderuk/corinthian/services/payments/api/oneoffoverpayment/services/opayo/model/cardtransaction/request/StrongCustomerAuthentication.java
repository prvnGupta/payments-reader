
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class StrongCustomerAuthentication extends ModelBase {
    private static final long serialVersionUID = 532357773090603168L;

    private String notificationURL;
    private String browserIP;
    private String browserAcceptHeader;
    private String browserJavascriptEnabled;
    private String browserLanguage;
    private String browserUserAgent;
    private String challengeWindowSize;
    private String transType;
}
