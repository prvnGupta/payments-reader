package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MortgageSingleOverpaymentInternalTransferResponse extends ModelBase {
    private boolean paymentDone;
    private String base64Pdf;
}
