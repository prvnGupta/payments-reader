package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class CreateUniqueNumber {
    private static final String DATE_FORMAT_YY_M_MDD_H_HMM = "yyMMddHHmm";
    private static final String UPR_PREFIX = "MORTGAGE";
    private static final String TIMEZONE = "Europe/London";
    private final String uniqueNumber;

    public CreateUniqueNumber() {
        Date curDate = new Date();
        SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT_YY_M_MDD_H_HMM);
        format.setTimeZone(TimeZone.getTimeZone(TIMEZONE));
        this.uniqueNumber = UPR_PREFIX + format.format(curDate);
    }

    public String getUniqueNumber() {
        return uniqueNumber;
    }
}
