package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.payments.api.BaseController;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferResponseWrapper;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.io.IOException;

import static org.springframework.http.HttpStatus.OK;

@RestController
@Slf4j
public class MortgageOverpaymentInternalTransferController extends BaseController {

    private final MortgageOverpaymentInternalTransferService mortgageOverpaymentInternalTransferService;

    @Autowired
    public MortgageOverpaymentInternalTransferController(MortgageOverpaymentInternalTransferService mortgageOverpaymentInternalTransferService) {
        this.mortgageOverpaymentInternalTransferService = mortgageOverpaymentInternalTransferService;
    }

    @PutMapping(
            value = "/{mortgageAccount}/internal-transfer-one-off-overpayment",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )

    @ApiOperation(
            value = "Backend aggregation layer to make a one off overpayments using internal transfer.",
            nickname = "oneOffOverpaymentInternalTransfer",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to make one-off overpayments using internal transfer. It will call simulation, update-payment-method, make the internal transfer, apply the payments in AMNF and generate and return a PDF"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")})

    public final ResponseEntity<MortgageSingleOverpaymentInternalTransferResponseWrapper> oneOffOverpaymentInternalTransfer(
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @PathVariable int mortgageAccount,
            @Valid @RequestBody MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest,
            HttpServletRequest httpServletRequest) throws GeneralException, FraudException, IOException, PaymentsFuncException {

        MortgageSingleOverpaymentInternalTransferResponse mortgageSingleOverpaymentInternalTransferResponse = mortgageOverpaymentInternalTransferService.makePayment(mortgageAccount, mortgageSingleOverpaymentInternalTransferRequest, jwtToken, extractIpAddress(httpServletRequest));

        return buildInternalTransferResponse(mortgageSingleOverpaymentInternalTransferResponse);
    }

    private ResponseEntity<MortgageSingleOverpaymentInternalTransferResponseWrapper> buildInternalTransferResponse(MortgageSingleOverpaymentInternalTransferResponse mortgageSingleOverpaymentInternalTransferResponse) {

        var response = new MortgageSingleOverpaymentInternalTransferResponseWrapper();
        response.setData(mortgageSingleOverpaymentInternalTransferResponse);
        response.setInfo(ServiceInfoCreator.ok());
        return new ResponseEntity<>(response, OK);
    }

    // added here because we wanted to change the exception only for one-off
    @ExceptionHandler({PaymentsFuncException.class})
    public ResponseEntity<InternalTransferResponseWrapper> handlePaymentFailedException(final PaymentsFuncException paymentsFuncException) {
        ServiceInfo info = new ServiceInfo();
        info.setCode(paymentsFuncException.getMessage());
        info.setMessage("Payment error");
        info.setStatus("ko");
        InternalTransferResponseWrapper responseWrapper = new InternalTransferResponseWrapper();
        responseWrapper.setInfo(info);

        return new ResponseEntity<>(responseWrapper, OK);
    }

    @ExceptionHandler({FraudException.class})
    public ResponseEntity<InternalTransferResponseWrapper> handleFraudFailedException() {
        ServiceInfo info = new ServiceInfo();
        info.setCode("PAYMENT_ERROR_FBA");
        info.setMessage("Payment error");
        info.setStatus("ko");

        InternalTransferResponseWrapper responseWrapper = new InternalTransferResponseWrapper();
        responseWrapper.setInfo(info);

        return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
    }

}










