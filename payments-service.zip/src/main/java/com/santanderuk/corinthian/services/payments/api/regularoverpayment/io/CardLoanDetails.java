package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class CardLoanDetails {

    private String loanSchema;
    private int loanApplicationSequenceNumber;
    private String optionChosen;
    private BigDecimal loanErcAmount;
    private BigDecimal loanOverpaymentAmount;
    private BigDecimal loanTotalPaymentAmount;
    private BigDecimal newMonthlyPayment;
    private String newMortgageTerm;
    private BigDecimal interestSaving;

}
