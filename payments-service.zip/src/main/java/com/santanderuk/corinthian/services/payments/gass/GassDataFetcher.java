package com.santanderuk.corinthian.services.payments.gass;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.AnmfLoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.ODirectDebitDetails;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.OutputStruc;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.RetrieveMccResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Borrower;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.BorrowerElement;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class GassDataFetcher {

    private final AnmfCoreClient anmfClient;
    private final HeartBeatClient heartBeatClient;
    private final BksConnectClient bksConnectClient;
    private final GassConfig gassConfig;
    private final EndpointConfiguration endpointConfiguration;

    @Autowired
    public GassDataFetcher(AnmfCoreClient anmfClient, HeartBeatClient heartBeatClient, BksConnectClient bksConnectClient, GassConfig gassConfig, EndpointConfiguration endpointConfiguration) {
        this.anmfClient = anmfClient;
        this.heartBeatClient = heartBeatClient;
        this.bksConnectClient = bksConnectClient;
        this.gassConfig = gassConfig;
        this.endpointConfiguration = endpointConfiguration;
    }

    public String fetchLdapUid(String jwtToken) {
        try {
            return JwtUtilities.getLdapUidFromJWT(jwtToken);
        } catch (Exception e) {
            return "";
        }
    }

    public String fetchCustomerNumber(String jwtToken) {
        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(jwtToken);
        return bdpCustomer.getCustomerType() + bdpCustomer.getCustomerNumber();
    }


    public String fetchMortgageAccountNumber(int accountNumber) {
        return gassConfig.getAnmfSortcode() + " " + StringUtils.leftPad(String.valueOf(accountNumber), 9, '0');
    }

    public String fetchOverpaymentCancellationEffectiveDate(int accountNumber) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        try {
            AnmfRegion region = heartBeatClient.fetchCurrentRegion();
            AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse = anmfClient.fetchLoanPaymentPlan(accountNumber, endpointConfiguration.getAnmfLoanPaymentPlanUrl(), region);

            OutputStruc anmfLoanPaymentPlanResponseOutputStruct = anmfLoanPaymentPlanResponse.getLoanPaymentPlanResponse().getOutputStruc();
            if (anmfLoanPaymentPlanResponseOutputStruct.getOBacsCycle().equalsIgnoreCase("y")) {
                LocalDate nextAvailableDate = LocalDate.parse(anmfLoanPaymentPlanResponseOutputStruct.getONextAvailPaymentDt(), formatter);
                LocalDate effectiveCancelledDate = nextAvailableDate.minusMonths(1).plusDays(1);
                return formatter.format(effectiveCancelledDate);

            }
        } catch (MaintenanceException | ConnectionException e) {
            log.error(e.getMessage());
        }

        return formatter.format(LocalDate.now());
    }

    public String fetchOriginAccount(int accountNumber) {
        try {
            AnmfRegion region = heartBeatClient.fetchCurrentRegion();
            AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse = anmfClient.fetchLoanPaymentPlan(accountNumber, endpointConfiguration.getAnmfLoanPaymentPlanUrl(), region);
            ODirectDebitDetails directDebitDetails = anmfLoanPaymentPlanResponse.getLoanPaymentPlanResponse().getOutputStruc().getODirectDebitDetails();
            String directDebitSortCode = directDebitDetails.getOBankSortCode();
            int directDebitAccount = directDebitDetails.getOBankAccount();

            return directDebitSortCode.replace("-", "") + " " + String.format("%08d", directDebitAccount);

        } catch (MaintenanceException | ConnectionException e) {
            log.error(e.getMessage());
        }

        return "";
    }

    public String fetchMccId(String ldapUid) {
        try {
            RetrieveMccResponse mccResponse = bksConnectClient.getMccFromLdapUid(endpointConfiguration.getRetrieveMccUrl(), ldapUid);
            return buildMccId(mccResponse);
        } catch (GeneralException e) {
            log.error("Failed to get MCC response due to :", e);
        }
        return "";
    }


    public String buildMccId(final RetrieveMccResponse retrieveMccControllerResponse) {
        PartenonContract partenonContract = retrieveMccControllerResponse.getDataResponse().getMccContract().getPartenonContract();
        try {
            return partenonContract.getCentre().getCompany() + " " + partenonContract.getCentre().getCentreCode() + " " + partenonContract.getProductTypeCode() + " " + partenonContract.getContractNumber();
        } catch (Exception e) {
            return "";
        }
    }

    public Borrower toFormattedDataBorrowerList(final List<OCustomer> anmfCustomerList) {
        Borrower borrowerWrapper = new Borrower();
        List<BorrowerElement> borrowerList = new ArrayList<>(anmfCustomerList.size());
        for (OCustomer currentCustomer : anmfCustomerList) {
            BorrowerElement borrowerElement = new BorrowerElement(
                    formatName(currentCustomer),
                    currentCustomer.getOBdpType(),
                    String.valueOf(currentCustomer.getOCustomerId())
            );
            borrowerList.add(borrowerElement);
        }
        borrowerWrapper.setBorrowerList(borrowerList);
        return borrowerWrapper;
    }

    public String formatName(final OCustomer currentCustomer) {

        String name = formatAttribute(currentCustomer.getOCustomerTitle()) +
                formatAttribute(currentCustomer.getOForename1()) +
                formatAttribute(currentCustomer.getOForename2()) +
                formatAttribute(currentCustomer.getOForename3()) +
                formatAttribute(currentCustomer.getOSurname());
        return name.trim();
    }

    private String formatAttribute(final String attribute) {
        if (attributeIsEmpty(attribute)) {
            return "";
        } else {
            return attribute + " ";
        }
    }

    private boolean attributeIsEmpty(final String attribute) {
        return attribute == null || attribute.trim().equalsIgnoreCase("");
    }

    public String fetchMccIdFromJwt(String jwtToken) {
        return fetchMccId(fetchLdapUid(jwtToken));
    }

    public String fetchFormattedAmount(BigDecimal amount) {
        return amount.multiply(new BigDecimal("100")).setScale(0, RoundingMode.HALF_UP).toString();
    }
}
