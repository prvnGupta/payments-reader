
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.confirmtransaction.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request.VendorData;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class ConfirmCardTransactionRequest extends ModelBase {
    private static final long serialVersionUID = -6553838434790826146L;

    private String inputCode;
    private String confirmType;
    private VendorData vendorData;
}
