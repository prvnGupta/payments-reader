package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.LacService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request.CardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.CardTransactionResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.confirmtransaction.request.ConfirmCardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cps.CPSCardPaymentRequest;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class OpayoPaymentService {

    private final OpayoPaymentClient opayoPaymentClient;
    private final OpayoPaymentMapper opayoPaymentMapper;
    private final OpayoConfig opayoConfig;
    private final LacService lacService;

    @Autowired
    public OpayoPaymentService(OpayoPaymentClient opayoPaymentClient, OpayoPaymentMapper opayoPaymentMapper, OpayoConfig opayoConfig, LacService lacService) {
        this.opayoPaymentClient = opayoPaymentClient;
        this.opayoPaymentMapper = opayoPaymentMapper;
        this.lacService = lacService;
        this.opayoConfig = opayoConfig;
    }

    public void confirmCardTransaction(CardMortgageSingleOverpaymentsContext context, String transactionId) throws OpayoException {
        log.info("confirmCardTransaction -> started");
        ConfirmCardTransactionRequest confirmCardTransactionRequest = opayoPaymentMapper.generateConfirmCardTransactionBaasApiRequest(context);
        CardTransactionResponse cardTransactionResponse = opayoPaymentClient.confirmCardTransaction(opayoConfig.getConfirmUrl().replace("{transactionId}", transactionId), confirmCardTransactionRequest);
        context.setCardTransactionResponse(cardTransactionResponse);
        log.info("confirmCardTransaction -> finished");
    }

    public void makeCardTransaction(CardMortgageSingleOverpaymentsContext context) throws OpayoException {
        log.info("makeCardTransaction -> started");
        CardTransactionRequest cardTransactionRequest = opayoPaymentMapper.generateCardTransactionBaasApiRequest(context);
        CardTransactionResponse cardTransactionResponse = opayoPaymentClient.makeCardTransaction(opayoConfig.getCardTransactionUrl(), cardTransactionRequest);
        context.setCardTransactionResponse(cardTransactionResponse);
        context.getCardTransactionDetails().setVendorCode(cardTransactionRequest.getVendorData().getVendorCode());
        log.info("makeCardTransaction -> finished");
    }

    public void updateCPS(CardMortgageSingleOverpaymentsContext context) {
        CPSCardPaymentRequest cPSCardPaymentRequest;
        try {
            log.info("updateCPS -> started");
            String mortgageSortCodeAccNo = getSortCodeAndAccountNumber(context.getMortgageAccount());
            PartenonAccountNumber partenonAccountNumber = this.lacService.getPartenonAccountNumber(mortgageSortCodeAccNo);
            context.setAnmfPartenonAccountNumber(partenonAccountNumber);
            cPSCardPaymentRequest = opayoPaymentMapper.generateCPSCardPaymentRequest(context, mortgageSortCodeAccNo);
            opayoPaymentClient.updateCPS(cPSCardPaymentRequest);
            log.info("updateCPS -> finished");
        } catch (Exception ex) {
            log.error("triggerEmailAlert -> Exception while sending data to CPS Api", ex);
        }
    }

    private String getSortCodeAndAccountNumber(Integer accountNumber) {
        String formattedAccNumber = StringUtils.leftPad(String.valueOf(accountNumber), 9, '0');
        return String.format("%s%s", this.opayoConfig.getAnmfSortcode(), formattedAccNumber);
    }

}
