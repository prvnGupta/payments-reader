package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CancelRegularRegularOverpaymentFormattedData extends RegularOverpaymentFormattedData {


    private String overpaymentCancellationEffectiveDate;
    private String overpaymentEffect;
    private String originAccount;
    private String destinationAccount;


}
