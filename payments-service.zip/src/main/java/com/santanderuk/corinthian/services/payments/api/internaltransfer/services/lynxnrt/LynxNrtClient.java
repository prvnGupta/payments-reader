package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt;

import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.io.lynxNRT.LynxNRTDataRequest;
import com.santanderuk.corinthian.hub.lynxnrtconnection.io.lynxNRT.LynxNRTDataResponse;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class LynxNrtClient {

    private final RestTemplate restTemplate;
    private final OverpaymentsConfig overpaymentsConfig;

    public LynxNrtClient(RestTemplate paymentRestTemplate, OverpaymentsConfig overpaymentsConfig) {
        this.restTemplate = paymentRestTemplate;
        this.overpaymentsConfig = overpaymentsConfig;
    }

    public void callLynxNRTClient(LynxNRTDataRequest lynxNRTDataRequest) throws LynxNRTException {

        HttpEntity<LynxNRTDataRequest> httpEntity = createLynxNRTHttpEntity(lynxNRTDataRequest);

        ResponseEntity<LynxNRTDataResponse> responseEntity;
        try {
            log.info("About to call LynxNRT Core Api");
            log.debug("LynxNrt Request: {}", lynxNRTDataRequest.toString().replaceAll("[\r\n]", ""));

            String lynxNRTUrl = overpaymentsConfig.getLynxNRTEndpoint();
            log.debug("Calling endpoint: {}", lynxNRTUrl.replaceAll("[\r\n]", ""));

            responseEntity = restTemplate.postForEntity(lynxNRTUrl, httpEntity, LynxNRTDataResponse.class);
            LynxNRTDataResponse response = responseEntity.getBody();

            log.debug("Data received from LynxNRT: {}", response);

        } catch (Exception ex) {
            log.warn("Exception while calling LynxNRT Core Api", ex);
            throw new LynxNRTException("Exception while calling LynxNRT Core Api", ex);
        }
    }

    private HttpEntity<LynxNRTDataRequest> createLynxNRTHttpEntity(LynxNRTDataRequest lynxNRTDataRequest) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-Client-Id", overpaymentsConfig.getClientId());
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(lynxNRTDataRequest, headers);
    }
}
