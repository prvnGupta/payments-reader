package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.DebitResponse;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MortgageSingleOverpaymentsContext {
    private AnmfRegion anmfRegion;
    private AnmfAccountServiceResponse anmfAccountServiceResponse;
    private CustomerDetailsResponse customerDetailsResponse;
    private InternalTransferAccountsDetails internalTransferAccountsDetails;
    private String accountFromAlias;
    private OCustomer loggedCustomer;
    private int mortgageAccount;
    private String ipAddress;
    private SimulationChosenValues simulationChosenValues;
    private String ldapUid;
    private OutputStruc updatedSimulationResponse;
    private int simIdV1;
    private int simIdV2;
    private DebitResponse debitResponse;
    private PartenonAccountNumber mccPartenonAccount;
    private String mccId;
}
