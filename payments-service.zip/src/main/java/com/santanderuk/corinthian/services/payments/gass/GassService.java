package com.santanderuk.corinthian.services.payments.gass;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.santanderuk.corinthian.gassaudit.model.GassMessage;
import com.santanderuk.corinthian.gassaudit.writer.GassMQFactory;
import com.santanderuk.corinthian.gassaudit.writer.GassMessageGenerator;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass.RegularOverpaymentFormattedDataGenerator;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted.CancelRegularRegularOverpaymentFormattedData;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted.CreateEditRegularOverpaymentRegularOverpaymentFormattedData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class GassService {
    private final GassMessageGenerator gassMessageGenerator;
    private final RegularOverpaymentFormattedDataGenerator regularOverpaymentFormattedDataGenerator;
    private final GassMQFactory gassMQFactory;
    private final GassDataFetcher gassDataFetcher;
    @Value("${gass.regular-overpayment.trngrpid}")
    private String regularOverpaymentTrxGroup;

    @Autowired
    public GassService(GassMessageGenerator gassMessageGenerator, RegularOverpaymentFormattedDataGenerator regularOverpaymentFormattedDataGenerator, GassMQFactory gassMQFactory, GassDataFetcher gassDataFetcher) {
        this.gassMessageGenerator = gassMessageGenerator;
        this.regularOverpaymentFormattedDataGenerator = regularOverpaymentFormattedDataGenerator;
        this.gassMQFactory = gassMQFactory;
        this.gassDataFetcher = gassDataFetcher;
    }

    public void auditCancelRegularOverpayment(int account, String jwtToken, String ipAddress, String status, String impact, CustomerDetailsResponse customerDetailsResponse, RegularOverpaymentContext context) {
        CancelRegularRegularOverpaymentFormattedData formattedData = regularOverpaymentFormattedDataGenerator.createCancelFormattedData(account, jwtToken, impact, customerDetailsResponse, context);
        String customerNumber = gassDataFetcher.fetchCustomerNumber(jwtToken);
        String ldapUid = gassDataFetcher.fetchLdapUid(jwtToken);
        String amount = gassDataFetcher.fetchFormattedAmount(context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay());
        GassMessage gassMessage = gassMessageGenerator.createGassMessage(account, customerNumber, ldapUid, status, ipAddress, regularOverpaymentTrxGroup, "Cancel regular overpayment", amount);
        gassMessage = gassMessageGenerator.addFormattedDataPayload(gassMessage, formattedData);
        gassMQFactory.publishToQueue(gassMessage);
        log.info("auditCancelRegularOverpayment send to queue");
        log.debug(gassMessageToString(gassMessage));
    }

    public void auditEditRegularOverpayment(int account, String jwtToken, String ipAddress, SetUpRegularOverpaymentServiceInput controllerRequest, String status, CustomerDetailsResponse customerDetailsResponse, RegularOverpaymentContext context) {
        CreateEditRegularOverpaymentRegularOverpaymentFormattedData formattedData = regularOverpaymentFormattedDataGenerator.createEditRegularOverpaymentFormattedData(account, jwtToken, controllerRequest, customerDetailsResponse, context);
        String customerNumber = gassDataFetcher.fetchCustomerNumber(jwtToken);
        String ldapUid = gassDataFetcher.fetchLdapUid(jwtToken);
        String amount = gassDataFetcher.fetchFormattedAmount(controllerRequest.getOverpaymentAmount()
                .add(context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay()));
        GassMessage gassMessage = gassMessageGenerator.createGassMessage(account, customerNumber, ldapUid, status, ipAddress, regularOverpaymentTrxGroup, "Amend regular overpayment", amount);
        gassMessage = gassMessageGenerator.addFormattedDataPayload(gassMessage, formattedData);
        gassMQFactory.publishToQueue(gassMessage);
        log.info("auditEditRegularOverpayment send to queue");
        log.debug(gassMessageToString(gassMessage));
    }


    private String gassMessageToString(GassMessage gassMessage) {
        XmlMapper xmlMapper = new XmlMapper();
        try {
            return xmlMapper.writeValueAsString(gassMessage);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return "Error parsing message";
        }
    }
}
