package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RegularOverpaymentData extends ModelBase {
    private static final long serialVersionUID = 1669380501073765564L;
    private boolean paymentDone;
}
