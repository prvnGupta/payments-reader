package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataRequest;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils.PaymentReferenceGenerator;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
@Slf4j
public class LynxFraudCheckMapper {

    public static final String EXCEPTION_WHILE_GENERATING_FRAUD_CHECK_REQUEST = "Exception while generating Fraud Check request";
    public static final String DD_MM_YYYY_HH_MM_SS_SSSSSS = "dd-MM-yyyy HH:mm:ss.SSSSSS";
    private final InternalAccountFormatConverter internalAccountFormatConverter;
    private final OverpaymentsConfig config;
    private final PaymentReferenceGenerator paymentReferenceGenerator;
    private final Clock clock;

    public LynxFraudCheckMapper(InternalAccountFormatConverter internalAccountFormatConverter, OverpaymentsConfig config, PaymentReferenceGenerator paymentReferenceGenerator, Clock clock) {
        this.internalAccountFormatConverter = internalAccountFormatConverter;
        this.config = config;
        this.paymentReferenceGenerator = paymentReferenceGenerator;
        this.clock = clock;
    }

    public LynxDataRequest decorateRequestData(InternalTransferRequest internalTransferRequest, InternalTransferAccountsDetails accountsDetails, SetupResponse setupResponse, String ldapUid) throws FraudException {

        try {
            LynxDataRequest lynxDataRequest = new LynxDataRequest();

            lynxDataRequest.setDebitEmpresa(accountsDetails.getAccountFrom().getPartenonAccountNumber().getCompany());
            lynxDataRequest.setDebitCentre(accountsDetails.getAccountFrom().getPartenonAccountNumber().getCentre());
            lynxDataRequest.setDebitProduct(accountsDetails.getAccountFrom().getPartenonAccountNumber().getProduct());
            lynxDataRequest.setDebitContractNo(accountsDetails.getAccountFrom().getPartenonAccountNumber().getContract());
            lynxDataRequest.setDebitType(config.getLynxFraudDebitType());
            lynxDataRequest.setDebitDetalle(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(accountsDetails.getAccountFrom().getLocalAccountNumber()));

            lynxDataRequest.setCreditEmpresa(accountsDetails.getAccountTo().getPartenonAccountNumber().getCompany());
            lynxDataRequest.setCreditCentre(accountsDetails.getAccountTo().getPartenonAccountNumber().getCentre());
            lynxDataRequest.setCreditProduct(accountsDetails.getAccountTo().getPartenonAccountNumber().getProduct());
            lynxDataRequest.setCreditContractNo(accountsDetails.getAccountTo().getPartenonAccountNumber().getContract());
            lynxDataRequest.setCreditType(config.getLynxFraudCreditType());
            lynxDataRequest.setCreditDetail(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(accountsDetails.getAccountTo().getLocalAccountNumber()));

            lynxDataRequest.setBeneficiaryName(decorateName(internalTransferRequest.getCustomerFirstName(), internalTransferRequest.getCustomerLastName()));
            lynxDataRequest.setStaffUserID(ldapUid);
            lynxDataRequest.setCurrency(config.getLynxFraudCurrency());
            lynxDataRequest.setOverpaymentAmount(internalTransferRequest.getPaymentAmount().doubleValue());
            lynxDataRequest.setTransTimestamp(formatDataTimeCorrectly());
            lynxDataRequest.setCustomerNumber(Integer.toString(internalTransferRequest.getBdpCustomer().getCustomerNumber()));
            lynxDataRequest.setCustomerType(internalTransferRequest.getBdpCustomer().getCustomerType());
            lynxDataRequest.setMandateNumber(setupResponse.getNumsOr());
            lynxDataRequest.setChannelType(config.getLynxFraudChannelType());
            lynxDataRequest.setProcessFlag(config.getLynxFraudProcessFlag());
            lynxDataRequest.setFlagCreditDebit(config.getLynxFraudFlagCreditDebit());
            lynxDataRequest.setTransCode(config.getLynxFraudApplicationCodeFee());
            lynxDataRequest.setTransType(config.getLynxFraudMessageType());
            lynxDataRequest.setReference(internalTransferRequest.getPaymentReference());

            return lynxDataRequest;
        } catch (Exception e) {
            log.warn(EXCEPTION_WHILE_GENERATING_FRAUD_CHECK_REQUEST);
            throw new FraudException(EXCEPTION_WHILE_GENERATING_FRAUD_CHECK_REQUEST);
        }
    }

    public LynxDataRequest decorateRequestData(MortgageSingleOverpaymentsContext context, SetupResponse setupResponse) throws FraudException {

        try {
            LynxDataRequest lynxDataRequest = new LynxDataRequest();

            lynxDataRequest.setDebitEmpresa(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCompany());
            lynxDataRequest.setDebitCentre(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCentre());
            lynxDataRequest.setDebitProduct(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getProduct());
            lynxDataRequest.setDebitContractNo(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getContract());
            lynxDataRequest.setDebitType(config.getLynxFraudDebitType());
            lynxDataRequest.setDebitDetalle(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(context.getInternalTransferAccountsDetails().getAccountFrom().getLocalAccountNumber()));

            lynxDataRequest.setCreditEmpresa(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCompany());
            lynxDataRequest.setCreditCentre(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCentre());
            lynxDataRequest.setCreditProduct(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getProduct());
            lynxDataRequest.setCreditContractNo(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getContract());
            lynxDataRequest.setCreditType(config.getLynxFraudCreditType());
            lynxDataRequest.setCreditDetail(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(context.getInternalTransferAccountsDetails().getAccountTo().getLocalAccountNumber()));

            lynxDataRequest.setBeneficiaryName(decorateName(context.getLoggedCustomer().getOForename1(), context.getLoggedCustomer().getOSurname()));
            lynxDataRequest.setStaffUserID(context.getLdapUid());
            lynxDataRequest.setCurrency(config.getLynxFraudCurrency());
            lynxDataRequest.setOverpaymentAmount(context.getUpdatedSimulationResponse().getOTotPayment().doubleValue());
            lynxDataRequest.setTransTimestamp(formatDataTimeCorrectly());
            lynxDataRequest.setCustomerNumber(Integer.toString(context.getLoggedCustomer().getOCustomerId()));
            lynxDataRequest.setCustomerType(context.getLoggedCustomer().getOBdpType());
            lynxDataRequest.setMandateNumber(setupResponse.getNumsOr());
            lynxDataRequest.setChannelType(config.getLynxFraudChannelType());
            lynxDataRequest.setProcessFlag(config.getLynxFraudProcessFlag());
            lynxDataRequest.setFlagCreditDebit(config.getLynxFraudFlagCreditDebit());
            lynxDataRequest.setTransCode(config.getLynxFraudApplicationCodeOverpayment());
            lynxDataRequest.setTransType(config.getLynxFraudMessageType());
            lynxDataRequest.setReference(paymentReferenceGenerator.generateSingleOverpaymentInternalTransferReference(context.getMortgageAccount(), context.getLoggedCustomer().getOSurname()));

            return lynxDataRequest;
        } catch (Exception e) {
            log.warn(EXCEPTION_WHILE_GENERATING_FRAUD_CHECK_REQUEST);
            throw new FraudException(EXCEPTION_WHILE_GENERATING_FRAUD_CHECK_REQUEST);
        }
    }


    private String formatDataTimeCorrectly() {
        return LocalDateTime.now(clock).format(DateTimeFormatter.ofPattern(DD_MM_YYYY_HH_MM_SS_SSSSSS));
    }

    private String decorateName(String customerFirstName, String customerLastName) {
        return customerFirstName + " " + customerLastName;
    }
}
