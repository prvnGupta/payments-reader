package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations;


import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.OperativeSecurityException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
@Slf4j
public class OneOffCommonValidations {
    private final OverpaymentsConfig overpaymentsConfig;
    private final EndpointConfiguration endpointConfiguration;
    private final AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;


    @Autowired
    public OneOffCommonValidations(OverpaymentsConfig overpaymentsConfig, EndpointConfiguration endpointConfiguration, AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService) {
        this.overpaymentsConfig = overpaymentsConfig;
        this.endpointConfiguration = endpointConfiguration;
        this.anmfBelongToCustomerWithBorrowerListService = anmfBelongToCustomerWithBorrowerListService;
    }

    public void validateMinimumOverpaymentAmount(List<LoanDetails> inputLoanDetailsList) throws ValidationsException {
        log.info("Validations: validate overpayment amount greater then minimum");
        if (overpaymentsConfig.getMinimumOverpaymentAmount().compareTo(getTotalOverpaymentAmount(inputLoanDetailsList)) > 0) {
            throw new ValidationsException("EXC_MIN_OVP_AMOUNT", "Chosen overpayment amount below permitted minimum amount.");
        }
    }

    public CustomerDetailsResponse validateMortgageBelongToCustomer(int mortgageAccount, String jwtToken, AnmfRegion anmfRegion) throws OperativeSecurityException, ValidationsException, ConnectionException {
        log.info("Validations: validate mortgage account belong to customer");
        return checkOperativeSecurityWithCustomerList(mortgageAccount, jwtToken, anmfRegion);
    }

    public void validateMaximumAmountAllowed(BigDecimal paymentAmount, AnmfAccountServiceResponse anmfAccountServiceResponse) throws ValidationsException {
        log.info("Validations: validate maximum amount allowed to overpay");
        BigDecimal calculatedMaxPayment = anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOContMonPay().
                multiply(BigDecimal.valueOf(3));
        BigDecimal maxAmountAllowed = anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOCapitalBalance().subtract(calculatedMaxPayment);
        if (paymentAmount.compareTo(maxAmountAllowed) > 0) {
            throw new ValidationsException("EXC_MAX_AMOUNT_LIMIT", "The overpayment amount exceeds the maximum amount allowed.");
        }
    }

    public void validateNumberOfSingleOverpaymentsDoneToday(AnmfAccountServiceResponse anmfAccountServiceResponse) throws ValidationsException {
        log.info("Validations: validate maximum number of overpayments not reached");
        if (overpaymentsConfig.getMaximumNumberOfOverpayments() <= anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOOverpayNum()) {
            throw new ValidationsException("EXC_MAX_NUM_OVP_REACHED", "Maximum number of overpayments done.");
        }
    }

    public void validateInputLoans(List<LoanDetails> inputLoanDetailsList, AnmfAccountServiceResponse anmfAccountServiceResponse) throws ValidationsException {
        for (LoanDetails inputLoanDetails : inputLoanDetailsList) {
            checkInputLoanExistsInAnmf(inputLoanDetails, anmfAccountServiceResponse);
        }
        for (OActiveLoanDetail anmfLoan : anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails()) {
            checkLoanExistsInInput(anmfLoan, inputLoanDetailsList);
        }
    }

    private void checkLoanExistsInInput(OActiveLoanDetail anmfLoan, List<LoanDetails> inputLoanDetailsList) throws ValidationsException {
        boolean loanFound = false;
        for (LoanDetails inputLoanDetails : inputLoanDetailsList) {
            if (isSameLoan(anmfLoan, inputLoanDetails)) {
                loanFound = true;
            }
        }
        if (!loanFound) {
            throw new ValidationsException("EXC_INVALID_LOAN_INPUT", "invalid loan input");
        }
    }

    private void checkInputLoanExistsInAnmf(LoanDetails inputLoanDetails, AnmfAccountServiceResponse anmfAccountServiceResponse) throws ValidationsException {
        boolean loanFound = false;
        for (OActiveLoanDetail anmfLoan : anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails()) {
            if (isSameLoan(anmfLoan, inputLoanDetails)) {
                loanFound = true;
            }
        }
        if (!loanFound) {
            throw new ValidationsException("EXC_INVALID_LOAN_INPUT", "invalid loan input");
        }
    }

    private boolean isSameLoan(OActiveLoanDetail anmfLoan, LoanDetails inputLoanDetails) {
        return anmfLoan.getOLoanScheme().equalsIgnoreCase(inputLoanDetails.getLoanScheme()) && anmfLoan.getOApplSeqNo() == inputLoanDetails.getAppSeqNumber();
    }

    private BigDecimal getTotalOverpaymentAmount(List<LoanDetails> inputLoanDetailsList) {
        return inputLoanDetailsList.stream().map(LoanDetails::getLoanOverpaymentAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private CustomerDetailsResponse checkOperativeSecurityWithCustomerList(int mortgageAccount, String jwt, AnmfRegion activeRegion) throws OperativeSecurityException, ValidationsException, ConnectionException {
        AnmfBelongsToCustomerWithBorrowerList response = anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(mortgageAccount, jwt, endpointConfiguration.getAnmfCustomerServiceUrl(), activeRegion);
        if (overpaymentsConfig.isOperativeSecurity()) {
            if (!response.getAnmfBelongsToCustomer()) {
                log.error("Security KO. Mortgage account does not belong to customer");
                throw new OperativeSecurityException("SECURITY_KO", "Mortgage account does not belong to customer");
            }
        }
        return response.getCustomerDetailsResponse();
    }

}
