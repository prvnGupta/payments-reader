package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request.CardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.CardTransactionResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.confirmtransaction.request.ConfirmCardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cps.CPSCardPaymentRequest;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class OpayoPaymentClient {

    public static final String OPAYO_CLIENT_EXC = "OPAYO_CLIENT_EXC";
    private final OpayoConfig opayoConfig;
    private final OverpaymentsConfig overpaymentsConfig;
    private final RestTemplate restTemplate;

    @Autowired
    public OpayoPaymentClient(OpayoConfig opayoConfig, OverpaymentsConfig overpaymentsConfig, RestTemplate paymentRestTemplate) {
        this.opayoConfig = opayoConfig;
        this.overpaymentsConfig = overpaymentsConfig;
        this.restTemplate = paymentRestTemplate;
    }

    public CardTransactionResponse makeCardTransaction(String serviceUrl, CardTransactionRequest cardTransactionRequest) throws OpayoException {
        try {
            log.info("OpayoPaymentClient -> makeCardTransaction: About to call cardTransaction Baas Api");
            log.debug("OpayoPaymentClient -> makeCardTransaction: request {}", cardTransactionRequest);
            ResponseEntity<CardTransactionResponse> cardTransactionResponseResponseEntity = restTemplate.postForEntity(serviceUrl, new HttpEntity<>(cardTransactionRequest, generateHeaders()), CardTransactionResponse.class);
            log.info("OpayoPaymentClient -> makeCardTransaction: got response from cardTransaction Baas Api");
            return cardTransactionResponseResponseEntity.getBody();
        } catch (Exception ex) {
            log.warn("Exception while calling card-transaction baas api", ex);
            throw new OpayoException(OPAYO_CLIENT_EXC, "Exception while calling card-transaction baas api", ex);
        }
    }

    public CardTransactionResponse confirmCardTransaction(String serviceUrl, ConfirmCardTransactionRequest confirmCardTransactionRequest) throws OpayoException {
        try {
            log.info("OpayoPaymentClient -> confirmCardTransaction: About to call cardTransaction Baas Api");
            log.debug("OpayoPaymentClient -> confirmCardTransaction: request {}", confirmCardTransactionRequest);
            ResponseEntity<CardTransactionResponse> cardTransactionResponseResponseEntity = restTemplate.postForEntity(serviceUrl, new HttpEntity<>(confirmCardTransactionRequest, generateHeaders()), CardTransactionResponse.class);
            log.info("OpayoPaymentClient -> confirmCardTransaction: got response from cardTransaction Baas Api");
            return cardTransactionResponseResponseEntity.getBody();
        } catch (Exception ex) {
            log.warn("Exception while calling confirm-transaction baas api", ex);
            throw new OpayoException(OPAYO_CLIENT_EXC, "Exception while calling confirm-transaction baas api", ex);
        }
    }

    public void updateCPS(CPSCardPaymentRequest cPSCardPaymentRequest) throws OpayoException {
        try {
            log.info("OpayoPaymentClient -> updateCPS: About to call cps endpoint Core Api");
            log.debug("OpayoPaymentClient -> updateCPS. Request: {}", cPSCardPaymentRequest);

            String updateCPSUrl = opayoConfig.getUpdateCpsUrl();
            log.debug("Calling endpoint: {}", updateCPSUrl);

            restTemplate.postForEntity(updateCPSUrl, createUpdateCPSHttpEntity(cPSCardPaymentRequest), Void.class);
        } catch (Exception ex) {
            log.error("Exception while sending data to CPS Api endpoint ", ex);
            throw new OpayoException(OPAYO_CLIENT_EXC, "Exception while calling Update CPS baas api", ex);
        }
    }

    private HttpEntity<CPSCardPaymentRequest> createUpdateCPSHttpEntity(CPSCardPaymentRequest cpsRequest) {
        return new HttpEntity<>(cpsRequest, generateHeaders());
    }

    private MultiValueMap<String, String> generateHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-Client-Id", overpaymentsConfig.getClientId());
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }

}
