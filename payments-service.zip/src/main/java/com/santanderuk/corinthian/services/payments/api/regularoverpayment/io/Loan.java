package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Loan extends ModelBase {

    private static final long serialVersionUID = 2076778372374613831L;

    @NotNull
    @Pattern(regexp = "[a-zA-Z0-9]{2}")
    private String loanSchema;

    @NotNull
    @Pattern(regexp = "[0-9]{1,2}")
    private String appSequenceNumber;

    @NotNull
    @Pattern(regexp = "[R|I]")
    private String loanType;

    @Min(1)
    private int orderId;

}
