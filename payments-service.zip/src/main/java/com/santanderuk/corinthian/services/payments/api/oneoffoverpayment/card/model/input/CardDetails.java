package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CardDetails extends ModelBase {
    private static final long serialVersionUID = 5515588816130582390L;

    @NotBlank
    private String customerId;
    @NotBlank
    @Pattern(regexp = "^[0-9]{10,16}$")
    private String cardNumber;
    @NotBlank
    @Pattern(regexp = "^(0[1-9]|1[0-2])/?([0-9]{2})$")
    private String expiryDate;
    @NotBlank
    @Pattern(regexp = "^[0-9]{3,4}$")
    private String cvv;
    @Valid
    private Address address;
}
