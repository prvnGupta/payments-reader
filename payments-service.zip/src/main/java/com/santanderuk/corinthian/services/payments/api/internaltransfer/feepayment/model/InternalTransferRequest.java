package com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.math.BigDecimal;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InternalTransferRequest extends ModelBase {

    @NotBlank
    @Size(min = 1, max = 50)
    private String customerFirstName;

    @NotNull
    @Size(min = 1, max = 50)
    private String customerLastName;

    @Valid
    private BdpCustomer bdpCustomer;

    @Valid
    private LocalAccountNumber originAccount;

    @Valid
    private LocalAccountNumber destinationAccount;

    @NotNull
    private BigDecimal paymentAmount;

    @NotNull
    @Size(min = 1, max = 50)
    private String paymentReference;
}
