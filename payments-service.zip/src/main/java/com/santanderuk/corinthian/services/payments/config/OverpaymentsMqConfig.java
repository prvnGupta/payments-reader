package com.santanderuk.corinthian.services.payments.config;

import com.santanderuk.corinthian.hub.paymentsmqwriter.implementation.PaymentsMqWriterServiceImplementation;
import com.santanderuk.corinthian.hub.paymentsmqwriter.interfaces.PaymentMqWriterServiceInterface;
import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
@Setter
public class OverpaymentsMqConfig {

    @Value("${paymentsrabbitmq.host}")
    private String paymentsMqHost;

    @Value("${paymentsrabbitmq.virtualhost}")
    private String paymentsMqVirtualHost;

    @Value("${paymentsrabbitmq.paymentsqueue}")
    private String paymentsMqQueue;

    @Value("${paymentsrabbitmq.username}")
    private String paymentsMqUsername;

    @Value("${paymentsrabbitmq.password}")
    private String paymentsMqPassword;

    @Value("${paymentsrabbitmq.port}")
    private int paymentsMqPort;

    @Value("${simulation.user-id}")
    private String applyPaymentEmergeUser;

    @Bean
    PaymentMqWriterServiceInterface paymentMqWriterServiceInterface() {
        return new PaymentsMqWriterServiceImplementation();
    }

}
