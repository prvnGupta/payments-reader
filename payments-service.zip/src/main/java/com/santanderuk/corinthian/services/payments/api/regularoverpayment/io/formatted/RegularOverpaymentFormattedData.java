package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted;

import com.santanderuk.corinthian.gassaudit.model.FormattedData;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Borrower;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public abstract class RegularOverpaymentFormattedData implements FormattedData {

    private String customerNumber = "";
    private Borrower borrowerList = new Borrower();
    private String multiChannelContractId = "";
    private String mortgageAccountNumber = "";
    private String contractualMonthlyPaymentAmount = "";
    private String overpaymentAmount = "";
    private String directDebitTotalAmount = "";
}
