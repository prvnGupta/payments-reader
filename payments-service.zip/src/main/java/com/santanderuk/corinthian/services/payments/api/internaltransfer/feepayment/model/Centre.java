package com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
public class Centre extends ModelBase {

    @NotBlank
    private String company;

    @NotBlank
    private String centreCode;
}
