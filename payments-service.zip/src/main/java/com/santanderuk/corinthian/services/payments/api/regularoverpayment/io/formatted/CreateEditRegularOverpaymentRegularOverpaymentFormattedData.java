package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CreateEditRegularOverpaymentRegularOverpaymentFormattedData extends RegularOverpaymentFormattedData {

    private String directDebitTotalAmount;
    private String startDate;
    private String endDate;
    private String numberOfPayments;
    private String overpaymentEffect;
    private String originAccount;
    private String destinationAccount;
    private List<FormattedLoan> formattedLoans;
}
