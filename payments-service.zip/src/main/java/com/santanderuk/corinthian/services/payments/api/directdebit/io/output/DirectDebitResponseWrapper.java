package com.santanderuk.corinthian.services.payments.api.directdebit.io.output;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DirectDebitResponseWrapper extends ModelBase {

    private DirectDebitResponse data;
    private ServiceInfo info;

}
