package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational;

import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalServiceResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CardOperationalService {

    private final CardOperationalClient cardOperationalClient;

    @Autowired
    public CardOperationalService(CardOperationalClient cardOperationalClient) {
        this.cardOperationalClient = cardOperationalClient;
    }

    public CardOperationalServiceResponse checkIfSantanderCard(CardOneOffPaymentRequest cardOneOffPaymentRequest) {
        try {
            log.info("checkIfSantanderCard started");
            CardOperationalServiceResponse cardOperationalServiceResponse = new CardOperationalServiceResponse();
            CardOperationalResponse cardOperationalResponse = cardOperationalClient.callCardOperational(cardOneOffPaymentRequest.getCardDetails().getCardNumber());
            cardOperationalServiceResponse.setSantanderCard(true);
            cardOperationalServiceResponse.setOnwSantanderCard(checkIfUsingOwnCard(cardOperationalResponse, cardOneOffPaymentRequest.getCardDetails().getCustomerId()));
            log.info("checkIfSantanderCard finished");
            return cardOperationalServiceResponse;
        } catch (CardOperationalException e) {
            return new CardOperationalServiceResponse(false, false);
        }
    }

    private boolean checkIfUsingOwnCard(CardOperationalResponse cardOperationalResponse, String customerId) {
        return cardOperationalResponse.getOperationalityDetails().getFnumber().equalsIgnoreCase(customerId);
    }
}
