package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class ClearPaymentCache {
    private final CacheManager cacheManagerLongLife;

    @Autowired
    public ClearPaymentCache(CacheManager cacheManagerLongLife) {
        this.cacheManagerLongLife = cacheManagerLongLife;
    }

    public void deleteCardTransactionCache(String transactionId) {
        try {
            log.info("deleting cache for card-transaction-{} after confirmation done.", transactionId.replaceAll("[\r\n]", ""));
            Cache cacheGetRegularOverpayment = cacheManagerLongLife.getCache("card-transaction");
            cacheGetRegularOverpayment.evict("card-transaction-" + transactionId);
        } catch (Exception e) {
            log.warn("Exception while clearing cache for transactionId: {}", transactionId.replaceAll("[\r\n]", ""));
        }
    }
}
