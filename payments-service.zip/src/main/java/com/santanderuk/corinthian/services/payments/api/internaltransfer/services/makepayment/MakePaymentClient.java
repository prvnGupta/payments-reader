package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;


import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import java.util.Objects;

@Component
@Slf4j
public class MakePaymentClient {

    private final RestTemplate restTemplate;
    private final OverpaymentsConfig overpaymentsConfig;

    public MakePaymentClient(RestTemplate paymentRestTemplate, OverpaymentsConfig overpaymentsConfig) {
        this.restTemplate = paymentRestTemplate;
        this.overpaymentsConfig = overpaymentsConfig;
    }

    public DebitResponse callDebitPayment(DebitRequest debitRequest) throws PaymentsFuncException {

        HttpEntity<DebitRequest> httpEntity = createHttpEntity(debitRequest);

        ResponseEntity<DebitResponse> responseEntity;
        try {
            log.info("About to call make-payment Core Api");
            log.debug("Make-payment Request: {}", debitRequest);

            String makePaymentUrl = overpaymentsConfig.getMakePaymentEndpoint();
            log.debug("Calling endpoint: {}", makePaymentUrl);

            responseEntity = restTemplate.postForEntity(makePaymentUrl, httpEntity, DebitResponse.class);
            log.info("Make Payment -> Make Payment response received");

        } catch (Exception ex) {
            log.error("Exception while calling make-payment Core Api", ex);
            throw new PaymentsFuncException("Exception while calling Debit payment", ex);
        }

        checkControlledExceptionsForDebitPartenon(Objects.requireNonNull(responseEntity.getBody()));

        return responseEntity.getBody();
    }

    private void checkControlledExceptionsForDebitPartenon(DebitResponse response) throws PaymentsFuncException {
        if (response.getStatus().equalsIgnoreCase("FUNCERR") || response.getStatus().equalsIgnoreCase("PAYERR")) {
            log.debug("An unknown error received from Partenon Payments...{}", response);
            throw new PaymentsFuncException("PAYMENT_ERROR");
        }
        if (response.getStatus().equalsIgnoreCase("NFAERR")) {
            log.debug("Error has occurred because of no funds available {}", response);
            throw new PaymentsFuncException("PAYMENT_ERROR_UCF");
        }
        if (response.getStatus().equalsIgnoreCase("ACCOUNTBLOCKED")) {
            log.debug("Error has occurred because internal account is blocked {}", response);
            throw new PaymentsFuncException("PAYMENT_ERROR_PBA");
        }
    }

    private HttpEntity<DebitRequest> createHttpEntity(DebitRequest debitRequest) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.add("X-IBM-Client-Id", overpaymentsConfig.getClientId());
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(debitRequest, headers);
    }
}
