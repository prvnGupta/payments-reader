package com.santanderuk.corinthian.services.payments.api.regularoverpayment;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.AnmfLoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.commons.time.AvailableDates;
import com.santanderuk.corinthian.services.commons.time.AvailableDatesCalculator;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.validation.ValidationRule;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

import static com.santanderuk.corinthian.services.commons.exceptions.ValidationsException.Type.*;

@Component
public class RegularOverpaymentFunctionalValidation {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private final List<ValidationRule> validationRules;

    public RegularOverpaymentFunctionalValidation(List<ValidationRule> validationRules) {
        this.validationRules = validationRules;
    }

    public void validate(final RegularOverpaymentContext context) throws ValidationsException {
        checkOverpaymentAmount(context);
        checkDatesSelected(context);
        checkLoanPartsInRequestIsAnExistingLoanPartFromTheCustomer(context);
    }

    private void checkDatesSelected(RegularOverpaymentContext context) throws ValidationsException {
        AvailableDates availableDates = createAvailableDates(context.getAnmfLoanPaymentPlanResponse(), context.getAnmfAccountResponse());

        checkStartingDateIsInOneOfTheAvailableDates(context.getControllerRequest(), availableDates);
        checkEndDateIsBeforeAvailableFinalDate(context.getControllerRequest(), availableDates);
    }

    private void checkOverpaymentAmount(RegularOverpaymentContext context) throws ValidationsException {
        checkOverpaymentAmountIsMoreThanThehighestOfNextThreePayments(context);
        RunMaxRegularAmountRule(context);
    }

    private void RunMaxRegularAmountRule(RegularOverpaymentContext context) throws ValidationsException {
        for (ValidationRule validationRule : validationRules) {
            validationRule.validate(context);
        }
    }

    private void checkLoanPartsInRequestIsAnExistingLoanPartFromTheCustomer(final RegularOverpaymentContext context) throws ValidationsException {
        List<OActiveLoanDetail> oActiveLoanDetails = context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails();
        for (Loan loan : context.getControllerRequest().getLoans()) {
            if (!loanBelongsToAccount(oActiveLoanDetails, loan)) {
                throw new ValidationsException(EXC_FUNCTIONAL_VALIDATION_NOT_VALID_LOAN);
            }
        }
    }

    private boolean loanBelongsToAccount(List<OActiveLoanDetail> anmfLoans, Loan loan) {
        final long coincidences = anmfLoans.stream().filter(anmfLoan -> areTheSameLoan(anmfLoan, loan)).count();
        return coincidences > 0;
    }

    private boolean areTheSameLoan(final OActiveLoanDetail anmfLoan, final Loan loanFromInput) {
        final boolean loanSchemeIsTheSame = anmfLoan.getOLoanScheme().equalsIgnoreCase(loanFromInput.getLoanSchema());
        final boolean loanSequenceNumberIsTheSame = String.valueOf(anmfLoan.getOApplSeqNo()).equalsIgnoreCase(loanFromInput.getAppSequenceNumber());

        return loanSchemeIsTheSame && loanSequenceNumberIsTheSame;
    }

    private AvailableDates createAvailableDates(final AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse, final AnmfAccountServiceResponse anmfAccountServiceResponse) {
        final AvailableDatesCalculator availableDatesCalculator = new AvailableDatesCalculator();
        final String nextAvailablePaymentDate = anmfLoanPaymentPlanResponse.getLoanPaymentPlanResponse().getOutputStruc().getONextAvailPaymentDt();
        final String redemptionDate = getRedemptionForLoanThatEndsLast(anmfAccountServiceResponse);

        return availableDatesCalculator.createAvailableDates(nextAvailablePaymentDate, redemptionDate, convertBacsCycleToBoolean(anmfLoanPaymentPlanResponse));
    }

    private String getRedemptionForLoanThatEndsLast(AnmfAccountServiceResponse anmfAccountServiceResponse) {
        return anmfAccountServiceResponse.getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().stream()
                .map(OActiveLoanDetail -> LocalDate.parse(OActiveLoanDetail.getORedemptionDate(), FORMATTER))
                .max(LocalDate::compareTo)
                .orElseThrow().format(FORMATTER);
    }

    private boolean convertBacsCycleToBoolean(final AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse) {
        return "Y".equalsIgnoreCase(anmfLoanPaymentPlanResponse.getLoanPaymentPlanResponse().getOutputStruc().getOBacsCycle());
    }

    private void checkEndDateIsBeforeAvailableFinalDate(final SetUpRegularOverpaymentServiceInput input, final AvailableDates availableDates) throws ValidationsException {
        final String endDate = input.getEndDate();
        LocalDate endSelectedDate;
        LocalDate finalDate;

        if (isNotUntilFurtherNotice(endDate)) {
            try {
                endSelectedDate = LocalDate.parse(endDate, FORMATTER);
                finalDate = LocalDate.parse(availableDates.getFinalAvailableEndingDate(), FORMATTER);
            } catch (DateTimeParseException e) {
                throw new ValidationsException(BAD_REQUEST);
            }
            if (endSelectedDate.isAfter(finalDate)) {
                throw new ValidationsException(EXC_FUNCTIONAL_VALIDATION_ENDING_DATE_NOT_VALID);
            }
        }
    }

    private boolean isNotUntilFurtherNotice(final String endDate) {
        return !"untilfurthernotice".equalsIgnoreCase(endDate);
    }

    private void checkStartingDateIsInOneOfTheAvailableDates(final SetUpRegularOverpaymentServiceInput input, final AvailableDates availableDates) throws ValidationsException {
        final String startingDate = input.getStartDate();
        final List<String> availableDatesList = convertAvailablesToList(availableDates);

        if (!availableDatesList.contains(startingDate)) {
            throw new ValidationsException(EXC_FUNCTIONAL_VALIDATION_STARTING_DATE_NOT_VALID);
        }
    }

    private List<String> convertAvailablesToList(final AvailableDates availableDates) {
        return Arrays.asList(
                availableDates.getFirstAvailableDate(),
                availableDates.getSecondAvailableDate(),
                availableDates.getThirdAvailableDate()
        );
    }

    private void checkOverpaymentAmountIsMoreThanThehighestOfNextThreePayments(RegularOverpaymentContext context) throws ValidationsException {

        BigDecimal overpaymentAmount = context.getControllerRequest().getOverpaymentAmount();
        BigDecimal contractualMonthlyAmount = context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay();

        BigDecimal totalWithRegularOverPayment = contractualMonthlyAmount.add(overpaymentAmount);
        BigDecimal maxNext3MonthlyPayments = fetchMaxPaymentAmountInNext3Months(context);

        if (totalWithRegularOverPayment.compareTo(maxNext3MonthlyPayments) <= 0) {
            throw new ValidationsException(EXC_FUNCTIONAL_VALIDATION_AMOUNT_LESS_THAN_HIGHEST_OF_NEXT_3_PAYMENTS);
        }

    }

    private BigDecimal fetchMaxPaymentAmountInNext3Months(RegularOverpaymentContext context) {

        List<BigDecimal> monthlyAmounts = new ArrayList<>();
        BigDecimal nextPaymentAmount = context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getONextMonthlyPayment();

        if (nextPaymentAmount == null) {
            return context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay();
        }

        monthlyAmounts.add(nextPaymentAmount);

        BigDecimal secondPaymentAmount = context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOSecondMonthlyPayment();

        if (secondPaymentAmount == null) {
            return findMaxMonthlyAmount(monthlyAmounts);
        }

        monthlyAmounts.add(secondPaymentAmount);
        return findMaxMonthlyAmount(monthlyAmounts);
    }

    private BigDecimal findMaxMonthlyAmount(List<BigDecimal> monthlyAmounts) {
        Optional<BigDecimal> max = monthlyAmounts.stream().max(Comparator.naturalOrder());
        return max.orElseGet(() -> monthlyAmounts.get(0));
    }
}
