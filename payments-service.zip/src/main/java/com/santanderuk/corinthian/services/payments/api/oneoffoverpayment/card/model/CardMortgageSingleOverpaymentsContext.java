package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.CardTransactionResponse;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CardMortgageSingleOverpaymentsContext {

    private AnmfRegion anmfRegion;
    private CardOneOffPaymentRequest cardOneOffPaymentRequest;
    private AnmfAccountServiceResponse anmfAccountServiceResponse;
    private CustomerDetailsResponse customerDetailsResponse;
    private OCustomer loggedCustomer;
    private int mortgageAccount;
    private String ipAddress;
    private SimulationChosenValues simulationChosenValues;
    private String ldapUid;
    private CardTransactionDetails cardTransactionDetails;
    private PartenonAccountNumber anmfPartenonAccountNumber;
    private CardTransactionResponse cardTransactionResponse;
    private String cres;
    private boolean santanderCard;
    private boolean usingOwnSantanderCard;
    private String origin;
}
