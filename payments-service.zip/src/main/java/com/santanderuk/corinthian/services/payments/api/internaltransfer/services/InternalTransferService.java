package com.santanderuk.corinthian.services.payments.api.internaltransfer.services;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck.LynxFraudCheckService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.LacService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt.LynxNRTService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.DebitResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.MakePaymentService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class InternalTransferService {

    private final LacService lacService;
    private final SetupPaymentMapper setupPaymentMapper;
    private final SetupPaymentClient setupPaymentClient;
    private final LynxFraudCheckService lynxFraudCheckService;
    private final LynxNRTService lynxNRTService;
    private final MakePaymentService makePaymentService;

    @Autowired
    public InternalTransferService(LacService lacService, SetupPaymentMapper setupPaymentMapper, SetupPaymentClient setupPaymentClient, LynxFraudCheckService lynxFraudCheckService, LynxNRTService lynxNRTService, MakePaymentService makePaymentService) {
        this.lacService = lacService;
        this.setupPaymentMapper = setupPaymentMapper;
        this.setupPaymentClient = setupPaymentClient;
        this.lynxFraudCheckService = lynxFraudCheckService;
        this.lynxNRTService = lynxNRTService;
        this.makePaymentService = makePaymentService;
    }

    public InternalTransferResponse makePayment(InternalTransferRequest internalTransferRequest, String ldapUid, String remoteIpAddress) throws PaymentsFuncException, FraudException, GeneralException {
        InternalTransferAccountsDetails accountsDetails = lacService.getAccountsDetails(internalTransferRequest.getOriginAccount(), internalTransferRequest.getDestinationAccount());
        SetupRequest setupRequest = setupPaymentMapper.generateSetupRequest(accountsDetails.getAccountFrom().getPartenonAccountNumber(), internalTransferRequest.getPaymentAmount());
        SetupResponse setupResponse = setupPaymentClient.callSetup(setupRequest);

        DebitResponse debitResponse = new DebitResponse();
        try {
            lynxFraudCheckService.callLynxFraudCheck(internalTransferRequest, accountsDetails, setupResponse, ldapUid);
            debitResponse = makePaymentService.callMakePayment(setupRequest, setupResponse, internalTransferRequest, accountsDetails);


            lynxNRTService.mapAndCallLynxNRT(internalTransferRequest, accountsDetails, debitResponse.getStatus(), ldapUid, remoteIpAddress);
        } catch (FraudException fe) {
            if (fe.getMessage().trim().equalsIgnoreCase("TRANSACTION DECLINED BY FRAUD")) {
                callLynxNrtWithKoStatus(internalTransferRequest, ldapUid, remoteIpAddress, accountsDetails);
            }
            throw fe;
        } catch (PaymentsFuncException pfe) {
            callLynxNrtWithKoStatus(internalTransferRequest, ldapUid, remoteIpAddress, accountsDetails);
            throw pfe;
        } catch (LynxNRTException lynxNRTException) {
            log.warn("Exception while calling LynxNRT service after debit payment OK");
        }

        InternalTransferResponse internalTransferResponse = new InternalTransferResponse();
        internalTransferResponse.setPaymentId(debitResponse.getCreateUniqueNumber().getUniqueNumber());
        return internalTransferResponse;
    }

    private void callLynxNrtWithKoStatus(InternalTransferRequest internalTransferRequest, String ldapUid, String remoteIpAddress, InternalTransferAccountsDetails accountsDetails) {
        try {
            lynxNRTService.mapAndCallLynxNRT(internalTransferRequest, accountsDetails, "KO", ldapUid, remoteIpAddress);
        } catch (LynxNRTException lynxNRTException) {
            log.warn("Exception while calling LynxNRT service after debit payment or fraud-check error");
        }
    }
}
