package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.applyoverpayment;

import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentsMqMessage {
    private ANMFSimulationRequest anmfSimulationRequest;
    private ANMFSimulationRequest anmfUpdateSimulationRequest;
    private ApplyOverpaymentRequest applyOverpaymentRequest;
}
