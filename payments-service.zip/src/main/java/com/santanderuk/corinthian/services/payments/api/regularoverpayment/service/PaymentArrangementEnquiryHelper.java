package com.santanderuk.corinthian.services.payments.api.regularoverpayment.service;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.ANMFPaymentArrangementResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.OPayArrOvpInst;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.AnmfCoreException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.PaymentServiceConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
@Slf4j
public class PaymentArrangementEnquiryHelper {

    private final AnmfCoreClient anmfCoreClient;
    private final EndpointConfiguration endpointConfiguration;
    private final PaymentServiceConfig paymentServiceConfig;

    @Autowired
    public PaymentArrangementEnquiryHelper(AnmfCoreClient anmfCoreClient, EndpointConfiguration endpointConfiguration, PaymentServiceConfig paymentServiceConfig) {
        this.anmfCoreClient = anmfCoreClient;
        this.endpointConfiguration = endpointConfiguration;
        this.paymentServiceConfig = paymentServiceConfig;
    }

    public OPayArrOvpInst extractInstructionToBeAmendedOrCancelled(int account, AnmfRegion region) throws GeneralException {

        ANMFPaymentArrangementResponse anmfPaymentArrangementResponse = anmfCoreClient.fetchMortgageArrangements(
                account,
                endpointConfiguration.getAnmfFetchRegularOverpaymentUrl(),
                paymentServiceConfig.getPaymentArrangementsType(),
                region
        );

        List<OPayArrOvpInst> listOfANMFInstructions = getAnmfInstructions(anmfPaymentArrangementResponse);

        List<OPayArrOvpInst> listOfEligibleInstructions = listOfANMFInstructions.stream().filter(oPayArrOvpInst ->
                oPayArrOvpInst.getOPayArrOccurrence().equalsIgnoreCase("REGULAR") &&
                        oPayArrOvpInst.getOPayArrType().equalsIgnoreCase("D") &&
                        (
                                oPayArrOvpInst.getOPayArrStatus().equalsIgnoreCase("A") ||
                                        oPayArrOvpInst.getOPayArrStatus().equalsIgnoreCase("P")
                        )
        ).collect(Collectors.toList());

        if (listOfEligibleInstructions.size() == 1) {
            return listOfEligibleInstructions.get(0);
        } else {
            throw new GeneralException("ACCOUNT_NOT_ELEGIBLE_FOR_REG_OVP_INSTRUCTION_CANCELLATION_OR_AMENDMENT", "Cancellation or amendment only allowed if one unique Direct Debit Regular instruction is setup");
        }
    }


    private List<OPayArrOvpInst> getAnmfInstructions(ANMFPaymentArrangementResponse payArrResponse) throws AnmfCoreException {
        List<OPayArrOvpInst> listOfANMFInstructions;
        try {
            listOfANMFInstructions = payArrResponse.getPaymentArrangementResponse().getOutputStruc().getOPayArrOvpInstList();
        } catch (Exception e) {
            log.error("Error parsing Regular Overpayment Enquiry response from ANMF", e);
            throw new AnmfCoreException("ANMF_INVALID_RESPONSE", "Error parsing Regular Overpayment Enquiry response from ANMF", e);
        }
        return listOfANMFInstructions;
    }
}
