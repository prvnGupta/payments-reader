package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import lombok.extern.slf4j.Slf4j;
import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.multipdf.PDFMergerUtility;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import org.springframework.core.io.ClassPathResource;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

@Slf4j
public class PDFCreationFileCreator {
    // Font files
    public static final String FILE_OPEN_SANS_BOLD_TTF = "OpenSans-Bold.ttf";
    public static final String FILE_OPEN_SANS_REGULAR_TTF = "OpenSans-Regular.ttf";

    // Configurations for text
    public static final int TEXT_INITIAL_POSITION_X = 95;
    public static final int TEXT_INITIAL_POSITION_X_2 = 70;
    public static final int TEXT_INITIAL_POSITION_Y = 705;
    public static final int TEXT_INITIAL_POSITION_Y_2 = 750;
    public static final int TEXT_INITIAL_POSITION_Y_3 = 780;

    // Font sizes
    public static final int FONT_SIZE_HEADER = 24;
    public static final int FONT_SIZE_PARAGRAPH = 10;
    public static final int FONT_SIZE_FOOTER = 5;

    // Lines heights
    public static final int LEADING_NEW_PARAGRAPH = 30;

    public static final int LEADING_NEW_PARAGRAPH_3 = 55;
    public static final int LEADING_NEW_PARAGRAPH_4 = 25;
    public static final int LEADING_NEW_LINE = 14;
    public static final int LEADING_NEW_LINE_3 = 18;
    public static final int LEADING_NEW_LINE_4 = 16;
    public static final int LEADING_NEW_LINE_6 = 22;
    public static final int LEADING_NEW_LINE_7 = 6;
    public static final int LEADING_FIRST_ELEMENT = 40;
    public static final int LEADING_FIRST_ELEMENT_2 = 34;
    public static final int LEADING_NEW_ELEMENT = 30;
    public static final int LEADING_NEW_ELEMENT_2 = 25;

    // Creating tabulation with spaces
    public static final String TABULATION_FIRST_LEVEL = "     ";
    public static final String TABULATION_SECOND_LEVEL = "                ";

    // Initial position for alignment to the right
    public static final int RIGHT_ALIGNMENT_INITIAL_POSITION = 445;

    // Others
    public static final int ZERO = 0;
    public static final float FLOAT_THOUSAND = 1000.0f;

    // Texts for the pdf
    public static final String TEXT_HEADER_YOUR_OVERPAYMENT_DETAILS = "Your overpayment details";
    public static final String TEXT_PARAGRAPH_1_LINE_1 = "Your payment is being processed. Your payment will show up on your account and statement";
    public static final String TEXT_PARAGRAPH_1_LINE_2_CARD_PAY = "within the next 3 working days subject to normal bank checks. Please do not";

    public static final String TEXT_PARAGRAPH_1_LINE_2 = "at the latest by the end of the next working day subject to normal bank checks. Please do not";
    public static final String TEXT_PARAGRAPH_1_LINE_3 = "attempt this transaction again.";
    public static final String TEXT_PARAGRAPH_2_LINE_1 = "If for any reason you need your payment returned, you must request this within 28 days.";
    public static final String TEXT_PARAGRAPH_2_LINE_2 = "After 28 days you will be required to apply for an additional loan, which may be at a different rate";
    public static final String TEXT_PARAGRAPH_2_LINE_3 = "of interest than your current mortgage.";
    public static final String TEXT_MORTGAGE_ACCOUNT_DETAILS = "Mortgage account details:";
    public static final String TEXT_SORT_CODE = "Sort code";
    public static final String TEXT_ACCOUNT_NUMBER = "Account number";
    public static final String TEXT_OVERPAYMENT_SUMMARY = "Overpayment summary";
    public static final String TEXT_YOUR_PAYMENT = "Your payment:";
    public static final String TEXT_OVERPAYMENT = "Overpayment";
    public static final String TEXT_EARLY_REPAYMENT_CHARGE = "Early repayment charge";
    public static final String TEXT_YOU_HAVE_CHOSEN = "You have chosen ";
    public static final String TEXT_TO_REDUCE_YOUR_MONTHLY_PAYMENTS = "to reduce your monthly payments:";
    public static final String TEXT_TO_PAY_OFF_YOUR_MORTGAGE_SOONER = "to pay off your mortgage sooner:";
    public static final String TEXT_TO_REDUCE_YOUR_BALANCE = "to reduce your balance:";
    public static final String TEXT_IN_THE_FUTURE_IF_YOU_WISH_TO_EXTEND_YOUR_TERM_WE_WILL_NEED_TO_CONFIRM_AFFORDABILITY = "In the future if you wish to extend your term we will need to confirm affordability";
    public static final String TEXT_MONTHLY_PAYMENT_SAVING = "Monthly payment saving";
    public static final String TEXT_MORTGAGE_TERM = "Mortgage term";
    public static final String TEXT_INTEREST_SAVING = "Interest saving";
    public static final String TEXT_YOUR_NEW_MONTHLY_PAYMENTS = "Your new monthly payments:";
    public static final String TEXT_YOUR_NEXT_TWO_DIRECT_DEBITS_MAY_VARY_SLIGHTLY_FROM_YOUR_NORMAL_MONTHLY_PAYMENT = "Your next two Direct Debits may vary slightly from your normal monthly payment";
    public static final String TEXT_YOUR_NEXT_THREE_PAYMENTS_ARE_AS_FOLLOWS = "Your next three payments are as follows:";
    public static final String TEXT_YOUR_NEXT_THREE_MONTHLY_PAYMENTS_ARE_AS_FOLLOWS = "Your next three monthly payments are as follows:";
    public static final String TEXT_1ST_PAYMENT = "1st payment";
    public static final String TEXT_2ND_PAYMENT = "2nd payment";
    public static final String TEXT_FUTURE_MONTHLY_PAYMENT = "Future monthly payment";
    public static final String TEXT_YOUR_NEW_OUTSTANDING_BALANCE_AFTER_OVERPAYMENT = "Your new outstanding balance after overpayment:";
    public static final String STRING_DEBIT_CARD = "debitcard";
    public static final String TEXT_PAYMENT_METHOD = "Payment method:";
    public static final String TEXT_ACCOUNT_TO_MAKE_OVERPAYMENT_FROM = "Account to make overpayment from:";
    public static final String TEXT_PAYMENT_TO_BE_TAKEN_ON = "Payment to be taken on:";
    public static final String TEXT_OVP_REQUESTED_DATE = "Overpayment requested date:";

    // For lines used as separators between elements
    public static final float SEPARATOR_LINE_WIDTH = 0.5f;
    public static final int SEPARATOR_LINE_X_LEFT = 95;
    public static final int SEPARATOR_LINE_X_RIGHT = 550;
    public static final int SEPARATOR_LINE_X_LEFT_ML = 70;
    public static final int SEPARATOR_LINE_X_RIGHT_ML = 525;
    public static final int SEPARATOR_LINE_Y_LINE_1 = 570;
    public static final int SEPARATOR_LINE_Y_LINE_1_ML = 634;
    public static final int SEPARATOR_LINE_Y_LINE_2 = 510;
    public static final int SEPARATOR_LINE_Y_LINE_2_ML = 574;
    public static final int SEPARATOR_LINE_Y_LINE_3 = 450;
    public static final int SEPARATOR_LINE_Y_LINE_4 = 380;
    public static final int SEPARATOR_LINE_Y_LINE_5 = 265;
    public static final int SEPARATOR_LINE_Y_LINE_6 = 235;
    public static final int SEPARATOR_LINE_Y_LINE_7 = 190;

    public static final int SEPARATOR_LINE_Y_LINE_7_CARD = 205;
    public static final int SEPARATOR_LINE_Y_LINE_8 = 160;

    public static final int SEPARATOR_LINE_Y_LINE_8_CARD = 175;
    public static final int OFFSET_IF_FUTURE_SENTENCE = -30;

    public static final double PAGE_HEIGHT = 775.0;
    public static final int BLOCK_1_HEIGHT = 266;
    public static final int LOAN_1_HEIGHT = 159;
    public static final int MIDDLE_LOAN_HEIGHT = 130;
    public static final int LAST_LOAN_HEIGHT = 140;
    public static final int BLOCK_2_HEIGHT = 62;
    public static final int BLOCK_3_HEIGHT = 123;
    public static final int BLOCK_4_HEIGHT = 35;
    public static final int BLOCK_5_HEIGHT = 58;
    public static final int BLOCK_6_HEIGHT = 75;
    public static final int CONST_SPACE_1 = 53;
    public static final int CONST_SPACE_2 = 119;
    public static final int CONST_SPACE_3 = 63;
    public static final int CONST_SPACE_4 = 129;
    public static final int CONST_SPACE_5 = 15;
    public static final int CONST_SPACE_6 = 80;
    public static final int CONST_SPACE_7 = 61;
    public static final int CONST_SPACE_8 = 30;
    public static final int CONST_SPACE_9 = -6;
    public static final int CONST_SPACE_10 = -40;
    public static final int CONST_SPACE_11 = -50;
    public static final int CONST_SPACE_12 = 35;
    public static final int CONST_SPACE_13 = 5;
    public static final int CONST_SPACE_14 = -40;
    public static final int CONST_SPACE_15 = 25;
    public static final int CONST_SPACE_16 = -5;
    public static final int CONST_SPACE_17 = -50;
    public static final int CONST_SPACE_18 = 10;
    public static final int CONST_SPACE_19 = 7;

    // Strings
    public static final String FILE_NAME_ORIGINAL_PDF = "blank-pdf-with-logo-and-footer.pdf";
    public static final String FILE_NAME_PDF_WITH_LOGO_AND_FOOTER_LABEL = "blank-pdf-with-logo-and-footer-label.pdf";
    public static final String FILE_NAME_PDF_WITH_FOOTER_LABEL = "blank-pdf-with-footer-label.pdf";
    public static final String FILE_WITH_LOGO_AND_FOOTER = "file-with-logo-and-footer";
    public static final String FILE_WITH_FOOTER = "file-with-footer";

    public static final String TEXT_PARAGRAPH_1_LINE_1_ML = "Your payment is being processed. Your account will be updated within the next 3 working";

    public static final String TEXT_PARAGRAPH_1_LINE_2_ML = "days subject to normal bank checks. Please do not attempt this transaction again.";

    public static final String TEXT_PARAGRAPH_2_LINE_1_ML = "If for any reason you need your payment returned, you must request this within 28 days.";

    public static final String TEXT_PARAGRAPH_2_LINE_2_ML = "After 28 days you will be required to apply for an additional loan, which may be at a different";
    public static final String TEXT_PARAGRAPH_2_LINE_3_ML = "rate of interest than your current mortgage.";

    public static final String TEXT_BALANCE_BEFORE_OVERPAYMENT = "Balance (before overpayment)";
    public static final String TEXT_TOTAL_OVERPAYMENT = "Total overpayment";
    public static final String TEXT_TOTAL_EARLY_REPAYMENT_CHARGE = "Total early repayment charge";
    public static final String TEXT_TOTAL_PAYMENT = "Your total payment";
    public static final String TEXT_FOOTER_LINE_1 = "Santander UK plc. Registered Office: 2 Triton Square, Regent's Place, London, NW1 3AN, United Kingdom. Registered Number 2294747. Registered in England and Wales.";
    public static final String TEXT_FOOTER_LINE_2 = "www.santander.co.uk. Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. Our Financial";
    public static final String TEXT_FOOTER_LINE_3 = "Services Register number is 106054. You can check this on the Financial Services Register by visiting the FCA’s website www.fca.org.uk/register. Santander and the flame logo are";
    public static final String TEXT_FOOTER_LINE_4 = "registered trademarks.";
    public static final String TEXT_FOOTER_LINE_5 = "December 22";

    private PDFCreationFileCreator() {
    }

    public static String createPdfSingleLoan(String fileName, PDFCreationDataSingleLoan pdfCreationDataSingleLoan) {
        try {
            // This is to help to work out the lines positions if we are writing or not the text that only appear when
            // you choose to pay sooner
            int offSetChosenOption = 0;
            boolean isDebitCardPayment = pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodSelection().equals(STRING_DEBIT_CARD);
            String paymentText = isDebitCardPayment ? TEXT_OVP_REQUESTED_DATE : TEXT_PAYMENT_TO_BE_TAKEN_ON;
            // Blank pdf with logo where we will be adding the info
            ClassPathResource blankPdf = new ClassPathResource(FILE_NAME_ORIGINAL_PDF);

            // Creating document, page and contentStream
            PDDocument document = PDDocument.load(blankPdf.getInputStream());
            PDPage page = document.getDocumentCatalog().getPages().get(0);
            PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);

            // Loading fonts
            PDFont fontOpenSansBold = PDType0Font.load(document, new ClassPathResource(FILE_OPEN_SANS_BOLD_TTF).getInputStream());
            PDFont fontOpenSansRegular = PDType0Font.load(document, new ClassPathResource(FILE_OPEN_SANS_REGULAR_TTF).getInputStream());

            // Beginning the text
            contentStream.beginText();
            contentStream.setNonStrokingColor(Color.BLACK);
            contentStream.newLineAtOffset(TEXT_INITIAL_POSITION_X, TEXT_INITIAL_POSITION_Y);

            // Font configuration for the header
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_HEADER);
            contentStream.showText(TEXT_HEADER_YOUR_OVERPAYMENT_DETAILS);

            // PARAGRAPH SECTION //
            contentStream.setLeading(LEADING_NEW_PARAGRAPH);
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TEXT_PARAGRAPH_1_LINE_1);
            contentStream.setLeading(LEADING_NEW_LINE); // Changing line height
            contentStream.newLine();
            contentStream.showText(isDebitCardPayment ? TEXT_PARAGRAPH_1_LINE_2_CARD_PAY : TEXT_PARAGRAPH_1_LINE_2);
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_1_LINE_3);
            contentStream.setLeading(LEADING_NEW_PARAGRAPH); // Changing line height for new paragraph
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_2_LINE_1);
            contentStream.setLeading(LEADING_NEW_LINE); // Changing line height for returning regular size
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_2_LINE_2);
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_2_LINE_3);

            // MORTGAGE ACCOUNT SECTION //
            // Mortgage account details
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_FIRST_ELEMENT); // Changing line height
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_MORTGAGE_ACCOUNT_DETAILS);
            // Sort code
            contentStream.setLeading(LEADING_NEW_LINE); // Changing line height for returning regular size
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_SORT_CODE);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getSortCode()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getSortCode());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getSortCode()), ZERO);
            // Account number
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_ACCOUNT_NUMBER);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getAccountNumber()), ZERO);

            // YOUR PAYMENT SECTION //
            // Your payment
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_ELEMENT); // Changing line height
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_YOUR_PAYMENT);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getTotalPayment()), ZERO);
            // Overpayment
            contentStream.setLeading(LEADING_NEW_LINE); // Changing line height for returning regular size
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_OVERPAYMENT);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getTotalOverpayment()), ZERO);
            // Early repayment charge
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_EARLY_REPAYMENT_CHARGE);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getTotalEarlyRepayment()), ZERO);

            // CHOOSE SECTION //
            // You have
            String sentenceForChosenHeader = getSentenceForChosenHeader(pdfCreationDataSingleLoan.getChosenHeader());

            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_ELEMENT); // Changing line height
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_YOU_HAVE_CHOSEN + sentenceForChosenHeader);
            contentStream.setLeading(LEADING_NEW_LINE); // Changing line height for returning regular size
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            if (pdfCreationDataSingleLoan.getChosenHeader() != null && pdfCreationDataSingleLoan.getChosenHeader().equals("T")) {
                contentStream.newLine();
                contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_IN_THE_FUTURE_IF_YOU_WISH_TO_EXTEND_YOUR_TERM_WE_WILL_NEED_TO_CONFIRM_AFFORDABILITY);
                offSetChosenOption = OFFSET_IF_FUTURE_SENTENCE;
                contentStream.newLine();
            }
            // Monthly payment
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_MONTHLY_PAYMENT_SAVING);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getMonthlyPaymentSaving()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getMonthlyPaymentSaving());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getMonthlyPaymentSaving()), ZERO);
            // Mortgage term
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_MORTGAGE_TERM);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getMortgageTerm()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getMortgageTerm());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getMortgageTerm()), ZERO);
            // Interest saving
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_INTEREST_SAVING);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getInterestSaving()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getInterestSaving());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getInterestSaving()), ZERO);

            // YOUR NEW MONTHLY PAYMENT SECTION //
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_ELEMENT); // Changing line height
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_YOUR_NEW_MONTHLY_PAYMENTS);
            contentStream.setLeading(LEADING_NEW_LINE); // Changing line height for returning regular size
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_YOUR_NEXT_TWO_DIRECT_DEBITS_MAY_VARY_SLIGHTLY_FROM_YOUR_NORMAL_MONTHLY_PAYMENT);
            contentStream.newLine();
            contentStream.newLine();

            // NEXT THREE PAYMENTS SECTION //
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_YOUR_NEXT_THREE_PAYMENTS_ARE_AS_FOLLOWS);
            // 1st payment
            //contentStream.setLeading(LEADING_NEW_LINE); // Changing line height for returning regular size
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_1ST_PAYMENT);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getFirstPayment()), ZERO);
            contentStream.newLine();
            // 2nd payment
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_2ND_PAYMENT);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getSecondPayment()), ZERO);
            // Future payment
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_FUTURE_MONTHLY_PAYMENT);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getFuturePayment()), ZERO);

            // YOUR NEW OUTSTANDING BALANCE SECTION //
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_ELEMENT); // Changing line height
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_YOUR_NEW_OUTSTANDING_BALANCE_AFTER_OVERPAYMENT);
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getNewOutstandingBalance()), ZERO);

            // YOUR PAYMENT METHOD SECTION //
            String sentenceForPaymentSelection = isDebitCardPayment ? TEXT_PAYMENT_METHOD : TEXT_ACCOUNT_TO_MAKE_OVERPAYMENT_FROM;

            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_ELEMENT); // Changing line height
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + sentenceForPaymentSelection);
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethod()), ZERO);
            contentStream.setLeading(LEADING_NEW_LINE);
            if (!isDebitCardPayment) {
                contentStream.newLine();
                contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName()), ZERO);
                contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName());
                contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getPaymentMethodName()), ZERO);
            }

            // PAYMENT TO BE TAKEN ON SECTION //
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_ELEMENT); // Changing line height
            contentStream.newLine();

            contentStream.showText(TABULATION_FIRST_LEVEL + paymentText);
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn()), ZERO);
            contentStream.showText(pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataSingleLoan.getPdfCreationData().getPaymentTakenOn()), ZERO);
            contentStream.newLine();

            // End of text operations
            contentStream.endText();

            // Creating lines
            contentStream.setStrokingColor(Color.lightGray);
            contentStream.setLineWidth(SEPARATOR_LINE_WIDTH);

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT, SEPARATOR_LINE_Y_LINE_1);
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, SEPARATOR_LINE_Y_LINE_1);

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT, SEPARATOR_LINE_Y_LINE_2);
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, SEPARATOR_LINE_Y_LINE_2);

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT, SEPARATOR_LINE_Y_LINE_3);
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, SEPARATOR_LINE_Y_LINE_3);

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT, (float) (SEPARATOR_LINE_Y_LINE_4 + offSetChosenOption));
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, (float) (SEPARATOR_LINE_Y_LINE_4 + offSetChosenOption));

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT, (float) (SEPARATOR_LINE_Y_LINE_5 + offSetChosenOption));
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, (float) (SEPARATOR_LINE_Y_LINE_5 + offSetChosenOption));

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT, (float) (SEPARATOR_LINE_Y_LINE_6 + offSetChosenOption));
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, (float) (SEPARATOR_LINE_Y_LINE_6 + offSetChosenOption));

            if (!isDebitCardPayment) {
                contentStream.moveTo(SEPARATOR_LINE_X_LEFT, (float) (SEPARATOR_LINE_Y_LINE_7 + offSetChosenOption));
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, (float) (SEPARATOR_LINE_Y_LINE_7 + offSetChosenOption));

                contentStream.moveTo(SEPARATOR_LINE_X_LEFT, (float) (SEPARATOR_LINE_Y_LINE_8 + offSetChosenOption));
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, (float) (SEPARATOR_LINE_Y_LINE_8 + offSetChosenOption));
            } else {
                contentStream.moveTo(SEPARATOR_LINE_X_LEFT, (float) (SEPARATOR_LINE_Y_LINE_7_CARD + offSetChosenOption));
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, (float) (SEPARATOR_LINE_Y_LINE_7_CARD + offSetChosenOption));

                contentStream.moveTo(SEPARATOR_LINE_X_LEFT, (float) (SEPARATOR_LINE_Y_LINE_8_CARD + offSetChosenOption));
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT, (float) (SEPARATOR_LINE_Y_LINE_8_CARD + offSetChosenOption));
            }

            // Draw the lines
            contentStream.stroke();

            // Closing content stream, saving file and closing the document
            contentStream.close();
            document.save(fileName);
            document.close();

        } catch (IOException e) {
            log.warn("IOException when trying create the pdf");
        }

        return fileName;
    }

    public static String createPdfMultiLoan(String fileName, PDFCreationDataMultiLoan pdfCreationDataMultiLoan) {
        try {
            int currentPage = 0;
            int occupiedPageSpace;
            int nextBlockHeight;
            long numberOfLoansWithOverpayment = getNumberOfLoansWithOverpayment(pdfCreationDataMultiLoan);
            int lineFourPage;
            int lineFourSpace;
            boolean lineFiveFirstElement = false;
            boolean lineSixFirstElement = false;
            boolean lineSevenFirstElement = false;
            int lineFivePage;
            int lineFiveSpace;
            boolean isDebitCardPayment = pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodSelection().equals(STRING_DEBIT_CARD);
            String paymentText = isDebitCardPayment ? TEXT_OVP_REQUESTED_DATE : TEXT_PAYMENT_TO_BE_TAKEN_ON;

            createBlankPdf(fileName, numberOfLoansWithOverpayment);

            PDDocument document = PDDocument.load(new File(fileName));
            PDPage page = document.getDocumentCatalog().getPages().get(currentPage++);
            PDPageContentStream contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);

            // Loading fonts
            PDFont fontOpenSansBold = PDType0Font.load(document, new ClassPathResource(FILE_OPEN_SANS_BOLD_TTF).getInputStream());
            PDFont fontOpenSansRegular = PDType0Font.load(document, new ClassPathResource(FILE_OPEN_SANS_REGULAR_TTF).getInputStream());

            // Beginning the text
            contentStream.beginText();
            contentStream.setNonStrokingColor(Color.BLACK);
            contentStream.newLineAtOffset(TEXT_INITIAL_POSITION_X_2, TEXT_INITIAL_POSITION_Y_2);

            // Font configuration for the header
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_HEADER);
            contentStream.showText(TEXT_HEADER_YOUR_OVERPAYMENT_DETAILS);

            // PARAGRAPH SECTION //
            contentStream.setLeading(LEADING_NEW_PARAGRAPH);
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TEXT_PARAGRAPH_1_LINE_1_ML);
            contentStream.setLeading(LEADING_NEW_LINE);
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_1_LINE_2_ML);
            contentStream.setLeading(LEADING_NEW_PARAGRAPH_4);
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_2_LINE_1_ML);
            contentStream.setLeading(LEADING_NEW_LINE);
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_2_LINE_2_ML);
            contentStream.newLine();
            contentStream.showText(TEXT_PARAGRAPH_2_LINE_3_ML);

            // MORTGAGE ACCOUNT SECTION //
            // Mortgage account details
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_FIRST_ELEMENT_2);
            contentStream.newLine();
            contentStream.showText(TEXT_MORTGAGE_ACCOUNT_DETAILS);
            // Sort code
            contentStream.setLeading(LEADING_NEW_LINE_3);
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_SORT_CODE);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getSortCode()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getSortCode());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getSortCode()), ZERO);
            // Account number
            contentStream.setLeading(LEADING_NEW_LINE);
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_ACCOUNT_NUMBER);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getAccountNumber()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getAccountNumber());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getAccountNumber()), ZERO);

            occupiedPageSpace = BLOCK_1_HEIGHT;

            // Loan Details
            if (isDebitCardPayment) {
                contentStream.setLeading(LEADING_NEW_PARAGRAPH);
                contentStream.newLine();
                contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                contentStream.showText(TEXT_OVERPAYMENT_SUMMARY);
                contentStream.setLeading(LEADING_NEW_PARAGRAPH_4);
                contentStream.newLine();
            } else {
                contentStream.setLeading(LEADING_NEW_PARAGRAPH_3);
                contentStream.newLine();
            }
            int numberOfLoansPrinted = 0;
            for (int i = 0; i < pdfCreationDataMultiLoan.getLoanDetails().size(); i++) {
                if (BigDecimal.ZERO.compareTo(pdfCreationDataMultiLoan.getLoanDetails().get(i).getOverpaymentInBigDecimal()) < 0) {
                    numberOfLoansPrinted++;
                    contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                    contentStream.showText(pdfCreationDataMultiLoan.getLoanDetails().get(i).getDescription());
                    contentStream.setLeading(LEADING_NEW_LINE_4);
                    contentStream.newLine();
                    contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
                    contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_BALANCE_BEFORE_OVERPAYMENT);
                    contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                    contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getBalanceBeforeOverpayment()), ZERO);
                    contentStream.showText(pdfCreationDataMultiLoan.getLoanDetails().get(i).getBalanceBeforeOverpayment());
                    contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getBalanceBeforeOverpayment()), ZERO);
                    contentStream.newLine();
                    contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
                    contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_OVERPAYMENT);
                    contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                    contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getOverpayment()), ZERO);
                    contentStream.showText(pdfCreationDataMultiLoan.getLoanDetails().get(i).getOverpayment());
                    contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getOverpayment()), ZERO);

                    // CHOOSE SECTION //
                    // You have
                    String sentenceForChosenHeader = getSentenceForChosenHeader(pdfCreationDataMultiLoan.getLoanDetails().get(i).getChosenHeader());

                    contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                    contentStream.setLeading(LEADING_NEW_ELEMENT_2);
                    contentStream.newLine();
                    contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_YOU_HAVE_CHOSEN + sentenceForChosenHeader);
                    contentStream.setLeading(LEADING_NEW_LINE_3);
                    contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
                    // Monthly payment
                    contentStream.newLine();
                    contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_MONTHLY_PAYMENT_SAVING);
                    contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                    contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getMonthlyPaymentSaving()), ZERO);
                    contentStream.showText(pdfCreationDataMultiLoan.getLoanDetails().get(i).getMonthlyPaymentSaving());
                    contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getMonthlyPaymentSaving()), ZERO);
                    // Mortgage term
                    contentStream.setLeading(LEADING_NEW_LINE);
                    contentStream.newLine();
                    contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
                    contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_MORTGAGE_TERM);
                    contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                    contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getMortgageTerm()) - CONST_SPACE_19, ZERO);
                    contentStream.showText(pdfCreationDataMultiLoan.getLoanDetails().get(i).getMortgageTerm());
                    contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getMortgageTerm()) + CONST_SPACE_19, ZERO);
                    // Interest saving
                    contentStream.newLine();
                    contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
                    contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_INTEREST_SAVING);
                    contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
                    contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getInterestSaving()), ZERO);
                    contentStream.showText(pdfCreationDataMultiLoan.getLoanDetails().get(i).getInterestSaving());
                    contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getLoanDetails().get(i).getInterestSaving()), ZERO);
                    contentStream.setLeading(LEADING_NEW_PARAGRAPH_4);
                    contentStream.newLine();

                    if (numberOfLoansPrinted == 1) {
                        occupiedPageSpace += LOAN_1_HEIGHT;
                    } else if (numberOfLoansPrinted == numberOfLoansWithOverpayment) {
                        occupiedPageSpace += LAST_LOAN_HEIGHT;
                    } else {
                        occupiedPageSpace += MIDDLE_LOAN_HEIGHT;
                    }

                    if (numberOfLoansPrinted < numberOfLoansWithOverpayment - 1) {
                        nextBlockHeight = MIDDLE_LOAN_HEIGHT;
                    } else if (numberOfLoansPrinted < numberOfLoansWithOverpayment) {
                        nextBlockHeight = LAST_LOAN_HEIGHT;
                    } else {
                        nextBlockHeight = BLOCK_2_HEIGHT;
                    }

                    if ((PAGE_HEIGHT - occupiedPageSpace) < nextBlockHeight) {
                        contentStream.endText();
                        contentStream.close();
                        page = document.getDocumentCatalog().getPages().get(currentPage++);
                        contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
                        occupiedPageSpace = 0;
                        contentStream.beginText();
                        contentStream.setNonStrokingColor(Color.BLACK);
                        contentStream.newLineAtOffset(TEXT_INITIAL_POSITION_X_2, TEXT_INITIAL_POSITION_Y_3);
                    }
                }
            }

            // YOUR PAYMENT SECTION //
            // Total overpayment
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_LINE_4);
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_TOTAL_OVERPAYMENT);
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getTotalOverpayment()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getTotalOverpayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getTotalOverpayment()), ZERO);
            // Total early repayment charge
            contentStream.setLeading(LEADING_NEW_LINE);
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_TOTAL_EARLY_REPAYMENT_CHARGE);
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getTotalEarlyRepayment()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getTotalEarlyRepayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getTotalEarlyRepayment()), ZERO);
            //
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.setLeading(LEADING_NEW_LINE);
            contentStream.newLine();
            contentStream.showText(TABULATION_FIRST_LEVEL + TEXT_TOTAL_PAYMENT);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getTotalPayment()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getTotalPayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getTotalPayment()), ZERO);
            contentStream.setLeading(LEADING_NEW_PARAGRAPH_4);
            contentStream.newLine();
            contentStream.setLeading(LEADING_NEW_LINE_4);
            contentStream.newLine();

            occupiedPageSpace += BLOCK_2_HEIGHT;
            nextBlockHeight = BLOCK_3_HEIGHT;
            lineFourPage = currentPage - 1;
            lineFourSpace = occupiedPageSpace;
            if (PAGE_HEIGHT - occupiedPageSpace < nextBlockHeight) {
                contentStream.endText();
                contentStream.close();
                page = document.getDocumentCatalog().getPages().get(currentPage++);
                contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
                occupiedPageSpace = 0;
                contentStream.beginText();
                contentStream.setNonStrokingColor(Color.BLACK);
                contentStream.newLineAtOffset(TEXT_INITIAL_POSITION_X_2, TEXT_INITIAL_POSITION_Y_3);
            }

            // YOUR NEW MONTHLY PAYMENT SECTION //
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TEXT_YOUR_NEW_MONTHLY_PAYMENTS);
            contentStream.setLeading(LEADING_NEW_LINE_3);
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_YOUR_NEXT_TWO_DIRECT_DEBITS_MAY_VARY_SLIGHTLY_FROM_YOUR_NORMAL_MONTHLY_PAYMENT);
            contentStream.setLeading(LEADING_NEW_LINE_6);
            contentStream.newLine();

            // NEXT THREE PAYMENTS SECTION //
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_YOUR_NEXT_THREE_MONTHLY_PAYMENTS_ARE_AS_FOLLOWS);
            // 1st payment
            contentStream.setLeading(LEADING_NEW_LINE);
            contentStream.newLine();
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_1ST_PAYMENT);
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getFirstPayment()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getFirstPayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getFirstPayment()), ZERO);
            contentStream.newLine();
            // 2nd payment
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_2ND_PAYMENT);
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getSecondPayment()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getSecondPayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getSecondPayment()), ZERO);
            // Future payment
            contentStream.newLine();
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TABULATION_SECOND_LEVEL + TEXT_FUTURE_MONTHLY_PAYMENT);
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getFuturePayment()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getFuturePayment());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getFuturePayment()), ZERO);
            contentStream.setLeading(LEADING_NEW_ELEMENT);
            contentStream.newLine();

            occupiedPageSpace += BLOCK_3_HEIGHT;
            nextBlockHeight = BLOCK_4_HEIGHT;
            if (PAGE_HEIGHT - occupiedPageSpace < nextBlockHeight) {
                contentStream.endText();
                contentStream.close();
                page = document.getDocumentCatalog().getPages().get(currentPage++);
                contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
                occupiedPageSpace = 0;
                contentStream.beginText();
                contentStream.setNonStrokingColor(Color.BLACK);
                contentStream.newLineAtOffset(TEXT_INITIAL_POSITION_X_2, TEXT_INITIAL_POSITION_Y_3);
                lineFiveFirstElement = true;
            }

            lineFivePage = currentPage - 1;
            lineFiveSpace = occupiedPageSpace;
            // YOUR NEW OUTSTANDING BALANCE SECTION //
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.showText(TEXT_YOUR_NEW_OUTSTANDING_BALANCE_AFTER_OVERPAYMENT);
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getNewOutstandingBalance()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getNewOutstandingBalance());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getNewOutstandingBalance()), ZERO);
            contentStream.setLeading(LEADING_NEW_ELEMENT);
            contentStream.newLine();

            occupiedPageSpace += BLOCK_4_HEIGHT;
            nextBlockHeight = BLOCK_5_HEIGHT;
            if (PAGE_HEIGHT - occupiedPageSpace < nextBlockHeight) {
                contentStream.endText();
                contentStream.close();
                page = document.getDocumentCatalog().getPages().get(currentPage++);
                contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
                occupiedPageSpace = 0;
                contentStream.beginText();
                contentStream.setNonStrokingColor(Color.BLACK);
                contentStream.newLineAtOffset(TEXT_INITIAL_POSITION_X_2, TEXT_INITIAL_POSITION_Y_3);
                lineSixFirstElement = true;
            }

            // YOUR PAYMENT METHOD SECTION //
            String sentenceForPaymentSelection = isDebitCardPayment ? TEXT_PAYMENT_METHOD : TEXT_ACCOUNT_TO_MAKE_OVERPAYMENT_FROM;

            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.showText(sentenceForPaymentSelection);
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethod()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethod());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethod()), ZERO);
            contentStream.setLeading(LEADING_NEW_LINE);
            if (!isDebitCardPayment) {
                contentStream.newLine();
                contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodName()), ZERO);
                contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodName());
                contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getPaymentMethodName()), ZERO);
            }
            contentStream.setLeading(LEADING_NEW_ELEMENT);
            contentStream.newLine();

            occupiedPageSpace += BLOCK_5_HEIGHT;
            nextBlockHeight = BLOCK_6_HEIGHT;
            if (PAGE_HEIGHT - occupiedPageSpace < nextBlockHeight) {
                contentStream.endText();
                contentStream.close();
                page = document.getDocumentCatalog().getPages().get(currentPage);
                contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
                contentStream.beginText();
                contentStream.setNonStrokingColor(Color.BLACK);
                contentStream.newLineAtOffset(TEXT_INITIAL_POSITION_X_2, TEXT_INITIAL_POSITION_Y_3);
                lineSevenFirstElement = true;
            }

            // PAYMENT TO BE TAKEN ON SECTION //
            contentStream.setFont(fontOpenSansBold, FONT_SIZE_PARAGRAPH);
            contentStream.showText(paymentText);
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_PARAGRAPH);
            contentStream.newLineAtOffset(calculateRightAlignmentXPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getPaymentTakenOn()), ZERO);
            contentStream.showText(pdfCreationDataMultiLoan.getPdfCreationData().getPaymentTakenOn());
            contentStream.newLineAtOffset(calculateRightAlignmentPreviousPosition(fontOpenSansRegular, pdfCreationDataMultiLoan.getPdfCreationData().getPaymentTakenOn()), ZERO);
            contentStream.setLeading(LEADING_NEW_ELEMENT_2);
            contentStream.newLine();

            // Footer Text
            contentStream.setFont(fontOpenSansRegular, FONT_SIZE_FOOTER);
            contentStream.setNonStrokingColor(Color.darkGray);
            contentStream.showText(TEXT_FOOTER_LINE_1);
            contentStream.setLeading(LEADING_NEW_LINE_7);
            contentStream.newLine();
            contentStream.showText(TEXT_FOOTER_LINE_2);
            contentStream.newLine();
            contentStream.showText(TEXT_FOOTER_LINE_3);
            contentStream.newLine();
            contentStream.showText(TEXT_FOOTER_LINE_4);
            contentStream.setLeading(LEADING_NEW_LINE);
            contentStream.newLine();
            contentStream.showText(TEXT_FOOTER_LINE_5);

            // End of text operations
            contentStream.endText();
            contentStream.close();

            // Creating lines
            page = document.getDocumentCatalog().getPages().get(0);
            contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
            contentStream.setStrokingColor(Color.lightGray);
            contentStream.setLineWidth(SEPARATOR_LINE_WIDTH);

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, SEPARATOR_LINE_Y_LINE_1_ML);
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, SEPARATOR_LINE_Y_LINE_1_ML);

            contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, SEPARATOR_LINE_Y_LINE_2_ML);
            contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, SEPARATOR_LINE_Y_LINE_2_ML);
            contentStream.stroke();
            contentStream.close();

            page = document.getDocumentCatalog().getPages().get(lineFivePage);
            contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
            contentStream.setStrokingColor(Color.lightGray);
            contentStream.setLineWidth(SEPARATOR_LINE_WIDTH);

            if (!lineFiveFirstElement) {
                if (numberOfLoansPrinted == 1) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_7);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_7);
                } else if (numberOfLoansPrinted == 2) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_10);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_10);
                } else if (numberOfLoansPrinted == 3) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_12);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_12);
                } else {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_15);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_15);
                }
            }
            if (!lineSixFirstElement) {
                if (numberOfLoansPrinted == 1) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_8);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_8);
                } else if (isDebitCardPayment && numberOfLoansPrinted == 2) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_11 + CONST_SPACE_18);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_11 + CONST_SPACE_18);
                } else if (numberOfLoansPrinted == 2) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_11);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_11);
                } else if (numberOfLoansPrinted == 3) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_13);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_13);
                } else {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_16);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_16);
                }
            }
            if (!lineSevenFirstElement) {
                if (numberOfLoansPrinted < 3) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_9);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_9);
                } else if (isDebitCardPayment && numberOfLoansPrinted == 3) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_14 + CONST_SPACE_18);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_14 + CONST_SPACE_18);
                } else if (numberOfLoansPrinted == 3) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_14);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_14);
                } else if (isDebitCardPayment) {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_17 + CONST_SPACE_18);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_17 + CONST_SPACE_18);
                } else {
                    contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_17);
                    contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFiveSpace + CONST_SPACE_17);
                }
            }

            contentStream.stroke();
            contentStream.close();

            page = document.getDocumentCatalog().getPages().get(lineFourPage);
            contentStream = new PDPageContentStream(document, page, PDPageContentStream.AppendMode.APPEND, false);
            contentStream.setStrokingColor(Color.lightGray);
            contentStream.setLineWidth(SEPARATOR_LINE_WIDTH);

            contentStream.setLineDashPattern(new float[]{2, 2}, 0);
            if (numberOfLoansPrinted == 1) {
                contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_1);
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_1);

                contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_2);
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_2);
            } else if (lineFourPage == 0) {
                contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_3);
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_3);

                contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_4);
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_4);
            } else {
                contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_5);
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_5);

                contentStream.moveTo(SEPARATOR_LINE_X_LEFT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_6);
                contentStream.lineTo(SEPARATOR_LINE_X_RIGHT_ML, (int) PAGE_HEIGHT - lineFourSpace + CONST_SPACE_6);
            }

            // Draw the lines
            contentStream.stroke();

            // Closing content stream, saving file and closing the document
            contentStream.close();
            document.save(fileName);
            document.close();

        } catch (IOException e) {
            log.warn("IOException when trying to create the multi loan pdf");
        }

        return fileName;
    }

    private static void createBlankPdf(String fileName, long numberOfLoansWithOverpayment) throws IOException {
        // Blank pdf with logo where we will be adding the info
        ClassPathResource blankPdfWithLogoAndFooter = new ClassPathResource(FILE_NAME_PDF_WITH_LOGO_AND_FOOTER_LABEL);
        ClassPathResource blankPdfWithFooter = new ClassPathResource(FILE_NAME_PDF_WITH_FOOTER_LABEL);

        int totalSpaceRequired = calculateTotalSpaceRequired(numberOfLoansWithOverpayment);

        int numberOfPagesRequired = (int) Math.ceil(totalSpaceRequired / PAGE_HEIGHT);

        // Creating document, pages and contentStream
        PDDocument document1 = PDDocument.load(blankPdfWithLogoAndFooter.getInputStream());
        document1.save(FILE_WITH_LOGO_AND_FOOTER);
        document1.close();
        File fileWithLogoAndFooter = new File(FILE_WITH_LOGO_AND_FOOTER);
        PDDocument document2 = PDDocument.load(blankPdfWithFooter.getInputStream());
        document2.save(FILE_WITH_FOOTER);
        document2.close();
        File fileWithFooter = new File(FILE_WITH_FOOTER);
        PDFMergerUtility pdfMergerUtility = new PDFMergerUtility();
        pdfMergerUtility.setDestinationFileName(fileName);
        pdfMergerUtility.addSource(fileWithLogoAndFooter);
        for (int i = 1; i < numberOfPagesRequired; i++) {
            pdfMergerUtility.addSource(fileWithFooter);
        }

        pdfMergerUtility.mergeDocuments(MemoryUsageSetting.setupMainMemoryOnly());

        if (!fileWithLogoAndFooter.delete()) {
            log.warn("Exception deleting FileWithLogoAndFooter. Review why");
        }
        if (!fileWithFooter.delete()) {
            log.warn("Exception deleting FileWithFooter. Review why");
        }

    }

    private static int calculateTotalSpaceRequired(long numberOfLoansWithOverpayment) {

        int totalSpaceRequired = BLOCK_1_HEIGHT;

        if (numberOfLoansWithOverpayment == 1) {
            totalSpaceRequired += LOAN_1_HEIGHT;
        } else if (numberOfLoansWithOverpayment == 2) {
            totalSpaceRequired += LOAN_1_HEIGHT;
            totalSpaceRequired += LAST_LOAN_HEIGHT;
        } else {
            totalSpaceRequired += LOAN_1_HEIGHT;
            totalSpaceRequired += MIDDLE_LOAN_HEIGHT * (numberOfLoansWithOverpayment - 2);
            totalSpaceRequired += LAST_LOAN_HEIGHT;
        }
        totalSpaceRequired += BLOCK_2_HEIGHT;
        totalSpaceRequired += BLOCK_3_HEIGHT;
        totalSpaceRequired += BLOCK_4_HEIGHT;
        totalSpaceRequired += BLOCK_5_HEIGHT;
        totalSpaceRequired += BLOCK_6_HEIGHT;

        return totalSpaceRequired;
    }

    private static long getNumberOfLoansWithOverpayment(PDFCreationDataMultiLoan pdfCreationDataMultiLoan) {
        return pdfCreationDataMultiLoan.getLoanDetails().stream().filter(loan -> loan.getOverpaymentInBigDecimal().compareTo(BigDecimal.ZERO) > 0).count();

    }

    private static String getSentenceForChosenHeader(String chosenHeader) {
        String sentenceForChosenHeader;
        if (chosenHeader != null) {
            sentenceForChosenHeader = switch (chosenHeader) {
                case "M" ->
                    // Reduce monthly payment
                        TEXT_TO_REDUCE_YOUR_MONTHLY_PAYMENTS;
                case "B" ->
                    // Not paying enough so reducing balance
                        TEXT_TO_REDUCE_YOUR_BALANCE;
                default -> TEXT_TO_PAY_OFF_YOUR_MORTGAGE_SOONER;
            };
        } else {
            // if nothing was chosen is a IO mortgage
            sentenceForChosenHeader = TEXT_TO_REDUCE_YOUR_MONTHLY_PAYMENTS;
        }
        return sentenceForChosenHeader;
    }

    private static float calculateRightAlignmentXPosition(PDFont fontUsed, String word) {
        BigDecimal rightAlignmentInitialPosition = BigDecimal.valueOf(RIGHT_ALIGNMENT_INITIAL_POSITION);
        BigDecimal textWidth = BigDecimal.valueOf(calculateTextWidth(fontUsed, word));
        return rightAlignmentInitialPosition.subtract(textWidth).floatValue();
    }

    private static float calculateRightAlignmentPreviousPosition(PDFont fontUsed, String word) {
        BigDecimal minusRightAlignmentInitialPosition = BigDecimal.valueOf(-RIGHT_ALIGNMENT_INITIAL_POSITION);
        BigDecimal textWidth = BigDecimal.valueOf(calculateTextWidth(fontUsed, word));
        return minusRightAlignmentInitialPosition.add(textWidth).floatValue();
    }

    private static float calculateTextWidth(PDFont fontUsed, String word) {
        float width = 0;
        try {
            BigDecimal stringWidth = BigDecimal.valueOf(fontUsed.getStringWidth(word));
            BigDecimal floatThousand = BigDecimal.valueOf(FLOAT_THOUSAND);
            BigDecimal fontSizeParagraph = BigDecimal.valueOf(FONT_SIZE_PARAGRAPH);
            width = (stringWidth.divide(floatThousand, RoundingMode.HALF_UP)).multiply(fontSizeParagraph).floatValue();
        } catch (IOException e) {
            if (log.isDebugEnabled()) {
                log.debug("calculateTextWidth - IOException when trying calculate the text width for the pdf");
            }
        }
        return width;
    }

}
