package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.SecureRandom;
import java.util.Base64;

@Service
@Slf4j
public class PDFCreationService {

    private final PDFCreationDataMapper pdfCreationDataAccess;
    private final SecureRandom random = new SecureRandom();

    @Autowired
    public PDFCreationService(PDFCreationDataMapper pdfCreationDataAccess) {
        this.pdfCreationDataAccess = pdfCreationDataAccess;
    }

    public String createBase64PdfFileForInternalTransfer(MortgageSingleOverpaymentsContext context) {
        try {
            String fileName = context.getUpdatedSimulationResponse().getOLoanData().size() == 1 ? createPdfSingleLoan(context) : createPdfMultiLoan(context);
            byte[] inFileBytes = readPdfContents(fileName);
            deletePdf(fileName);
            return getBase64EncodedPdf(inFileBytes);
        } catch (Exception e) {
            log.error("Error while generating overpayment PDF", e);
            return "";
        }
    }


    public String createBase64PdfFileForCardPayment(CardMortgageSingleOverpaymentsContext context) {
        try {
            log.info("createBase64PdfFileForCardPayment -> started");
            String fileName = context.getCardTransactionDetails().getUpdatedSimulationResponse().getOLoanData().size() == 1 ? createPdfForCardPaymentSingleLoan(context) : createPdfForCardPaymentMultiLoan(context);
            byte[] inFileBytes = readPdfContents(fileName);
            deletePdf(fileName);
            String base64EncodedPdf = getBase64EncodedPdf(inFileBytes);
            log.info("createBase64PdfFileForCardPayment -> finished");
            return base64EncodedPdf;
        } catch (Exception e) {
            log.error("triggerEmailAlert -> Error while generating overpayment PDF", e);
            return "";
        }
    }

    private String getBase64EncodedPdf(byte[] inFileBytes) {
        return new String(Base64.getEncoder().encode(inFileBytes), StandardCharsets.UTF_8);
    }

    private byte[] readPdfContents(String fileName) throws IOException {
        return Files.readAllBytes(Paths.get(fileName));
    }

    private String createPdfSingleLoan(MortgageSingleOverpaymentsContext context) {
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataSingleLoan(context);
        return PDFCreationFileCreator.createPdfSingleLoan(createNewFileName(), pdfCreationDataSingleLoan);
    }

    private String createPdfMultiLoan(MortgageSingleOverpaymentsContext context) {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = pdfCreationDataAccess.getPdfCreationDataMultiLoan(context);
        return PDFCreationFileCreator.createPdfMultiLoan(createNewFileName(), pdfCreationDataMultiLoan);
    }

    private String createPdfForCardPaymentSingleLoan(CardMortgageSingleOverpaymentsContext context) {
        PDFCreationDataSingleLoan pdfCreationDataSingleLoan = pdfCreationDataAccess.getPdfCreationDataForCardPayment(context);
        return PDFCreationFileCreator.createPdfSingleLoan(createNewFileName(), pdfCreationDataSingleLoan);
    }

    private String createPdfForCardPaymentMultiLoan(CardMortgageSingleOverpaymentsContext context) {
        PDFCreationDataMultiLoan pdfCreationDataMultiLoan = pdfCreationDataAccess.getPdfCreationDataForCardPaymentMultiLoan(context);
        return PDFCreationFileCreator.createPdfMultiLoan(createNewFileName(), pdfCreationDataMultiLoan);
    }

    private void deletePdf(String fileName) {
        File overpaymentsPdf = new File(fileName);
        boolean deleted = overpaymentsPdf.delete();
        if (!deleted) {
            log.error("Error while deleting PDF");
        }
    }

    private String createNewFileName() {
        int maxInt = Integer.MAX_VALUE;

        String randomString = String.valueOf(random.nextInt(maxInt));
        return "overpayment_summary-".concat(randomString).concat(".pdf");
    }
}
