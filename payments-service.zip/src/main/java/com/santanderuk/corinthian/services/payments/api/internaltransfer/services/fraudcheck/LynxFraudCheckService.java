package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataRequest;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.springframework.stereotype.Service;

@Service
public class LynxFraudCheckService {

    private final LynxFraudCheckMapper lynxFraudCheckMapper;

    private final LynxFraudCheckClient lynxFraudCheckClient;

    public LynxFraudCheckService(LynxFraudCheckMapper lynxFraudCheckMapper, LynxFraudCheckClient lynxFraudCheckClient) {
        this.lynxFraudCheckMapper = lynxFraudCheckMapper;
        this.lynxFraudCheckClient = lynxFraudCheckClient;
    }

    public LynxDataResponse callLynxFraudCheck(InternalTransferRequest inputRequest, InternalTransferAccountsDetails accountsDetails, SetupResponse setupResponse, String ldapUid) throws FraudException {
        LynxDataRequest lynxDataRequest = lynxFraudCheckMapper.decorateRequestData(inputRequest, accountsDetails, setupResponse, ldapUid);
        return lynxFraudCheckClient.callFraudCheck(lynxDataRequest);
    }

    public void callLynxFraudCheck(MortgageSingleOverpaymentsContext context, SetupResponse setupResponse) throws FraudException {
        LynxDataRequest lynxDataRequest = lynxFraudCheckMapper.decorateRequestData(context, setupResponse);
        lynxFraudCheckClient.callFraudCheck(lynxDataRequest);
    }
}
