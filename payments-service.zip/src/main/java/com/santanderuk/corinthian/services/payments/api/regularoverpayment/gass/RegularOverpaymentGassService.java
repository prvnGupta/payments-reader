package com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass;

import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.SetUpRegularOverpaymentGassMQServiceInterface;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentGassItem;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class RegularOverpaymentGassService {

    @Autowired
    private SetUpRegularOverpaymentGassMQServiceInterface setUpRegularOverpaymentGassMQService;

    public void callGass(SetUpRegularOverpaymentGassItem setUpRegularOverpaymentGassItem) {
        log.debug("Data sent to GASS setup: {}", setUpRegularOverpaymentGassItem.toString().replaceAll("[\r\n]", ""));
        try {
            setUpRegularOverpaymentGassMQService.sendToMQSetUpRegularOverpayment(setUpRegularOverpaymentGassItem);
            log.info("RegularOverpaymentService - > GASS Record correctly inserted on MQ");
        } catch (GeneralException e) {
            log.error("Failed to send to GASS due to: ", e);
        }
    }
}
