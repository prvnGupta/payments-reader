package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac;

import com.santanderuk.corinthian.services.commons.clients.lac.LocalAccountConverterClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalAccountDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LacService {
    private final EndpointConfiguration endpointConfiguration;
    private final LocalAccountConverterClient lacClient;
    private final InternalAccountFormatConverter internalAccountFormatConverter;

    @Autowired
    public LacService(EndpointConfiguration endpointConfiguration, LocalAccountConverterClient lacClient, InternalAccountFormatConverter internalAccountFormatConverter) {
        this.endpointConfiguration = endpointConfiguration;
        this.lacClient = lacClient;
        this.internalAccountFormatConverter = internalAccountFormatConverter;
    }


    public InternalTransferAccountsDetails getAccountsDetails(LocalAccountNumber accountFrom, LocalAccountNumber accountTo) throws GeneralException {
        InternalAccountDetails internalAccountFromDetails = new InternalAccountDetails();
        internalAccountFromDetails.setLocalAccountNumber(accountFrom);

        InternalAccountDetails internalAccountToDetails = new InternalAccountDetails();
        internalAccountToDetails.setLocalAccountNumber(accountTo);

        String accountFromStringFormat = formatSavingAccount(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(accountFrom));
        String accountToStringFormat = formatSavingAccount(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(accountTo));

        String accountFromPartenonStringFormat = lacClient.localAccountToPartenonFormat(endpointConfiguration.getLacUrl(), accountFromStringFormat);
        String accountToPartenonStringFormat = lacClient.localAccountToPartenonFormat(endpointConfiguration.getLacUrl(), accountToStringFormat);

        internalAccountFromDetails.setPartenonAccountNumber(internalAccountFormatConverter.convertStringToPartenonAccountNumber(accountFromPartenonStringFormat));
        internalAccountToDetails.setPartenonAccountNumber(internalAccountFormatConverter.convertStringToPartenonAccountNumber(accountToPartenonStringFormat));

        return generateInternalTransferAccountDetails(internalAccountFromDetails, internalAccountToDetails);
    }

    public PartenonAccountNumber getPartenonAccountNumber(String sortCodeAccountNumber) throws GeneralException {
        PartenonAccountNumber partenonAccountNumber = null;
        String accountFromPartenonStringFormat = lacClient.localAccountToPartenonFormat(endpointConfiguration.getLacUrl(), sortCodeAccountNumber);
        partenonAccountNumber = internalAccountFormatConverter.convertStringToPartenonAccountNumber(accountFromPartenonStringFormat);
        return partenonAccountNumber;
    }

    private String formatSavingAccount(String account) {
        if (account.startsWith("SAVING")) {
            return account.trim().length() > 15 ? account.substring(0, 15) : account;
        } else {
            return account;
        }
    }

    private InternalTransferAccountsDetails generateInternalTransferAccountDetails(InternalAccountDetails internalAccountFromDetails, InternalAccountDetails internalAccountToDetails) {
        InternalTransferAccountsDetails internalTransferAccountsDetails = new InternalTransferAccountsDetails();
        internalTransferAccountsDetails.setAccountFrom(internalAccountFromDetails);
        internalTransferAccountsDetails.setAccountTo(internalAccountToDetails);
        return internalTransferAccountsDetails;
    }
}
