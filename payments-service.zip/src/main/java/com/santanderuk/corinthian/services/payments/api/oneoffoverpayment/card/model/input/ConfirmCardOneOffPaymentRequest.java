package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ConfirmCardOneOffPaymentRequest extends ModelBase {
    private static final long serialVersionUID = 5271446383234623769L;

    @NotBlank
    private String cres;
}
