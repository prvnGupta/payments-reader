package com.santanderuk.corinthian.services.payments.api.regularoverpayment.validation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OStruc;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import static com.santanderuk.corinthian.services.commons.exceptions.ValidationsException.Type.EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS;
import static com.santanderuk.corinthian.services.commons.exceptions.ValidationsException.Type.EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE;
import static java.math.RoundingMode.HALF_UP;

@Component
public class RegularOVRPMaxInputAmountRule implements ValidationRule {


    private static boolean isERC(OActiveLoanDetail loan) {
        return "Y".equalsIgnoreCase(loan.getOErcDetailsGrp().getOErcApplFlag());
    }

    private static boolean isNotERC(OActiveLoanDetail loan) {
        return !isERC(loan);
    }

    @Override
    public void validate(RegularOverpaymentContext regularOverpaymentContext) throws ValidationsException {
        List<OActiveLoanDetail> filteredLoanList = filter3D3FLoanScheme(regularOverpaymentContext.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails());
        validateMaxAmount(regularOverpaymentContext, filteredLoanList);
    }

    private void validateMaxAmount(RegularOverpaymentContext regularOverpaymentContext, List<OActiveLoanDetail> loanList) throws ValidationsException {

        boolean isSingleLoan = loanList.size() == 1;
        if (isSingleLoan) {
            validateSingleLoanMaxAmount(regularOverpaymentContext, loanList);
        } else {
            validateMultiLoanMaxAmount(regularOverpaymentContext, loanList);
        }
    }

    private void validateSingleLoanMaxAmount(RegularOverpaymentContext regularOverpaymentContext, List<OActiveLoanDetail> loanList) throws ValidationsException {
        final var account = regularOverpaymentContext.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc();

        var firstLoan = loanList.get(0);
        if (isERC(firstLoan)) {
            checkERCAllowance(regularOverpaymentContext, firstLoan.getOErcDetailsGrp().getOProdErc().getOTotProdErcAllow());
        } else {
            var amount = subtractingBalanceFromThreeMonthlyPayments(addingCapitalAndArrearsBalance(account), account.getOContMonPay());
            checkBalanceMinus3Months(regularOverpaymentContext, amount);
        }
    }

    private BigDecimal subtractingBalanceFromThreeMonthlyPayments(BigDecimal outstandingBalance, BigDecimal monthlyPayments) {
        return outstandingBalance.subtract(monthlyPayments.multiply(new BigDecimal("3")).setScale(2, HALF_UP));
    }

    private void validateMultiLoanMaxAmount(RegularOverpaymentContext regularOverpaymentContext, List<OActiveLoanDetail> loanList) throws ValidationsException {

        final var account = regularOverpaymentContext.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc();

        if (allLoansHasErc(loanList)) {
            checkERCAllowance(regularOverpaymentContext, addingAmountsForUniqueProduct(loanList));
        } else if (noLoansHasErc(loanList)) {
            checkBalanceMinus3Months(regularOverpaymentContext, subtractingBalanceFromThreeMonthlyPayments(addingCapitalAndArrearsBalance(account), account.getOContMonPay()));
        } else {
            mixedERCLoans(regularOverpaymentContext, loanList);
        }
    }

    private boolean allLoansHasErc(List<OActiveLoanDetail> loans) {
        int count = (int) loans.stream().filter(this::hasErcAndIsFixedOnly).count();
        return count == loans.size();
    }

    private BigDecimal addingAmountsForUniqueProduct(List<OActiveLoanDetail> loanList) {
        var products = new HashSet<String>();
        var amount = BigDecimal.ZERO;
        for (var loan : loanList) {
            amount = totalAmountsForUniqueProduct(products, amount, loan);
        }
        return amount;
    }

    private BigDecimal totalAmountsForUniqueProduct(HashSet<String> products, BigDecimal amount, OActiveLoanDetail loan) {
        if (!products.contains(loan.getOProductCode())) {
            products.add(loan.getOProductCode());
            amount = amount.add(loan.getOErcDetailsGrp().getOProdErc().getOTotProdErcAllow());
        }
        return amount;
    }

    private boolean noLoansHasErc(List<OActiveLoanDetail> loans) {
        int count = (int) loans.stream().filter(RegularOVRPMaxInputAmountRule::isNotERC).count();
        return count == loans.size();
    }

    private boolean hasErcAndIsFixedOnly(OActiveLoanDetail oLoan) {
        return oLoan.getOErcDetailsGrp().getOErcApplFlag().equalsIgnoreCase("Y") && oLoan.getOProductDesc().toLowerCase().contains("year fixed");
    }

    private void mixedERCLoans(RegularOverpaymentContext regularOverpaymentContext, List<OActiveLoanDetail> loanList) throws ValidationsException {

        final var account = regularOverpaymentContext.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc();

        var ercAllowancePlusLoanBalanceAmount = BigDecimal.ZERO;
        var balanceMinusThreeMonthlyPaymentAmount = subtractingBalanceFromThreeMonthlyPayments(addingCapitalAndArrearsBalance(account), account.getOContMonPay());

        Set<String> products = new HashSet<>();
        for (var loan : loanList) {
            if (hasErcAndIsFixedOnly(loan)) {
                if (!products.contains(loan.getOProductCode())) {
                    products.add(loan.getOProductCode());
                    ercAllowancePlusLoanBalanceAmount = ercAllowancePlusLoanBalanceAmount.add(loan.getOErcDetailsGrp().getOProdErc().getOTotProdErcAllow());
                }
            } else {
                ercAllowancePlusLoanBalanceAmount = ercAllowancePlusLoanBalanceAmount.add(addingCapitalArrearsRecBalance(loan));
            }
        }
        if (ercAllowancePlusLoanBalanceAmount.compareTo(balanceMinusThreeMonthlyPaymentAmount) > 0) {
            checkBalanceMinus3Months(regularOverpaymentContext, balanceMinusThreeMonthlyPaymentAmount);
        } else {
            checkERCAllowance(regularOverpaymentContext, ercAllowancePlusLoanBalanceAmount);
        }
    }

    private List<OActiveLoanDetail> filter3D3FLoanScheme(List<OActiveLoanDetail> anmfLoanParts) {

        return anmfLoanParts.stream()
                .filter(anmfLoanPart -> partIsAllowed(anmfLoanPart.getOLoanScheme()))
                .collect(Collectors.toList());
    }

    private Boolean partIsAllowed(String loanScheme) {
        var notAllowedSchemes = Arrays.asList("3D", "3F");
        return !notAllowedSchemes.contains(loanScheme);
    }

    private BigDecimal addingCapitalAndArrearsBalance(OStruc anmfAccount) {

        var capitalBalance = anmfAccount.getOCapitalBalance();
        var arrearsBalanceTotal = arrearsBalanceTotal(anmfAccount);

        return capitalBalance.add(arrearsBalanceTotal);
    }

    private BigDecimal arrearsBalanceTotal(OStruc anmfAccountInfoResponse) {

        var arrearsBalance = anmfAccountInfoResponse.getOArrearsBalance();
        var sundriesArrears = anmfAccountInfoResponse.getOSundriesArrears();
        var recBalance = anmfAccountInfoResponse.getORecBalance();
        var sundriesRec = anmfAccountInfoResponse.getOSundriesRec();

        return arrearsBalance.add(sundriesArrears).add(recBalance).add(sundriesRec);
    }

    private BigDecimal addingCapitalArrearsRecBalance(OActiveLoanDetail oLoan) {

        var capitalBalance = oLoan.getOCapitalBalance();
        var arrearsBalance = oLoan.getOArrearsBalance();
        var drawdownLeft = oLoan.getODrawdownLeft();
        var recBalance = oLoan.getORecBalance();

        return capitalBalance.add(arrearsBalance).add(drawdownLeft).add(recBalance).setScale(2, HALF_UP);
    }

    private void checkBalanceMinus3Months(RegularOverpaymentContext regularOverpaymentContext, BigDecimal amount) throws ValidationsException {
        if (regularOverpaymentContext.getControllerRequest().getOverpaymentAmount().compareTo(amount) > 0) {
            throw new ValidationsException(EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_BALANCE_MINUS_3_MONTHS);
        }
    }

    private void checkERCAllowance(RegularOverpaymentContext regularOverpaymentContext, BigDecimal amount) throws ValidationsException {
        if (regularOverpaymentContext.getControllerRequest().getOverpaymentAmount().compareTo(amount) > 0) {
            throw new ValidationsException(EXC_FUNCTIONAL_VALIDATION_AMOUNT_MORE_THAN_ERC_ALLOWANCE);
        }
    }
}
