package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cps;

import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
public class CPSCardPaymentRequest extends ModelBase {

    private String agentCode;
    private BigDecimal amount;
    private String bankAuthorisationCode;
    private String birthDate;
    private String cardId;
    private String contractAccountNumber;
    private String contractBranch;
    private String contractEntity;
    private String contractId;
    private String contractProduct;
    private String currency;
    private String expiryDate;
    private int issueNumber;
    private String line1;
    private String merchantId;
    private String number;
    private String numberAnt;
    private String personName;
    private int personNumber;
    private String personType;
    private String postCodeIdentification;
    private String postCodeRegular;
    private String printedName;
    private String process;
    private String startDate;
    private String statusCode;
    private String statusDetail;
    private String transactionId;
    private String vendorCode;

}
