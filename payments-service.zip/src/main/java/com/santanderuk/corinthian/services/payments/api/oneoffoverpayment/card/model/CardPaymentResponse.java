package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class CardPaymentResponse {
    private boolean paymentDone;
    private String transactionId;
    private ThreeDSDetails threeDSDetails;
    private String base64Pdf;
    private boolean usingOwnSantanderCard;
}
