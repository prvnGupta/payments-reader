package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by c0245070 on 12/07/2017.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"company", "centre", "product", "contract", "overpaymentAmount", "currency", "residenceCountry", "transactionBranch", "expensesIndicator", "transmissionType"})
public class SetupRequest {

    @JsonProperty("company")
    private String company;
    @JsonProperty("centre")
    private String centre;
    @JsonProperty("product")
    private String product;
    @JsonProperty("contract")
    private String contract;
    @JsonProperty("overpaymentAmount")
    private double overpaymentAmount;
    @JsonProperty("currency")
    private String currency;
    @JsonProperty("residenceCountry")
    private String residenceCountry;
    @JsonProperty("transactionBranch")
    private String transactionBranch;
    @JsonProperty("expensesIndicator")
    private String expensesIndicator;
    @JsonProperty("transmissionType")
    private String transmissionType;


    public SetupRequest() {
    }

    public SetupRequest(String company, String centre, String product, String contract, double overpaymentAmount, String currency, String residenceCountry, String transactionBranch, String expensesIndicator, String transmissionType) {
        this.company = company;
        this.centre = centre;
        this.product = product;
        this.contract = contract;
        this.overpaymentAmount = overpaymentAmount;
        this.currency = currency;
        this.residenceCountry = residenceCountry;
        this.transactionBranch = transactionBranch;
        this.expensesIndicator = expensesIndicator;
        this.transmissionType = transmissionType;
    }

    @JsonProperty("company")
    public String getCompany() {
        return company;
    }

    @JsonProperty("company")
    public void setCompany(String company) {
        this.company = company;
    }

    @JsonProperty("centre")
    public String getCentre() {
        return centre;
    }

    @JsonProperty("centre")
    public void setCentre(String centre) {
        this.centre = centre;
    }

    @JsonProperty("product")
    public String getProduct() {
        return product;
    }

    @JsonProperty("product")
    public void setProduct(String product) {
        this.product = product;
    }

    @JsonProperty("contract")
    public String getContract() {
        return contract;
    }

    @JsonProperty("contract")
    public void setContract(String contract) {
        this.contract = contract;
    }

    @JsonProperty("overpaymentAmount")
    public double getOverpaymentAmount() {
        return overpaymentAmount;
    }

    @JsonProperty("overpaymentAmount")
    public void setOverpaymentAmount(double overpaymentAmount) {
        this.overpaymentAmount = overpaymentAmount;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("residenceCountry")
    public String getResidenceCountry() {
        return residenceCountry;
    }

    @JsonProperty("residenceCountry")
    public void setResidenceCountry(String residenceCountry) {
        this.residenceCountry = residenceCountry;
    }

    @JsonProperty("transactionBranch")
    public String getTransactionBranch() {
        return transactionBranch;
    }

    @JsonProperty("transactionBranch")
    public void setTransactionBranch(String transactionBranch) {
        this.transactionBranch = transactionBranch;
    }

    @JsonProperty("expensesIndicator")
    public String getExpensesIndicator() {
        return expensesIndicator;
    }

    @JsonProperty("expensesIndicator")
    public void setExpensesIndicator(String expensesIndicator) {
        this.expensesIndicator = expensesIndicator;
    }

    @JsonProperty("transmissionType")
    public String getTransmissionType() {
        return transmissionType;
    }

    @JsonProperty("transmissionType")
    public void setTransmissionType(String transmissionType) {
        this.transmissionType = transmissionType;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("company", company)
                .append("centre", centre)
                .append("product", product)
                .append("contract", contract)
                .append("overpaymentAmount", overpaymentAmount)
                .append("currency", currency)
                .append("residenceCountry", residenceCountry)
                .append("transactionBranch", transactionBranch)
                .append("expensesIndicator", expensesIndicator)
                .append("transmissionType", transmissionType)
                .toString();
    }
}
