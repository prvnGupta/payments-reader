package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SetUpRegularOverpaymentServiceInput extends ModelBase {
    private static final long serialVersionUID = 5682386489243134432L;

    @NotNull
    private BigDecimal overpaymentAmount;

    @NotNull
    @Pattern(regexp = "^\\d{2}\\/\\d{2}\\/\\d{4}$")
    private String startDate;

    @NotNull
    private String endDate;

    @NotNull
    @Valid
    private List<Loan> loans;

    @Override
    public String toString() {
        return ReflectionToStringBuilder.toString(this, ToStringStyle.JSON_STYLE);
    }

}
