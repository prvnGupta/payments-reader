package com.santanderuk.corinthian.services.payments.api.regularoverpayment;


import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.OActiveLoanDetail;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.ILoanData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.OverpaymentArrangementRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.RegularOverpaymentInput;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.config.PaymentServiceConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class RegularOverpaymentMapper {

    private final PaymentServiceConfig config;

    public RegularOverpaymentMapper(PaymentServiceConfig config) {
        this.config = config;
    }

    public AnmfRegularOverpaymentCUDRequest generateDeleteRequest(final RegularOverpaymentContext context) {
        RegularOverpaymentInput setUpInputStruct = buildRegularOverpaymentInput("cancel");

        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(context.getJwtToken());
        setUpInputStruct.setIBdpType(bdpCustomer.getCustomerType());
        setUpInputStruct.setIBdpNumber(bdpCustomer.getCustomerNumber());

        setUpInputStruct.setIMortAccNo(context.getAccount());
        setUpInputStruct.setIOvpInstSeq(context.getSequential());
        setUpInputStruct.setIOvpInstAction(context.getInstructionAction());

        setUpInputStruct.setIOvpInstImpact(context.getInstruction().getOPayArrImpact());
        setUpInputStruct.setIOvpInstEndDate(context.getInstruction().getOPayArrEndDate());
        setUpInputStruct.setIOvpInstNoEndDate(coerceToYorN(context.getInstruction().getOPayArrNoEndDate()));
        setUpInputStruct.setIOvpInstStartDate(context.getInstruction().getOPayArrStartDate());

        BigDecimal totalPaymentAmount = context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay().add(BigDecimal.valueOf(context.getInstruction().getOPayArrMonPay()));
        setUpInputStruct.setIOvpInstTotMonPay(totalPaymentAmount);

        OverpaymentArrangementRequest overpaymentArrangementRequest = new OverpaymentArrangementRequest();
        overpaymentArrangementRequest.setInputStruc(setUpInputStruct);

        AnmfRegularOverpaymentCUDRequest deleteRequest = new AnmfRegularOverpaymentCUDRequest();
        deleteRequest.setOverpaymentArrangementRequest(overpaymentArrangementRequest);

        return deleteRequest;
    }

    private String coerceToYorN(String noEndDate) {
        return noEndDate.equalsIgnoreCase("YES") ? "Y" : "N";
    }


    public AnmfRegularOverpaymentCUDRequest generateSetUpEditCoreRequest(final RegularOverpaymentContext context) {
        RegularOverpaymentInput setUpInputStruct = buildRegularOverpaymentInput("edit");

        setUpInputStruct.setILoanDatas(buildILoanData(context.getControllerRequest()));

        BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(context.getJwtToken());
        setUpInputStruct.setIBdpType(bdpCustomer.getCustomerType());
        setUpInputStruct.setIBdpNumber(bdpCustomer.getCustomerNumber());

        setUpInputStruct.setIMortAccNo(context.getAccount());
        setUpInputStruct.setIOvpInstEndDate(context.getControllerRequest().getEndDate());
        setOvpInstImpact(context, setUpInputStruct);
        setUpInputStruct.setIOvpInstSeq(context.getSequential());
        setUpInputStruct.setIOvpInstAction(context.getInstructionAction());

        if (context.getControllerRequest().getEndDate().equalsIgnoreCase("untilfurthernotice")) {
            setUpInputStruct.setIOvpInstNoEndDate("Y");
            setUpInputStruct.setIOvpInstEndDate("");
        } else {
            setUpInputStruct.setIOvpInstNoEndDate("N");
            setUpInputStruct.setIOvpInstEndDate(context.getControllerRequest().getEndDate());
        }

        setUpInputStruct.setIOvpInstStartDate(context.getControllerRequest().getStartDate());
        BigDecimal totalPaymentAmount = context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay().add(context.getControllerRequest().getOverpaymentAmount());
        setUpInputStruct.setIOvpInstTotMonPay(totalPaymentAmount);

        OverpaymentArrangementRequest overpaymentArrangementRequest = new OverpaymentArrangementRequest();
        overpaymentArrangementRequest.setInputStruc(setUpInputStruct);

        AnmfRegularOverpaymentCUDRequest anmfSetupRegularRequest = new AnmfRegularOverpaymentCUDRequest();
        anmfSetupRegularRequest.setOverpaymentArrangementRequest(overpaymentArrangementRequest);

        return anmfSetupRegularRequest;
    }

    private void setOvpInstImpact(RegularOverpaymentContext context, RegularOverpaymentInput setUpInputStruct) {
        List<OActiveLoanDetail> activeLoansOnly = context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOActiveLoanDetails().stream()
                .filter(OActiveLoanDetail -> isActiveLoan(OActiveLoanDetail.getOLoanScheme())).collect(Collectors.toList());

        setUpInputStruct.setIOvpInstImpact("T"); //default value
        activeLoansOnly.forEach(OActiveLoanDetail -> {
            if (OActiveLoanDetail.getORepaymentType().equalsIgnoreCase("I")) {
                setUpInputStruct.setIOvpInstImpact("");
            }
        });
    }

    private boolean isActiveLoan(String loanScheme) {
        List<String> notAllowedSchemes = Arrays.asList("3D", "3F");
        return !notAllowedSchemes.contains(loanScheme);
    }

    private RegularOverpaymentInput buildRegularOverpaymentInput(String editOrCancel) {
        RegularOverpaymentInput setUpInputStruct = new RegularOverpaymentInput();
        setUpInputStruct.setIChannelType(config.getSetUpRegularInstructionChannelType());
        setUpInputStruct.setICallingAppl(config.getSetUpRegularInstructionCallingApp());
        setUpInputStruct.setISourceAppl(config.getSetUpRegularInstructionSourceApp());
        setUpInputStruct.setIPayarrType(config.getSetUpRegularInstructionType());
        setUpInputStruct.setIOvpInstToUse(config.getSetUpRegularInstructionToUse());
        if (editOrCancel.equalsIgnoreCase("cancel")) {
            setUpInputStruct.setIOvpInstCancelReason("6");
        }
        setUpInputStruct.setIUserId(config.getSetUpRegularUserId());
        return setUpInputStruct;
    }


    private List<ILoanData> buildILoanData(final SetUpRegularOverpaymentServiceInput controllerRequest) {

        final var loanDatas = new ArrayList<ILoanData>();

        for (var loan : controllerRequest.getLoans()) {
            var loanData = new ILoanData();
            loanData.setIApplSeqNo(loan.getAppSequenceNumber());
            loanData.setILoanSch(loan.getLoanSchema());
            loanData.setILoanOrder(loan.getOrderId());
            loanData.setIOvpInstStopErc(config.getSetUpRegularInstructionStopErc());

            loanDatas.add(loanData);
        }


        return loanDatas;
    }

}
