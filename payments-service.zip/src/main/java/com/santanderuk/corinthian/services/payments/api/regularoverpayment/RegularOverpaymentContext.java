package com.santanderuk.corinthian.services.payments.api.regularoverpayment;

import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentFormattedData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.loanpaymentplan.AnmfLoanPaymentPlanResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.OPayArrOvpInst;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.MccContract;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegularOverpaymentContext {
    private AnmfAccountServiceResponse anmfAccountResponse;
    private AnmfLoanPaymentPlanResponse anmfLoanPaymentPlanResponse;
    private CustomerDetailsResponse customerDetailsResponse;
    private AnmfRegularOverpaymentCUDResponse anmfSetupRegularResponse;
    private String ipAddress;
    private SetUpRegularOverpaymentServiceInput controllerRequest;
    private String jwtToken;
    private int account;
    private SetUpRegularOverpaymentFormattedData formattedData;
    private MccContract mccContract;
    private String ldapUid;
    private String resultIndicatorForGass;
    private AnmfRegion anmfRegion;
    private Integer sequential;
    private String instructionAction;
    private OPayArrOvpInst instruction;
}
