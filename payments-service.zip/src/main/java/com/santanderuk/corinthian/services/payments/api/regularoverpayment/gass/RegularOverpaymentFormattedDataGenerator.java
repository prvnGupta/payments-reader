package com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Borrower;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted.CancelRegularRegularOverpaymentFormattedData;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted.CreateEditRegularOverpaymentRegularOverpaymentFormattedData;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.formatted.FormattedLoan;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.MONTHS;

@Component
public class RegularOverpaymentFormattedDataGenerator {

    private final GassDataFetcher gassDataFetcher;

    @Autowired
    public RegularOverpaymentFormattedDataGenerator(GassDataFetcher gassDataFetcher) {
        this.gassDataFetcher = gassDataFetcher;
    }

    public CreateEditRegularOverpaymentRegularOverpaymentFormattedData createEditRegularOverpaymentFormattedData(int accountNumber, String jwtToken, SetUpRegularOverpaymentServiceInput controllerRequest, CustomerDetailsResponse customerDetailsResponse, RegularOverpaymentContext context) {

        List<OCustomer> customerList = customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList();
        Borrower borrower = gassDataFetcher.toFormattedDataBorrowerList(customerList);

        CreateEditRegularOverpaymentRegularOverpaymentFormattedData formattedData = new CreateEditRegularOverpaymentRegularOverpaymentFormattedData();

        BigDecimal directDebitTotalAmount = controllerRequest.getOverpaymentAmount()
                .add(context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay());

        formattedData.setCustomerNumber(gassDataFetcher.fetchCustomerNumber(jwtToken));
        formattedData.setBorrowerList(borrower);
        formattedData.setMultiChannelContractId(gassDataFetcher.fetchMccIdFromJwt(jwtToken));
        formattedData.setMortgageAccountNumber(gassDataFetcher.fetchMortgageAccountNumber(accountNumber));
        formattedData.setContractualMonthlyPaymentAmount(
                toFormattedString(context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay()));
        formattedData.setOverpaymentAmount(controllerRequest.getOverpaymentAmount().toPlainString());
        formattedData.setDirectDebitTotalAmount(toFormattedString(directDebitTotalAmount));
        formattedData.setStartDate(controllerRequest.getStartDate());
        formattedData.setEndDate(controllerRequest.getEndDate());
        formattedData.setNumberOfPayments(
                calculateNumberOfPayments(controllerRequest.getStartDate(), controllerRequest.getEndDate()));
        formattedData.setOverpaymentEffect(fetchOverpaymentType(controllerRequest.getLoans()));
        formattedData.setOriginAccount(gassDataFetcher.fetchOriginAccount(accountNumber));
        formattedData.setDestinationAccount(StringUtils.leftPad(String.valueOf(accountNumber), 9, '0'));
        formattedData.setFormattedLoans(mapLoans(controllerRequest.getLoans()));
        return formattedData;
    }

    private List<FormattedLoan> mapLoans(List<Loan> loans) {
        List<Loan> sortByOrderId = loans.stream()
                .sorted(Comparator.comparing(Loan::getOrderId))
                .collect(Collectors.toList());

        List<FormattedLoan> gassLoanList = new ArrayList<>();
        sortByOrderId.forEach(loan -> {
            FormattedLoan formattedLoan = new FormattedLoan();
            formattedLoan.setLoanSchema(loan.getLoanSchema());
            formattedLoan.setLoanType(loan.getLoanType());
            formattedLoan.setAppSequenceNumber(loan.getAppSequenceNumber());
            formattedLoan.setOrderId(loan.getOrderId());
            gassLoanList.add(formattedLoan);
        });
        return gassLoanList;
    }

    public CancelRegularRegularOverpaymentFormattedData createCancelFormattedData(int accountNumber, String jwtToken, String impact,
                                                                                  CustomerDetailsResponse customerDetailsResponse, RegularOverpaymentContext context) {
        CancelRegularRegularOverpaymentFormattedData cancelRegularFormattedData = new CancelRegularRegularOverpaymentFormattedData();

        List<OCustomer> oCustomerList = customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList();
        Borrower borrower = gassDataFetcher.toFormattedDataBorrowerList(oCustomerList);

        cancelRegularFormattedData.setCustomerNumber(gassDataFetcher.fetchCustomerNumber(jwtToken));
        cancelRegularFormattedData.setBorrowerList(borrower);
        cancelRegularFormattedData.setMultiChannelContractId(gassDataFetcher.fetchMccIdFromJwt(jwtToken));
        cancelRegularFormattedData.setMortgageAccountNumber(gassDataFetcher.fetchMortgageAccountNumber(accountNumber));
        cancelRegularFormattedData.setContractualMonthlyPaymentAmount(toFormattedString(context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay()));
        cancelRegularFormattedData.setOverpaymentAmount("0.00");
        cancelRegularFormattedData.setDirectDebitTotalAmount(toFormattedString(context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay()));
        cancelRegularFormattedData.setOverpaymentCancellationEffectiveDate(gassDataFetcher.fetchOverpaymentCancellationEffectiveDate(accountNumber));
        cancelRegularFormattedData.setOriginAccount(gassDataFetcher.fetchOriginAccount(accountNumber));
        cancelRegularFormattedData.setDestinationAccount(StringUtils.leftPad(String.valueOf(accountNumber), 9, '0'));
        cancelRegularFormattedData.setOverpaymentEffect(impact);

        return cancelRegularFormattedData;
    }


    private String toFormattedString(BigDecimal amount) {
        return String.format("%.2f", amount);
    }

    private String calculateNumberOfPayments(final String startDate, final String endDate) {
        if (isFurtherNotice(endDate)) {
            return "";
        } else {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
            LocalDate localDateStart = LocalDate.parse(startDate, formatter);
            LocalDate localDateEnd = LocalDate.parse(endDate, formatter);

            return String.valueOf(MONTHS.between(localDateStart, localDateEnd) + 1);
        }
    }

    private boolean isFurtherNotice(final String endDate) {
        return "untilfurthernotice".equalsIgnoreCase(endDate.trim());
    }

    private String fetchOverpaymentType(@NotNull @Valid List<Loan> loanList) {
        for (Loan loan : loanList) {
            if ("I".equalsIgnoreCase(loan.getLoanType().trim())) {
                return "M";
            }
        }
        return "T";
    }
}
