package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io;

import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ServiceInfoWrapper {
    private static final long serialVersionUID = 8698137884884507741L;
    private ServiceInfo info;
}
