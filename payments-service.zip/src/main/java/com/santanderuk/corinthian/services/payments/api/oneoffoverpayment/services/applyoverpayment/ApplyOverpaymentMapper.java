package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.applyoverpayment;

import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.*;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class ApplyOverpaymentMapper {
    @Autowired
    public ApplyOverpaymentMapper() {
    }

    public ApplyOverpaymentRequest generateApplyOverpaymentRequest(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext, String upr) {
        ApplyOverpaymentRequest applyOverpaymentRequest = new ApplyOverpaymentRequest();
        applyOverpaymentRequest.setCreateWsPayReceivedRequest(generateCreateWsPayReceivedRequest(mortgageSingleOverpaymentsContext, upr));
        return applyOverpaymentRequest;
    }


    private CreateWsPayReceivedRequest generateCreateWsPayReceivedRequest(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext, String upr) {
        CreateWsPayReceivedRequest createWsPayReceivedRequest = new CreateWsPayReceivedRequest();
        Request request = new Request();
        InputStruct inputStruct = new InputStruct();
        IO32129 io32129 = new IO32129();

        io32129.setIAccountNo(mortgageSingleOverpaymentsContext.getMortgageAccount());
        io32129.setIPmtTypeIn("OVR");
        io32129.setISimPmtMeth("TT");
        io32129.setISimulatorId(mortgageSingleOverpaymentsContext.getSimIdV2());
        io32129.setISimValDate(getTodayDateInANMFFormat());
        io32129.setIAmount(mortgageSingleOverpaymentsContext.getUpdatedSimulationResponse().getOTotPayment());
        io32129.setIUpr(upr);

        inputStruct.setIo32129(io32129);
        request.setInputStruct(inputStruct);
        createWsPayReceivedRequest.setRequest(request);

        return createWsPayReceivedRequest;
    }

    private String getTodayDateInANMFFormat() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

}
