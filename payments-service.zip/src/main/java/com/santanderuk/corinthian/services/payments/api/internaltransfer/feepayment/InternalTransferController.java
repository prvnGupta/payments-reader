package com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.payments.api.BaseController;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.InternalTransferService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import static org.springframework.http.HttpStatus.OK;

@RestController
@Slf4j
public class InternalTransferController extends BaseController {

    private final InternalTransferService internalTransferService;

    @Autowired
    public InternalTransferController(InternalTransferService internalTransferService) {
        this.internalTransferService = internalTransferService;
    }

    @PostMapping(
            value = "/internal-transfer",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public final ResponseEntity<InternalTransferResponseWrapper> payInternalPayment(
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @Valid @RequestBody InternalTransferRequest internalTransferRequest,
            HttpServletRequest httpServletRequest) throws GeneralException, PaymentsFuncException, FraudException {

        InternalTransferResponse response = internalTransferService.makePayment(internalTransferRequest, JwtUtilities.getLdapUidFromJWT(jwtToken), extractIpAddress(httpServletRequest));
        return buildInternalTransferResponse(response);
    }

    private ResponseEntity<InternalTransferResponseWrapper> buildInternalTransferResponse(InternalTransferResponse response) {
        InternalTransferResponseWrapper internalTransferResponseWrapper = new InternalTransferResponseWrapper();
        internalTransferResponseWrapper.setInfo(ServiceInfoCreator.ok());
        internalTransferResponseWrapper.setResponse(response);
        return new ResponseEntity<>(internalTransferResponseWrapper, OK);
    }

    // added here because we wanted to change the exception only for one-off
    @ExceptionHandler({PaymentsFuncException.class})
    public ResponseEntity<InternalTransferResponseWrapper> handlePaymentFailedException(final PaymentsFuncException paymentsFuncException) {
        ServiceInfo info = new ServiceInfo();
        info.setMessage(paymentsFuncException.getMessage());
        info.setStatus("ko");
        info.setCode("PAYMENT_ERROR");
        InternalTransferResponseWrapper responseWrapper = new InternalTransferResponseWrapper();
        responseWrapper.setInfo(info);

        return new ResponseEntity<>(responseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler({FraudException.class})
    public ResponseEntity<InternalTransferResponseWrapper> handleFraudFailedException() {
        ServiceInfo info = new ServiceInfo();
        info.setMessage("Exception while calling LynxFraud Core Api");
        info.setCode("500");
        info.setStatus("ko");

        InternalTransferResponseWrapper responseWrapper = new InternalTransferResponseWrapper();
        responseWrapper.setInfo(info);

        return new ResponseEntity<>(responseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
