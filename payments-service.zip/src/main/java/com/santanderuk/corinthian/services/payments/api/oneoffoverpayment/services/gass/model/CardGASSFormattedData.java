package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.santanderuk.corinthian.gassaudit.model.FormattedData;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.BorrowerElement;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.CardLoanDetails;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CardGASSFormattedData implements FormattedData {

    @JacksonXmlProperty(localName = "CardNumber")
    private String cardNumber;

    @JacksonXmlProperty(localName = "CardName")
    private String cardName;

    @JacksonXmlProperty(localName = "AddressLine1")
    private String addressLine1;

    @JacksonXmlProperty(localName = "PostCode")
    private String postCode;

    @JacksonXmlProperty(localName = "CustomerName")
    private String customerName;

    @JacksonXmlProperty(localName = "BeneficiaryName")
    private String beneficiaryName;

    @JacksonXmlProperty(localName = "DateOfBirth")
    private String dateOfBirth;

    @JacksonXmlElementWrapper(localName = "BorrowerList")
    @JacksonXmlProperty(localName = "borrower")
    private List<BorrowerElement> borrowerList;

    @JacksonXmlProperty(localName = "MCCID")
    private String mccId;

    @JacksonXmlProperty(localName = "EarlyRepaymentCharge")
    private Boolean earlyRepaymentCharge;

    @JacksonXmlProperty(localName = "EarlyRepaymentChargeAmount")
    private BigDecimal earlyRepaymentChargeAmount;

    @JacksonXmlProperty(localName = "TransactionId")
    private String transactionId;

    @JacksonXmlProperty(localName = "OverPaymentAmount")
    private BigDecimal overPaymentAmount;

    @JacksonXmlProperty(localName = "Currency")
    private String currency;

    @JacksonXmlProperty(localName = "TotalAmount")
    private BigDecimal totalAmount;

    @JacksonXmlProperty(localName = "PartenonFormatMortgageAccountNumber")
    private String partenonFormatMortgageAccountNumber;

    @JacksonXmlProperty(localName = "ChannelType")
    private String channelType;

    @JacksonXmlProperty(localName = "OpayoResponseCode")
    private String opayoResponseCode;

    @JacksonXmlElementWrapper(localName = "loanDetails")
    @JacksonXmlProperty(localName = "loan")
    private List<CardLoanDetails> loanDetails;

}
