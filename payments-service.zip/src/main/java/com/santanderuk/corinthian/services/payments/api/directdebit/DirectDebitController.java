package com.santanderuk.corinthian.services.payments.api.directdebit;

import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.payments.api.BaseController;
import com.santanderuk.corinthian.services.payments.api.directdebit.io.input.DirectDebitAccount;
import com.santanderuk.corinthian.services.payments.api.directdebit.io.output.DirectDebitResponse;
import com.santanderuk.corinthian.services.payments.api.directdebit.io.output.DirectDebitResponseWrapper;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@Validated
public class DirectDebitController extends BaseController {

    private final HeartBeatClient heartBeatClient;

    public DirectDebitController(HeartBeatClient heartBeatClient) {
        this.heartBeatClient = heartBeatClient;
    }

    @ApiOperation(
            value = "Backend aggregation layer to change the direct debit account for an ANMF account number.",
            nickname = "changeDirectDebitDetails",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to to change the direct debit account for an ANMF account number."
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")})
    @PutMapping(path = "/{mortgageAccount}/change-direct-debit-details",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DirectDebitResponseWrapper> changeDirectDebitDetails(
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @PathVariable int mortgageAccount,
            @Valid @RequestBody DirectDebitAccount directDebitAccount,
            HttpServletRequest httpServletRequest
    ) throws GeneralException {

        AnmfRegion anmfRegion = heartBeatClient.fetchCurrentRegion();
        checkOperativeSecurity(mortgageAccount, jwtToken, anmfRegion);

        // code to implement in sub tickets

        return new ResponseEntity<DirectDebitResponseWrapper>(wrapResponse(new DirectDebitResponse(true)), HttpStatus.OK);

    }

    private DirectDebitResponseWrapper wrapResponse(DirectDebitResponse directDebitResponse) {
        DirectDebitResponseWrapper directDebitResponseWrapper = new DirectDebitResponseWrapper();
        directDebitResponseWrapper.setData(directDebitResponse);
        directDebitResponseWrapper.setInfo(ServiceInfoCreator.ok());
        return directDebitResponseWrapper;
    }

}
