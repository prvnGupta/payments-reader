package com.santanderuk.corinthian.services.payments.api;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.exceptions.*;
import com.santanderuk.corinthian.services.commons.model.AnmfBelongsToCustomerWithBorrowerList;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerService;
import com.santanderuk.corinthian.services.commons.operativesecurity.AnmfBelongToCustomerWithBorrowerListService;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetupRegularOverpaymentResponseWrapper;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.PaymentServiceConfig;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import javax.validation.ConstraintViolationException;
import java.util.Objects;

@Slf4j
public class BaseController {

    private static final String REGEX_CARRIAGE_RETURN = "[\r\n]";

    @Autowired
    public PaymentServiceConfig config;

    @Autowired
    public AnmfBelongToCustomerService anmfBelongToCustomerService;

    @Autowired
    public AnmfBelongToCustomerWithBorrowerListService anmfBelongToCustomerWithBorrowerListService;

    @Autowired
    public EndpointConfiguration endpointConfiguration;

    public void checkOperativeSecurity(int accountNumber, String jwtToken, AnmfRegion region) throws OperativeSecurityException, ConnectionException, ValidationsException {
        if (config.isOperativeSecurity()) {
            if (!anmfBelongToCustomerService.anmfBelongsToCustomer(accountNumber, jwtToken, endpointConfiguration.getAnmfCustomerServiceUrl(), region)) {
                log.error("Security KO. Mortgage does not belong to customer");
                throw new OperativeSecurityException("SECURITY_KO", "Mortgage does not belong to customer");
            }
        }
    }

    public CustomerDetailsResponse checkOperativeSecurityWithCustomerList(int accountNumber, String jwtToken, AnmfRegion region) throws OperativeSecurityException, ConnectionException, ValidationsException {
        AnmfBelongsToCustomerWithBorrowerList response = anmfBelongToCustomerWithBorrowerListService.anmfBelongsToCustomerWithBorrowerList(accountNumber, jwtToken, endpointConfiguration.getAnmfCustomerServiceUrl(), region);
        if (config.isOperativeSecurity()) {
            if (!response.getAnmfBelongsToCustomer()) {
                log.error("Security KO. Mortgage does not belong to customer");
                throw new OperativeSecurityException("SECURITY_KO", "Mortgage does not belong to customer");
            }
        }
        return response.getCustomerDetailsResponse();
    }

    public String sanitiseString(String stringToSanitise) {
        return stringToSanitise.replaceAll(REGEX_CARRIAGE_RETURN, "");
    }

    public String extractIpAddress(HttpServletRequest httpServletRequest) {
        String ipAddress = httpServletRequest.getHeader("X-FORWARDED-FOR");
        return StringUtils.isBlank(ipAddress) ? "127.0.0.1" : ipAddress.split(",")[0].trim();
    }

    public String extractOrigin(HttpServletRequest httpServletRequest) {
        String origin = httpServletRequest.getHeader("Origin");
        if (null == origin) {
            origin = "";
        }
        log.info("extractOrigin: {}", origin.replaceAll(REGEX_CARRIAGE_RETURN, ""));
        return StringUtils.isBlank(origin) ? "" : origin;
    }

    @ExceptionHandler(ValidationsException.class)
    public ResponseEntity<SetupRegularOverpaymentResponseWrapper> handleValidationException(final ValidationsException validationExc) {
        final SetupRegularOverpaymentResponseWrapper responseWrapper = new SetupRegularOverpaymentResponseWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.exception(validationExc));
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(GeneralException.class)
    public ResponseEntity<SetupRegularOverpaymentResponseWrapper> handleANMFCoreException(final GeneralException generalException) {
        final SetupRegularOverpaymentResponseWrapper responseWrapper = new SetupRegularOverpaymentResponseWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.exception(generalException));
        return new ResponseEntity<>(responseWrapper, HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(OperativeSecurityException.class)
    public ResponseEntity<SetupRegularOverpaymentResponseWrapper> handleOperativeSecurityException(final GeneralException generalException) {
        final SetupRegularOverpaymentResponseWrapper responseWrapper = new SetupRegularOverpaymentResponseWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.exception(generalException));
        return new ResponseEntity<>(responseWrapper, HttpStatus.UNAUTHORIZED);
    }

    @ExceptionHandler(MaintenanceException.class)
    public ResponseEntity<SetupRegularOverpaymentResponseWrapper> handleOperativeSecurityException(final MaintenanceException maintenanceException) {
        final SetupRegularOverpaymentResponseWrapper responseWrapper = new SetupRegularOverpaymentResponseWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.exception(maintenanceException));
        return new ResponseEntity<>(responseWrapper, HttpStatus.SERVICE_UNAVAILABLE);
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<MortgageSingleOverpaymentInternalTransferResponseWrapper> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        final MortgageSingleOverpaymentInternalTransferResponseWrapper responseWrapper = new MortgageSingleOverpaymentInternalTransferResponseWrapper();
        ServiceInfo info = ServiceInfoCreator.ok();
        info.setStatus("ko");
        info.setCode("BAD_REQUEST");
        info.setMessage(Objects.requireNonNull(ex.getBindingResult().getFieldError()).getField() + " is invalid");
        responseWrapper.setInfo(info);
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ConstraintViolationException.class)
    ResponseEntity<MortgageSingleOverpaymentInternalTransferResponseWrapper> handleConstraintViolationException(ConstraintViolationException cve) {
        final MortgageSingleOverpaymentInternalTransferResponseWrapper responseWrapper = new MortgageSingleOverpaymentInternalTransferResponseWrapper();
        ServiceInfo info = ServiceInfoCreator.ok();
        info.setStatus("ko");
        info.setCode("BAD_REQUEST");
        info.setMessage(cve.getConstraintViolations().stream().iterator().next().getMessage());
        responseWrapper.setInfo(info);
        return new ResponseEntity<>(responseWrapper, HttpStatus.BAD_REQUEST);
    }
}
