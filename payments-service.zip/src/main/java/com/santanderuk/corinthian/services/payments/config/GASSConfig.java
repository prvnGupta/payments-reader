package com.santanderuk.corinthian.services.payments.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;


@Configuration
@Getter
@Setter
public class GASSConfig {

    @Value("${gass.defaultvalues.trngrpid}")
    private int auditTrnGrpId;

    @Value("${gass.defaultvalues.authcdcompsysid}")
    private String authCdUserCompSysId;

    @Value("${gass.defaultvalues.compsysid}")
    private String instGrUserCompSysId;

    @Value("${gass.defaultvalues.orgid}")
    private String orgId;

    @Value("${gass.defaultvalues.orguttp}")
    private String orgUttp;

    @Value("${gass.defaultvalues.orgutid}")
    private String orgUtId;

    @Value("${gass.defaultvalues.authcduser}")
    private String authCdUser;

    @Value("${gass.defaultvalues.trntpnamedebitcard}")
    private String transactionNameDebitCardPayment;

    @Value("${gass.defaultvalues.dvctyp}")
    private String dvcTypInternet;

    @Value("${gass.defaultvalues.appsysid}")
    private String appSysIdInternet;
}

