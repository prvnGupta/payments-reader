package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational;


import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

public class CardOperationalException extends GeneralException {
    public CardOperationalException(String code, String message) {
        super(code, message);
    }

    public CardOperationalException(String code, String message, Exception e) {
        super(code, message, e);
    }
}


