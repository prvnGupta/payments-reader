package com.santanderuk.corinthian.services.payments.api.regularoverpayment.validation;

import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;

public interface ValidationRule {
    void validate(RegularOverpaymentContext regularOverpaymentContext) throws ValidationsException;
}
