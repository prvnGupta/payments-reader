package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup;

import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class SetupPaymentClient {
    private final RestTemplate restTemplate;
    private final OverpaymentsConfig overpaymentsConfig;

    @Autowired
    public SetupPaymentClient(RestTemplate paymentRestTemplate, OverpaymentsConfig overpaymentsConfig) {
        this.restTemplate = paymentRestTemplate;
        this.overpaymentsConfig = overpaymentsConfig;
    }

    public SetupResponse callSetup(SetupRequest setupRequest) throws PaymentsFuncException {

        try {
            log.info("About to call SetupPayment Core Api");

            HttpEntity<SetupRequest> httpEntity = createHttpEntity(setupRequest);

            ResponseEntity<SetupResponse> responseEntity = restTemplate.postForEntity(
                    overpaymentsConfig.getSetupEndpoint(),
                    httpEntity,
                    SetupResponse.class
            );
            SetupResponse response = responseEntity.getBody();

            checkSetupPaymentResponse(response);

            return response;
        } catch (Exception e) {
            log.warn("Exception while calling SetupPayment Core Api", e);
            throw new PaymentsFuncException("PAYMENT_ERROR_SPE", e);
        }
    }

    private void checkSetupPaymentResponse(SetupResponse response) throws PaymentsFuncException {
        log.debug("Setup Payment Core Api response: {}", response);

        if (setupPaymentOk(response)) {
            log.info("Setup Payment Core Api executed OK");
        } else {
            log.warn("InternalTransferDataAccess -> Payment Setup failed");
            throw new PaymentsFuncException("setup ko");
        }
    }

    private HttpEntity<SetupRequest> createHttpEntity(SetupRequest setupRequest) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-Client-Id", overpaymentsConfig.getClientId());
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(setupRequest, headers);
    }

    private boolean setupPaymentOk(SetupResponse setupResponse) {
        return !setupResponse.getStatus().equalsIgnoreCase("KO");
    }

}
