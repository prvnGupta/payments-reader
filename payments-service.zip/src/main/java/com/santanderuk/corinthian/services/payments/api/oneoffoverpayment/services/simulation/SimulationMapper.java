package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.*;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service
public class SimulationMapper {
    public static final String EMPTY_SIMULATION_PAYMENT_METHOD = "";
    public static final String PAYMENT_METHOD_TT = "TT";
    public static final String PAYMENT_METHOD_DC = "DC";
    private final OverpaymentsConfig overpaymentsConfig;

    @Autowired
    public SimulationMapper(OverpaymentsConfig overpaymentsConfig) {
        this.overpaymentsConfig = overpaymentsConfig;
    }

    public ANMFSimulationRequest generateCreateSimulationRequest(MortgageSingleOverpaymentsContext context, int version) {
        ANMFSimulationRequest anmfSimulationRequest = new ANMFSimulationRequest();

        anmfSimulationRequest.setOverpaymentSimulationRequest(generateSimulationOperation(
                context.getMortgageAccount(),
                context.getSimulationChosenValues(),
                context.getLoggedCustomer(),
                context.getLdapUid(),
                getOriginalSimulationIdFromContext(context, version),
                version)
        );
        return anmfSimulationRequest;
    }

    public ANMFSimulationRequest generateCardCreateSimulationRequest(CardMortgageSingleOverpaymentsContext context) {
        ANMFSimulationRequest anmfSimulationRequest = new ANMFSimulationRequest();

        anmfSimulationRequest.setOverpaymentSimulationRequest(generateSimulationOperation(
                context.getMortgageAccount(),
                context.getSimulationChosenValues(),
                context.getLoggedCustomer(),
                context.getLdapUid(),
                0,
                1)
        );
        return anmfSimulationRequest;
    }

    public ANMFSimulationRequest generateUpdatePaymentMethodSimulationRequest(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext, int version) {
        ANMFSimulationRequest anmfSimulationRequest = new ANMFSimulationRequest();
        anmfSimulationRequest.setOverpaymentSimulationRequest(generateUpdatePaymentMethodSimulationOperation(
                getSimulationId(mortgageSingleOverpaymentsContext, version),
                mortgageSingleOverpaymentsContext.getMortgageAccount(),
                mortgageSingleOverpaymentsContext.getSimulationChosenValues().getErcCollectionOption(),
                mortgageSingleOverpaymentsContext.getLoggedCustomer(),
                mortgageSingleOverpaymentsContext.getLdapUid(),
                PAYMENT_METHOD_TT,
                getOriginalSimulationIdFromContext(mortgageSingleOverpaymentsContext, version),
                version));
        return anmfSimulationRequest;
    }

    public ANMFSimulationRequest generateCardUpdatePaymentMethodSimulationRequest(CardMortgageSingleOverpaymentsContext cardContext) {
        ANMFSimulationRequest anmfSimulationRequest = new ANMFSimulationRequest();
        anmfSimulationRequest.setOverpaymentSimulationRequest(generateUpdatePaymentMethodSimulationOperation(
                cardContext.getCardTransactionDetails().getUpdatedSimulationResponse().getOSimulationId(),
                cardContext.getMortgageAccount(),
                cardContext.getSimulationChosenValues().getErcCollectionOption(),
                cardContext.getLoggedCustomer(),
                cardContext.getLdapUid(),
                PAYMENT_METHOD_DC,
                0,
                1));
        return anmfSimulationRequest;
    }


    private OverpaymentSimulationRequest generateSimulationOperation(int mortgageAccount, SimulationChosenValues simulationChosenValues, OCustomer loggedCustomer, String ldapUid, int originalSimulationId, int version) {
        OverpaymentSimulationRequest overpaymentSimulationRequest = new OverpaymentSimulationRequest();

        InputStruc inputStruct = new InputStruc();
        inputStruct.setISimulationId(0);
        inputStruct.setIMortAccNo(mortgageAccount);
        inputStruct.setIOvpDate(getTodayDateInANMFFormat());
        inputStruct.setITotOvpAmount(simulationChosenValues.getPaymentAmount());
        inputStruct.setIErcCollOpt(simulationChosenValues.getErcCollectionOption());
        inputStruct.setIChanTypeCd(overpaymentsConfig.getChannelType());
        inputStruct.setISimVersion(version);
        inputStruct.setIBdpType(loggedCustomer.getOBdpType());
        inputStruct.setIBdpNumber(loggedCustomer.getOCustomerId());
        inputStruct.setIStaffId(ldapUid);
        inputStruct.setICallingAppl(overpaymentsConfig.getCallingApplication());
        inputStruct.setIPaymentData(generateSimulationPaymentData(EMPTY_SIMULATION_PAYMENT_METHOD));
        inputStruct.setILoanData(generateILoanData(simulationChosenValues));
        inputStruct.setIDistriType("O");
        inputStruct.setIErcAllowImp("");
        inputStruct.setIKfiRefNo("");
        inputStruct.setIUserId(overpaymentsConfig.getSimulationUserId());
        inputStruct.setIOriginalSimulationId(originalSimulationId);
        overpaymentSimulationRequest.setInputStruc(inputStruct);

        return overpaymentSimulationRequest;

    }

    private OverpaymentSimulationRequest generateUpdatePaymentMethodSimulationOperation(int simId, int mortgageAccount, String ercCollectionOption, OCustomer loggedCustomer, String ldapUid, String paymentMethod, int originalSimulationId, int version) {
        OverpaymentSimulationRequest overpaymentSimulationRequest = new OverpaymentSimulationRequest();

        InputStruc inputStruct = new InputStruc();
        inputStruct.setISimulationId(simId);
        inputStruct.setIMortAccNo(mortgageAccount);
        inputStruct.setIOvpDate(getTodayDateInANMFFormat());
        inputStruct.setIErcCollOpt(ercCollectionOption);
        inputStruct.setITotOvpAmount(BigDecimal.ZERO);
        inputStruct.setIChanTypeCd(overpaymentsConfig.getChannelType());
        inputStruct.setISimVersion(version);
        inputStruct.setIBdpType(loggedCustomer.getOBdpType());
        inputStruct.setILoanData(generateDummyILoanDataForUpdatePaymentMethod());
        inputStruct.setIBdpNumber(loggedCustomer.getOCustomerId());
        inputStruct.setIStaffId(ldapUid);
        inputStruct.setICallingAppl(overpaymentsConfig.getCallingApplication());
        inputStruct.setIPaymentData(generateSimulationPaymentData(paymentMethod));
        inputStruct.setIDistriType("O");
        inputStruct.setIErcAllowImp("");
        inputStruct.setIKfiRefNo("");
        inputStruct.setIUserId(overpaymentsConfig.getSimulationUserId());
        inputStruct.setIOriginalSimulationId(originalSimulationId);
        overpaymentSimulationRequest.setInputStruc(inputStruct);
        return overpaymentSimulationRequest;

    }

    private List<ILoanData> generateILoanData(SimulationChosenValues simulationChosenValues) {
        List<ILoanData> iLoanDataList = new ArrayList<>(simulationChosenValues.getLoanDetails().size());

        for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
            iLoanDataList.add(generateLoanDetailsElement(loanDetails));
        }

        return iLoanDataList;
    }

    private ILoanData generateLoanDetailsElement(LoanDetails loanDetails) {
        ILoanData iLoanData = new ILoanData();
        iLoanData.setILoanSch(loanDetails.getLoanScheme());
        iLoanData.setIApplSeqNo(loanDetails.getAppSeqNumber());
        iLoanData.setIChangeType(loanDetails.getLoanChangeType());
        iLoanData.setILnOvpAmount(loanDetails.getLoanOverpaymentAmount());
        iLoanData.setIErcWaiver("N");
        iLoanData.setIErcWaiverRsn("");
        return iLoanData;
    }

    private List<ILoanData> generateDummyILoanDataForUpdatePaymentMethod() {
        List<ILoanData> iLoanDataList = new ArrayList<>();
        ILoanData iLoanData = new ILoanData();
        iLoanData.setILoanSch("AA");
        iLoanData.setIApplSeqNo(0);
        iLoanData.setIChangeType("M");
        iLoanData.setILnOvpAmount(BigDecimal.ZERO);
        iLoanData.setIErcWaiver("N");
        iLoanData.setIErcWaiverRsn("");
        iLoanDataList.add(iLoanData);
        return iLoanDataList;
    }

    private IPaymentData generateSimulationPaymentData(String paymentMethod) {
        IPaymentData iPaymentData = new IPaymentData();
        iPaymentData.setISimPayMeth(paymentMethod);
        return iPaymentData;
    }

    private String getTodayDateInANMFFormat() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDateTime now = LocalDateTime.now();
        return dtf.format(now);
    }

    private int getOriginalSimulationIdFromContext(MortgageSingleOverpaymentsContext context, int version) {
        return version == 1 ? 0 : context.getSimIdV1();
    }

    private int getSimulationId(MortgageSingleOverpaymentsContext context, int version) {
        return version == 1 ? context.getSimIdV1() : context.getSimIdV2();
    }


}
