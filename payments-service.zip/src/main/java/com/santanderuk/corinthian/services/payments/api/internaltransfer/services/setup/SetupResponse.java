package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by c0245070 on 12/07/2017.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"codDocum", "codPers", "ctaGasto", "domiord", "indCentC", "indCentGa", "idEmprGa", "idProd", "idProdC", "idSPro", "idSubtip", "indApun", "indCarta", "indLiq", "indOrdSo", "jCodPer",
        "nmpzadom", "numsOr", "tipDoc", "tipoPers", "tipTranf", "tipTrasf", "status", "statusDescription"})
public class SetupResponse {

    @JsonProperty("codDocum")
    private String codDocum;

    @JsonProperty("codPers")
    private int codPers;

    @JsonProperty("ctaGasto")
    private String ctaGasto;

    @JsonProperty("domiord")
    private String domiord;

    @JsonProperty("idCentC")
    private String idCentC;

    @JsonProperty("idCentGa")
    private String idCentGa;

    @JsonProperty("idEmprGa")
    private String idEmprGa;

    @JsonProperty("idProd")
    private String idProd;

    @JsonProperty("idProdC")
    private String idProdC;

    @JsonProperty("idSPro")
    private String idSPro;

    @JsonProperty("idSubtip")
    private String idSubtip;

    @JsonProperty("indApun")
    private String indApun;

    @JsonProperty("indCarta")
    private String indCarta;

    @JsonProperty("indLiq")
    private String indLiq;

    @JsonProperty("indOrdSo")
    private String indOrdSo;

    @JsonProperty("jCodPer")
    private String jCodPer;

    @JsonProperty("nmpzadom")
    private String nmpzadom;

    @JsonProperty("numsOr")
    private String numsOr;

    @JsonProperty("tipDoc")
    private String tipDoc;

    @JsonProperty("tipoPers")
    private String tipoPers;

    @JsonProperty("tipTranf")
    private String tipTranf;

    @JsonProperty("tipTrasf")
    private String tipTrasf;

    @JsonProperty("status")
    private String status;

    @JsonProperty("statusDescription")
    private String statusDescription;


    public SetupResponse() {
    }

    public SetupResponse(String codDocum, int codPers, String ctaGasto, String domiord, String idCentC, String idCentGa, String idEmprGa,
                         String idProd, String idProdC, String idSPro, String idSubtip, String indApun, String indCarta,
                         String indLiq, String indOrdSo, String jCodPer, String nmpzadom, String numsOr, String tipDoc,
                         String tipoPers, String tipTranf, String tipTrasf, String status, String statusDescription) {
        this.codDocum = codDocum;
        this.codPers = codPers;
        this.ctaGasto = ctaGasto;
        this.domiord = domiord;
        this.idCentC = idCentC;
        this.idCentGa = idCentGa;
        this.idEmprGa = idEmprGa;
        this.idProd = idProd;
        this.idProdC = idProdC;
        this.idSPro = idSPro;
        this.idSubtip = idSubtip;
        this.indApun = indApun;
        this.indCarta = indCarta;
        this.indLiq = indLiq;
        this.indOrdSo = indOrdSo;
        this.jCodPer = jCodPer;
        this.nmpzadom = nmpzadom;
        this.numsOr = numsOr;
        this.tipDoc = tipDoc;
        this.tipoPers = tipoPers;
        this.tipTranf = tipTranf;
        this.tipTrasf = tipTrasf;
        this.status = status;
        this.statusDescription = statusDescription;
    }

    @JsonProperty("codDocum")
    public String getCodDocum() {
        return codDocum;
    }

    @JsonProperty("codDocum")
    public void setCodDocum(String codDocum) {
        this.codDocum = codDocum;
    }

    @JsonProperty("codPers")
    public int getCodPers() {
        return codPers;
    }

    @JsonProperty("codPers")
    public void setCodPers(int codPers) {
        this.codPers = codPers;
    }

    @JsonProperty("ctaGasto")
    public String getCtaGasto() {
        return ctaGasto;
    }

    @JsonProperty("ctaGasto")
    public void setCtaGasto(String ctaGasto) {
        this.ctaGasto = ctaGasto;
    }

    @JsonProperty("domiord")
    public String getDomiord() {
        return domiord;
    }

    @JsonProperty("domiord")
    public void setDomiord(String domiord) {
        this.domiord = domiord;
    }

    @JsonProperty("idCentC")
    public String getIdCentC() {
        return idCentC;
    }

    @JsonProperty("idCentC")
    public void setIdCentC(String idCentC) {
        this.idCentC = idCentC;
    }

    @JsonProperty("idCentGa")
    public String getIdCentGa() {
        return idCentGa;
    }

    @JsonProperty("idCentGa")
    public void setIdCentGa(String idCentGa) {
        this.idCentGa = idCentGa;
    }

    @JsonProperty("idEmprGa")
    public String getIdEmprGa() {
        return idEmprGa;
    }

    @JsonProperty("idEmprGa")
    public void setIdEmprGa(String idEmprGa) {
        this.idEmprGa = idEmprGa;
    }

    @JsonProperty("idProd")
    public String getIdProd() {
        return idProd;
    }

    @JsonProperty("idProd")
    public void setIdProd(String idProd) {
        this.idProd = idProd;
    }

    @JsonProperty("idProdC")
    public String getIdProdC() {
        return idProdC;
    }

    @JsonProperty("idProdC")
    public void setIdProdC(String idProdC) {
        this.idProdC = idProdC;
    }

    @JsonProperty("idSPro")
    public String getIdSPro() {
        return idSPro;
    }

    @JsonProperty("idSPro")
    public void setIdSPro(String idSPro) {
        this.idSPro = idSPro;
    }

    @JsonProperty("idSubtip")
    public String getIdSubtip() {
        return idSubtip;
    }

    @JsonProperty("idSubtip")
    public void setIdSubtip(String idSubtip) {
        this.idSubtip = idSubtip;
    }

    @JsonProperty("indApun")
    public String getIndApun() {
        return indApun;
    }

    @JsonProperty("indApun")
    public void setIndApun(String indApun) {
        this.indApun = indApun;
    }

    @JsonProperty("indCarta")
    public String getIndCarta() {
        return indCarta;
    }

    @JsonProperty("indCarta")
    public void setIndCarta(String indCarta) {
        this.indCarta = indCarta;
    }

    @JsonProperty("indLiq")
    public String getIndLiq() {
        return indLiq;
    }

    @JsonProperty("indLiq")
    public void setIndLiq(String indLiq) {
        this.indLiq = indLiq;
    }

    @JsonProperty("indOrdSo")
    public String getIndOrdSo() {
        return indOrdSo;
    }

    @JsonProperty("indOrdSo")
    public void setIndOrdSo(String indOrdSo) {
        this.indOrdSo = indOrdSo;
    }

    @JsonProperty("jCodPer")
    public String getjCodPer() {
        return jCodPer;
    }

    @JsonProperty("jCodPer")
    public void setjCodPer(String jCodPer) {
        this.jCodPer = jCodPer;
    }

    @JsonProperty("nmpzadom")
    public String getNmpzadom() {
        return nmpzadom;
    }

    @JsonProperty("nmpzadom")
    public void setNmpzadom(String nmpzadom) {
        this.nmpzadom = nmpzadom;
    }

    @JsonProperty("numsOr")
    public String getNumsOr() {
        return numsOr;
    }

    @JsonProperty("numsOr")
    public void setNumsOr(String numsOr) {
        this.numsOr = numsOr;
    }

    @JsonProperty("tipDoc")
    public String getTipDoc() {
        return tipDoc;
    }

    @JsonProperty("tipDoc")
    public void setTipDoc(String tipDoc) {
        this.tipDoc = tipDoc;
    }

    @JsonProperty("tipoPers")
    public String getTipoPers() {
        return tipoPers;
    }

    @JsonProperty("tipoPers")
    public void setTipoPers(String tipoPers) {
        this.tipoPers = tipoPers;
    }

    @JsonProperty("tipTranf")
    public String getTipTranf() {
        return tipTranf;
    }

    @JsonProperty("tipTranf")
    public void setTipTranf(String tipTranf) {
        this.tipTranf = tipTranf;
    }

    @JsonProperty("tipTrasf")
    public String getTipTrasf() {
        return tipTrasf;
    }

    @JsonProperty("tipTrasf")
    public void setTipTrasf(String tipTrasf) {
        this.tipTrasf = tipTrasf;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("statusDescription ")
    public String getStatusDescription() {
        return statusDescription;
    }

    @JsonProperty("statusDescription ")
    public void setStatusDescription(String statusDescription) {
        this.statusDescription = statusDescription;
    }


    @Override
    public String toString() {
        return new org.apache.commons.lang3.builder.ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("codDocum", codDocum)
                .append("codPers", codPers)
                .append("ctaGasto", ctaGasto)
                .append("domiord", domiord)
                .append("idCentC", idCentC)
                .append("idCentGa", idCentGa)
                .append("idEmprGa", idEmprGa)
                .append("idProd", idProd)
                .append("idProdC", idProdC)
                .append("idSPro", idSPro)
                .append("idSubtip", idSubtip)
                .append("indApun", indApun)
                .append("indCarta", indCarta)
                .append("indLiq", indLiq)
                .append("indOrdSo", indOrdSo)
                .append("jCodPer", jCodPer)
                .append("nmpzadom", nmpzadom)
                .append("numsOr", numsOr)
                .append("tipDoc", tipDoc)
                .append("tipoPers", tipoPers)
                .append("tipTranf", tipTranf)
                .append("tipTrasf", tipTrasf)
                .append("status", status)
                .append("statusDescription", statusDescription)
                .toString();
    }
}
