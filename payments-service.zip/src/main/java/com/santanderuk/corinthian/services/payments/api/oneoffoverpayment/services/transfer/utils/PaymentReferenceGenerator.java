package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

@Service
public class PaymentReferenceGenerator {

    public static final String STRING_EMPTY = "";
    public static final String STRING_SPACE = " ";

    public String generateSingleOverpaymentInternalTransferReference(int mortgageAccount, String customerSurname) {
        String paymentReference;

        paymentReference = StringUtils.leftPad(String.valueOf(mortgageAccount), 9, '0') + customerSurname.replace(STRING_SPACE, STRING_EMPTY);
        // the reference must have 18 characters
        String paymentReference18Char;
        if (paymentReference.length() >= 18) {
            paymentReference18Char = String.format("%.18s", paymentReference);
        } else {
            paymentReference18Char = StringUtils.rightPad(paymentReference, 18);
        }

        return paymentReference18Char.toUpperCase();
    }
}
