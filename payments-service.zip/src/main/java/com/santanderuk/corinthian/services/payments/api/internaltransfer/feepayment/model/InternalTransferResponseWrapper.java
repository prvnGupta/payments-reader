package com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class InternalTransferResponseWrapper {
    private ServiceInfo info;
    private InternalTransferResponse response;
}
