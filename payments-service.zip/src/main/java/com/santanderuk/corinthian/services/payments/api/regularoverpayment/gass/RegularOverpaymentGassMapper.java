package com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.gassaudit.config.RabbitMqConfig;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentGassItem;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.model.BdpCustomer;
import com.santanderuk.corinthian.services.commons.utilities.JwtUtilities;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class RegularOverpaymentGassMapper {

    private final GassConfig gassConfig;

    private final RabbitMqConfig rabbitMqConfig;

    @Autowired
    public RegularOverpaymentGassMapper(GassConfig gassConfig, RabbitMqConfig rabbitMqConfig) {
        this.gassConfig = gassConfig;
        this.rabbitMqConfig = rabbitMqConfig;
    }


    public SetUpRegularOverpaymentGassItem toRegularOverpaymentGassItem(final RegularOverpaymentContext context) throws GeneralException {
        log.info("RegularOverpaymentService - > Calling Gass Dependency for set-up regular overpayment");

        final BdpCustomer bdpCustomer = JwtUtilities.getBdpCustomerFromJWT(context.getJwtToken());
        final String ipAddress = fetchIpAddress(context.getIpAddress());

        context.getFormattedData().setCustomerNumber(bdpCustomer.getCustomerType() + bdpCustomer.getCustomerNumber());

        return new SetUpRegularOverpaymentGassItem(
                rabbitMqConfig.getGassMqHost(),
                rabbitMqConfig.getGassMqVirtualHost(),
                rabbitMqConfig.getGassMqPort(),
                rabbitMqConfig.getGassMqQueue(),
                rabbitMqConfig.getGassMqUsername(),
                rabbitMqConfig.getGassMqPassword(),
                gassConfig.getGassCompsysid(),
                gassConfig.getGassDvctyp(),
                gassConfig.getGassOrgid(),
                gassConfig.getGassOrguttp(),
                gassConfig.getGassAuthcduserid(),
                gassConfig.getGassAuthcdcompsysid(),
                gassConfig.getGassAppsysid(),
                gassConfig.getGassTrngrpid(),
                gassConfig.getTrnTpNameSetUpRegular(),
                context.getResultIndicatorForGass(),
                context.getFormattedData().getCustomerNumber(),
                gassConfig.getAnmfSortcode() + " " + String.format("%09d", Integer.valueOf(context.getFormattedData().getDestinationAccount())),
                context.getFormattedData().getDirectDebitTotalAmount(),
                ipAddress,
                context.getLdapUid(),
                context.getFormattedData());
    }


    private String fetchIpAddress(final String clientIp) {
        String ipAddress = gassConfig.getIpAddress();

        if (clientIpIsNotEmpty(clientIp)) {
            ipAddress = clientIp;
        }
        return ipAddress;
    }

    private boolean clientIpIsNotEmpty(String clientIp) {
        return clientIp != null && !"".equalsIgnoreCase(clientIp.trim());
    }
}
