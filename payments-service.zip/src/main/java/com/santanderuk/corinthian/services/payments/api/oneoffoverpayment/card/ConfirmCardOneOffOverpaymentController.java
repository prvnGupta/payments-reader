package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.payments.api.BaseController;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.ConfirmCardOneOffPaymentRequest;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@Validated
public class ConfirmCardOneOffOverpaymentController extends BaseController {

    private final CardOneOffOverpaymentService cardOneOffOverpaymentService;

    public ConfirmCardOneOffOverpaymentController(CardOneOffOverpaymentService cardOneOffOverpaymentService) {
        this.cardOneOffOverpaymentService = cardOneOffOverpaymentService;
    }


    @ApiOperation(
            value = "Backend aggregation layer to confirm a one off overpayments using debit card.",
            nickname = "confirmCardOneOffOverpayment",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to confirm a 3DS debit card one-off overpayments. It will call simulation, update-payment-method, make the card payment (including Gass and lynx) and generate and return a PDF"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")})

    @PostMapping(path = "/{mortgageAccount}/confirm-card-one-off-overpayment/{transactionId}",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CardPaymentResponseWrapper> confirmCardOneOffOverpayment(
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @PathVariable int mortgageAccount,
            @PathVariable String transactionId,
            @Valid @RequestBody ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest,
            HttpServletRequest httpServletRequest) throws GeneralException {

        CardPaymentResponse cardPaymentResponse = cardOneOffOverpaymentService.confirmCardOneOffOverpayment(mortgageAccount, transactionId, confirmCardOneOffPaymentRequest, jwtToken, extractIpAddress(httpServletRequest));
        return new ResponseEntity<>(wrapResponse(cardPaymentResponse), HttpStatus.CREATED);
    }

    private CardPaymentResponseWrapper wrapResponse(CardPaymentResponse cardPaymentResponse) {
        CardPaymentResponseWrapper responseWrapper = new CardPaymentResponseWrapper();
        responseWrapper.setData(cardPaymentResponse);
        responseWrapper.setInfo(ServiceInfoCreator.ok());
        return responseWrapper;
    }

}
