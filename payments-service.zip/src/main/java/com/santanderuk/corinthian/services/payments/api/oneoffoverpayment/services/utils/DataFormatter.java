package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.utils;

import com.santanderuk.corinthian.services.commons.time.TimeMachine;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

@Slf4j
@Component
public class DataFormatter {
    public static final String CONST_FORMAT_DDMMYYYY = "dd/MM/yyyy";
    public static final String CONST_SPACE_YEAR_STRING = " year";
    public static final String CONST_SPACE_YEARS_STRING = " years";
    public static final String CONST_SPACE_MONTH_STRING = " month";
    public static final String CONST_SPACE_MONTHS_STRING = " months";
    public static final String CONST_SPACE_STRING = " ";

    public String calculateTermRemaining(String simMaturityDate) {

        log.debug("CalculateTermRemaining for simMaturityDate: {}", simMaturityDate);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(CONST_FORMAT_DDMMYYYY);

        LocalDate maturityDate = LocalDate.parse(simMaturityDate, formatter);
        LocalDate todayDate = TimeMachine.now().toLocalDate();

        int years = Period.between(todayDate, maturityDate).getYears();
        int months = Period.between(todayDate, maturityDate).getMonths();
        int days = Period.between(todayDate, maturityDate).getDays();

        if (days > 0) {
            months++;
            if (months > 11) {
                years++;
                months = 0;
            }
        }

        String yearDescription = years == 1 ? String.valueOf(years).concat(CONST_SPACE_YEAR_STRING) : String.valueOf(years).concat(CONST_SPACE_YEARS_STRING);
        String monthDescription = months == 1 ? String.valueOf(months).concat(CONST_SPACE_MONTH_STRING) : String.valueOf(months).concat(CONST_SPACE_MONTHS_STRING);

        log.debug("CalculateTermRemaining finish ok");
        return yearDescription.concat(CONST_SPACE_STRING).concat(monthDescription);
    }

    public String getTodayFormattedDate() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(CONST_FORMAT_DDMMYYYY);
        LocalDateTime today = TimeMachine.now();
        return formatter.format(today);
    }
}
