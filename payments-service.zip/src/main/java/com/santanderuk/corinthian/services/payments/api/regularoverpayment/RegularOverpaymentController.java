package com.santanderuk.corinthian.services.payments.api.regularoverpayment;

import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfo;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.payments.api.BaseController;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.RegularOverpaymentData;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.ServiceInfoWrapper;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetupRegularOverpaymentResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.service.CancelRegularOverpaymentService;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.service.EditRegularOverpaymentService;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.service.SetupRegularOverpaymentService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

import static com.santanderuk.corinthian.services.commons.exceptions.MaintenanceException.Type.MAINTENANCE_REGION_X;

@RestController
@Slf4j
public class RegularOverpaymentController extends BaseController {

    public static final String REGULAR_OVERPAYMENT_TYPE = "S";
    public static final int SEQUENTIAL = 0;
    private static final String REGEX_CARRIAGE_RETURN = "[\r\n]";
    private static final AnmfRegion W = AnmfRegion.W;
    private final SetupRegularOverpaymentService setupRegularOverpaymentService;

    private final CancelRegularOverpaymentService cancelRegularOverpaymentService;

    private final HeartBeatClient heartBeatClient;

    private final EditRegularOverpaymentService editRegularOverpaymentService;


    public RegularOverpaymentController(SetupRegularOverpaymentService setupRegularOverpaymentService, CancelRegularOverpaymentService cancelRegularOverpaymentService, HeartBeatClient heartBeatClient, EditRegularOverpaymentService editRegularOverpaymentService) {
        this.setupRegularOverpaymentService = setupRegularOverpaymentService;
        this.cancelRegularOverpaymentService = cancelRegularOverpaymentService;
        this.heartBeatClient = heartBeatClient;
        this.editRegularOverpaymentService = editRegularOverpaymentService;
    }

    @ApiOperation(
            value = "Backend aggregation layer to endpoint to set up a new regular overpayment for a mortgage.",
            nickname = "setUpRegularOverpayment",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to setup a new regular overpayment"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = SetupRegularOverpaymentResponseWrapper.class),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PostMapping(
            value = "regular-overpayment/{account}",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public final ResponseEntity<SetupRegularOverpaymentResponseWrapper> setUpRegularOverpayment(
            @RequestBody(required = true) @Validated SetUpRegularOverpaymentServiceInput controllerRequest,
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @PathVariable int account,
            HttpServletRequest httpServletRequest) throws GeneralException, IOException {

        logControllerBeginning(controllerRequest, jwtToken);

        AnmfRegion region = heartBeatClient.fetchCurrentRegion();

        CustomerDetailsResponse customerDetailsResponse = checkOperativeSecurityWithCustomerList(account, jwtToken, region);

        checkRegionIsAllowed(region);

        final RegularOverpaymentContext context = generateRegularOverpaymentContext(controllerRequest, jwtToken, account, httpServletRequest, region, customerDetailsResponse);

        RegularOverpaymentData regularOverpaymentData = setupRegularOverpaymentService.setUpRegularOverpayment(context);
        SetupRegularOverpaymentResponseWrapper setupRegularOverpaymentResponseWrapper = new SetupRegularOverpaymentResponseWrapper(regularOverpaymentData, ServiceInfoCreator.ok());
        logControllerEnding(setupRegularOverpaymentResponseWrapper);
        return createResponseEntity(setupRegularOverpaymentResponseWrapper);
    }

    @ApiOperation(
            value = "Backend aggregation layer to endpoint to cancel an existing regular overpayment for a mortgage.",
            nickname = "cancelRegularOverpayment",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to cancel an existing regular overpayment"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = ServiceInfo.class),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @DeleteMapping(
            value = "regular-overpayment/{account}",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public final ResponseEntity<ServiceInfoWrapper> cancelRegularOverpayment(
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @PathVariable int account,
            HttpServletRequest httpServletRequest) throws GeneralException {

        AnmfRegion region = heartBeatClient.fetchCurrentRegion();
        CustomerDetailsResponse customerDetailsResponse = checkOperativeSecurityWithCustomerList(account, jwtToken, region);

        checkRegionIsAllowed(region);

        cancelRegularOverpaymentService.cancelExistingInstruction(account, jwtToken, extractIpAddress(httpServletRequest), customerDetailsResponse);

        ServiceInfoWrapper responseWrapper = new ServiceInfoWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.ok());

        return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
    }


    @ApiOperation(
            value = "Backend aggregation layer to endpoint to edit an existing regular overpayment for a mortgage.",
            nickname = "editRegularOverpayment",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to edit an existing regular overpayment"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK", response = ServiceInfo.class),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")
    })
    @PutMapping(
            value = "regular-overpayment/{account}",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public final ResponseEntity<ServiceInfoWrapper> editRegularOverpayment(
            @RequestBody(required = true) @Validated SetUpRegularOverpaymentServiceInput controllerRequest,
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @PathVariable int account,
            HttpServletRequest httpServletRequest) throws GeneralException {

        AnmfRegion region = heartBeatClient.fetchCurrentRegion();

        CustomerDetailsResponse customerDetailsResponse = checkOperativeSecurityWithCustomerList(account, jwtToken, region);

        checkRegionIsAllowed(region);

        editRegularOverpaymentService.editExistingInstruction(account, jwtToken, extractIpAddress(httpServletRequest), controllerRequest, customerDetailsResponse);

        ServiceInfoWrapper responseWrapper = new ServiceInfoWrapper();
        responseWrapper.setInfo(ServiceInfoCreator.ok());
        return new ResponseEntity<>(responseWrapper, HttpStatus.OK);
    }


    private void checkRegionIsAllowed(final AnmfRegion region) throws MaintenanceException {
        if (region == W) {
            throw new MaintenanceException(MAINTENANCE_REGION_X);
        }
    }

    private ResponseEntity<SetupRegularOverpaymentResponseWrapper> createResponseEntity(
            final SetupRegularOverpaymentResponseWrapper setupRegularOverpaymentResponseWrapper
    ) {
        return new ResponseEntity<>(
                setupRegularOverpaymentResponseWrapper,
                createdOrAccepted(setupRegularOverpaymentResponseWrapper.getData().isPaymentDone())
        );
    }

    private void logControllerEnding(
            final SetupRegularOverpaymentResponseWrapper setupRegularOverpaymentResponseWrapper
    ) {
        log.info("payments/set-up-regular-overpayment finished ok");
        log.debug("payments/set-up-regular-overpayment response: {}", sanitiseString(setupRegularOverpaymentResponseWrapper.toString()));
    }

    private void logControllerBeginning(
            final SetUpRegularOverpaymentServiceInput controllerRequest,
            final String jwtToken
    ) {
        log.info("set-up-regular-overpayment request received");
        log.debug("set-up-regular-overpayment request received: {}", sanitiseString(controllerRequest.toString()));
        log.debug("Jwt: {}", jwtToken.replaceAll(REGEX_CARRIAGE_RETURN, ""));
    }

    private HttpStatus createdOrAccepted(final boolean isPaymentDone) {
        return isPaymentDone ? HttpStatus.CREATED : HttpStatus.ACCEPTED;
    }

    private RegularOverpaymentContext generateRegularOverpaymentContext(SetUpRegularOverpaymentServiceInput controllerRequest, String jwtToken, int account, HttpServletRequest httpServletRequest, AnmfRegion region, CustomerDetailsResponse customerDetailsResponse) {
        final RegularOverpaymentContext context = new RegularOverpaymentContext();
        context.setCustomerDetailsResponse(customerDetailsResponse);
        context.setAnmfRegion(region);
        context.setIpAddress(extractIpAddress(httpServletRequest));
        context.setControllerRequest(controllerRequest);
        context.setJwtToken(jwtToken);
        context.setAccount(account);
        context.setSequential(SEQUENTIAL);
        context.setInstructionAction(REGULAR_OVERPAYMENT_TYPE);
        return context;
    }
}
