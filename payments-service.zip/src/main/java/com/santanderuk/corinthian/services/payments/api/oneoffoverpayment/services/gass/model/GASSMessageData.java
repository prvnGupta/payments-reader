package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model;

import lombok.Data;

@Data
public class GASSMessageData {

    private int AppSysId;
    private String AuditTrnTpName;
    private String customerId;
    private String userId;
    private String mccId;
    private String deviceId;
    private String ldapUid;
    private int deviceTyp;
    private String formattedData;
    private int audittrngrpid;
    private String anmfAccount;
    private String amount;
}
