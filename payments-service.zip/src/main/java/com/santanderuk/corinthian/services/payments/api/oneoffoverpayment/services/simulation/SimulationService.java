package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation;

import com.santanderuk.corinthian.services.commons.anmfclient.SimulationClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.ANMFSimulationResponse;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SimulationService {

    private final SimulationClient simulationClient;
    private final EndpointConfiguration endpointConfiguration;
    private final SimulationMapper simulationMapper;

    @Autowired
    public SimulationService(SimulationClient simulationClient, EndpointConfiguration endpointConfiguration, SimulationMapper simulationMapper) {
        this.simulationClient = simulationClient;
        this.endpointConfiguration = endpointConfiguration;
        this.simulationMapper = simulationMapper;
    }

    public void createOverpaymentSimulationV1(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext) throws GeneralException {
        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 1);
        ANMFSimulationResponse anmfSimulationResponse = simulationClient.simulate(endpointConfiguration.getAnmfSimulationUrl(), anmfSimulationRequest, mortgageSingleOverpaymentsContext.getAnmfRegion());
        log.debug("create simulation V1 request: {}", anmfSimulationRequest);
        checkErrorsInAnmfResponse(anmfSimulationResponse);
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc());
        mortgageSingleOverpaymentsContext.setSimIdV1(anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
    }


    public void createOverpaymentSimulationV2(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext) throws GeneralException {
        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCreateSimulationRequest(mortgageSingleOverpaymentsContext, 2);
        ANMFSimulationResponse anmfSimulationResponse = simulationClient.simulate(endpointConfiguration.getAnmfSimulationUrl(), anmfSimulationRequest, mortgageSingleOverpaymentsContext.getAnmfRegion());
        log.debug("create simulation V2 request: {}", anmfSimulationRequest);
        checkErrorsInAnmfResponse(anmfSimulationResponse);
        mortgageSingleOverpaymentsContext.setUpdatedSimulationResponse(anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc());
        mortgageSingleOverpaymentsContext.setSimIdV2(anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getOSimulationId());
    }

    public void updatePaymentMethodV1(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext) throws GeneralException {
        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 1);
        log.debug("updatePaymentMethod Internal transfer request: {}", anmfSimulationRequest);
        ANMFSimulationResponse updatePaymentMethodResponse = simulationClient.simulate(endpointConfiguration.getAnmfSimulationUrl(), anmfSimulationRequest, mortgageSingleOverpaymentsContext.getAnmfRegion());
        checkErrorsInAnmfResponse(updatePaymentMethodResponse);
    }

    public void updatePaymentMethodV2(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext) throws GeneralException {
        ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateUpdatePaymentMethodSimulationRequest(mortgageSingleOverpaymentsContext, 2);
        log.debug("updatePaymentMethod v2 Internal transfer request: {}", anmfSimulationRequest);
        ANMFSimulationResponse updatePaymentMethodResponse = simulationClient.simulate(endpointConfiguration.getAnmfSimulationUrl(), anmfSimulationRequest, mortgageSingleOverpaymentsContext.getAnmfRegion());
        checkErrorsInAnmfResponse(updatePaymentMethodResponse);
    }

    public void updatePaymentMethodCard(CardMortgageSingleOverpaymentsContext cardContext) {

        try {
            log.info("updatePaymentMethodCard -> started");
            ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCardUpdatePaymentMethodSimulationRequest(cardContext);
            log.debug("updatePaymentMethod Card request: {}", anmfSimulationRequest);
            ANMFSimulationResponse updatePaymentMethodResponse = simulationClient.simulate(endpointConfiguration.getAnmfSimulationUrl(), anmfSimulationRequest, cardContext.getAnmfRegion());
            checkErrorsInAnmfResponse(updatePaymentMethodResponse);
            log.info("updatePaymentMethodCard -> finished");
        } catch (Exception e) {
            log.error("triggerEmailAlert -> Error while updating simulationPaymentMethod", e);
        }

    }

    public void createCardOverpaymentSimulation(CardMortgageSingleOverpaymentsContext cardContext) throws GeneralException {
        try {
            log.info("createCardOverpaymentSimulation -> started");
            ANMFSimulationRequest anmfSimulationRequest = simulationMapper.generateCardCreateSimulationRequest(cardContext);
            log.debug("createCardOverpaymentSimulation Card request: {}", anmfSimulationRequest);
            ANMFSimulationResponse anmfSimulationResponse = simulationClient.simulate(endpointConfiguration.getAnmfSimulationUrl(), anmfSimulationRequest, cardContext.getAnmfRegion());
            checkErrorsInAnmfResponse(anmfSimulationResponse);
            cardContext.getCardTransactionDetails().setUpdatedSimulationResponse(anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc());
            log.info("createCardOverpaymentSimulation -> finished");
        } catch (Exception e) {
            log.error("Error while Creating card payment simulation");
            throw new GeneralException("EXC_SIMULATION_ERROR_RESPONSE", "Error creating overpayment simulation");
        }
    }


    private void checkErrorsInAnmfResponse(ANMFSimulationResponse anmfSimulationResponse) throws GeneralException {
        if (!anmfSimulationResponse.getOverpaymentSimulationResponse().getOutputStruc().getEStruc().getECode().equalsIgnoreCase("")) {
            throw new GeneralException("EXC_SIMULATION_ERROR_RESPONSE", "Error received from simulation core service");
        }
    }
}
