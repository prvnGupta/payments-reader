package com.santanderuk.corinthian.services.payments.version;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class VersionController {

    private final VersionService service;

    @Autowired
    public VersionController(VersionService service) {
        this.service = service;
    }

    @GetMapping(value = "/version", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<VersionResponse> getVersion() {

        return new ResponseEntity<>(service.getInfo(), HttpStatus.OK);
    }
}
