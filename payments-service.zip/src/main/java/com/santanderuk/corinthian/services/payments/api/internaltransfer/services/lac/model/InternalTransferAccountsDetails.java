package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model;

import lombok.Data;

@Data
public class InternalTransferAccountsDetails {
    private InternalAccountDetails accountFrom;
    private InternalAccountDetails accountTo;
}
