package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
public class PDFLoan {

    private String description;
    private String balanceBeforeOverpayment;
    private String overpayment;
    private BigDecimal overpaymentInBigDecimal;
    private String chosenHeader;
    private String monthlyPaymentSaving;
    private String mortgageTerm;
    private String interestSaving;

}
