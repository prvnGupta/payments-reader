package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt;

import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.io.lynxNRT.LynxNRTDataRequest;
import com.santanderuk.corinthian.services.commons.utilities.InternalAccountFormatConverter;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils.PaymentReferenceGenerator;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Component
@Slf4j
public class LynxNRTDataMapper {

    public static final String STRING_EMPTY = "";
    public static final String STRING_SPACE = " ";
    public static final String EXCEPTION_WHILE_CREATING_LYNX_NRT_REQUEST = "Exception while creating LynxNrt Request";
    public static final String LYNX_NRTDATA_REQUEST = "LynxNRTDataRequest : {}";


    private final OverpaymentsConfig config;
    private final Clock clock;
    private final InternalAccountFormatConverter internalAccountFormatConverter;
    private final OverpaymentsConfig overpaymentsConfig;
    private final PaymentReferenceGenerator paymentReferenceGenerator;

    public LynxNRTDataMapper(OverpaymentsConfig config, Clock clock, InternalAccountFormatConverter internalAccountFormatConverter, OverpaymentsConfig overpaymentsConfig, PaymentReferenceGenerator paymentReferenceGenerator) {
        this.config = config;
        this.clock = clock;
        this.internalAccountFormatConverter = internalAccountFormatConverter;
        this.overpaymentsConfig = overpaymentsConfig;

        this.paymentReferenceGenerator = paymentReferenceGenerator;
    }

    public LynxNRTDataRequest decorateLynxNRTRequestData(InternalTransferRequest request, InternalTransferAccountsDetails accountsDetails, String status, String ldapUid, String remoteIpAddress) throws LynxNRTException {

        try {
            LynxNRTDataRequest lynxNRTDataRequest = new LynxNRTDataRequest();

            lynxNRTDataRequest.setPartenonFromEmpresa(accountsDetails.getAccountFrom().getPartenonAccountNumber().getCompany());
            lynxNRTDataRequest.setPartenonFromCentro(accountsDetails.getAccountFrom().getPartenonAccountNumber().getCentre());
            lynxNRTDataRequest.setPartenonFromProduct(accountsDetails.getAccountFrom().getPartenonAccountNumber().getProduct());
            lynxNRTDataRequest.setPartenonFromContract(accountsDetails.getAccountFrom().getPartenonAccountNumber().getContract());
            lynxNRTDataRequest.setFromSortCodeAccount(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(accountsDetails.getAccountFrom().getLocalAccountNumber()));

            lynxNRTDataRequest.setPartenonToEmpresa(accountsDetails.getAccountTo().getPartenonAccountNumber().getCompany());
            lynxNRTDataRequest.setPartenonToCentro(accountsDetails.getAccountTo().getPartenonAccountNumber().getCentre());
            lynxNRTDataRequest.setPartenonToProduct(accountsDetails.getAccountTo().getPartenonAccountNumber().getProduct());
            lynxNRTDataRequest.setPartenonToContract(accountsDetails.getAccountTo().getPartenonAccountNumber().getContract());
            lynxNRTDataRequest.setToSortCodeAccount(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(accountsDetails.getAccountTo().getLocalAccountNumber()));

            lynxNRTDataRequest.setDAmount(request.getPaymentAmount().doubleValue());
            lynxNRTDataRequest.setPaymentName(request.getCustomerFirstName() + STRING_SPACE + request.getCustomerLastName());
            lynxNRTDataRequest.setCurrency(config.getSetupDataCurrency());
            lynxNRTDataRequest.setPaymentReference(request.getPaymentReference());
            lynxNRTDataRequest.setPaymentDate(getTodayTimestamp());

            lynxNRTDataRequest.setCustomerTipoDePersona(request.getBdpCustomer().getCustomerType());
            lynxNRTDataRequest.setCustomerCodigoDePersona(Integer.toString(request.getBdpCustomer().getCustomerNumber()));
            lynxNRTDataRequest.setUserID(ldapUid);
            lynxNRTDataRequest.setClientIP(remoteIpAddress);

            lynxNRTDataRequest.setSessionID(STRING_EMPTY);
            lynxNRTDataRequest.setSessionIDSec(STRING_EMPTY);
            lynxNRTDataRequest.setServerID(STRING_EMPTY);

            lynxNRTDataRequest.setCategoryName(overpaymentsConfig.getLynxNRTCategoryName());

            setResponseCodeAndMessage(status, lynxNRTDataRequest);

            log.debug(LYNX_NRTDATA_REQUEST, lynxNRTDataRequest);

            return lynxNRTDataRequest;
        } catch (Exception e) {
            log.warn(EXCEPTION_WHILE_CREATING_LYNX_NRT_REQUEST);
            throw new LynxNRTException(EXCEPTION_WHILE_CREATING_LYNX_NRT_REQUEST, e);
        }
    }

    public LynxNRTDataRequest decorateLynxNRTRequestData(MortgageSingleOverpaymentsContext context, String status) throws LynxNRTException {

        try {
            LynxNRTDataRequest lynxNRTDataRequest = new LynxNRTDataRequest();

            lynxNRTDataRequest.setPartenonFromEmpresa(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCompany());
            lynxNRTDataRequest.setPartenonFromCentro(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getCentre());
            lynxNRTDataRequest.setPartenonFromProduct(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getProduct());
            lynxNRTDataRequest.setPartenonFromContract(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber().getContract());
            lynxNRTDataRequest.setFromSortCodeAccount(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(context.getInternalTransferAccountsDetails().getAccountFrom().getLocalAccountNumber()));

            lynxNRTDataRequest.setPartenonToEmpresa(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCompany());
            lynxNRTDataRequest.setPartenonToCentro(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCentre());
            lynxNRTDataRequest.setPartenonToProduct(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getProduct());
            lynxNRTDataRequest.setPartenonToContract(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getContract());
            lynxNRTDataRequest.setToSortCodeAccount(internalAccountFormatConverter.convertLocalAccountNumberToStringFormat(context.getInternalTransferAccountsDetails().getAccountTo().getLocalAccountNumber()));

            lynxNRTDataRequest.setDAmount(context.getUpdatedSimulationResponse().getOTotPayment().doubleValue());
            lynxNRTDataRequest.setPaymentName(context.getLoggedCustomer().getOForename1() + STRING_SPACE + context.getLoggedCustomer().getOSurname());
            lynxNRTDataRequest.setCurrency(config.getSetupDataCurrency());
            lynxNRTDataRequest.setPaymentReference(paymentReferenceGenerator.generateSingleOverpaymentInternalTransferReference(context.getMortgageAccount(), context.getLoggedCustomer().getOSurname()));
            lynxNRTDataRequest.setPaymentDate(getTodayTimestamp());

            lynxNRTDataRequest.setCustomerTipoDePersona(context.getLoggedCustomer().getOBdpType());
            lynxNRTDataRequest.setCustomerCodigoDePersona(Integer.toString(context.getLoggedCustomer().getOCustomerId()));
            lynxNRTDataRequest.setUserID(context.getLdapUid());
            lynxNRTDataRequest.setClientIP(context.getIpAddress());

            lynxNRTDataRequest.setSessionID(STRING_EMPTY);
            lynxNRTDataRequest.setSessionIDSec(STRING_EMPTY);
            lynxNRTDataRequest.setServerID(STRING_EMPTY);

            lynxNRTDataRequest.setCategoryName(overpaymentsConfig.getLynxNRTCategoryName());

            setResponseCodeAndMessage(status, lynxNRTDataRequest);

            log.debug(LYNX_NRTDATA_REQUEST, lynxNRTDataRequest);

            return lynxNRTDataRequest;
        } catch (Exception e) {
            log.warn(EXCEPTION_WHILE_CREATING_LYNX_NRT_REQUEST);
            throw new LynxNRTException(EXCEPTION_WHILE_CREATING_LYNX_NRT_REQUEST, e);
        }
    }

    private String getTodayTimestamp() {

        return LocalDateTime.now(clock).format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
    }

    private void setResponseCodeAndMessage(String status, LynxNRTDataRequest lynxNRTDataRequest) {
        if (status.equalsIgnoreCase("OK")) {
            lynxNRTDataRequest.setResponseCode("000");
            lynxNRTDataRequest.setResponseMessage("Transaction completed successfully");
        } else {
            lynxNRTDataRequest.setResponseCode("999");
            lynxNRTDataRequest.setResponseMessage("Transaction Failed");
        }
    }


}
