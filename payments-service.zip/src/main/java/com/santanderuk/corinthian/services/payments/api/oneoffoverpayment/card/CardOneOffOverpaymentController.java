package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.serviceinfo.ServiceInfoCreator;
import com.santanderuk.corinthian.services.payments.api.BaseController;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponseWrapper;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

@RestController
@Validated
public class CardOneOffOverpaymentController extends BaseController {

    private final CardOneOffOverpaymentService cardOneOffOverpaymentService;

    public CardOneOffOverpaymentController(CardOneOffOverpaymentService cardOneOffOverpaymentService) {
        this.cardOneOffOverpaymentService = cardOneOffOverpaymentService;
    }


    @ApiOperation(
            value = "Backend aggregation layer to make a one off overpayments using debit card.",
            nickname = "cardOneOffOverpayment",
            notes = "This endpoint is used by Corinthian frontend p-sanmf-mortgage-centre application to make one-off overpayments using debit card. It will call simulation, update-payment-method, make the card payment (including Gaas and lynx) and generate and return a PDF"
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "OK"),
            @ApiResponse(code = 400, message = "Bad Format"),
            @ApiResponse(code = 401, message = "Unauthorised"),
            @ApiResponse(code = 403, message = "Forbidden"),
            @ApiResponse(code = 404, message = "Not Found"),
            @ApiResponse(code = 500, message = "Internal Server Error"),
            @ApiResponse(code = 502, message = "Bad gateway"),
            @ApiResponse(code = 503, message = "The service is temporarily unavailable"),
            @ApiResponse(code = 504, message = "Gateway Timeout")})

    @PostMapping(path = "/{mortgageAccount}/card-one-off-overpayment",
            produces = MediaType.APPLICATION_JSON_VALUE,
            consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<CardPaymentResponseWrapper> cardOneOffOverpayment(
            @RequestHeader(name = "Authorization", required = true) String jwtToken,
            @PathVariable int mortgageAccount,
            @Valid @RequestBody CardOneOffPaymentRequest cardOneOffPaymentRequest,
            HttpServletRequest httpServletRequest) throws GeneralException {
        CardPaymentResponse response = cardOneOffOverpaymentService.makeCardOneOffOverpayment(mortgageAccount, cardOneOffPaymentRequest, jwtToken, extractIpAddress(httpServletRequest), extractOrigin(httpServletRequest));

        return new ResponseEntity<>(wrapResponse(response), HttpStatus.CREATED);
    }

    private CardPaymentResponseWrapper wrapResponse(CardPaymentResponse cardPaymentResponse) {
        CardPaymentResponseWrapper responseWrapper = new CardPaymentResponseWrapper();
        responseWrapper.setData(cardPaymentResponse);
        responseWrapper.setInfo(ServiceInfoCreator.ok());
        return responseWrapper;
    }
}
