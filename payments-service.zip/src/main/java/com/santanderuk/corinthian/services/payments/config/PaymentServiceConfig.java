package com.santanderuk.corinthian.services.payments.config;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.ApplyOverpaymentClient;
import com.santanderuk.corinthian.services.commons.anmfclient.SimulationClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectClient;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.BksConnectMapper;
import com.santanderuk.corinthian.services.commons.clients.lac.LocalAccountConverterClient;
import com.santanderuk.corinthian.services.commons.config.ApiManagerConfig;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.time.Clock;
import java.util.ArrayList;
import java.util.List;

@Configuration
@Getter
@ComponentScan(basePackages = "com.santanderuk.corinthian")
public class PaymentServiceConfig {

    @Value("${operativesecurity}")
    private boolean operativeSecurity;

    @Value("${setupregularparameters.instructiontype}")
    private String setUpRegularInstructionType;

    @Value("${setupregularparameters.instructiontouse}")
    private String setUpRegularInstructionToUse;

    @Value("${setupregularparameters.instructionsequence}")
    private String setUpRegularInstructionSequence;

    @Value("${setupregularparameters.action}")
    private String setUpRegularInstructionAction;

    @Value("${setupregularparameters.channeltype}")
    private String setUpRegularInstructionChannelType;

    @Value("${setupregularparameters.sourceapp}")
    private String setUpRegularInstructionSourceApp;

    @Value("${setupregularparameters.callingapp}")
    private String setUpRegularInstructionCallingApp;

    @Value("${setupregularparameters.loanorder}")
    private String setUpRegularInstructionLoanOrder;

    @Value("${setupregularparameters.stoperc}")
    private String setUpRegularInstructionStopErc;

    @Value("${setupregularparameters.userid}")
    private String setUpRegularUserId;

    @Value("${regularOverpaymentEnquiry.payment-arrangements-type}")
    private String paymentArrangementsType;

    @Bean
    public Clock clock() {
        return Clock.systemDefaultZone();
    }

    @Bean
    public AnmfCoreClient anmfCoreClient() {
        return new AnmfCoreClient(objectMapper(), paymentRestTemplate(), apiManagerConfig());
    }

    @Bean
    public BksConnectClient bksConnectClient() {
        return new BksConnectClient(apiManagerConfig(), paymentRestTemplate(), bksConnectMapper());
    }

    @Bean
    public SimulationClient simulationClient() {
        return new SimulationClient(paymentRestTemplate(), apiManagerConfig());
    }

    @Bean
    public ApplyOverpaymentClient applyOverpaymentClient() {
        return new ApplyOverpaymentClient(paymentRestTemplate(), apiManagerConfig());
    }

    @Bean
    public LocalAccountConverterClient localAccountConverterClient() {
        return new LocalAccountConverterClient(paymentRestTemplate(), apiManagerConfig());
    }

    @Bean("paymentRestTemplate")
    public RestTemplate paymentRestTemplate() {
        RestTemplate restTemplate = new RestTemplate(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()));
        List<ClientHttpRequestInterceptor> interceptors = new ArrayList<>();
        interceptors.add(new LoggingRequestInterceptor());
        restTemplate.setInterceptors(interceptors);
        return restTemplate;
    }

    @Bean
    public ApiManagerConfig apiManagerConfig() {
        return new ApiManagerConfig();
    }

    @Bean
    public BksConnectMapper bksConnectMapper() {
        return new BksConnectMapper();
    }

    @Bean
    ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

}
