package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CardDataRedisPersistence {

    public static final String KEY_CARD_TRANSACTION = "card-transaction-";
    public static final String LONG_LIFE_CACHE = "cacheManagerLongLife";
    public static final String RETURN_CARRIAGE = "[\r\n]";
    public static final String EMPTY_STRING = "";

    private final OpayoUtils opayoUtils;

    public CardDataRedisPersistence(OpayoUtils opayoUtils) {
        this.opayoUtils = opayoUtils;
    }

    @Cacheable(cacheManager = LONG_LIFE_CACHE,
            cacheNames = "card-transaction",
            value = "card-transaction",
            key = "#root.target.KEY_CARD_TRANSACTION + #transactionId")
    public CardTransactionDetails cacheCardTransaction(final String transactionId, final CardMortgageSingleOverpaymentsContext context) throws GeneralException {
        try {
            log.info("caching card details for transaction: {}", transactionId.replaceAll(RETURN_CARRIAGE, EMPTY_STRING));
            CardTransactionDetails cardTransactionDetails = context.getCardTransactionDetails();
            log.debug("cardDetails: {}", cardTransactionDetails.toString().replaceAll(RETURN_CARRIAGE, EMPTY_STRING));
            String encryptedCard = opayoUtils.encryptGivenText(cardTransactionDetails.getCardNumber());
            cardTransactionDetails.setCardNumber(encryptedCard);
            log.info("caching card details for transaction: {} finished", transactionId.replaceAll(RETURN_CARRIAGE, EMPTY_STRING));
            return cardTransactionDetails;
        } catch (Exception e) {
            log.error("cardTransactionDetails not found on cache");
            throw new GeneralException("CONFIRM_CARD_PAYMENT_KO", "Error confirming 3ds payment");
        }
    }
}
