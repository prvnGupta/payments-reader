package com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BdpCustomer extends ModelBase {

    @NotBlank
    private String customerType;

    @NotNull
    private int customerNumber;
}
