package com.santanderuk.corinthian.services.payments.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
public class EndpointConfiguration {
    @Value("${anmf.services.account-details}")
    private String anmfAccountInfoUrl;

    @Value("${anmf.services.simulation}")
    private String anmfSimulationUrl;

    @Value("${anmf.services.apply-overpayment}")
    private String anmfApplyOverpaymentUrl;

    @Value("${anmf.services.customerservice}")
    private String anmfCustomerServiceUrl;

    @Value("${anmf.services.payment-arrangements-enquiry}")
    private String anmfFetchRegularOverpaymentUrl;

    @Value("${anmf.services.regular-overpayment}")
    private String anmfSetupEditCancelRegularOverpaymentUrl;

    @Value("${anmf.services.loan-payment-plan}")
    private String anmfLoanPaymentPlanUrl;

    @Value("${bksconnect.endpoints.retrievemcc}")
    private String retrieveMccUrl;

    @Value("${bksconnect.endpoints.contractsInMcc}")
    private String contractsInMcc;

    @Value("${lac.url}")
    private String lacUrl;

    @Value("${accountBalances}")
    private String accountBalancesUrl;
}
