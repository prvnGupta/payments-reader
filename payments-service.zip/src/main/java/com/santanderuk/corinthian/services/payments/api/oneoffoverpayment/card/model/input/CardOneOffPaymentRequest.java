package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CardOneOffPaymentRequest extends ModelBase {
    private static final long serialVersionUID = 5271446383234623769L;

    @Valid
    private CardDetails cardDetails;
    @NotBlank
    private String ercCollectionOption;
    @Valid
    List<LoanDetails> loanDetails;
    private String browserUserAgent;
    private String challengeWindowSize;
}
