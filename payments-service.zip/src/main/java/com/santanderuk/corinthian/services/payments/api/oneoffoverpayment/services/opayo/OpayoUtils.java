package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

@Component
@Slf4j
public class OpayoUtils {

    private static final String ENCRYPTION_ALGORITHM = "AES/GCM/NoPadding";
    public static final int KEY_LENGTH = 256;
    public static final int SALT_LENGTH = 16;
    private static final int IV_LENGTH_BYTE = 12;
    private static final int TAG_LENGTH_BIT = 128;
    private static final String DATE_TIME_FORMAT = "yyyyMMddHHmmss";
    private final SecureRandom random = new SecureRandom();

    @Value("${encrypt.password}")
    private String keyPassword;

    public String encryptGivenText(String plainText) throws GeneralException {
        try {
            byte[] salt = getRandomNonce(SALT_LENGTH);
            byte[] iv = getRandomNonce(IV_LENGTH_BYTE);
            SecretKey aesKeyFromPassword = getAESKeyFromPassword(keyPassword.toCharArray(), salt);

            Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM);
            cipher.init(Cipher.ENCRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
            byte[] cipherText = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
            byte[] cipherTextWithIvSalt = ByteBuffer.allocate(iv.length + salt.length + cipherText.length)
                    .put(iv)
                    .put(salt)
                    .put(cipherText)
                    .array();

            return Base64.getEncoder().encodeToString(cipherTextWithIvSalt);
        } catch (Exception ex) {
            log.error("Exception while encrypting data : ", ex);
            throw new GeneralException("CARD_ENCRYPTION_ERR", "Exception while encrypting the card", ex);
        }
    }

    public String decryptGivenText(String cipheredText) throws GeneralException {
        try {
            byte[] decode = Base64.getDecoder().decode(cipheredText.getBytes(StandardCharsets.UTF_8));
            ByteBuffer bb = ByteBuffer.wrap(decode);

            byte[] iv = new byte[IV_LENGTH_BYTE];
            bb.get(iv);
            byte[] salt = new byte[SALT_LENGTH];
            bb.get(salt);
            byte[] cipherText = new byte[bb.remaining()];
            bb.get(cipherText);

            SecretKey aesKeyFromPassword = getAESKeyFromPassword(keyPassword.toCharArray(), salt);
            Cipher cipher = Cipher.getInstance(ENCRYPTION_ALGORITHM);
            cipher.init(Cipher.DECRYPT_MODE, aesKeyFromPassword, new GCMParameterSpec(TAG_LENGTH_BIT, iv));
            byte[] plainText = cipher.doFinal(cipherText);
            return new String(plainText, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            log.error("Exception while decrypting data : ", ex);
            throw new GeneralException("CARD_ENCRYPTION_ERR", "Exception while encrypting the card", ex);
        }
    }

    private byte[] getRandomNonce(int numBytes) {
        byte[] nonce = new byte[numBytes];
        new SecureRandom().nextBytes(nonce);
        return nonce;
    }

    private SecretKey getAESKeyFromPassword(char[] password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        KeySpec spec = new PBEKeySpec(password, salt, 65536, KEY_LENGTH);
        return new SecretKeySpec(factory.generateSecret(spec).getEncoded(), "AES");
    }

    public String maskCardNumber(String cardNumber) {
        return cardNumber.substring(0, 6) + "*" + cardNumber.substring(cardNumber.length() - 4);
    }

    public String generateVendorCode(String cardNumber) {
        StringBuilder transactionId = new StringBuilder();

        int randomNumber = random.nextInt(99999);
        cardNumber = cardNumber.replace(" ", "");

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(DATE_TIME_FORMAT);
        String dateTime = LocalDateTime.now().format(formatter);
        String first6Digits = cardNumber.substring(0, 6);
        String last4Digits = cardNumber.substring(cardNumber.length() - 4);

        transactionId.append('O')
                .append(dateTime)
                .append(StringUtils.leftPad(String.valueOf(randomNumber), 5, '0'))
                .append(first6Digits)
                .append(last4Digits);

        return transactionId.toString();
    }
}
