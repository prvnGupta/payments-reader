package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.lynxnrtconnection.Exceptions.LynxNRTException;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck.LynxFraudCheckService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lynxnrt.LynxNRTService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.DebitResponse;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment.MakePaymentService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.*;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.gass.OneOffInternalTransferGassService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class OneOffInternalTransferService {
    public static final String SUCCESS_GASS_STATUS = "1";
    public static final String ERROR_GASS_STATUS = "2";

    private final SetupPaymentMapper setupPaymentMapper;
    private final SetupPaymentClient setupPaymentClient;
    private final LynxFraudCheckService lynxFraudCheckService;
    private final LynxNRTService lynxNRTService;
    private final MakePaymentService makePaymentService;
    private final OneOffInternalTransferGassService oneOffInternalTransferGassService;

    public OneOffInternalTransferService(SetupPaymentMapper setupPaymentMapper, SetupPaymentClient setupPaymentClient, LynxFraudCheckService lynxFraudCheckService, LynxNRTService lynxNRTService, MakePaymentService makePaymentService, OneOffInternalTransferGassService oneOffInternalTransferGassService) {
        this.setupPaymentMapper = setupPaymentMapper;
        this.setupPaymentClient = setupPaymentClient;
        this.lynxFraudCheckService = lynxFraudCheckService;
        this.lynxNRTService = lynxNRTService;
        this.makePaymentService = makePaymentService;
        this.oneOffInternalTransferGassService = oneOffInternalTransferGassService;
    }

    public String makeInternalTransfer(MortgageSingleOverpaymentsContext context) throws PaymentsFuncException, FraudException {

        SetupRequest setupRequest = setupPaymentMapper.generateSetupRequest(context.getInternalTransferAccountsDetails().getAccountFrom().getPartenonAccountNumber(), context.getUpdatedSimulationResponse().getOTotPayment());
        SetupResponse setupResponse = callSetupAndGass(context, setupRequest);

        DebitResponse debitResponse = callFraudAndDebitPersonalAccount(context, setupRequest, setupResponse);

        return debitResponse.getCreateUniqueNumber().getUniqueNumber();
    }

    private DebitResponse callFraudAndDebitPersonalAccount(MortgageSingleOverpaymentsContext context, SetupRequest setupRequest, SetupResponse setupResponse) throws FraudException, PaymentsFuncException {
        DebitResponse debitResponse = new DebitResponse();

        try {
            lynxFraudCheckService.callLynxFraudCheck(context, setupResponse);
            debitResponse = makePaymentService.callMakePayment(setupRequest, setupResponse, context);
            oneOffInternalTransferGassService.callGassMakePayment(context, SUCCESS_GASS_STATUS);
            lynxNRTService.mapAndCallLynxNRT(context, debitResponse.getStatus());
        } catch (FraudException fe) {
            if (fe.getMessage().trim().equalsIgnoreCase("TRANSACTION DECLINED BY FRAUD")) {
                callLynxNrtWithKoStatus(context);
            }
            throw fe;
        } catch (PaymentsFuncException pfe) {
            oneOffInternalTransferGassService.callGassMakePayment(context, ERROR_GASS_STATUS);
            callLynxNrtWithKoStatus(context);
            throw pfe;
        } catch (LynxNRTException lynxNRTException) {
            log.warn("Exception while calling LynxNRT service after debit payment OK");
        }
        return debitResponse;
    }

    private SetupResponse callSetupAndGass(MortgageSingleOverpaymentsContext context, SetupRequest setupRequest) throws PaymentsFuncException {
        String gassResultIndicator = ERROR_GASS_STATUS;
        SetupResponse setupResponse;
        try {
            setupResponse = setupPaymentClient.callSetup(setupRequest);
            gassResultIndicator = SUCCESS_GASS_STATUS;
        } finally {
            oneOffInternalTransferGassService.callGassSetup(context, gassResultIndicator);
        }
        return setupResponse;
    }

    private void callLynxNrtWithKoStatus(MortgageSingleOverpaymentsContext context) {
        try {
            lynxNRTService.mapAndCallLynxNRT(context, "KO");
        } catch (LynxNRTException lynxNRTException) {
            log.warn("Exception while calling LynxNRT service after debit payment or fraud-check error");
        }
    }


}
