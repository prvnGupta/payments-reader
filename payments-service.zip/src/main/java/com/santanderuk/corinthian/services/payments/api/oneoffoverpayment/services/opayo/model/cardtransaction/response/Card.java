
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Card extends ModelBase {

    private static final long serialVersionUID = -2744481134002013397L;

    private String cardId;
    private String schemaDescription;
    private Expiration expiration;
    private boolean reusable;

}
