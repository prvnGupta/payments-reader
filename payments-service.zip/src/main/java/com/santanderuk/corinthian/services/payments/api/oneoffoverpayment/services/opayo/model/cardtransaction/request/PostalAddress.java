
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class PostalAddress extends ModelBase {
    private static final long serialVersionUID = 2331698928709496148L;

    private String line1;
    private String line2;
    private City city;
    private String postCodeIdentification;
    private Country country;
}
