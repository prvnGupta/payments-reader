package com.santanderuk.corinthian.services.payments.api.regularoverpayment.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Component;


@Component
@Slf4j
public class ClearRegularOverpaymentCache {

    @Autowired
    private CacheManager cacheManagerShortLife;

    public void deleteRegularOverpaymentCache(int account) {
        log.debug("deleting cache for fetch-anmf-ov-arrangements-{} after setup/edit/cancel reg overpayment.", account);
        Cache cacheGetRegularOverpayment = cacheManagerShortLife.getCache("fetch-anmf-ov-arrangements");
        cacheGetRegularOverpayment.evict("fetch-anmf-ov-arrangements-" + account);
    }
}
