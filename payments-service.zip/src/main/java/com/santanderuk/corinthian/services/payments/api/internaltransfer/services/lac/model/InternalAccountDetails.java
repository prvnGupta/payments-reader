package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model;

import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import lombok.Data;

@Data
public class InternalAccountDetails {
    private PartenonAccountNumber partenonAccountNumber;
    private LocalAccountNumber localAccountNumber;
}
