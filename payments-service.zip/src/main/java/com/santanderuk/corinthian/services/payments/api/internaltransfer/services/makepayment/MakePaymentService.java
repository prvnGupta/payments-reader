package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;

import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MakePaymentService {

    private final MakePaymentMapper makePaymentMapper;
    private final MakePaymentClient makePaymentClient;

    @Autowired
    public MakePaymentService(MakePaymentMapper makePaymentMapper, MakePaymentClient makePaymentClient) {
        this.makePaymentMapper = makePaymentMapper;
        this.makePaymentClient = makePaymentClient;
    }

    public DebitResponse callMakePayment(SetupRequest setupRequest, SetupResponse setupResponse, InternalTransferRequest internalTransferRequest, InternalTransferAccountsDetails accountsDetails) throws PaymentsFuncException {
        DebitRequest debitRequest = makePaymentMapper.mapRequest(setupRequest, setupResponse, internalTransferRequest, accountsDetails);
        return makePaymentClient.callDebitPayment(debitRequest);
    }

    public DebitResponse callMakePayment(SetupRequest setupRequest, SetupResponse setupResponse, MortgageSingleOverpaymentsContext context) throws PaymentsFuncException {
        DebitRequest debitRequest = makePaymentMapper.mapRequest(setupRequest, setupResponse, context);
        return makePaymentClient.callDebitPayment(debitRequest);
    }
}
