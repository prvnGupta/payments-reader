package com.santanderuk.corinthian.services.payments.api.regularoverpayment.service;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.OPayArrOvpInst;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentMapper;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.gass.GassService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CancelRegularOverpaymentService {

    public static final String REGULAR_OVERPAYMENT_TYPE = "C";
    private static final String SUCCESS_GASS_STATUS = "1";
    private static final String ERROR_GASS_STATUS = "2";
    private final HeartBeatClient heartBeatClient;
    private final AnmfCoreClient anmfCoreClient;
    private final RegularOverpaymentMapper regularOverpaymentMapper;
    private final GassService gassService;
    private final ClearRegularOverpaymentCache clearRegularOverpaymentCache;
    private final EndpointConfiguration endpointConfiguration;
    private final PaymentArrangementEnquiryHelper paymentArrangementEnquiryHelper;

    @Autowired
    public CancelRegularOverpaymentService(HeartBeatClient heartBeatClient, AnmfCoreClient anmfCoreClient, RegularOverpaymentMapper regularOverpaymentMapper, GassService gassService, ClearRegularOverpaymentCache clearRegularOverpaymentCache, EndpointConfiguration endpointConfiguration, PaymentArrangementEnquiryHelper paymentArrangementEnquiryHelper) {
        this.heartBeatClient = heartBeatClient;
        this.anmfCoreClient = anmfCoreClient;
        this.regularOverpaymentMapper = regularOverpaymentMapper;
        this.gassService = gassService;
        this.clearRegularOverpaymentCache = clearRegularOverpaymentCache;
        this.endpointConfiguration = endpointConfiguration;
        this.paymentArrangementEnquiryHelper = paymentArrangementEnquiryHelper;
    }

    public void cancelExistingInstruction(int account, String jwtToken, String ipAddress, CustomerDetailsResponse customerDetailsResponse) throws GeneralException {

        String status = ERROR_GASS_STATUS;
        AnmfRegion region = heartBeatClient.fetchCurrentRegion();

        OPayArrOvpInst overpaymentInstructionToCancel = paymentArrangementEnquiryHelper.extractInstructionToBeAmendedOrCancelled(account, region);

        String impact = overpaymentInstructionToCancel.getOPayArrImpact();

        /*we can use builder pattern but in many methods we are getting and setting the data. seems context obj is not immutable. I am keeping as it is.
       We were passing many params in method. So i have changed a method signature and now we are directly passing context object to mapper.
       */
        final var context = new RegularOverpaymentContext();
        context.setAnmfAccountResponse(anmfCoreClient.fetchMortgageAccountDetailsV5(account, endpointConfiguration.getAnmfAccountInfoUrl(), region));
        context.setJwtToken(jwtToken);
        context.setAccount(account);
        context.setSequential(overpaymentInstructionToCancel.getOPayArrSeq());
        context.setInstructionAction(REGULAR_OVERPAYMENT_TYPE);
        context.setInstruction(overpaymentInstructionToCancel);

        AnmfRegularOverpaymentCUDRequest request = regularOverpaymentMapper.generateDeleteRequest(context);

        try {
            status = callAnmfCancelOverpaymentWithStatus(request);
        } finally {
            gassService.auditCancelRegularOverpayment(account, jwtToken, ipAddress, status, impact, customerDetailsResponse, context);
        }

    }

    public String callAnmfCancelOverpaymentWithStatus(AnmfRegularOverpaymentCUDRequest request) throws ConnectionException {
        AnmfRegularOverpaymentCUDResponse cudResponse = anmfCoreClient.deleteRegularPayment(request, endpointConfiguration.getAnmfSetupEditCancelRegularOverpaymentUrl());
        clearRegularOverpaymentCache.deleteRegularOverpaymentCache(request.getOverpaymentArrangementRequest().getInputStruc().getIMortAccNo());

        String eCode = cudResponse.getOverpaymentArrangementResponse().getOutputStruc().getEStruc().getECode();
        if (eCode.length() == 0) {
            return SUCCESS_GASS_STATUS;
        }
        return ERROR_GASS_STATUS;
    }


}
