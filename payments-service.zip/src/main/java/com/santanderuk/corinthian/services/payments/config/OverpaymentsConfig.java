package com.santanderuk.corinthian.services.payments.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;


@Getter
@Configuration
public class OverpaymentsConfig {

    @Value("${operativesecurity}")
    private boolean operativeSecurity;

    @Value("${apimanager.client-id-value}")
    private String clientId;

    @Value("${internal-transfer.card-operational.endpoint}")
    private String cardOperationalEndpoint;

    @Value("${internal-transfer.setup-payment.endpoint}")
    private String setupEndpoint;

    @Value("${internal-transfer.lynx-fraud.endpoint}")
    private String lynxFraudEndpoint;

    @Value("${internal-transfer.make-payment.endpoint}")
    private String makePaymentEndpoint;

    @Value("${internal-transfer.setup-payment.currency}")
    private String setupDataCurrency;

    @Value("${internal-transfer.setup-payment.residenceCountry}")
    private String setupDataResidenceCountry;

    @Value("${internal-transfer.setup-payment.expensesIndicator}")
    private String setupDataExpensesIndicator;

    @Value("${internal-transfer.setup-payment.transmissionType}")
    private String setupDataTransmissionType;

    @Value("${internal-transfer.setup-payment.transactionBranch}")
    private String setupDataTransactionBranch;

    @Value("${internal-transfer.lynx-fraud.debit-type}")
    private String lynxFraudDebitType;

    @Value("${internal-transfer.lynx-fraud.credit-type}")
    private String lynxFraudCreditType;

    @Value("${internal-transfer.lynx-fraud.currency}")
    private String lynxFraudCurrency;

    @Value("${internal-transfer.lynx-fraud.channel-type}")
    private String lynxFraudChannelType;

    @Value("${internal-transfer.lynx-fraud.process-flag}")
    private String lynxFraudProcessFlag;

    @Value("${internal-transfer.lynx-fraud.flag-credit-debit}")
    private String lynxFraudFlagCreditDebit;

    @Value("${internal-transfer.lynx-fraud.application-code-fee}")
    private String lynxFraudApplicationCodeFee;

    @Value("${internal-transfer.lynx-fraud.application-code-overpayment}")
    private String lynxFraudApplicationCodeOverpayment;

    @Value("${internal-transfer.lynx-fraud.message-type}")
    private String lynxFraudMessageType;

    @Value("${internal-transfer.lynx-nrt.endpoint}")
    private String lynxNRTEndpoint;

    @Value("${internal-transfer.lynx-nrt.category-name}")
    private String lynxNRTCategoryName;

    @Value("${internal-transfer.make-payment.same-holder}")
    private String makePaymentSameHolder;

    @Value("${internal-transfer.make-payment.beneficiary-type}")
    private String makePaymentBeneficiaryType;

    @Value("${internal-transfer.make-payment.beneficiary-partenon-entity}")
    private String makePaymentBeneficiaryPartenonEntity;

    @Value("${internal-transfer.make-payment.beneficiary-account-branch}")
    private String makePaymentBeneficiaryAccountBranch;

    @Value("${one-off.beneficiaryLocalAccountNumber}")
    private String beneficiaryLocalAccountNumber;

    @Value("${one-off.beneficiaryLocalAccountSortcode}")
    private String beneficiaryLocalAccountSortcode;

    @Value("${simulation.channel-type}")
    private String channelType;

    @Value("${simulation.calling-application}")
    private String callingApplication;

    @Value("${simulation.user-id}")
    private String simulationUserId;

    @Value("${one-off.minimum-amount}")
    private BigDecimal minimumOverpaymentAmount;

    @Value("${one-off.maximumNumberOfOverpayments}")
    private int maximumNumberOfOverpayments;

}
