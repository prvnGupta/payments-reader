package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model;

import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.Address;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class CardTransactionDetails extends ModelBase {
    private static final long serialVersionUID = 3868315231538495449L;

    private String cardNumber;
    private int mortgageAccount;
    private String expiryDate;
    private Address address;
    private String cardHolderCustomerId;
    private String cardHolderFirstName;
    private String cardHolderLastName;
    private String cardHolderBirthDate;
    private BigDecimal overpaymentAmount;
    private String ercCollectionOption;
    private List<LoanDetails> loanDetails;
    private String vendorCode;
    private OutputStruc updatedSimulationResponse;
}
