package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PDFCreationData {

    private String sortCode;
    private String accountNumber;

    private String totalOverpayment;
    private String totalEarlyRepayment;
    private String totalPayment;

    private String firstPayment;
    private String secondPayment;
    private String futurePayment;

    private String newOutstandingBalance;

    private String paymentMethodSelection;
    private String paymentMethod;
    private String paymentMethodName;

    private String paymentTakenOn;

}
