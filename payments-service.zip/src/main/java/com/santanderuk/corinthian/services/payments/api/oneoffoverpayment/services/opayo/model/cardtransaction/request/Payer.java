
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;


@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class Payer extends ModelBase {
    private static final long serialVersionUID = 8735531487935571924L;

    private Account account;
    private ContactPoint contactPoint;
    private Person person;
}
