package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OLoanData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model.CardGASSFormattedData;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model.GASSMessageData;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.Card;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.CardTransactionResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.Transaction;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.BorrowerElement;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.CardLoanDetails;
import com.santanderuk.corinthian.services.payments.config.GASSConfig;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.lang.Integer.parseInt;

@Component
@Service
@Slf4j
public class CardGASSService {

    private final GASSClient gassClient;
    private final GASSConfig gassConfig;
    private final GassDataFetcher gassDataFetcher;
    private final OpayoConfig opayoConfig;

    private static final String CHANNEL_TYPE = "INT";
    private static final String CURRENCY_CODE = "826";
    private static final String SPACE = " ";
    private static final String EMPTY_STRING = "";

    @Autowired
    public CardGASSService(GassDataFetcher gassDataFetcher, GASSClient gassClient, GASSConfig gassConfig, OpayoConfig opayoConfig) {
        this.gassDataFetcher = gassDataFetcher;
        this.gassClient = gassClient;
        this.gassConfig = gassConfig;
        this.opayoConfig = opayoConfig;
    }

    public void auditDebitCardPayment(CardMortgageSingleOverpaymentsContext context, boolean success) {

        try {
            log.info("auditDebitCardPayment -> started");
            GASSMessageData gassMessage = generateGassMessage(context);
            gassClient.send(gassMessage, success);
            log.info("auditDebitCardPayment -> finished");
        } catch (Exception e) {
            log.error("triggerEmailAlert -> Error while auditing overpayments made through card payment for to GAAS", e);
        }

    }

    GASSMessageData generateGassMessage(CardMortgageSingleOverpaymentsContext context) {
        String mccId = gassDataFetcher.fetchMccId(context.getLdapUid());
        GASSMessageData gassMessageData = setCommonGassData(context, mccId);
        String formattedData = getGassCardFormatData(context, mccId);
        gassMessageData.setFormattedData(formattedData);
        return gassMessageData;
    }

    GASSMessageData setCommonGassData(CardMortgageSingleOverpaymentsContext context, String mccId) {

        GASSMessageData gassMessageData = new GASSMessageData();
        gassMessageData.setDeviceId(context.getIpAddress());
        gassMessageData.setAppSysId(parseInt(gassConfig.getAppSysIdInternet()));
        gassMessageData.setDeviceTyp(parseInt(gassConfig.getDvcTypInternet()));
        String customerId = "F" + context.getLoggedCustomer().getOCustomerId();
        gassMessageData.setCustomerId(customerId);
        gassMessageData.setUserId(customerId);
        gassMessageData.setLdapUid(context.getLdapUid());
        gassMessageData.setMccId(mccId);
        gassMessageData.setAmount(context.getCardTransactionDetails().getUpdatedSimulationResponse().getOTotPayment().multiply(new BigDecimal("100")).setScale(0, RoundingMode.HALF_UP).toString());
        gassMessageData.setAnmfAccount(opayoConfig.getAnmfSortcode() + " " + StringUtils.leftPad(String.valueOf(context.getMortgageAccount()), 9, '0'));
        gassMessageData.setAuditTrnTpName(gassConfig.getTransactionNameDebitCardPayment());
        gassMessageData.setAudittrngrpid(gassConfig.getAuditTrnGrpId());

        return gassMessageData;
    }


    String getGassCardFormatData(CardMortgageSingleOverpaymentsContext context, String mccId) {

        CardTransactionDetails cardTransactionDetails = context.getCardTransactionDetails();

        CardGASSFormattedData gassCardFormatData = new CardGASSFormattedData();
        gassCardFormatData.setCardNumber(cardTransactionDetails.getCardNumber().replace("*", "******"));
        gassCardFormatData.setCardName(getCardName(context));
        gassCardFormatData.setAddressLine1(cardTransactionDetails.getAddress().getLine1());
        gassCardFormatData.setPostCode(cardTransactionDetails.getAddress().getPostcode());
        gassCardFormatData.setCustomerName(cardTransactionDetails.getCardHolderFirstName() + SPACE + cardTransactionDetails.getCardHolderLastName());
        gassCardFormatData.setBeneficiaryName(cardTransactionDetails.getCardHolderFirstName() + SPACE + cardTransactionDetails.getCardHolderLastName());
        gassCardFormatData.setDateOfBirth(context.getLoggedCustomer().getODateOfBirth());
        gassCardFormatData.setMccId(mccId);
        gassCardFormatData.setEarlyRepaymentCharge(isERCApplicable(context.getCardTransactionDetails().getUpdatedSimulationResponse()));
        gassCardFormatData.setEarlyRepaymentChargeAmount(context.getCardTransactionDetails().getUpdatedSimulationResponse().getOTotErc());
        gassCardFormatData.setCurrency(CURRENCY_CODE);
        gassCardFormatData.setTransactionId(getTransactionId(context));
        gassCardFormatData.setOverPaymentAmount(context.getCardTransactionDetails().getUpdatedSimulationResponse().getOTotOvpAmount());
        gassCardFormatData.setTotalAmount(context.getCardTransactionDetails().getUpdatedSimulationResponse().getOTotPayment());
        gassCardFormatData.setPartenonFormatMortgageAccountNumber(getPartenonAccountNumber(context.getAnmfPartenonAccountNumber()));
        gassCardFormatData.setChannelType(CHANNEL_TYPE);
        gassCardFormatData.setOpayoResponseCode(getTransactionResponseCode(context.getCardTransactionResponse()));
        gassCardFormatData.setBorrowerList(generateBorrowerList(context));
        gassCardFormatData.setLoanDetails(generateLoanDetails(context));
        return gassCardMessageToString(gassCardFormatData);
    }

    private List<CardLoanDetails> generateLoanDetails(CardMortgageSingleOverpaymentsContext context) {
        List<CardLoanDetails> loanDetailsList = new ArrayList<>();
        for (OLoanData oLoanData : context.getCardTransactionDetails().getUpdatedSimulationResponse().getOLoanData()) {
            if (thereIsAnOverpaymentInLoan(oLoanData, context.getSimulationChosenValues())) {
                CardLoanDetails loan = new CardLoanDetails();
                loan.setLoanSchema(oLoanData.getOLoanSch());
                loan.setLoanApplicationSequenceNumber(oLoanData.getOApplSeqNo());
                loan.setOptionChosen(getOptionChosen(context.getSimulationChosenValues(), oLoanData));
                loan.setLoanErcAmount(oLoanData.getOLnErc());
                loan.setLoanOverpaymentAmount(getLoanOverpaymentAmount(context.getSimulationChosenValues(), oLoanData));
                loan.setLoanTotalPaymentAmount(getLoanTotalPaymentAmount(context.getSimulationChosenValues(), oLoanData));
                loan.setNewMonthlyPayment(oLoanData.getOLnSimMonPay());
                loan.setNewMortgageTerm(oLoanData.getOLnSimMatDt());
                loan.setInterestSaving(getInterestSavingAcrossTerm(oLoanData));
                loanDetailsList.add(loan);
            }
        }
        return loanDetailsList;
    }

    private boolean thereIsAnOverpaymentInLoan(OLoanData oLoanData, SimulationChosenValues simulationChosenValues) {
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    return loanDetails.getLoanOverpaymentAmount().compareTo(BigDecimal.ZERO) != 0;
                }
            }
        }
        return false;
    }

    private BigDecimal getLoanOverpaymentAmount(SimulationChosenValues simulationChosenValues, OLoanData oLoanData) {
        BigDecimal loanOverpaymentAmount = BigDecimal.valueOf(0);
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    loanOverpaymentAmount = simulationChosenValues.getErcCollectionOption().equalsIgnoreCase("I") ? loanDetails.getLoanOverpaymentAmount().subtract(oLoanData.getOLnErc()) : loanDetails.getLoanOverpaymentAmount();
                }
            }
        }
        return loanOverpaymentAmount;
    }

    private BigDecimal getLoanTotalPaymentAmount(SimulationChosenValues simulationChosenValues, OLoanData oLoanData) {
        BigDecimal loanTotalPaymentAmount = BigDecimal.valueOf(0);
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    loanTotalPaymentAmount = simulationChosenValues.getErcCollectionOption().equalsIgnoreCase("I") ? loanDetails.getLoanOverpaymentAmount() : loanDetails.getLoanOverpaymentAmount().add(oLoanData.getOLnErc());
                }
            }
        }
        return loanTotalPaymentAmount;
    }

    private String getCardName(CardMortgageSingleOverpaymentsContext context) {
        return Optional.ofNullable(context)
                .map(CardMortgageSingleOverpaymentsContext::getCardTransactionResponse)
                .map(CardTransactionResponse::getCard)
                .map(Card::getSchemaDescription).orElse(EMPTY_STRING);
    }

    private String getTransactionId(CardMortgageSingleOverpaymentsContext context) {
        return Optional.ofNullable(context)
                .map(CardMortgageSingleOverpaymentsContext::getCardTransactionResponse)
                .map(CardTransactionResponse::getTransaction)
                .map(Transaction::getTransactionId)
                .orElse(EMPTY_STRING);
    }

    private String gassCardMessageToString(CardGASSFormattedData gassCardFormatData) {
        XmlMapper xmlMapper = new XmlMapper();
        try {
            return xmlMapper.writer().withRootName("formattedData").writeValueAsString(gassCardFormatData);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return "Error parsing message";
        }
    }

    private String getPartenonAccountNumber(PartenonAccountNumber partenonAccountNumber) {
        String partenonAccNo = EMPTY_STRING;
        if (null != partenonAccountNumber) {
            partenonAccNo = partenonAccountNumber.getCompany() + partenonAccountNumber.getCentre() +
                    partenonAccountNumber.getProduct() + partenonAccountNumber.getContract();
        }
        return partenonAccNo;
    }

    private BigDecimal getInterestSavingAcrossTerm(OLoanData oLoanData) {
        BigDecimal interestSavingAcrossTerm = new BigDecimal(0);
        BigDecimal oLnIntDataBeforeSim = oLoanData.getOLnIntBefSim();
        BigDecimal oLnIntDataAfterSim = oLoanData.getOLnIntAftSim();
        if (null != oLnIntDataBeforeSim && null != oLnIntDataAfterSim) {
            interestSavingAcrossTerm = oLnIntDataBeforeSim.subtract(oLnIntDataAfterSim);
        }
        return interestSavingAcrossTerm;
    }

    private String getOptionChosen(SimulationChosenValues simulationChosenValues, OLoanData oLoanData) {
        String optionChosenValue = EMPTY_STRING;
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    if (loanDetails.getLoanChangeType().equalsIgnoreCase("T")) {
                        optionChosenValue = "Reduce Mortgage Term";
                    } else {
                        optionChosenValue = "Reduce Monthly Payments";
                    }
                }
            }
        }
        return optionChosenValue;
    }

    private String getTransactionResponseCode(CardTransactionResponse cardTransactionResponse) {
        String gassStatus = "999";
        if (null != cardTransactionResponse && null != cardTransactionResponse.getStatus() && StringUtils.isNotEmpty(cardTransactionResponse.getStatus().getStatusCode())) {
            if (cardTransactionResponse.getStatus().getStatusCode().equalsIgnoreCase("0000")) {
                gassStatus = "000";
            }
        }
        return gassStatus;
    }

    private boolean isERCApplicable(OutputStruc outputStruc) {
        return null != outputStruc && null != outputStruc.getOTotErc() && outputStruc.getOTotErc().compareTo(BigDecimal.ZERO) > 0;
    }

    private List<BorrowerElement> generateBorrowerList(CardMortgageSingleOverpaymentsContext context) {
        return Optional.ofNullable(context)
                .map(CardMortgageSingleOverpaymentsContext::getCustomerDetailsResponse)
                .map(CustomerDetailsResponse::getCustomerServiceResponse)
                .map(CustomerServiceResponse::getOStruc)
                .map(t ->
                        t.getOCustomerList().stream().map(borrower ->
                                new BorrowerElement(formatName(borrower), borrower.getOBdpType(), String.valueOf(borrower.getOCustomerId()))).collect(Collectors.toCollection(ArrayList<BorrowerElement>::new)))
                .orElseGet(ArrayList::new);
    }

    private String formatName(final OCustomer currentCustomer) {

        String name = formatAttribute(currentCustomer.getOCustomerTitle()) +
                formatAttribute(currentCustomer.getOForename1()) +
                formatAttribute(currentCustomer.getOForename2()) +
                formatAttribute(currentCustomer.getOForename3()) +
                formatAttribute(currentCustomer.getOSurname());
        return name.trim();
    }

    private String formatAttribute(final String attribute) {
        if (attributeIsEmpty(attribute)) {
            return EMPTY_STRING;
        } else {
            return attribute + " ";
        }
    }

    private boolean attributeIsEmpty(final String attribute) {
        return attribute == null || attribute.trim().equalsIgnoreCase(EMPTY_STRING);
    }
}
