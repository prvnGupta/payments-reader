package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;

import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request.*;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.CardTransactionResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response.Transaction;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.confirmtransaction.request.ConfirmCardTransactionRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cps.CPSCardPaymentRequest;
import com.santanderuk.corinthian.services.payments.config.OpayoConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Component
@Slf4j
public class OpayoPaymentMapper {
    public static final char CHAR_SPACE = ' ';
    public static final String DEFAULT_CARDID = "00000000-0000-0000-0000-000000000000";
    public static final String EMPTY_STRING = "";
    public static final String DEFAULT_BANK_AUTH_CODE = "999999";
    public static final String OPAYO_MAPPER_EXC = "OPAYO_MAPPER_EXC";

    private final OpayoConfig opayoConfig;
    private final OpayoUtils opayoUtils;

    @Autowired
    public OpayoPaymentMapper(OpayoConfig opayoConfig, OpayoUtils opayoUtils) {
        this.opayoConfig = opayoConfig;
        this.opayoUtils = opayoUtils;
    }

    public ConfirmCardTransactionRequest generateConfirmCardTransactionBaasApiRequest(CardMortgageSingleOverpaymentsContext context) throws OpayoException {
        var confirmCardTransactionRequest = new ConfirmCardTransactionRequest();
        try {
            confirmCardTransactionRequest.setConfirmType(opayoConfig.getConfirmType());
            confirmCardTransactionRequest.setInputCode(context.getCres());
            confirmCardTransactionRequest.setVendorData(generateVendorDataConfirm(context));
            return confirmCardTransactionRequest;
        } catch (Exception e) {
            log.error("Exception While generating Opayo confirm-transaction request");
            throw new OpayoException(OPAYO_MAPPER_EXC, "Exception While generating Opayo confirm-transaction request", e);
        }
    }

    public CardTransactionRequest generateCardTransactionBaasApiRequest(CardMortgageSingleOverpaymentsContext context) throws OpayoException {
        try {
            log.debug("OpayoPaymentMapper -> generateCardTransactionBaasApiRequest: starting");
            CardTransactionRequest cardTransactionRequest = new CardTransactionRequest();

            cardTransactionRequest.setCardData(generateCardData(context));
            cardTransactionRequest.setPaymentData(generatePaymentData(context));
            cardTransactionRequest.setVendorData(generateVendorData(context));
            cardTransactionRequest.setAdditionalData(generateAdditionalData(context));

            log.debug("OpayoPaymentMapper -> generateCardTransactionBaasApiRequest: ended OK");
            return cardTransactionRequest;
        } catch (Exception e) {
            log.error("Exception While generating Opayo card-transaction request");
            throw new OpayoException(OPAYO_MAPPER_EXC, "Exception While generating Opayo card-transaction request", e);
        }
    }

    public CPSCardPaymentRequest generateCPSCardPaymentRequest(CardMortgageSingleOverpaymentsContext context, String mortgageSortCodeAccNo) throws OpayoException {
        try {
            CPSCardPaymentRequest cpsCardPaymentRequest = new CPSCardPaymentRequest();
            CardTransactionDetails cardTransactionDetails = context.getCardTransactionDetails();
            String customerName = getCustomerForenameSurname(cardTransactionDetails);

            cpsCardPaymentRequest.setMerchantId(opayoConfig.getMerchantId());
            cpsCardPaymentRequest.setAgentCode(opayoConfig.getAgentCode());
            cpsCardPaymentRequest.setAmount(cardTransactionDetails.getUpdatedSimulationResponse().getOTotPayment());
            cpsCardPaymentRequest.setBankAuthorisationCode(getBankAuthorizationCode(context));
            cpsCardPaymentRequest.setBirthDate(formatBirthDate(cardTransactionDetails.getCardHolderBirthDate()));
            cpsCardPaymentRequest.setCardId(getCardId(context));
            cpsCardPaymentRequest.setContractAccountNumber(context.getAnmfPartenonAccountNumber().getContract());
            cpsCardPaymentRequest.setContractBranch(context.getAnmfPartenonAccountNumber().getCentre());
            cpsCardPaymentRequest.setContractEntity(context.getAnmfPartenonAccountNumber().getCompany());
            cpsCardPaymentRequest.setContractProduct(context.getAnmfPartenonAccountNumber().getProduct());
            cpsCardPaymentRequest.setContractId(getLast4DigitsOfCard(cardTransactionDetails.getCardNumber()));
            cpsCardPaymentRequest.setCurrency(opayoConfig.getCurrency());
            cpsCardPaymentRequest.setExpiryDate(formatExpiryDate(cardTransactionDetails.getExpiryDate()));
            cpsCardPaymentRequest.setIssueNumber(opayoConfig.getIssueNumber());
            cpsCardPaymentRequest.setLine1(formatLineOne(context));
            cpsCardPaymentRequest.setNumber(cardTransactionDetails.getCardNumber());
            cpsCardPaymentRequest.setNumberAnt(mortgageSortCodeAccNo);
            cpsCardPaymentRequest.setPersonName(customerName);
            cpsCardPaymentRequest.setPrintedName(customerName);
            cpsCardPaymentRequest.setPersonNumber(context.getLoggedCustomer().getOCustomerId());
            cpsCardPaymentRequest.setPersonType(context.getLoggedCustomer().getOBdpType());
            cpsCardPaymentRequest.setPostCodeIdentification(cardTransactionDetails.getAddress().getPostcode());
            cpsCardPaymentRequest.setPostCodeRegular(cardTransactionDetails.getAddress().getPostcode());
            cpsCardPaymentRequest.setProcess(opayoConfig.getCpsProcess());
            cpsCardPaymentRequest.setStartDate(EMPTY_STRING);
            cpsCardPaymentRequest.setStatusCode(generateStatusCode(context));
            cpsCardPaymentRequest.setStatusDetail(generateStatusDetail(context));
            cpsCardPaymentRequest.setTransactionId(getTransactionId(context));
            cpsCardPaymentRequest.setVendorCode(context.getCardTransactionDetails().getVendorCode());
            return cpsCardPaymentRequest;
        } catch (Exception e) {
            throw new OpayoException(OPAYO_MAPPER_EXC, "Failed to generate Update CPS Request", e);
        }
    }

    private String getTransactionId(CardMortgageSingleOverpaymentsContext cardContext) {
        return Optional.of(cardContext)
                .map(CardMortgageSingleOverpaymentsContext::getCardTransactionResponse)
                .map(CardTransactionResponse::getTransaction)
                .map(Transaction::getTransactionId)
                .orElse("");
    }

    private String formatExpiryDate(String expiryDate) {
        return expiryDate.replace("/", EMPTY_STRING);
    }

    private String formatLineOne(CardMortgageSingleOverpaymentsContext cardContext) {
        String line1 = cardContext.getCardTransactionDetails().getAddress().getLine1();
        return line1.length() > 9 ? line1.substring(0, 9) : line1;
    }

    private String getCardId(CardMortgageSingleOverpaymentsContext cardContext) {
        return isCardIdEmpty(cardContext) ? DEFAULT_CARDID : cardContext.getCardTransactionResponse().getCard().getCardId();
    }

    private boolean isCardIdEmpty(CardMortgageSingleOverpaymentsContext cardContext) {
        return null == cardContext.getCardTransactionResponse() || null == cardContext.getCardTransactionResponse().getCard().getCardId() || cardContext.getCardTransactionResponse().getCard().getCardId().equals("");
    }

    private String getBankAuthorizationCode(CardMortgageSingleOverpaymentsContext cardContext) {
        return (null == cardContext.getCardTransactionResponse() || null == cardContext.getCardTransactionResponse().getVendorData().getBankAuthorisationCode()) ? DEFAULT_BANK_AUTH_CODE : cardContext.getCardTransactionResponse().getVendorData().getBankAuthorisationCode();
    }

    private String generateStatusCode(CardMortgageSingleOverpaymentsContext cardContext) {
        return (null == cardContext.getCardTransactionResponse()) ? "9999" : cardContext.getCardTransactionResponse().getStatus().getStatusCode();
    }


    private String generateStatusDetail(CardMortgageSingleOverpaymentsContext cardContext) {
        return (null == cardContext.getCardTransactionResponse()) ? "Error 500 from Confirm Baas Api" : cardContext.getCardTransactionResponse().getStatus().getStatusDetail();
    }


    private AdditionalData generateAdditionalData(CardMortgageSingleOverpaymentsContext context) {
        AdditionalData additionalData = new AdditionalData();
        additionalData.setAgentCode(opayoConfig.getAgentCode());
        additionalData.setMerchantId(opayoConfig.getMerchantId());
        additionalData.setEntryMethod(opayoConfig.getEntryMethod());
        additionalData.setApply3DSecure(opayoConfig.getApply3DSecure());
        additionalData.setGiftAid(opayoConfig.isGiftAid());
        additionalData.setStrongCustomerAuthentication(generateStrongCustomerAuthentication(context));
        return additionalData;
    }

    private StrongCustomerAuthentication generateStrongCustomerAuthentication(CardMortgageSingleOverpaymentsContext context) {
        StrongCustomerAuthentication strongCustomerAuthentication = new StrongCustomerAuthentication();

        strongCustomerAuthentication.setNotificationURL(generateNotificationUrl(context.getOrigin()));
        strongCustomerAuthentication.setBrowserIP(StringUtils.isNotEmpty(context.getIpAddress()) ? context.getIpAddress() : "127.0.0.1");
        strongCustomerAuthentication.setBrowserJavascriptEnabled("False");
        strongCustomerAuthentication.setBrowserAcceptHeader("text/html, application/json");
        strongCustomerAuthentication.setBrowserLanguage("en-GB");
        strongCustomerAuthentication.setBrowserUserAgent(StringUtils.isNotEmpty(context.getCardOneOffPaymentRequest().getBrowserUserAgent()) ? context.getCardOneOffPaymentRequest().getBrowserUserAgent() : "unknown");
        strongCustomerAuthentication.setChallengeWindowSize(StringUtils.isNotEmpty(context.getCardOneOffPaymentRequest().getChallengeWindowSize()) ? context.getCardOneOffPaymentRequest().getChallengeWindowSize() : "Large");
        strongCustomerAuthentication.setTransType(opayoConfig.getTransType());
        return strongCustomerAuthentication;
    }

    private String generateNotificationUrl(String origin) {
        if (StringUtils.isNotBlank(origin)) {
            return origin + opayoConfig.getNotificationUrl();
        } else {
            return opayoConfig.getDefaultLiveDomain() + opayoConfig.getNotificationUrl();
        }

    }

    private VendorData generateVendorData(CardMortgageSingleOverpaymentsContext context) {
        VendorData vendorData = new VendorData();
        vendorData.setVendorName(opayoConfig.getVendorName());
        vendorData.setVendorCode(opayoUtils.generateVendorCode(context.getCardOneOffPaymentRequest().getCardDetails().getCardNumber()));
        return vendorData;
    }

    private VendorData generateVendorDataConfirm(CardMortgageSingleOverpaymentsContext context) {
        VendorData vendorData = new VendorData();
        vendorData.setVendorName(opayoConfig.getVendorName());
        vendorData.setVendorCode(context.getCardTransactionDetails().getVendorCode());
        return vendorData;
    }

    private PaymentData generatePaymentData(CardMortgageSingleOverpaymentsContext context) {
        PaymentData paymentData = new PaymentData();

        paymentData.setSubject(opayoConfig.getSubject());
        paymentData.setPayer(generatePayer(context));
        paymentData.setPaymentAmount(generatePaymentAmount(context));

        return paymentData;
    }

    private PaymentAmount generatePaymentAmount(CardMortgageSingleOverpaymentsContext context) {
        PaymentAmount paymentAmount = new PaymentAmount();
        paymentAmount.setAmount(context.getCardTransactionDetails().getUpdatedSimulationResponse().getOTotPayment());
        paymentAmount.setCurrency(opayoConfig.getCurrency());
        return paymentAmount;
    }

    private Payer generatePayer(CardMortgageSingleOverpaymentsContext context) {
        Payer payer = new Payer();
        payer.setAccount(generatePayerAccount(context.getMortgageAccount()));
        payer.setContactPoint(generateContactPoint(context));
        payer.setPerson(generatePerson(context));
        return payer;
    }

    private Person generatePerson(CardMortgageSingleOverpaymentsContext context) {
        Person person = new Person();

        person.setPersonName(generatePersonName(context));
        person.setBirthDate(formatBirthDate(context.getCardTransactionDetails().getCardHolderBirthDate()));
        person.setPostcodeRegular(context.getCardOneOffPaymentRequest().getCardDetails().getAddress().getPostcode());

        return person;
    }

    private String formatBirthDate(String birthDate) {
        DateTimeFormatter anmfFormat = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter cpsFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate birthDateLocalDate = LocalDate.parse(birthDate, anmfFormat);

        return cpsFormat.format(birthDateLocalDate);
    }

    private PersonName generatePersonName(CardMortgageSingleOverpaymentsContext context) {
        PersonName personName = new PersonName();

        personName.setGivenName(context.getCardTransactionDetails().getCardHolderFirstName());
        personName.setLastName(context.getCardTransactionDetails().getCardHolderLastName());

        return personName;
    }

    private ContactPoint generateContactPoint(CardMortgageSingleOverpaymentsContext context) {
        ContactPoint contactPoint = new ContactPoint();
        PostalAddress postalAddress = new PostalAddress();
        postalAddress.setLine1(StringUtils.left(context.getCardOneOffPaymentRequest().getCardDetails().getAddress().getLine1(), 49));
        postalAddress.setLine2(StringUtils.left(context.getCardOneOffPaymentRequest().getCardDetails().getAddress().getLine2(), 49));
        City city = new City();
        city.setName(context.getCardOneOffPaymentRequest().getCardDetails().getAddress().getCity());
        postalAddress.setCity(city);
        postalAddress.setPostCodeIdentification(context.getCardOneOffPaymentRequest().getCardDetails().getAddress().getPostcode());
        Country country = new Country();
        country.setCode("GB");
        postalAddress.setCountry(country);
        contactPoint.setPostalAddress(postalAddress);
        return contactPoint;
    }

    private Account generatePayerAccount(int mortgageAccount) {
        Account account = new Account();
        Contract contract = new Contract();
        contract.setContractId(StringUtils.leftPad(String.valueOf(mortgageAccount), 9, '0'));
        account.setContract(contract);
        return account;
    }

    private CardData generateCardData(CardMortgageSingleOverpaymentsContext context) {
        CardData cardData = new CardData();
        cardData.setNumber(context.getCardOneOffPaymentRequest().getCardDetails().getCardNumber());
        cardData.setCvv(context.getCardOneOffPaymentRequest().getCardDetails().getCvv());
        cardData.setExpiration(generateExpiration(context.getCardOneOffPaymentRequest().getCardDetails().getExpiryDate()));
        cardData.setPrintedName(generateCardHolderName(context));
        cardData.setReusable(opayoConfig.isReusable());
        cardData.setSave(opayoConfig.isSave());
        return cardData;
    }

    private String generateCardHolderName(CardMortgageSingleOverpaymentsContext context) {
        return context.getCardTransactionDetails().getCardHolderFirstName() + CHAR_SPACE + context.getCardTransactionDetails().getCardHolderLastName();
    }

    private Expiration generateExpiration(String expiryDate) {
        String[] splitExpiryDate = expiryDate.split("/");
        Expiration expiration = new Expiration();
        expiration.setMonth(splitExpiryDate[0]);
        expiration.setYear(splitExpiryDate[1]);
        return expiration;
    }

    private String getCustomerForenameSurname(CardTransactionDetails cardTransactionDetails) {
        StringBuilder customerName = new StringBuilder();

        if (StringUtils.isNotEmpty(cardTransactionDetails.getCardHolderFirstName())) {
            customerName.append(cardTransactionDetails.getCardHolderFirstName());
        }

        if (StringUtils.isNotEmpty(cardTransactionDetails.getCardHolderLastName())) {
            customerName.append(CHAR_SPACE);
            customerName.append(cardTransactionDetails.getCardHolderLastName());
        }

        return customerName.toString();
    }

    private String getLast4DigitsOfCard(String cardNum) {
        return cardNum.substring(cardNum.length() - 4);
    }

}
