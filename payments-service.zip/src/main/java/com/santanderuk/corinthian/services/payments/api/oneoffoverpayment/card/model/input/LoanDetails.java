package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LoanDetails extends ModelBase {
    @NotBlank
    private String loanScheme;
    @NotNull
    private int appSeqNumber;
    @NotNull
    private BigDecimal loanOverpaymentAmount;
    @NotBlank
    private String loanChangeType;
}
