package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class Borrower {

    private List<BorrowerElement> borrowerList;
    private List<BorrowerElement> emptyBorrowerList = new ArrayList<>();

}
