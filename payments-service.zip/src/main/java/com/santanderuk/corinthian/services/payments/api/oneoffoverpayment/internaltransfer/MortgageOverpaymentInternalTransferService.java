package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.PaymentsFuncException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.applyoverpayment.ApplyOverpaymentInAnmfService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.OneOffInternalTransferService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations.InternalTransferOneOffValidationsAndContextGeneratorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class MortgageOverpaymentInternalTransferService {
    private final OneOffInternalTransferService oneOffInternalTransferService;
    private final SimulationService simulationService;
    private final InternalTransferOneOffValidationsAndContextGeneratorService internalTransferOneOffValidationsAndContextGeneratorService;
    private final ApplyOverpaymentInAnmfService applyOverpaymentInAnmfService;
    private final PDFCreationService pdfCreationService;

    @Autowired
    public MortgageOverpaymentInternalTransferService(OneOffInternalTransferService oneOffInternalTransferService, SimulationService simulationService, InternalTransferOneOffValidationsAndContextGeneratorService internalTransferOneOffValidationsAndContextGeneratorService, ApplyOverpaymentInAnmfService applyOverpaymentInAnmfService, PDFCreationService pdfCreationService) {

        this.oneOffInternalTransferService = oneOffInternalTransferService;
        this.simulationService = simulationService;
        this.internalTransferOneOffValidationsAndContextGeneratorService = internalTransferOneOffValidationsAndContextGeneratorService;
        this.applyOverpaymentInAnmfService = applyOverpaymentInAnmfService;
        this.pdfCreationService = pdfCreationService;
    }

    public MortgageSingleOverpaymentInternalTransferResponse makePayment(int mortgageAccount, MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest, String jwtToken, String remoteIpAddress) throws GeneralException, PaymentsFuncException, FraudException {

        log.info("about to validateRequestAndGenerateContext. account: {}", mortgageAccount);
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = internalTransferOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(mortgageAccount, mortgageSingleOverpaymentInternalTransferRequest, jwtToken, remoteIpAddress);
        log.info("validateRequestAndGenerateContext OK. account: {}", mortgageAccount);

        log.info("about to updateSimulationWithChosenValues. account: {}", mortgageAccount);
        simulationService.createOverpaymentSimulationV1(mortgageSingleOverpaymentsContext);
        log.info("updateSimulationWithChosenValues OK. account: {}", mortgageAccount);

        log.info("about to updatePaymentMethod. account: {}", mortgageAccount);
        simulationService.updatePaymentMethodV1(mortgageSingleOverpaymentsContext);
        log.info("updatePaymentMethod OK. account: {}", mortgageAccount);

        log.info("about to makeInternalTransfer. account: {}", mortgageAccount);
        String upr = oneOffInternalTransferService.makeInternalTransfer(mortgageSingleOverpaymentsContext);
        log.info("makeInternalTransfer OK. account: {}", mortgageAccount);

        log.info("about to applyInternalTransferOverpayment. account: {}", mortgageAccount);
        applyOverpaymentInAnmfService.applyInternalTransferOverpayment(mortgageSingleOverpaymentsContext, upr);
        log.info("applyInternalTransferOverpayment finished. account: {}", mortgageAccount);

        log.info("about to generatePdf. account: {}", mortgageAccount);
        String generatedPdf = generatePdf(mortgageSingleOverpaymentsContext);
        log.info("generatePdf finished. account: {}", mortgageAccount);

        return generateServiceResponse(generatedPdf);
    }

    private MortgageSingleOverpaymentInternalTransferResponse generateServiceResponse(String generatedPdf) {
        MortgageSingleOverpaymentInternalTransferResponse response = new MortgageSingleOverpaymentInternalTransferResponse();
        response.setPaymentDone(true);
        response.setBase64Pdf(generatedPdf);
        return response;
    }

    private String generatePdf(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext) {
        return pdfCreationService.createBase64PdfFileForInternalTransfer(mortgageSingleOverpaymentsContext);
    }
}
