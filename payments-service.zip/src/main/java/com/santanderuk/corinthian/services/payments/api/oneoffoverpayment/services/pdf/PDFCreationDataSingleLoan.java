package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PDFCreationDataSingleLoan {
    private PDFCreationData pdfCreationData;
    private String chosenHeader;
    private String monthlyPaymentSaving;
    private String mortgageTerm;
    private String interestSaving;
}
