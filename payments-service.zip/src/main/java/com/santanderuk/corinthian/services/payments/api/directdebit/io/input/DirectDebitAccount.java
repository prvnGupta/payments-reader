package com.santanderuk.corinthian.services.payments.api.directdebit.io.input;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Getter
@Setter
@JsonInclude(JsonInclude.Include.NON_NULL)
public class DirectDebitAccount extends ModelBase {

    @NotNull
    private boolean isInternalAccount;
    @NotBlank
    private String sortcode;
    @NotBlank
    private String accountNumber;

}
