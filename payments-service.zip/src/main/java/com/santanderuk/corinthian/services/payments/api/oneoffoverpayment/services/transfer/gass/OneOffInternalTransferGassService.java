package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.gass;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.gassaudit.config.RabbitMqConfig;
import com.santanderuk.corinthian.hub.corinthiangass.common.Borrower;
import com.santanderuk.corinthian.hub.corinthiangass.common.BorrowerElement;
import com.santanderuk.corinthian.hub.corinthiangass.common.GassLoanDetails;
import com.santanderuk.corinthian.hub.corinthiangass.common.Loan;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.implementation.MakeInternalTransferGassMQServiceImplementation;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferFormattedData;
import com.santanderuk.corinthian.hub.corinthiangass.makeinternaltransfer.model.MakeInternalTransferGassItem;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.implementation.SetUpGassMQServiceImplementation;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferFormattedData;
import com.santanderuk.corinthian.hub.corinthiangass.setupinternaltransfer.model.SetUpInternalTransferGassItem;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OLoanData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.simulations.OutputStruc;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class OneOffInternalTransferGassService {
    public static final String STRING_EMPTY = "";
    public static final String STRING_SPACE = " ";

    @Value("${gass.defaultvalues.trntpnamesetup}")
    private String oneOffSetupGassTransactionName;

    @Value("${gass.defaultvalues.trntpnamemake}")
    private String oneOffDebitGassTransactionName;

    private final RabbitMqConfig rabbitMqConfig;
    private final GassDataFetcher gassDataFetcher;
    private final GassConfig gassConfig;
    private final SetUpGassMQServiceImplementation setUpGassMQService;
    private final MakeInternalTransferGassMQServiceImplementation makeInternalTransferGassMQService;

    public OneOffInternalTransferGassService(RabbitMqConfig rabbitMqConfig, GassDataFetcher gassDataFetcher, GassConfig gassConfig, SetUpGassMQServiceImplementation setUpGassMQService, MakeInternalTransferGassMQServiceImplementation makeInternalTransferGassMQService) {
        this.rabbitMqConfig = rabbitMqConfig;
        this.gassDataFetcher = gassDataFetcher;
        this.gassConfig = gassConfig;
        this.setUpGassMQService = setUpGassMQService;
        this.makeInternalTransferGassMQService = makeInternalTransferGassMQService;
    }

    public void callGassSetup(MortgageSingleOverpaymentsContext context,
                              String setUpResultIndicator) {
        try {
            log.info("OneOffInternalTransferGassService - > Calling Gass Dependency for set-up internal Transfer");

            SetUpInternalTransferFormattedData setUpInternalTransferFormattedData = getSetUpInternalTransferFormattedData(context);

            SetUpInternalTransferGassItem setUpInternalTransferGassItem = new SetUpInternalTransferGassItem(
                    rabbitMqConfig.getGassMqHost(),
                    rabbitMqConfig.getGassMqVirtualHost(),
                    rabbitMqConfig.getGassMqPort(),
                    rabbitMqConfig.getGassMqQueue(),
                    rabbitMqConfig.getGassMqUsername(),
                    rabbitMqConfig.getGassMqPassword(),
                    gassConfig.getGassCompsysid(),
                    gassConfig.getGassDvctyp(),
                    gassConfig.getGassOrgid(),
                    gassConfig.getGassOrguttp(),
                    gassConfig.getGassAuthcduserid(),
                    gassConfig.getGassAuthcdcompsysid(),
                    gassConfig.getGassAppsysid(),
                    gassConfig.getGassTrngrpid(),
                    oneOffSetupGassTransactionName,
                    setUpResultIndicator,
                    context.getLoggedCustomer().getOBdpType() + context.getLoggedCustomer().getOCustomerId(),
                    getLocalAccountAsString(context.getInternalTransferAccountsDetails().getAccountFrom().getLocalAccountNumber()),
                    context.getUpdatedSimulationResponse().getOTotPayment().toString(),
                    context.getIpAddress().equalsIgnoreCase("") ? "127.0.0.1" : context.getIpAddress(),
                    context.getLdapUid(),
                    setUpInternalTransferFormattedData);

            log.debug("Data sent to GASS setup: {}", setUpInternalTransferGassItem);
            setUpGassMQService.sendToMQSetUpInternalTransfer(setUpInternalTransferGassItem);
            log.info("OneOffInternalTransferGassService - > GASS Record correctly inserted on MQ");
        } catch (Exception ex) {
            log.error("OneOffInternalTransferGassService - > Error while creating audit record: ", ex);
        }
    }

    public void callGassMakePayment(MortgageSingleOverpaymentsContext context,
                                    String resultIndicator) {
        try {
            log.info("OneOffInternalTransferGassService - > Calling Gass Dependency for make internal Transfer");
            MakeInternalTransferFormattedData makeInternalTransferFormattedData = generateMakeInternalTransferFormattedData(context);

            MakeInternalTransferGassItem makeInternalTransferGassItem = new MakeInternalTransferGassItem(
                    rabbitMqConfig.getGassMqHost(),
                    rabbitMqConfig.getGassMqVirtualHost(),
                    rabbitMqConfig.getGassMqPort(),
                    rabbitMqConfig.getGassMqQueue(),
                    rabbitMqConfig.getGassMqUsername(),
                    rabbitMqConfig.getGassMqPassword(),
                    gassConfig.getGassCompsysid(),
                    gassConfig.getGassDvctyp(),
                    gassConfig.getGassOrgid(),
                    gassConfig.getGassOrguttp(),
                    gassConfig.getGassAuthcduserid(),
                    gassConfig.getGassAuthcdcompsysid(),
                    gassConfig.getGassAppsysid(),
                    gassConfig.getGassTrngrpid(),
                    oneOffDebitGassTransactionName,
                    resultIndicator,
                    context.getLoggedCustomer().getOBdpType() + context.getLoggedCustomer().getOCustomerId(),
                    getLocalAccountAsString(context.getInternalTransferAccountsDetails().getAccountFrom().getLocalAccountNumber()),
                    context.getUpdatedSimulationResponse().getOTotPayment().toString(),
                    context.getIpAddress().equalsIgnoreCase("") ? "127.0.0.1" : context.getIpAddress(),
                    context.getLdapUid(),
                    makeInternalTransferFormattedData);

            log.debug("Data sent to GASS debit: {}", makeInternalTransferGassItem);
            makeInternalTransferGassMQService.sendToMQMakeInternalTransfer(makeInternalTransferGassItem);
            log.info("OneOffInternalTransferGassService - > GASS Record correctly inserted on MQ");
        } catch (Exception ex) {
            log.error("OneOffInternalTransferGassService - > Error while creating audit record: ", ex);
        }
    }

    private MakeInternalTransferFormattedData generateMakeInternalTransferFormattedData(MortgageSingleOverpaymentsContext context) {
        MakeInternalTransferFormattedData makeInternalTransferFormattedData = new MakeInternalTransferFormattedData();

        makeInternalTransferFormattedData.setBorrowerList(anmfToFormattedData(context.getCustomerDetailsResponse()));
        makeInternalTransferFormattedData.setOriginAccount(getLocalAccountAsString(context.getInternalTransferAccountsDetails().getAccountFrom().getLocalAccountNumber()));
        makeInternalTransferFormattedData.setDestinationAccount(gassDataFetcher.fetchMortgageAccountNumber(context.getMortgageAccount()));
        makeInternalTransferFormattedData.setMultiChannelContractId(context.getMccId());
        makeInternalTransferFormattedData.setEarlyRepaymentChargeIndicator(getERCIndicator(context.getUpdatedSimulationResponse()));
        makeInternalTransferFormattedData.setEarlyRepaymentChargeAmount(context.getUpdatedSimulationResponse().getOTotErc().toString());
        makeInternalTransferFormattedData.setOverpaymentAmount(context.getUpdatedSimulationResponse().getOTotOvpAmount().toString());
        makeInternalTransferFormattedData.setTotalPaymentAmount(context.getUpdatedSimulationResponse().getOTotPayment().toString());
        makeInternalTransferFormattedData.setLoanDetails(generateLoanDetails(context));
        return makeInternalTransferFormattedData;
    }

    private SetUpInternalTransferFormattedData getSetUpInternalTransferFormattedData(MortgageSingleOverpaymentsContext context) {
        SetUpInternalTransferFormattedData setUpInternalTransferFormattedData = new SetUpInternalTransferFormattedData();

        setUpInternalTransferFormattedData.setBorrowerList(anmfToFormattedData(context.getCustomerDetailsResponse()));
        setUpInternalTransferFormattedData.setOriginAccount(getLocalAccountAsString(context.getInternalTransferAccountsDetails().getAccountFrom().getLocalAccountNumber()));
        setUpInternalTransferFormattedData.setMultiChannelContractId(context.getMccId());
        setUpInternalTransferFormattedData.setDestinationAccount(gassDataFetcher.fetchMortgageAccountNumber(context.getMortgageAccount()));
        setUpInternalTransferFormattedData.setEarlyRepaymentChargeIndicator(getERCIndicator(context.getUpdatedSimulationResponse()));
        setUpInternalTransferFormattedData.setEarlyRepaymentChargeAmount(context.getUpdatedSimulationResponse().getOTotErc().toString());
        setUpInternalTransferFormattedData.setOverpaymentAmount(context.getUpdatedSimulationResponse().getOTotOvpAmount().toString());
        setUpInternalTransferFormattedData.setTotalPaymentAmount(context.getUpdatedSimulationResponse().getOTotPayment().toString());
        setUpInternalTransferFormattedData.setLoanDetails(generateLoanDetails(context));
        return setUpInternalTransferFormattedData;
    }


    private String getLocalAccountAsString(LocalAccountNumber localAccountNumber) {
        return localAccountNumber.getSortcode() + localAccountNumber.getAccountNumber();
    }

    private String getERCIndicator(OutputStruc anmfSimulationResponse) {
        String ercIndicator;
        if (anmfSimulationResponse.getOTotErc().compareTo(BigDecimal.ZERO) == 0) {
            ercIndicator = "N";
        } else {
            ercIndicator = "Y";
        }
        return ercIndicator;
    }

    private Borrower anmfToFormattedData(CustomerDetailsResponse customerDetailsResponse) {
        Borrower borrower = new Borrower();
        int listSize = customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().size();
        List<BorrowerElement> borrowerList = new ArrayList<>(listSize);

        for (OCustomer oCustomer : customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList()) {
            BorrowerElement borrowerElement = generateBorrowerElement(oCustomer);
            borrowerList.add(borrowerElement);
        }
        borrower.setBorrower(borrowerList);
        return borrower;
    }

    private GassLoanDetails generateLoanDetails(MortgageSingleOverpaymentsContext context) {
        GassLoanDetails loanDetails = new GassLoanDetails();
        int listSize = context.getUpdatedSimulationResponse().getOLoanData().size();
        List<Loan> loanList = new ArrayList<>(listSize);
        for (OLoanData oLoanData : context.getUpdatedSimulationResponse().getOLoanData()) {
            if (thereIsAnOverpaymentInLoan(oLoanData, context.getSimulationChosenValues())) {
                Loan loan = new Loan();
                loan.setLoanSchema(oLoanData.getOLoanSch());
                loan.setLoanApplicationSequenceNumber(oLoanData.getOApplSeqNo());
                loan.setOptionChosen(getOptionChosen(context.getSimulationChosenValues(), oLoanData));
                loan.setLoanErcAmount(oLoanData.getOLnErc().toString());
                loan.setLoanOverpaymentAmount(getLoanOverpaymentAmount(context.getSimulationChosenValues(), oLoanData).toString());
                loan.setLoanTotalPaymentAmount(getLoanTotalPaymentAmount(context.getSimulationChosenValues(), oLoanData).toString());
                loan.setNewMonthlyPayment(oLoanData.getOLnSimMonPay().toString());
                loan.setNewLoanEndDate(oLoanData.getOLnSimMatDt());
                loan.setInterestSaving(getInterestSavingAcrossTerm(oLoanData).toString());
                loanList.add(loan);
            }
        }
        loanDetails.setLoan(loanList);
        return loanDetails;
    }

    private boolean thereIsAnOverpaymentInLoan(OLoanData oLoanData, SimulationChosenValues simulationChosenValues) {
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    return loanDetails.getLoanOverpaymentAmount().compareTo(BigDecimal.ZERO) != 0;
                }
            }
        }
        return false;
    }

    private BigDecimal getLoanOverpaymentAmount(SimulationChosenValues simulationChosenValues, OLoanData oLoanData) {
        BigDecimal loanOverpaymentAmount = BigDecimal.valueOf(0);
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    loanOverpaymentAmount = simulationChosenValues.getErcCollectionOption().equalsIgnoreCase("I") ? loanDetails.getLoanOverpaymentAmount().subtract(oLoanData.getOLnErc()) : loanDetails.getLoanOverpaymentAmount();
                }
            }
        }
        return loanOverpaymentAmount;
    }

    private BigDecimal getLoanTotalPaymentAmount(SimulationChosenValues simulationChosenValues, OLoanData oLoanData) {
        BigDecimal loanTotalPaymentAmount = BigDecimal.valueOf(0);
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    loanTotalPaymentAmount = simulationChosenValues.getErcCollectionOption().equalsIgnoreCase("I") ? loanDetails.getLoanOverpaymentAmount() : loanDetails.getLoanOverpaymentAmount().add(oLoanData.getOLnErc());
                }
            }
        }
        return loanTotalPaymentAmount;
    }

    private BigDecimal getInterestSavingAcrossTerm(OLoanData oLoanData) {
        BigDecimal interestSavingAcrossTerm = new BigDecimal(0);
        BigDecimal oLnIntDataBeforeSim = oLoanData.getOLnIntBefSim();
        BigDecimal oLnIntDataAfterSim = oLoanData.getOLnIntAftSim();
        if (null != oLnIntDataBeforeSim && null != oLnIntDataAfterSim) {
            interestSavingAcrossTerm = oLnIntDataBeforeSim.subtract(oLnIntDataAfterSim);
        }
        return interestSavingAcrossTerm;
    }

    private String getOptionChosen(SimulationChosenValues simulationChosenValues, OLoanData oLoanData) {
        String optionChosenValue = "";
        if (null != simulationChosenValues && null != simulationChosenValues.getLoanDetails()) {
            for (LoanDetails loanDetails : simulationChosenValues.getLoanDetails()) {
                if (loanDetails.getLoanScheme().equalsIgnoreCase(oLoanData.getOLoanSch()) && loanDetails.getAppSeqNumber() == oLoanData.getOApplSeqNo()) {
                    if (loanDetails.getLoanChangeType().equalsIgnoreCase("T")) {
                        optionChosenValue = "Reduce Mortgage Term";
                    } else {
                        optionChosenValue = "Reduce Monthly Payments";
                    }
                }
            }
        }
        return optionChosenValue;
    }

    private BorrowerElement generateBorrowerElement(OCustomer oCustomer) {
        String name = gassDataFetcher.formatName(oCustomer);
        return new BorrowerElement(
                name,
                oCustomer.getOBdpType(),
                String.valueOf(oCustomer.getOCustomerId())
        );
    }


    private String mccToFormattedData(PartenonAccountNumber mccPartenonAccount) {
        try {
            return mccPartenonAccount.getCompany() + STRING_SPACE + mccPartenonAccount.getCentre() + STRING_SPACE + mccPartenonAccount.getProduct() + STRING_SPACE + mccPartenonAccount.getContract();
        } catch (Exception e) {
            return STRING_EMPTY;
        }
    }

}
