package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational;

import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalResponse;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class CardOperationalClient {

    private final OverpaymentsConfig overpaymentsConfig;
    private final RestTemplate restTemplate;

    @Autowired
    public CardOperationalClient(OverpaymentsConfig overpaymentsConfig, RestTemplate paymentRestTemplate) {
        this.overpaymentsConfig = overpaymentsConfig;
        this.restTemplate = paymentRestTemplate;
    }

    public CardOperationalResponse callCardOperational(String cardNumber) throws CardOperationalException {
        try {
            CardOperationalRequest request = generateCardOperationalRequest(cardNumber);
            log.info("CardOperationalClient -> callCardOperational: About to call CardOperational core Api");

            ResponseEntity<CardOperationalResponse> cardOperationalResponseEntity = restTemplate.postForEntity(overpaymentsConfig.getCardOperationalEndpoint(), new HttpEntity<>(request, generateHeaders()), CardOperationalResponse.class);
            log.info("CardOperationalClient -> callCardOperational: got response from CardOperational core Api");
            return cardOperationalResponseEntity.getBody();
        } catch (Exception ex) {
            log.info("NonSantanderCard");
            throw new CardOperationalException("CARD_OPERATIONAL", "Non Santander Card");
        }
    }

    private CardOperationalRequest generateCardOperationalRequest(String cardNumber) {
        CardOperationalRequest cardOperationalRequest = new CardOperationalRequest();
        cardOperationalRequest.setCardNumber(cardNumber);
        return cardOperationalRequest;

    }

    private MultiValueMap<String, String> generateHeaders() {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-Client-Id", overpaymentsConfig.getClientId());
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        return headers;
    }

}
