package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup;

import com.santanderuk.corinthian.services.commons.model.PartenonAccountNumber;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class SetupPaymentMapper {
    private final OverpaymentsConfig overpaymentsConfig;

    @Autowired
    public SetupPaymentMapper(OverpaymentsConfig overpaymentsConfig) {
        this.overpaymentsConfig = overpaymentsConfig;
    }

    public SetupRequest generateSetupRequest(PartenonAccountNumber accountFrom, BigDecimal amount) {
        SetupRequest setupRequest = new SetupRequest();

        setupRequest.setCompany(accountFrom.getCompany());
        setupRequest.setCentre(accountFrom.getCentre());
        setupRequest.setProduct(accountFrom.getProduct());
        setupRequest.setContract(accountFrom.getContract());

        setupRequest.setOverpaymentAmount(amount.doubleValue());

        setupRequest.setCurrency(overpaymentsConfig.getSetupDataCurrency());
        setupRequest.setResidenceCountry(overpaymentsConfig.getSetupDataResidenceCountry());
        setupRequest.setTransactionBranch(overpaymentsConfig.getSetupDataTransactionBranch());
        setupRequest.setExpensesIndicator(overpaymentsConfig.getSetupDataExpensesIndicator());
        setupRequest.setTransmissionType(overpaymentsConfig.getSetupDataTransmissionType());

        return setupRequest;

    }
}
