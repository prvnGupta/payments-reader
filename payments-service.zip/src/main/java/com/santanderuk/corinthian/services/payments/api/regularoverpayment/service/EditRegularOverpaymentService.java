package com.santanderuk.corinthian.services.payments.api.regularoverpayment.service;

import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDRequest;
import com.santanderuk.corinthian.services.commons.anmfclient.io.cudregular.AnmfRegularOverpaymentCUDResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.overpaymentarrangements.OPayArrOvpInst;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.ConnectionException;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentMapper;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.SetUpRegularOverpaymentServiceInput;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.gass.GassService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class EditRegularOverpaymentService {
    public static final String REGULAR_OVERPAYMENT_TYPE = "E";
    private static final String SUCCESS_GASS_STATUS = "1";
    private static final String ERROR_GASS_STATUS = "2";
    private final HeartBeatClient heartBeatClient;
    private final AnmfCoreClient anmfCoreClient;
    private final RegularOverpaymentMapper regularOverpaymentMapper;
    private final GassService gassService;
    private final ClearRegularOverpaymentCache clearRegularOverpaymentCache;
    private final EndpointConfiguration endpointConfiguration;
    private final PaymentArrangementEnquiryHelper paymentArrangementEnquiryHelper;

    @Autowired
    public EditRegularOverpaymentService(HeartBeatClient heartBeatClient, AnmfCoreClient anmfCoreClient, RegularOverpaymentMapper regularOverpaymentMapper, GassService gassService, ClearRegularOverpaymentCache clearRegularOverpaymentCache, EndpointConfiguration endpointConfiguration, PaymentArrangementEnquiryHelper paymentArrangementEnquiryHelper) {
        this.heartBeatClient = heartBeatClient;
        this.anmfCoreClient = anmfCoreClient;
        this.regularOverpaymentMapper = regularOverpaymentMapper;
        this.gassService = gassService;
        this.clearRegularOverpaymentCache = clearRegularOverpaymentCache;
        this.endpointConfiguration = endpointConfiguration;
        this.paymentArrangementEnquiryHelper = paymentArrangementEnquiryHelper;
    }

    public void editExistingInstruction(int account, String jwtToken, String ipAddress, SetUpRegularOverpaymentServiceInput controllerRequest, CustomerDetailsResponse customerDetailsResponse) throws GeneralException {

        String status = ERROR_GASS_STATUS;
        AnmfRegion region = heartBeatClient.fetchCurrentRegion();

        final var context = new RegularOverpaymentContext();
        fetchAllDataNeededForThisService(account, jwtToken, controllerRequest, region, context);
        AnmfRegularOverpaymentCUDRequest request = regularOverpaymentMapper.generateSetUpEditCoreRequest(context);

        try {
            status = callAnmfEditOverpaymentWithStatus(request);
        } finally {
            gassService.auditEditRegularOverpayment(account, jwtToken, ipAddress, controllerRequest, status, customerDetailsResponse, context);
        }
    }

    private void fetchAllDataNeededForThisService(int account, String jwtToken, SetUpRegularOverpaymentServiceInput controllerRequest, AnmfRegion region, RegularOverpaymentContext context) throws GeneralException {
        context.setControllerRequest(controllerRequest);
        addAnmfResponsesToContext(account, region, context);
        context.setJwtToken(jwtToken);
        context.setAccount(account);
        context.setInstructionAction(REGULAR_OVERPAYMENT_TYPE);
    }

    private void addAnmfResponsesToContext(int account, AnmfRegion region, RegularOverpaymentContext context) throws GeneralException {
        context.setAnmfAccountResponse(
                anmfCoreClient.fetchMortgageAccountDetailsV5(account, endpointConfiguration.getAnmfAccountInfoUrl(), region)
        );
        context.setAnmfLoanPaymentPlanResponse(
                anmfCoreClient.fetchLoanPaymentPlan(account, endpointConfiguration.getAnmfLoanPaymentPlanUrl(), region)
        );

        OPayArrOvpInst overpaymentInstructionToEdit = paymentArrangementEnquiryHelper.extractInstructionToBeAmendedOrCancelled(account, region);
        context.setSequential(overpaymentInstructionToEdit.getOPayArrSeq());
    }

    public String callAnmfEditOverpaymentWithStatus(AnmfRegularOverpaymentCUDRequest request) throws ConnectionException {
        AnmfRegularOverpaymentCUDResponse cudResponse = anmfCoreClient.editRegularPayment(request, endpointConfiguration.getAnmfSetupEditCancelRegularOverpaymentUrl());
        clearRegularOverpaymentCache.deleteRegularOverpaymentCache(request.getOverpaymentArrangementRequest().getInputStruc().getIMortAccNo());
        String eCode = cudResponse.getOverpaymentArrangementResponse().getOutputStruc().getEStruc().getECode();
        if (eCode.length() == 0) {
            return SUCCESS_GASS_STATUS;
        }
        return ERROR_GASS_STATUS;
    }
}
