package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;

import com.santanderuk.corinthian.services.payments.api.internaltransfer.feepayment.model.InternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.transfer.utils.PaymentReferenceGenerator;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MakePaymentMapper {

    private final OverpaymentsConfig overpaymentsConfig;
    private final PaymentReferenceGenerator paymentReferenceGenerator;

    @Autowired
    public MakePaymentMapper(OverpaymentsConfig overpaymentsConfig, PaymentReferenceGenerator paymentReferenceGenerator) {
        this.overpaymentsConfig = overpaymentsConfig;
        this.paymentReferenceGenerator = paymentReferenceGenerator;
    }

    public DebitRequest mapRequest(SetupRequest setupRequest, SetupResponse setupResponse, InternalTransferRequest internalTransferRequest, InternalTransferAccountsDetails accountsDetails) {
        DebitRequest debitRequest = new DebitRequest();

        debitRequest.setSetupRequest(setupRequest);
        debitRequest.setSetupResponse(setupResponse);

        debitRequest.setSameHolder(overpaymentsConfig.getMakePaymentSameHolder());

        debitRequest.setReference(internalTransferRequest.getPaymentReference());

        debitRequest.setPersonNumber(Integer.toString(internalTransferRequest.getBdpCustomer().getCustomerNumber()));

        debitRequest.setBeneficiaryType(overpaymentsConfig.getMakePaymentBeneficiaryType());

        debitRequest.setBeneficiaryPartenonEntity(accountsDetails.getAccountTo().getPartenonAccountNumber().getCompany());
        debitRequest.setBeneficiaryPartenonCentre(accountsDetails.getAccountTo().getPartenonAccountNumber().getCentre());
        debitRequest.setBeneficiaryPartenonProduct(accountsDetails.getAccountTo().getPartenonAccountNumber().getProduct());
        debitRequest.setBeneficiaryPartenonContract(accountsDetails.getAccountTo().getPartenonAccountNumber().getContract());

        debitRequest.setCreditAccountBranch(accountsDetails.getAccountTo().getPartenonAccountNumber().getCentre());

        return debitRequest;
    }

    public DebitRequest mapRequest(SetupRequest setupRequest, SetupResponse setupResponse, MortgageSingleOverpaymentsContext context) {
        DebitRequest debitRequest = new DebitRequest();

        debitRequest.setSetupRequest(setupRequest);
        debitRequest.setSetupResponse(setupResponse);

        debitRequest.setSameHolder(overpaymentsConfig.getMakePaymentSameHolder());

        debitRequest.setReference(paymentReferenceGenerator.generateSingleOverpaymentInternalTransferReference(context.getMortgageAccount(), context.getLoggedCustomer().getOSurname()));

        debitRequest.setPersonNumber(Integer.toString(context.getLoggedCustomer().getOCustomerId()));

        debitRequest.setBeneficiaryType(overpaymentsConfig.getMakePaymentBeneficiaryType());
        debitRequest.setBeneficiaryPartenonEntity(overpaymentsConfig.getMakePaymentBeneficiaryPartenonEntity());
        debitRequest.setCreditAccountBranch(overpaymentsConfig.getMakePaymentBeneficiaryAccountBranch());

        debitRequest.setBeneficiaryName(context.getLoggedCustomer().oSurname);
        debitRequest.setBeneficiaryPartenonCentre(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getCentre());
        debitRequest.setBeneficiaryPartenonProduct(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getProduct());
        debitRequest.setBeneficiaryPartenonContract(context.getInternalTransferAccountsDetails().getAccountTo().getPartenonAccountNumber().getContract());

        return debitRequest;
    }
}
