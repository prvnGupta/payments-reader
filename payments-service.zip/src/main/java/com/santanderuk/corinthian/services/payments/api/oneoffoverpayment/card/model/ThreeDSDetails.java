package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ThreeDSDetails {
    private String outputUrl;
    private String outputCode;
}
