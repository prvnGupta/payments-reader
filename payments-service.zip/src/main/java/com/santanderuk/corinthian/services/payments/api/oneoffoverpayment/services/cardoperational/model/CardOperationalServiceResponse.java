package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class CardOperationalServiceResponse {
    private boolean santanderCard;
    private boolean onwSantanderCard;
}
