package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations;


import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.exceptions.ValidationsException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.ConfirmCardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.CardOperationalService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model.CardOperationalServiceResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoUtils;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import static com.santanderuk.corinthian.services.commons.utilities.JwtUtilities.getBdpCustomerFromJWT;
import static com.santanderuk.corinthian.services.commons.utilities.JwtUtilities.getLdapUidFromJWT;

@Service
@Slf4j
public class CardOneOffValidationsAndContextGeneratorService {
    private final AnmfCoreClient anmfCoreClient;

    private final OneOffCommonValidations oneOffCommonValidations;
    private final EndpointConfiguration endpointConfiguration;
    private final HeartBeatClient heartBeatClient;
    private final OpayoUtils opayoUtils;
    private final CardOperationalService cardOperationalService;

    @Autowired
    public CardOneOffValidationsAndContextGeneratorService(AnmfCoreClient anmfCoreClient, OneOffCommonValidations oneOffCommonValidations, EndpointConfiguration endpointConfiguration, HeartBeatClient heartBeatClient, OpayoUtils opayoUtils, CardOperationalService cardOperationalService) {
        this.anmfCoreClient = anmfCoreClient;
        this.oneOffCommonValidations = oneOffCommonValidations;
        this.endpointConfiguration = endpointConfiguration;
        this.heartBeatClient = heartBeatClient;
        this.opayoUtils = opayoUtils;
        this.cardOperationalService = cardOperationalService;
    }

    public CardMortgageSingleOverpaymentsContext validateRequestAndGenerateContextForConfirm(int mortgageAccount, ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest, CardTransactionDetails cardTransactionDetails, String jwtToken, String ipAddress) throws GeneralException {
        validateSameAccount(mortgageAccount, cardTransactionDetails);
        AnmfRegion anmfRegion = heartBeatClient.fetchCurrentRegion();
        CustomerDetailsResponse customerDetailsResponse = oneOffCommonValidations.validateMortgageBelongToCustomer(mortgageAccount, jwtToken, anmfRegion);
        AnmfAccountServiceResponse anmfAccountServiceResponse = anmfCoreClient.fetchMortgageAccountDetailsV5(mortgageAccount, endpointConfiguration.getAnmfAccountInfoUrl(), anmfRegion);
        return generateSingleOverpaymentsContextConfirmation(anmfRegion, mortgageAccount, confirmCardOneOffPaymentRequest, jwtToken, ipAddress, customerDetailsResponse, anmfAccountServiceResponse, cardTransactionDetails);
    }

    public CardMortgageSingleOverpaymentsContext validateRequestAndGenerateContext(int mortgageAccount, CardOneOffPaymentRequest cardOneOffPaymentRequest, String jwtToken, String ipAddress, String origin) throws GeneralException {

        log.info("heartBeatClient started");
        AnmfRegion anmfRegion = heartBeatClient.fetchCurrentRegion();
        log.info("heartBeatClient finished");

        oneOffCommonValidations.validateMinimumOverpaymentAmount(cardOneOffPaymentRequest.getLoanDetails());

        log.info("Anmf Customer details started");
        CustomerDetailsResponse customerDetailsResponse = oneOffCommonValidations.validateMortgageBelongToCustomer(mortgageAccount, jwtToken, anmfRegion);
        log.info("Anmf Customer details finished");

        OCustomer cardHolderDetails = validateCardHolderIsABorrowerOfTheAccount(customerDetailsResponse, cardOneOffPaymentRequest);

        log.info("Anmf account details started");
        AnmfAccountServiceResponse anmfAccountServiceResponse = anmfCoreClient.fetchMortgageAccountDetailsV5(mortgageAccount, endpointConfiguration.getAnmfAccountInfoUrl(), anmfRegion);
        log.info("Anmf account details finished");

        oneOffCommonValidations.validateInputLoans(cardOneOffPaymentRequest.getLoanDetails(), anmfAccountServiceResponse);

        oneOffCommonValidations.validateMaximumAmountAllowed(getTotalOverpaymentAmount(cardOneOffPaymentRequest), anmfAccountServiceResponse);

        oneOffCommonValidations.validateNumberOfSingleOverpaymentsDoneToday(anmfAccountServiceResponse);

        return generateSingleOverpaymentsContext(anmfRegion, mortgageAccount, cardOneOffPaymentRequest, jwtToken, ipAddress, customerDetailsResponse, cardHolderDetails, anmfAccountServiceResponse, origin);
    }


    private void validateSameAccount(int mortgageAccount, CardTransactionDetails cardTransactionDetails) throws ValidationsException {
        log.info("Validations: validate mortgage account is the same originally used");
        if (mortgageAccount != cardTransactionDetails.getMortgageAccount()) {
            throw new ValidationsException("EXC_INVALID_MORTGAGE_ACCOUNT", "different mortgage account");
        }
    }

    private OCustomer validateCardHolderIsABorrowerOfTheAccount(CustomerDetailsResponse customerDetailsResponse, CardOneOffPaymentRequest cardOneOffPaymentRequest) throws ValidationsException {
        String formattedCustomerId = formatCustomerId(cardOneOffPaymentRequest.getCardDetails().getCustomerId());
        cardOneOffPaymentRequest.getCardDetails().setCustomerId(formattedCustomerId);
        log.info("Validations: validateCardHolderIsABorrowerOfTheAccount");
        for (OCustomer customer : customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList()) {
            if (isSameCustomer(customer, cardOneOffPaymentRequest.getCardDetails().getCustomerId())) {
                return customer;
            }
        }
        log.error("CardHolder is not a mortgage borrower");
        throw new ValidationsException("CARDHOLDER_KO", "CardHolder is not a mortgage borrower");

    }

    private String formatCustomerId(String customerIdFromRequest) {
        return customerIdFromRequest.substring(0, 1) + Integer.valueOf(customerIdFromRequest.substring(1));
    }

    private boolean isSameCustomer(OCustomer customer, String customerIdFromRequest) {
        String customerId = customer.getOBdpType() + customer.getOCustomerId();
        return customerId.equalsIgnoreCase(customerIdFromRequest.trim());
    }

    private CardMortgageSingleOverpaymentsContext generateSingleOverpaymentsContext(AnmfRegion anmfRegion, int mortgageAccount, CardOneOffPaymentRequest cardOneOffPaymentRequest, String jwtToken, String ipAddress, CustomerDetailsResponse customerDetailsResponse, OCustomer cardHolderDetails, AnmfAccountServiceResponse anmfAccountServiceResponse, String origin) throws GeneralException {
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();
        OCustomer loggedInCustomerDetails = getLoggedInCustomerDetails(customerDetailsResponse, jwtToken);

        cardMortgageSingleOverpaymentsContext.setAnmfRegion(anmfRegion);
        cardMortgageSingleOverpaymentsContext.setCardOneOffPaymentRequest(cardOneOffPaymentRequest);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(anmfAccountServiceResponse);
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(loggedInCustomerDetails);
        cardMortgageSingleOverpaymentsContext.setIpAddress(ipAddress);
        cardMortgageSingleOverpaymentsContext.setMortgageAccount(mortgageAccount);
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(setSimulationChosenValues(cardOneOffPaymentRequest));
        cardMortgageSingleOverpaymentsContext.setLdapUid(getLdapUidFromJWT(jwtToken));

        CardOperationalServiceResponse cardOperationalServiceResponse = cardOperationalService.checkIfSantanderCard(cardOneOffPaymentRequest);
        boolean santanderCard = cardOperationalServiceResponse.isSantanderCard();

        cardMortgageSingleOverpaymentsContext.setSantanderCard(santanderCard);
        cardMortgageSingleOverpaymentsContext.setUsingOwnSantanderCard(cardOperationalServiceResponse.isOnwSantanderCard());
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(generateCardTransactionDetails(mortgageAccount, cardOneOffPaymentRequest, cardHolderDetails, santanderCard));
        cardMortgageSingleOverpaymentsContext.setOrigin(origin);

        return cardMortgageSingleOverpaymentsContext;
    }

    private CardMortgageSingleOverpaymentsContext generateSingleOverpaymentsContextConfirmation(AnmfRegion anmfRegion, int mortgageAccount, ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest, String jwtToken, String ipAddress, CustomerDetailsResponse customerDetailsResponse, AnmfAccountServiceResponse anmfAccountServiceResponse, CardTransactionDetails cardTransactionDetails) throws GeneralException {
        CardMortgageSingleOverpaymentsContext cardMortgageSingleOverpaymentsContext = new CardMortgageSingleOverpaymentsContext();
        cardTransactionDetails.setCardNumber(opayoUtils.decryptGivenText(cardTransactionDetails.getCardNumber()));
        OCustomer loggedInCustomerDetails = getLoggedInCustomerDetails(customerDetailsResponse, jwtToken);

        cardMortgageSingleOverpaymentsContext.setAnmfRegion(anmfRegion);
        cardMortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(anmfAccountServiceResponse);
        cardMortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        cardMortgageSingleOverpaymentsContext.setLoggedCustomer(loggedInCustomerDetails);
        cardMortgageSingleOverpaymentsContext.setIpAddress(ipAddress);
        cardMortgageSingleOverpaymentsContext.setMortgageAccount(mortgageAccount);
        cardMortgageSingleOverpaymentsContext.setSimulationChosenValues(setSimulationChosenValues(cardTransactionDetails));
        cardMortgageSingleOverpaymentsContext.setLdapUid(getLdapUidFromJWT(jwtToken));
        cardMortgageSingleOverpaymentsContext.setCardTransactionDetails(cardTransactionDetails);
        cardMortgageSingleOverpaymentsContext.setCres(confirmCardOneOffPaymentRequest.getCres());

        return cardMortgageSingleOverpaymentsContext;
    }

    private CardTransactionDetails generateCardTransactionDetails(int mortgageAccount, CardOneOffPaymentRequest cardOneOffPaymentRequest, OCustomer cardHolderDetails, boolean santanderCard) {
        CardTransactionDetails cardTransactionDetails = new CardTransactionDetails();

        String cardNumber = cardOneOffPaymentRequest.getCardDetails().getCardNumber();

        if (!santanderCard) {
            cardNumber = opayoUtils.maskCardNumber(cardOneOffPaymentRequest.getCardDetails().getCardNumber());
        }

        cardTransactionDetails.setCardNumber(cardNumber);
        cardTransactionDetails.setMortgageAccount(mortgageAccount);
        cardTransactionDetails.setExpiryDate(cardOneOffPaymentRequest.getCardDetails().getExpiryDate());
        cardTransactionDetails.setAddress(cardOneOffPaymentRequest.getCardDetails().getAddress());
        cardTransactionDetails.setCardHolderCustomerId(cardHolderDetails.getOBdpType() + cardHolderDetails.getOCustomerId());
        cardTransactionDetails.setCardHolderFirstName(cardHolderDetails.getOForename1());
        cardTransactionDetails.setCardHolderLastName(cardHolderDetails.getOSurname());
        cardTransactionDetails.setCardHolderBirthDate(cardHolderDetails.getODateOfBirth());
        cardTransactionDetails.setOverpaymentAmount(getTotalOverpaymentAmount(cardOneOffPaymentRequest));
        cardTransactionDetails.setErcCollectionOption(cardOneOffPaymentRequest.getErcCollectionOption());
        cardTransactionDetails.setLoanDetails(cardOneOffPaymentRequest.getLoanDetails());

        return cardTransactionDetails;
    }


    private SimulationChosenValues setSimulationChosenValues(CardOneOffPaymentRequest cardOneOffPaymentRequest) {
        SimulationChosenValues simulationChosenValues = new SimulationChosenValues();
        simulationChosenValues.setPaymentAmount(getTotalOverpaymentAmount(cardOneOffPaymentRequest));
        simulationChosenValues.setErcCollectionOption(cardOneOffPaymentRequest.getErcCollectionOption());
        simulationChosenValues.setLoanDetails(cardOneOffPaymentRequest.getLoanDetails());
        return simulationChosenValues;

    }

    private SimulationChosenValues setSimulationChosenValues(CardTransactionDetails cardTransactionDetails) {
        SimulationChosenValues simulationChosenValues = new SimulationChosenValues();
        simulationChosenValues.setPaymentAmount(cardTransactionDetails.getOverpaymentAmount());
        simulationChosenValues.setLoanDetails(cardTransactionDetails.getLoanDetails());
        simulationChosenValues.setErcCollectionOption(cardTransactionDetails.getErcCollectionOption());
        return simulationChosenValues;

    }

    private OCustomer getLoggedInCustomerDetails(CustomerDetailsResponse customerDetailsResponse, String jwtToken) {
        int customerNumberFromJwt = getBdpCustomerFromJWT(jwtToken).getCustomerNumber();

        List<OCustomer> loggedInCustomerList = customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().stream().filter(customerList -> customerList.getOCustomerId() == customerNumberFromJwt).collect(Collectors.toList());
        return loggedInCustomerList.get(0);
    }

    private BigDecimal getTotalOverpaymentAmount(CardOneOffPaymentRequest request) {
        return request.getLoanDetails().stream().map(LoanDetails::getLoanOverpaymentAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

}
