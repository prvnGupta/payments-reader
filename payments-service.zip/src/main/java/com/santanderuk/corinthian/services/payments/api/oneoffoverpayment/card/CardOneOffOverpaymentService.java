package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card;

import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardMortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardPaymentResponse;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.CardTransactionDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.ThreeDSDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.CardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.ConfirmCardOneOffPaymentRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.CardGASSService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.CardDataRedisPersistence;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoException;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.OpayoPaymentService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.pdf.PDFCreationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationService;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations.CardOneOffValidationsAndContextGeneratorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class CardOneOffOverpaymentService {
    public static final String OPAYO_SUCCESS_STATUS = "0000";
    public static final String OPAYO_CHALLENGE_STATUS = "2021";
    public static final String CARD_TRANSACTION_KO = "CARD_TRANSACTION_KO";
    public static final String CONFIRM_EXC = "CONFIRM_EXC";
    public static final String COULD_NOT_PROCESS_CARD_PAYMENT = "Could not process card-payment";
    public static final String FAILED_CALL_TO_CONFIRM_BAAS_API = "Failed call to Confirm baas Api";

    private final CardOneOffValidationsAndContextGeneratorService cardOneOffValidationsAndContextGeneratorService;
    private final OpayoPaymentService opayoPaymentService;
    private final SimulationService simulationService;
    private final CardDataRedisPersistence cacheCardTransaction;
    private final PDFCreationService pdfCreationService;
    private final CardGASSService cardGASSService;
    private final ClearPaymentCache clearPaymentCache;

    @Autowired
    public CardOneOffOverpaymentService(CardOneOffValidationsAndContextGeneratorService cardOneOffValidationsAndContextGeneratorService, OpayoPaymentService opayoPaymentService,
                                        SimulationService simulationService, CardDataRedisPersistence cacheCardTransaction, PDFCreationService pdfCreationService, CardGASSService cardGASSService, ClearPaymentCache clearPaymentCache) {
        this.cardOneOffValidationsAndContextGeneratorService = cardOneOffValidationsAndContextGeneratorService;
        this.opayoPaymentService = opayoPaymentService;
        this.simulationService = simulationService;
        this.cacheCardTransaction = cacheCardTransaction;
        this.pdfCreationService = pdfCreationService;
        this.cardGASSService = cardGASSService;
        this.clearPaymentCache = clearPaymentCache;
    }


    public CardPaymentResponse makeCardOneOffOverpayment(int mortgageAccount, CardOneOffPaymentRequest cardOneOffPaymentRequest, String jwtToken, String ipAddress, String origin) throws GeneralException {
        try {
            CardMortgageSingleOverpaymentsContext context = cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContext(mortgageAccount, cardOneOffPaymentRequest, jwtToken, ipAddress, origin);

            // create simulation
            simulationService.createCardOverpaymentSimulation(context);

            // makeCardTransaction
            opayoPaymentService.makeCardTransaction(context);

            if (context.getCardTransactionResponse().getStatus().getStatusCode().equalsIgnoreCase(OPAYO_SUCCESS_STATUS)) {
                //FrictionLees
                String base64Pdf = processSuccessfulPayment(context);

                log.info("transaction frictionless by card-transactions Baas Api");
                return new CardPaymentResponse(true, "", null, base64Pdf, context.isUsingOwnSantanderCard());

            } else if (context.getCardTransactionResponse().getStatus().getStatusCode().equalsIgnoreCase(OPAYO_CHALLENGE_STATUS)) {
                // challenge
                processThreeDS(context);
                log.info("transaction challenged by card-transactions Baas Api");
                return generateChallengeResponse(context);
            } else {
                // rejected
                auditFailedPayment(context);
                log.info("transaction rejected by card-transactions Baas Api");
                throw new GeneralException(CARD_TRANSACTION_KO, COULD_NOT_PROCESS_CARD_PAYMENT);
            }
        } catch (OpayoException e) {
            log.warn("CardOneOffOverpaymentService -> makeCardOneOffOverpayment exception");
            throw new GeneralException(CARD_TRANSACTION_KO, COULD_NOT_PROCESS_CARD_PAYMENT, e);
        }
    }

    public CardPaymentResponse confirmCardOneOffOverpayment(int mortgageAccount, String transactionId, ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest, String jwtToken, String ipAddress) throws GeneralException {
        CardMortgageSingleOverpaymentsContext context;

        context = prepareConfirmTransaction(mortgageAccount, transactionId, confirmCardOneOffPaymentRequest, jwtToken, ipAddress);

        return processConfirmTransaction(transactionId, context);
    }

    private CardPaymentResponse processConfirmTransaction(String transactionId, CardMortgageSingleOverpaymentsContext context) throws GeneralException {
        try {

            // Call to confirm Baas Api
            opayoPaymentService.confirmCardTransaction(context, transactionId);

            if (context.getCardTransactionResponse().getStatus().getStatusCode().equalsIgnoreCase(OPAYO_SUCCESS_STATUS)) {
                // Confirmation OK
                String base64Pdf = processSuccessfulPayment(context);
                log.info("transaction confirmed OK");
                return new CardPaymentResponse(true, "", null, base64Pdf, false);

            } else {
                // Declined
                auditFailedPayment(context);
                log.info("transaction declined by confirm-transaction Baas Api");
                throw new GeneralException(CARD_TRANSACTION_KO, COULD_NOT_PROCESS_CARD_PAYMENT);
            }
        } catch (OpayoException e) {
            log.error(FAILED_CALL_TO_CONFIRM_BAAS_API);
            auditFailedPayment(context);
            throw new GeneralException(CONFIRM_EXC, FAILED_CALL_TO_CONFIRM_BAAS_API, e);
        } finally {
            clearPaymentCache.deleteCardTransactionCache(transactionId);
        }
    }

    private CardMortgageSingleOverpaymentsContext prepareConfirmTransaction(int mortgageAccount, String transactionId, ConfirmCardOneOffPaymentRequest confirmCardOneOffPaymentRequest, String jwtToken, String ipAddress) throws GeneralException {
        CardMortgageSingleOverpaymentsContext context;
        try {
            CardTransactionDetails cardTransactionDetails = cacheCardTransaction.cacheCardTransaction(transactionId, null);
            // Context and validations
            context = cardOneOffValidationsAndContextGeneratorService.validateRequestAndGenerateContextForConfirm(mortgageAccount, confirmCardOneOffPaymentRequest, cardTransactionDetails, jwtToken, ipAddress);
        } catch (Exception e) {
            log.error("Error while getting cardTransactionDetails from cache or generating Context");
            throw new GeneralException(CONFIRM_EXC, "Payment could not be confirmed", e);
        }
        return context;
    }

    private CardPaymentResponse generateChallengeResponse(CardMortgageSingleOverpaymentsContext context) {
        return new CardPaymentResponse(false, context.getCardTransactionResponse().getTransaction().getTransactionId(), generateThreeDsDetails(context), "", context.isUsingOwnSantanderCard());
    }

    private ThreeDSDetails generateThreeDsDetails(CardMortgageSingleOverpaymentsContext context) {
        return new ThreeDSDetails(context.getCardTransactionResponse().getOutputUrl(), context.getCardTransactionResponse().getOutputCode());
    }

    private void auditFailedPayment(CardMortgageSingleOverpaymentsContext context) {
        //call updateCPS
        opayoPaymentService.updateCPS(context);

        // call GASS
        cardGASSService.auditDebitCardPayment(context, false);
    }

    private void processThreeDS(CardMortgageSingleOverpaymentsContext context) throws GeneralException {
        // Store data in Redis
        cacheCardTransaction.cacheCardTransaction(context.getCardTransactionResponse().getTransaction().getTransactionId(), context);
    }

    private String processSuccessfulPayment(CardMortgageSingleOverpaymentsContext context) {
        // simulation update payment method
        simulationService.updatePaymentMethodCard(context);

        // update CPS
        opayoPaymentService.updateCPS(context);

        // call Gass
        cardGASSService.auditDebitCardPayment(context, true);

        // generate PDF
        return pdfCreationService.createBase64PdfFileForCardPayment(context);
    }


}
