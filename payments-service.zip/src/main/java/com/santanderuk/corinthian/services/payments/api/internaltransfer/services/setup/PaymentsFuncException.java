package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup;

public class PaymentsFuncException extends Exception {

    private static final long serialVersionUID = 1L;

    public PaymentsFuncException(String message) {
        super(message);

    }

    public PaymentsFuncException(String message, Exception e) {
        super(message, e);
        // To take the exception that we are forwarding when throwing PaymentsFuncException
    }

    public PaymentsFuncException(Throwable cause) {
        super(cause);
    }

    public PaymentsFuncException(String message, Throwable cause) {
        super(message, cause);
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }

    @Override
    public String toString() {
        return super.toString();
    }


}
