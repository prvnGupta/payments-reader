package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model;

import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class SimulationChosenValues {
    private BigDecimal paymentAmount;
    private String ercCollectionOption;
    private List<LoanDetails> loanDetails;
}
