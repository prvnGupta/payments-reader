package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo;


import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;

public class OpayoException extends GeneralException {
    public OpayoException(String code, String message) {
        super(code, message);
    }

    public OpayoException(String code, String message, Exception e) {
        super(code, message, e);
    }
}


