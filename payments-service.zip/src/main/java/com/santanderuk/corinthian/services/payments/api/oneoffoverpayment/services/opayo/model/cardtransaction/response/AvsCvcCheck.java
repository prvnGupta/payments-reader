
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class AvsCvcCheck extends ModelBase {
    private static final long serialVersionUID = 1L;

    private String status;
    private String address;
    private String postalCode;
    private String securityCode;
}
