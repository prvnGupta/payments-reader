package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass;

import com.santander.common.instrumentation.logger.functional.OperationPublisher;
import com.santander.common.instrumentation.logger.functional.dto.OperationInfo;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model.GASSMessageData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class GASSClient {

    private final OperationPublisher operationPublisher;
    private final GASSOperationInfoMapper gassOperationInfoMapper;

    @Autowired
    public GASSClient(OperationPublisher operationPublisher, GASSOperationInfoMapper gassOperationInfoMapper) {
        this.operationPublisher = operationPublisher;
        this.gassOperationInfoMapper = gassOperationInfoMapper;
    }

    public void send(GASSMessageData gassMessageData, boolean success) {
        String result = "";
        try {
            OperationInfo operationInfo = gassOperationInfoMapper.assemble(gassMessageData, success);

            if (operationInfo != null) {
                log.debug("auditing AuditTrnTpName - {} ", operationInfo.getAudittrntpname());
                log.debug("fmt data - {}", operationInfo.getFrmtddataString());

                result = operationPublisher.submitFunctionalEvent(operationInfo, false);
                log.debug("GASS Result: " + result);
            }

        } catch (Exception ex) {
            log.error("Error auditing to GASS", ex);
        } finally {
            if (!result.trim().equalsIgnoreCase("REST:SUCCESS")) {
                log.error("Error auditting to GASS - {}", result);
            }
        }
    }
}


