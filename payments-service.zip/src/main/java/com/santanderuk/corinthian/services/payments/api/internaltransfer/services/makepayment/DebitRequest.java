package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.makepayment;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupRequest;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.setup.SetupResponse;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * Created by c0245070 on 12/07/2017.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"setupRequest", "setupResponse", "sameHolder", "reference", "checkDigit", "beneficiaryName", "personNumber",
        "beneficiaryType", "beneficiaryPartenonEntity", "beneficiaryPartenonCentre", "beneficiaryPartenonProduct", "beneficiaryPartenonContract",
        "creditAccountBranch", "creditAccountCompany"})
public class DebitRequest {

    @JsonProperty("setupRequest")
    private SetupRequest setupRequest;

    @JsonProperty("setupResponse")
    private SetupResponse setupResponse;

    @JsonProperty("sameHolder")
    private String sameHolder;

    @JsonProperty("reference")
    private String reference;

    @JsonProperty("checkDigit")
    private String checkDigit;

    @JsonProperty("beneficiaryName")
    private String beneficiaryName;
    @JsonProperty("personNumber")
    private String personNumber;

    @JsonProperty("beneficiaryType")
    private String beneficiaryType;

    @JsonProperty("beneficiaryPartenonEntity")
    private String beneficiaryPartenonEntity;

    @JsonProperty("beneficiaryPartenonCentre")
    private String beneficiaryPartenonCentre;

    @JsonProperty("beneficiaryPartenonProduct")
    private String beneficiaryPartenonProduct;

    @JsonProperty("beneficiaryPartenonContract")
    private String beneficiaryPartenonContract;

    @JsonProperty("creditAccountBranch")
    private String creditAccountBranch;

    public DebitRequest() {
    }

    public DebitRequest(SetupRequest setupRequest, SetupResponse setupResponse) {
        this.setupRequest = setupRequest;
        this.setupResponse = setupResponse;
    }

    public DebitRequest(SetupRequest setupRequest, SetupResponse setupResponse, CreateUniqueNumber crnUPR) {
        this.setupRequest = setupRequest;
        this.setupResponse = setupResponse;
//        this.crnUPR = crnUPR;
    }

    @JsonProperty("setupRequest")
    public SetupRequest getSetupRequest() {
        return setupRequest;
    }

    @JsonProperty("setupRequest")
    public void setSetupRequest(SetupRequest setupRequest) {
        this.setupRequest = setupRequest;
    }

    @JsonProperty("setupResponse")
    public SetupResponse getSetupResponse() {
        return setupResponse;
    }

    @JsonProperty("setupResponse")
    public void setSetupResponse(SetupResponse setupResponse) {
        this.setupResponse = setupResponse;
    }

    @JsonProperty("sameHolder")
    public String getSameHolder() {
        return sameHolder;
    }

    @JsonProperty("sameHolder")
    public void setSameHolder(String sameHolder) {
        this.sameHolder = sameHolder;
    }

    @JsonProperty("reference")
    public String getReference() {
        return reference;
    }

    @JsonProperty("reference")
    public void setReference(String reference) {
        this.reference = reference;
    }

    @JsonProperty("checkDigit")
    public String getCheckDigit() {
        return checkDigit;
    }

    @JsonProperty("checkDigit")
    public void setCheckDigit(String checkDigit) {
        this.checkDigit = checkDigit;
    }

    @JsonProperty("beneficiaryName")
    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    @JsonProperty("beneficiaryName")
    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    @JsonProperty("personNumber")
    public String getPersonNumber() {
        return personNumber;
    }

    @JsonProperty("personNumber")
    public void setPersonNumber(String personNumber) {
        this.personNumber = personNumber;
    }

    @JsonProperty("beneficiaryType")
    public String getBeneficiaryType() {
        return beneficiaryType;
    }

    @JsonProperty("beneficiaryType")
    public void setBeneficiaryType(String beneficiaryType) {
        this.beneficiaryType = beneficiaryType;
    }

    @JsonProperty("beneficiaryPartenonEntity")
    public String getBeneficiaryPartenonEntity() {
        return beneficiaryPartenonEntity;
    }

    @JsonProperty("beneficiaryPartenonEntity")
    public void setBeneficiaryPartenonEntity(String beneficiaryPartenonEntity) {
        this.beneficiaryPartenonEntity = beneficiaryPartenonEntity;
    }

    @JsonProperty("beneficiaryPartenonCentre")
    public String getBeneficiaryPartenonCentre() {
        return beneficiaryPartenonCentre;
    }

    @JsonProperty("beneficiaryPartenonCentre")
    public void setBeneficiaryPartenonCentre(String beneficiaryPartenonCentre) {
        this.beneficiaryPartenonCentre = beneficiaryPartenonCentre;
    }

    @JsonProperty("beneficiaryPartenonProduct")
    public String getBeneficiaryPartenonProduct() {
        return beneficiaryPartenonProduct;
    }

    @JsonProperty("beneficiaryPartenonProduct")
    public void setBeneficiaryPartenonProduct(String beneficiaryPartenonProduct) {
        this.beneficiaryPartenonProduct = beneficiaryPartenonProduct;
    }

    @JsonProperty("beneficiaryPartenonContract")
    public String getBeneficiaryPartenonContract() {
        return beneficiaryPartenonContract;
    }

    @JsonProperty("beneficiaryPartenonContract")
    public void setBeneficiaryPartenonContract(String beneficiaryPartenonContract) {
        this.beneficiaryPartenonContract = beneficiaryPartenonContract;
    }

    @JsonProperty("creditAccountBranch")
    public String getCreditAccountBranch() {
        return creditAccountBranch;
    }

    @JsonProperty("creditAccountBranch")
    public void setCreditAccountBranch(String creditAccountBranch) {
        this.creditAccountBranch = creditAccountBranch;
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("setupRequest", setupRequest)
                .append("setupResponse", setupResponse)
                .append("sameHolder", sameHolder)
                .append("reference", reference)
                .append("checkDigit", checkDigit)
                .append("beneficiaryName", beneficiaryName)
                .append("personNumber", personNumber)
                .append("beneficiaryType", beneficiaryType)
                .append("beneficiaryPartenonEntity", beneficiaryPartenonEntity)
                .append("beneficiaryPartenonCentre", beneficiaryPartenonCentre)
                .append("beneficiaryPartenonProduct", beneficiaryPartenonProduct)
                .append("beneficiaryPartenonContract", beneficiaryPartenonContract)
                .append("creditAccountBranch", creditAccountBranch)
                .toString();
    }
}
