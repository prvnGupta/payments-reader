
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.opayo.model.cardtransaction.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class CardTransactionRequest extends ModelBase {
    private static final long serialVersionUID = -6553838434790826146L;

    private CardData cardData;
    private PaymentData paymentData;
    private VendorData vendorData;
    private AdditionalData additionalData;
}
