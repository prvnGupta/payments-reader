package com.santanderuk.corinthian.services.payments.api.regularoverpayment.gass;

import com.santanderuk.corinthian.gassaudit.config.GassConfig;
import com.santanderuk.corinthian.hub.corinthiangass.common.Borrower;
import com.santanderuk.corinthian.hub.corinthiangass.common.BorrowerElement;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.FormattedLoan;
import com.santanderuk.corinthian.hub.corinthiangass.setupregularoverpayment.model.SetUpRegularOverpaymentFormattedData;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.clients.bksconnect.io.PartenonContract;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.RegularOverpaymentContext;
import com.santanderuk.corinthian.services.payments.api.regularoverpayment.io.Loan;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import static java.time.temporal.ChronoUnit.MONTHS;

@Component
public class RegularOverpaymentFormattedDataMapper {

    public static final int POSITION_WHERE_SORTCODE_ENDS = 6;
    public static final String STRING_EMPTY = "";
    public static final String STRING_SPACE = " ";
    private final GassConfig gassConfig;

    public RegularOverpaymentFormattedDataMapper(GassConfig gassConfig) {
        this.gassConfig = gassConfig;
    }

    public SetUpRegularOverpaymentFormattedData toFormattedData(final RegularOverpaymentContext context) {
        final SetUpRegularOverpaymentFormattedData setUpRegularOverpaymentFormattedData = decorateWithDataFromControllerRequest(context);
        setUpRegularOverpaymentFormattedData.setDestinationAccount(StringUtils.leftPad(String.valueOf(context.getAccount()), 9, '0'));
        setUpRegularOverpaymentFormattedData.setMortgageAccountNumber(gassConfig.getAnmfSortcode() + " " + String.format("%09d", context.getAccount()));
        setUpRegularOverpaymentFormattedData.setBorrowerList(toGassBorrower(context.getCustomerDetailsResponse()));
        setUpRegularOverpaymentFormattedData.setOverpaymentEffect(fetchOverpaymentType(context.getControllerRequest().getLoans()));

        return setUpRegularOverpaymentFormattedData;
    }

    private SetUpRegularOverpaymentFormattedData decorateWithDataFromControllerRequest(
            final RegularOverpaymentContext context) {

        final SetUpRegularOverpaymentFormattedData setUpRegularOverpaymentFormattedData = new SetUpRegularOverpaymentFormattedData();

        final String directDebitTotalAmount = String.format("%.2f", context.getControllerRequest().getOverpaymentAmount().add(context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay()));

        setUpRegularOverpaymentFormattedData.setMultiChannelContractId(mccToFormattedData(context.getMccContract().getPartenonContract()));
        setUpRegularOverpaymentFormattedData.setContractualMonthlyPaymentAmount(String.format("%.2f", context.getAnmfAccountResponse().getAccountServiceResponse().getResponse().getOStruc().getOContMonPay()));
        setUpRegularOverpaymentFormattedData.setOverpaymentAmount(String.format("%.2f", context.getControllerRequest().getOverpaymentAmount()));
        setUpRegularOverpaymentFormattedData.setStartDate(context.getControllerRequest().getStartDate());
        setUpRegularOverpaymentFormattedData.setEndDate(context.getControllerRequest().getEndDate());
        setUpRegularOverpaymentFormattedData.setNumberOfPayments(calculateNumberOfPayments(context.getControllerRequest().getStartDate(), context.getControllerRequest().getEndDate()));
        setUpRegularOverpaymentFormattedData.setOriginAccount(formatLocalAccount(generateDirectDebitAccount(context)));
        setUpRegularOverpaymentFormattedData.setDirectDebitTotalAmount(directDebitTotalAmount);
        setUpRegularOverpaymentFormattedData.setFormattedLoans(mapLoans(context.getControllerRequest().getLoans()));

        return setUpRegularOverpaymentFormattedData;
    }

    private List<FormattedLoan> mapLoans(List<Loan> loans) {
        List<Loan> sortByOrderId = loans.stream()
                .sorted(Comparator.comparing(Loan::getOrderId))
                .collect(Collectors.toList());

        List<FormattedLoan> gassLoanList = new ArrayList<>();
        sortByOrderId.forEach(loan -> {
            FormattedLoan formattedLoan = new FormattedLoan();
            formattedLoan.setLoanSchema(loan.getLoanSchema());
            formattedLoan.setLoanType(loan.getLoanType());
            formattedLoan.setAppSequenceNumber(loan.getAppSequenceNumber());
            formattedLoan.setOrderId(loan.getOrderId());
            gassLoanList.add(formattedLoan);
        });
        return gassLoanList;
    }

    private String generateDirectDebitAccount(final RegularOverpaymentContext context) {
        final String directDebitSortCode = context.getAnmfLoanPaymentPlanResponse().getLoanPaymentPlanResponse().getOutputStruc().getODirectDebitDetails().getOBankSortCode();
        final int directDebitAccount = context.getAnmfLoanPaymentPlanResponse().getLoanPaymentPlanResponse().getOutputStruc().getODirectDebitDetails().getOBankAccount();

        return directDebitSortCode.replace("-", "") + " " + String.format("%08d", directDebitAccount);
    }

    private String calculateNumberOfPayments(final String startDate, final String endDate) {

        if (isFurtherNotice(endDate)) {
            return "";
        } else {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/MM/yyyy");
            LocalDate localDateStart = LocalDate.parse(startDate, formatter);
            LocalDate localDateEnd = LocalDate.parse(endDate, formatter);

            return String.valueOf(MONTHS.between(localDateStart, localDateEnd) + 1);

        }
    }

    private boolean isFurtherNotice(final String endDate) {
        return "untilfurthernotice".equalsIgnoreCase(endDate.trim());
    }


    public Borrower toGassBorrower(final CustomerDetailsResponse anmfCustomerServiceInfoResponse) {
        return toGassBorrower(anmfCustomerServiceInfoResponse.getCustomerServiceResponse().getOStruc().getOCustomerList());
    }

    public Borrower toGassBorrower(final List<OCustomer> anmfCustomerList) {
        Borrower borrower = new Borrower();
        List<BorrowerElement> borrowerList = new ArrayList<>(anmfCustomerList.size());
        for (OCustomer currentCustomer : anmfCustomerList) {
            String name = formatName(currentCustomer);

            BorrowerElement borrowerElement = new BorrowerElement(
                    name,
                    currentCustomer.getOBdpType(),
                    String.valueOf(currentCustomer.getOCustomerId())
            );
            borrowerList.add(borrowerElement);
        }
        borrower.setBorrower(borrowerList);
        return borrower;
    }

    private String formatName(final OCustomer currentCustomer) {

        String name = formatAttribute(currentCustomer.getOCustomerTitle()) +
                formatAttribute(currentCustomer.getOForename1()) +
                formatAttribute(currentCustomer.getOForename2()) +
                formatAttribute(currentCustomer.getOForename3()) +
                formatAttribute(currentCustomer.getOSurname());
        return name.trim();
    }

    private String formatAttribute(final String attribute) {
        if (attributeIsEmpty(attribute)) {
            return STRING_EMPTY;
        } else {
            return attribute + STRING_SPACE;
        }
    }

    private boolean attributeIsEmpty(final String attribute) {
        return attribute == null || STRING_EMPTY.equalsIgnoreCase(attribute.trim());
    }

    public String mccToFormattedData(final PartenonContract partenonContract) {
        String partenonContractGass = "";
        if (partenonContract != null) {
            if (partenonContract.getCentre().getCompany() != null) {
                partenonContractGass += partenonContract.getCentre().getCompany() + " ";
            }
            if (partenonContract.getCentre().getCentreCode() != null) {
                partenonContractGass += partenonContract.getCentre().getCentreCode() + " ";
            }
            if (partenonContract.getProductTypeCode() != null) {
                partenonContractGass += partenonContract.getProductTypeCode() + " ";
            }
            if (partenonContract.getContractNumber() != null) {
                partenonContractGass += partenonContract.getContractNumber();
            }
        }
        return partenonContractGass;
    }

    private String formatLocalAccount(final String localAccount) {
        if (localAccount != null && localAccount.length() > 13) {
            return localAccount.substring(0, POSITION_WHERE_SORTCODE_ENDS)
                    + " "
                    + localAccount.substring(POSITION_WHERE_SORTCODE_ENDS);
        } else {
            return localAccount;
        }
    }

    private String fetchOverpaymentType(List<Loan> loanList) {
        for (Loan loan : loanList) {
            if ("I".equalsIgnoreCase(loan.getLoanType().trim())) {
                return "M";
            }
        }
        return "T";
    }


}
