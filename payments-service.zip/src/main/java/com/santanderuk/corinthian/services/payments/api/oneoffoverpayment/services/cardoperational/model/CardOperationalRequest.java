
package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.cardoperational.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.santanderuk.corinthian.services.commons.model.ModelBase;
import lombok.Getter;
import lombok.Setter;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Getter
@Setter
public class CardOperationalRequest extends ModelBase {
    private static final long serialVersionUID = 1L;

    private String cardNumber;
}
