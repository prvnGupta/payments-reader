package com.santanderuk.corinthian.services.payments.api.internaltransfer.services.fraudcheck;

import com.santanderuk.corinthian.hub.corinthianFraudcommons.Exceptions.FraudException;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataRequest;
import com.santanderuk.corinthian.hub.corinthianFraudcommons.io.lynx.LynxDataResponse;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class LynxFraudCheckClient {

    private final RestTemplate restTemplate;
    private final OverpaymentsConfig overpaymentsConfig;

    public LynxFraudCheckClient(RestTemplate paymentRestTemplate, OverpaymentsConfig overpaymentsConfig) {
        this.restTemplate = paymentRestTemplate;
        this.overpaymentsConfig = overpaymentsConfig;
    }

    public LynxDataResponse callFraudCheck(LynxDataRequest lynxDataRequest) throws FraudException {

        HttpEntity<LynxDataRequest> httpEntity = createHttpEntity(lynxDataRequest);

        ResponseEntity<LynxDataResponse> responseEntity;
        try {
            log.info("About to call LynxFraudCheck Core Api");
            log.debug("FraudCheck Request: {}", lynxDataRequest.toString().replaceAll("[\r\n]", ""));

            String lynxFraudUrl = overpaymentsConfig.getLynxFraudEndpoint();
            log.debug("Calling endpoint: {}", lynxFraudUrl.replaceAll("[\r\n]", ""));

            responseEntity = restTemplate.postForEntity(lynxFraudUrl, httpEntity, LynxDataResponse.class);
            log.info("FraudCheck -> FraudCheck response received");
            LynxDataResponse response = responseEntity.getBody();
            validateLynxFraudResponse(response);

            return response;
        } catch (FraudException fe) {
            throw fe;
        } catch (Exception ex) {
            log.error("Exception while calling LynxFraud Core Api", ex);
            throw new FraudException("Exception while calling LynxFraud Core Api");
        }
    }

    private void validateLynxFraudResponse(LynxDataResponse response) throws FraudException {
        log.debug("LynxFraudCheck Response -> {}", response);
        if (lynxFraudCheckOk(response)) {
            log.info("Lynx fraud check is okay");
        } else if (response.getResponseCode().trim().equalsIgnoreCase("ko")) {
            log.warn("LynxFraudCheck -> Lynx fraud check failed");
            throw new FraudException("TRANSACTION DECLINED BY FRAUD");
        } else {
            log.error("Transaction pending by FRAUD...Lynx Response: {}", response);
            throw new FraudException("TRANSACTION PENDING BY FRAUD");
        }
    }

    private boolean lynxFraudCheckOk(LynxDataResponse response) {
        return response.getResponseCode().trim().equalsIgnoreCase("ok");
    }

    private HttpEntity<LynxDataRequest> createHttpEntity(LynxDataRequest lynxDataRequest) {
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("X-IBM-Client-Id", overpaymentsConfig.getClientId());
        headers.add("Accept", MediaType.APPLICATION_JSON_VALUE);
        headers.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        return new HttpEntity<>(lynxDataRequest, headers);
    }
}
