package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.applyoverpayment;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.santanderuk.corinthian.hub.paymentsmqwriter.interfaces.PaymentMqWriterServiceInterface;
import com.santanderuk.corinthian.hub.paymentsmqwriter.model.MqPaymentItem;
import com.santanderuk.corinthian.services.commons.anmfclient.ApplyOverpaymentClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.applyoverpaymenttransaction.ApplyOverpaymentRequest;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationMapper;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.simulation.SimulationService;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsMqConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class ApplyOverpaymentInAnmfService {

    private final EndpointConfiguration endpointConfiguration;
    private final HeartBeatClient heartBeatClient;
    private final ApplyOverpaymentMapper applyOverpaymentMapper;
    private final ApplyOverpaymentClient applyOverpaymentClient;
    private final OverpaymentsMqConfig overpaymentsMqConfig;
    private final PaymentMqWriterServiceInterface paymentMqWriterService;
    private final SimulationService simulationService;
    private final SimulationMapper simulationMapper;


    @Autowired
    public ApplyOverpaymentInAnmfService(EndpointConfiguration endpointConfiguration, HeartBeatClient heartBeatClient, ApplyOverpaymentMapper applyOverpaymentMapper, ApplyOverpaymentClient applyOverpaymentClient, OverpaymentsMqConfig overpaymentsMqConfig, PaymentMqWriterServiceInterface paymentMqWriterService, SimulationService simulationService, SimulationMapper simulationMapper) {
        this.endpointConfiguration = endpointConfiguration;
        this.heartBeatClient = heartBeatClient;
        this.applyOverpaymentMapper = applyOverpaymentMapper;
        this.applyOverpaymentClient = applyOverpaymentClient;
        this.overpaymentsMqConfig = overpaymentsMqConfig;
        this.paymentMqWriterService = paymentMqWriterService;
        this.simulationService = simulationService;
        this.simulationMapper = simulationMapper;
    }

    public void applyInternalTransferOverpayment(MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext, String upr) {
        try {
            if (AnmfRegion.A.equals(heartBeatClient.fetchCurrentRegion())) {
                simulationService.createOverpaymentSimulationV2(mortgageSingleOverpaymentsContext);
                simulationService.updatePaymentMethodV2(mortgageSingleOverpaymentsContext);
                ApplyOverpaymentRequest applyOverpaymentRequest = applyOverpaymentMapper.generateApplyOverpaymentRequest(mortgageSingleOverpaymentsContext, upr);
                applyPaymentOnlineInANMF(applyOverpaymentRequest);
            } else {
                sendPaymentToPaymentRabbitMq(mortgageSingleOverpaymentsContext, upr);
            }
        } catch (Exception e) {
            log.warn("applyInternalTransferOverpayment - > exception caught:- {}", e.getMessage(), e);
            log.info("applyInternalTransferOverpayment failed to execute, will get picked up in the Matched UnMatched report");
        }
    }

    private void applyPaymentOnlineInANMF(ApplyOverpaymentRequest applyOverpaymentRequest) {
        try {
            applyOverpaymentClient.pay(endpointConfiguration.getAnmfApplyOverpaymentUrl(), applyOverpaymentRequest, overpaymentsMqConfig.getApplyPaymentEmergeUser());
        } catch (Exception e) {
            log.warn("applyPaymentOnlineInANMF - >  exception caught:- {}", e.getMessage(), e);
            log.info("applyPaymentOnlineInANMF failed to execute, will get picked up in the Matched UnMatched report");
        }
    }

    private void sendPaymentToPaymentRabbitMq(MortgageSingleOverpaymentsContext context, String upr) throws JsonProcessingException {
        log.debug("WRegion action: Payment request to be sent to MQ: {}", context);
        MqPaymentItem mqPaymentItem = createMqPaymentItem(context, upr);
        paymentMqWriterService.sendPaymentToMQ(mqPaymentItem);
    }

    private MqPaymentItem createMqPaymentItem(MortgageSingleOverpaymentsContext context, String upr) throws JsonProcessingException {
        PaymentsMqMessage paymentsMqMessage = generatePaymentsMqMessage(context, upr);

        var jsonMapper = new JsonMapper();
        String anmfPaymentsRequestJsonString = jsonMapper.writeValueAsString(paymentsMqMessage);
        log.debug("anmfPaymentsRequest: {}", anmfPaymentsRequestJsonString);

        MqPaymentItem mqPaymentItem = new MqPaymentItem(
                overpaymentsMqConfig.getPaymentsMqHost(), overpaymentsMqConfig.getPaymentsMqVirtualHost(),
                overpaymentsMqConfig.getPaymentsMqPort(), overpaymentsMqConfig.getPaymentsMqQueue(),
                overpaymentsMqConfig.getPaymentsMqUsername(), overpaymentsMqConfig.getPaymentsMqPassword(),
                anmfPaymentsRequestJsonString);
        log.debug("Full mq item to be sent to MQ: {}", mqPaymentItem);
        return mqPaymentItem;
    }

    private PaymentsMqMessage generatePaymentsMqMessage(MortgageSingleOverpaymentsContext context, String upr) {
        PaymentsMqMessage paymentsMqMessage = new PaymentsMqMessage();

        paymentsMqMessage.setAnmfSimulationRequest(simulationMapper.generateCreateSimulationRequest(context, 2));
        paymentsMqMessage.setAnmfUpdateSimulationRequest(simulationMapper.generateUpdatePaymentMethodSimulationRequest(context, 2));
        paymentsMqMessage.setApplyOverpaymentRequest(applyOverpaymentMapper.generateApplyOverpaymentRequest(context, upr));

        return paymentsMqMessage;
    }

}
