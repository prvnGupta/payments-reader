package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass;


import com.santander.common.instrumentation.logger.functional.dto.OperationInfo;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.gass.model.GASSMessageData;
import com.santanderuk.corinthian.services.payments.config.GASSConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

@Component
@Slf4j
public class GASSOperationInfoMapper {

    private final GASSConfig gassConfig;

    public GASSOperationInfoMapper(GASSConfig gassConfig) {
        this.gassConfig = gassConfig;
    }

    public OperationInfo assemble(GASSMessageData gassMessageData, boolean success) {

        OperationInfo info = new OperationInfo();

        info.setAudittrntpname(gassMessageData.getAuditTrnTpName());

        info.setAppsysid(gassMessageData.getAppSysId());
        info.setAudittrngrpid(gassConfig.getAuditTrnGrpId());
        info.setAuthcdusercompsysid(Integer.parseInt(gassConfig.getAuthCdUserCompSysId()));
        info.setInstgrusercompsysid(Integer.parseInt(gassConfig.getInstGrUserCompSysId()));
        info.setOrgid(Integer.parseInt(gassConfig.getOrgId()));
        info.setOrgutid(gassConfig.getOrgUtId());
        info.setDvcid(gassMessageData.getDeviceId());
        info.setDvctyp(gassMessageData.getDeviceTyp());
        info.setOrguttp(Integer.parseInt(gassConfig.getOrgUttp()));
        info.setKeyamt(gassMessageData.getAmount());
        info.setAuthcduserusrid(gassConfig.getAuthCdUser());
        info.setAudittrntpname(gassMessageData.getAuditTrnTpName());
        info.setAuddttm(new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault()).format(new Date()));
        info.setKeyhldgref(gassMessageData.getAnmfAccount());
        info.setTrncltref(gassMessageData.getAnmfAccount());
        info.setKeyuserid(gassMessageData.getUserId());
        info.setKeyaltuid(gassMessageData.getLdapUid());
        info.setInstgruserusrid(gassMessageData.getUserId());
        info.setFrmtddata(gassMessageData.getFormattedData());
        info.setOprtnsuctyp(success ? 1 : 2);

        logOperationInfo(info);

        return info;
    }

    private void logOperationInfo(OperationInfo info) {

        StringBuilder sbData = new StringBuilder(500);

        sbData.append("appsysid=").append(info.getAppsysid()).append(',');
        sbData.append("trngrpid=").append(info.getAudittrngrpid()).append(',');
        sbData.append("cdsysid=").append(info.getAuthcdusercompsysid()).append(',');
        sbData.append("grsysid=").append(info.getInstgrusercompsysid()).append(',');
        sbData.append("orgid=").append(info.getOrgid()).append(',');
        sbData.append("orgutid=").append(info.getOrgutid()).append(',');
        sbData.append("dvcid=").append(info.getDvcid()).append(',');
        sbData.append("dvctyp=").append(info.getDvctyp()).append(',');
        sbData.append("orguttp=").append(info.getOrguttp()).append(',');
        sbData.append("cduserid=").append(info.getAuthcduserusrid()).append(',');
        sbData.append("trntpname=").append(info.getAudittrntpname()).append(',');
        sbData.append("auddttm=").append(info.getAuddttm()).append(',');
        sbData.append("hldgref=").append(info.getKeyhldgref()).append(',');
        sbData.append("keyaltuid=").append(info.getKeyaltuid()).append(',');
        sbData.append("userid=").append(info.getKeyuserid()).append(',');
        sbData.append("gruserid=").append(info.getInstgruserusrid()).append(',');
        sbData.append("frmtddata=").append(info.getFrmtddata().getValue()).append(',');
        sbData.append("suctyp=").append(info.getOprtnsuctyp());

        log.debug("OperationInfo - {}", sbData);
    }

}
