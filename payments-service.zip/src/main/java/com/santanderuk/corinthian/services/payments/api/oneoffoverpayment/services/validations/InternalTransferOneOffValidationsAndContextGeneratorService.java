package com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.services.validations;


import com.santanderuk.corinthian.services.commons.anmfclient.AnmfCoreClient;
import com.santanderuk.corinthian.services.commons.anmfclient.io.accountdetails.AnmfAccountServiceResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.CustomerDetailsResponse;
import com.santanderuk.corinthian.services.commons.anmfclient.io.customerdetails.OCustomer;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.AnmfRegion;
import com.santanderuk.corinthian.services.commons.clients.heartbeat.HeartBeatClient;
import com.santanderuk.corinthian.services.commons.exceptions.GeneralException;
import com.santanderuk.corinthian.services.commons.internalaccounts.InternalAccountsValidator;
import com.santanderuk.corinthian.services.commons.internalaccounts.RetrieveInternalAccounts;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.RetrieveInternalAccountsServiceUrls;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractElement;
import com.santanderuk.corinthian.services.commons.internalaccounts.io.contractsinmccresponse.ContractsInMccControllerResponse;
import com.santanderuk.corinthian.services.commons.model.LocalAccountNumber;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.LacService;
import com.santanderuk.corinthian.services.payments.api.internaltransfer.services.lac.model.InternalTransferAccountsDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.card.model.input.LoanDetails;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentInternalTransferRequest;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.MortgageSingleOverpaymentsContext;
import com.santanderuk.corinthian.services.payments.api.oneoffoverpayment.internaltransfer.model.SimulationChosenValues;
import com.santanderuk.corinthian.services.payments.config.EndpointConfiguration;
import com.santanderuk.corinthian.services.payments.config.OverpaymentsConfig;
import com.santanderuk.corinthian.services.payments.gass.GassDataFetcher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import static com.santanderuk.corinthian.services.commons.utilities.JwtUtilities.getBdpCustomerFromJWT;
import static com.santanderuk.corinthian.services.commons.utilities.JwtUtilities.getLdapUidFromJWT;

@Service
@Slf4j
public class InternalTransferOneOffValidationsAndContextGeneratorService {
    private final AnmfCoreClient anmfCoreClient;
    private final OneOffCommonValidations oneOffCommonValidations;
    private final EndpointConfiguration endpointConfiguration;
    private final HeartBeatClient heartBeatClient;
    private final LacService lacService;
    private final OverpaymentsConfig overpaymentsConfig;
    private final RetrieveInternalAccounts retrieveInternalAccounts;
    private final InternalAccountsValidator internalAccountsValidator;
    private GassDataFetcher gassDataFetcher;
    @Autowired
    public InternalTransferOneOffValidationsAndContextGeneratorService(AnmfCoreClient anmfCoreClient, OneOffCommonValidations oneOffCommonValidations, EndpointConfiguration endpointConfiguration, HeartBeatClient heartBeatClient, LacService lacService, OverpaymentsConfig overpaymentsConfig, RetrieveInternalAccounts retrieveInternalAccounts,
                                                                       InternalAccountsValidator internalAccountsValidator, GassDataFetcher gassDataFetcher) {
        this.anmfCoreClient = anmfCoreClient;
        this.oneOffCommonValidations = oneOffCommonValidations;
        this.endpointConfiguration = endpointConfiguration;
        this.heartBeatClient = heartBeatClient;
        this.lacService = lacService;
        this.overpaymentsConfig = overpaymentsConfig;
        this.retrieveInternalAccounts = retrieveInternalAccounts;
        this.internalAccountsValidator = internalAccountsValidator;
        this.gassDataFetcher = gassDataFetcher;
    }

    public MortgageSingleOverpaymentsContext validateRequestAndGenerateContext(int mortgageAccount, MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest, String jwtToken, String ipAddress) throws GeneralException {

        oneOffCommonValidations.validateMinimumOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails());

        AnmfRegion anmfRegion = heartBeatClient.fetchCurrentRegion();

        CustomerDetailsResponse customerDetailsResponse = oneOffCommonValidations.validateMortgageBelongToCustomer(mortgageAccount, jwtToken, anmfRegion);

        AnmfAccountServiceResponse anmfAccountServiceResponse = anmfCoreClient.fetchMortgageAccountDetailsV5(mortgageAccount, endpointConfiguration.getAnmfAccountInfoUrl(), anmfRegion);

        oneOffCommonValidations.validateInputLoans(mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails(), anmfAccountServiceResponse);

        oneOffCommonValidations.validateMaximumAmountAllowed(getTotalOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest), anmfAccountServiceResponse);

        oneOffCommonValidations.validateNumberOfSingleOverpaymentsDoneToday(anmfAccountServiceResponse);

        String selectedPersonalAccountAlias = validatePersonalAccountBelongToCustomerAndHasBalance(mortgageSingleOverpaymentInternalTransferRequest, jwtToken);

        return generateSingleOverpaymentsContext(mortgageAccount, mortgageSingleOverpaymentInternalTransferRequest, jwtToken, ipAddress, anmfRegion, customerDetailsResponse, anmfAccountServiceResponse, selectedPersonalAccountAlias);
    }

    private MortgageSingleOverpaymentsContext generateSingleOverpaymentsContext(int mortgageAccount, MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest, String jwtToken, String ipAddress, AnmfRegion anmfRegion, CustomerDetailsResponse customerDetailsResponse, AnmfAccountServiceResponse anmfAccountServiceResponse, String selectedPersonalAccountAlias) throws GeneralException {
        MortgageSingleOverpaymentsContext mortgageSingleOverpaymentsContext = new MortgageSingleOverpaymentsContext();
        OCustomer loggedInCustomerDetails = getLoggedInCustomerDetails(customerDetailsResponse, jwtToken);
        mortgageSingleOverpaymentsContext.setAnmfRegion(anmfRegion);
        mortgageSingleOverpaymentsContext.setAnmfAccountServiceResponse(anmfAccountServiceResponse);
        mortgageSingleOverpaymentsContext.setCustomerDetailsResponse(customerDetailsResponse);
        mortgageSingleOverpaymentsContext.setLoggedCustomer(loggedInCustomerDetails);
        mortgageSingleOverpaymentsContext.setInternalTransferAccountsDetails(callLacService(mortgageAccount, mortgageSingleOverpaymentInternalTransferRequest, loggedInCustomerDetails.getOSurname()));
        mortgageSingleOverpaymentsContext.setIpAddress(ipAddress);
        mortgageSingleOverpaymentsContext.setMortgageAccount(mortgageAccount);
        mortgageSingleOverpaymentsContext.setSimulationChosenValues(setSimulationChosenValues(mortgageSingleOverpaymentInternalTransferRequest));
        mortgageSingleOverpaymentsContext.setLdapUid(getLdapUidFromJWT(jwtToken));
        mortgageSingleOverpaymentsContext.setAccountFromAlias(selectedPersonalAccountAlias);
        mortgageSingleOverpaymentsContext.setMccId(gassDataFetcher.fetchMccId(mortgageSingleOverpaymentsContext.getLdapUid()));
        return mortgageSingleOverpaymentsContext;
    }

    private String validatePersonalAccountBelongToCustomerAndHasBalance(MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest, String jwtToken) throws GeneralException {
        log.info("Validations: validateInternal AccountBelongToCustomerAndHasBalance for internal transfer one-off overpayment");
        ContractsInMccControllerResponse accounts = retrieveInternalAccounts.getAccounts(getLdapUidFromJWT(jwtToken), getBdpCustomerFromJWT(jwtToken), generateRetrieveContractsUrls());
        internalAccountsValidator.validateAccountBelongToCustomerAndHasBalanceExcludingOverdraft(getTotalOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest), mortgageSingleOverpaymentInternalTransferRequest.getOriginAccount(), endpointConfiguration.getAccountBalancesUrl(), accounts.getDataResponse().getDataList().getContractElement());
        return retrieveAccountAlias(accounts, mortgageSingleOverpaymentInternalTransferRequest.getOriginAccount());
    }

    private String retrieveAccountAlias(ContractsInMccControllerResponse accounts, LocalAccountNumber originAccount) {
        for (ContractElement account : accounts.getDataResponse().getDataList().getContractElement()) {
            if (isSameSortCode(account, originAccount) && isSameAccountNumber(account, originAccount)) {
                return account.getAlias();
            }
        }
        return "";
    }

    private boolean isSameAccountNumber(ContractElement account, LocalAccountNumber originAccount) {
        return originAccount.getAccountNumber().equalsIgnoreCase(account.getContractDetails().getLocalContract().getLocalContractNumber().substring(6));
    }

    private boolean isSameSortCode(ContractElement account, LocalAccountNumber originAccount) {
        return originAccount.getSortcode().equalsIgnoreCase(account.getContractDetails().getLocalContract().getLocalContractNumber().substring(0, 6));
    }

    private SimulationChosenValues setSimulationChosenValues(MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest) {
        SimulationChosenValues simulationChosenValues = new SimulationChosenValues();
        simulationChosenValues.setPaymentAmount(getTotalOverpaymentAmount(mortgageSingleOverpaymentInternalTransferRequest));
        simulationChosenValues.setLoanDetails(mortgageSingleOverpaymentInternalTransferRequest.getLoanDetails());
        simulationChosenValues.setErcCollectionOption(mortgageSingleOverpaymentInternalTransferRequest.getErcCollectionOption());
        return simulationChosenValues;

    }

    private BigDecimal getTotalOverpaymentAmount(MortgageSingleOverpaymentInternalTransferRequest request) {
        return request.getLoanDetails().stream().map(LoanDetails::getLoanOverpaymentAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    private OCustomer getLoggedInCustomerDetails(CustomerDetailsResponse customerDetailsResponse, String jwtToken) {
        int customerNumberFromJwt = getBdpCustomerFromJWT(jwtToken).getCustomerNumber();

        List<OCustomer> loggedInCustomerList = customerDetailsResponse.getCustomerServiceResponse().getOStruc().getOCustomerList().stream().filter(customerList -> customerList.getOCustomerId() == customerNumberFromJwt).collect(Collectors.toList());
        return loggedInCustomerList.get(0);
    }

    private InternalTransferAccountsDetails callLacService(int mortgageAccount, MortgageSingleOverpaymentInternalTransferRequest mortgageSingleOverpaymentInternalTransferRequest, String customerSurname) throws GeneralException {
        return lacService.getAccountsDetails(mortgageSingleOverpaymentInternalTransferRequest.getOriginAccount(), generateDestinationLocalAccount(mortgageAccount, customerSurname));
    }

    private LocalAccountNumber generateDestinationLocalAccount(int mortgageAccount, String customerSurname) {
        return new LocalAccountNumber(overpaymentsConfig.getBeneficiaryLocalAccountSortcode(), getAccountNumber(mortgageAccount, customerSurname));
    }

    private String getAccountNumber(int mortgageAccount, String customerSurname) {
        return overpaymentsConfig.getBeneficiaryLocalAccountNumber() + zeroLeftPaddedMortgageAccount(mortgageAccount) + StringUtils.substring(customerSurname, 0, 17);
    }

    private String zeroLeftPaddedMortgageAccount(int mortgageAccount) {
        return StringUtils.leftPad(String.valueOf(mortgageAccount), 9, '0');
    }
    private RetrieveInternalAccountsServiceUrls generateRetrieveContractsUrls() {
        RetrieveInternalAccountsServiceUrls urls = new RetrieveInternalAccountsServiceUrls();
        urls.setContractsInMccUrl(endpointConfiguration.getContractsInMcc());
        urls.setRetrieveMccUrl(endpointConfiguration.getRetrieveMccUrl());
        return urls;
    }


}
