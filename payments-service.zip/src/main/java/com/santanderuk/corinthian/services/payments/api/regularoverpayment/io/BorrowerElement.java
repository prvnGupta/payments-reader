package com.santanderuk.corinthian.services.payments.api.regularoverpayment.io;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class BorrowerElement {

    private String name;
    private String customerType;
    private String customerCode;

}
